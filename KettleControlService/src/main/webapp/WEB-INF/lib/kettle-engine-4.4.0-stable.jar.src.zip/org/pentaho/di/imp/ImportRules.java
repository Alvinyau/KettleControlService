/*     */ package org.pentaho.di.imp;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.plugins.ImportRulePluginType;
/*     */ import org.pentaho.di.core.plugins.PluginInterface;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*     */ import org.pentaho.di.imp.rules.BaseImportRule;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportRules
/*     */   implements Cloneable
/*     */ {
/*     */   public static final String XML_TAG = "rules";
/*     */   protected List<ImportRuleInterface> rules;
/*     */   
/*     */   public ImportRules()
/*     */   {
/*  46 */     this.rules = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImportRules clone()
/*     */   {
/*  56 */     ImportRules importRules = new ImportRules();
/*     */     
/*  58 */     for (ImportRuleInterface rule : this.rules) {
/*  59 */       importRules.getRules().add(rule.clone());
/*     */     }
/*     */     
/*  62 */     return importRules;
/*     */   }
/*     */   
/*     */   public List<ImportValidationFeedback> verifyRules(Object subject) {
/*  66 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*     */     
/*  68 */     for (ImportRuleInterface rule : this.rules) {
/*  69 */       feedback.addAll(rule.verifyRule(subject));
/*     */     }
/*     */     
/*  72 */     return feedback;
/*     */   }
/*     */   
/*     */   public void loadXML(Node rulesNode) throws KettleException
/*     */   {
/*  77 */     List<Node> ruleNodes = XMLHandler.getNodes(rulesNode, BaseImportRule.XML_TAG);
/*  78 */     for (Node ruleNode : ruleNodes) {
/*  79 */       String id = XMLHandler.getTagValue(ruleNode, "id");
/*     */       
/*  81 */       PluginRegistry registry = PluginRegistry.getInstance();
/*     */       
/*  83 */       PluginInterface plugin = registry.findPluginWithId(ImportRulePluginType.class, id);
/*  84 */       if (plugin == null) {
/*  85 */         throw new KettleException("The import rule of type '" + id + "' could not be found in the plugin registry.");
/*     */       }
/*  87 */       ImportRuleInterface rule = (ImportRuleInterface)registry.loadClass(plugin);
/*     */       
/*  89 */       rule.loadXML(ruleNode);
/*     */       
/*  91 */       getRules().add(rule);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getXML() {
/*  96 */     StringBuilder xml = new StringBuilder();
/*     */     
/*  98 */     xml.append(XMLHandler.openTag("rules")).append(Const.CR).append(Const.CR);
/*     */     
/* 100 */     for (ImportRuleInterface rule : getRules())
/*     */     {
/* 102 */       PluginInterface plugin = PluginRegistry.getInstance().getPlugin(ImportRulePluginType.class, rule.getId());
/* 103 */       xml.append("<!-- ").append(plugin.getName()).append(" : ").append(plugin.getDescription()).append(Const.CR).append(" -->").append(Const.CR);
/*     */       
/* 105 */       xml.append(rule.getXML());
/* 106 */       xml.append(Const.CR).append(Const.CR);
/*     */     }
/*     */     
/* 109 */     xml.append(XMLHandler.closeTag("rules"));
/*     */     
/* 111 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public List<ImportRuleInterface> getRules() {
/* 115 */     return this.rules;
/*     */   }
/*     */   
/*     */   public void setRules(List<ImportRuleInterface> rules) {
/* 119 */     this.rules = rules;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\ImportRules.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */