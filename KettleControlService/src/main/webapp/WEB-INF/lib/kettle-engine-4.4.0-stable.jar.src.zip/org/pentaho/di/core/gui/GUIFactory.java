/*    */ package org.pentaho.di.core.gui;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GUIFactory
/*    */ {
/*    */   private static SpoonInterface spoonInstance;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 28 */   private static ThreadDialogs threadDialogs = new RuntimeThreadDialogs();
/*    */   
/*    */   public static SpoonInterface getInstance() {
/* 31 */     return spoonInstance;
/*    */   }
/*    */   
/*    */   public static void setSpoonInstance(SpoonInterface anInstance) {
/* 35 */     spoonInstance = anInstance;
/*    */   }
/*    */   
/*    */   public static ThreadDialogs getThreadDialogs() {
/* 39 */     return threadDialogs;
/*    */   }
/*    */   
/*    */   public static void setThreadDialogs(ThreadDialogs threadDialogs) {
/* 43 */     threadDialogs = threadDialogs;
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\GUIFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */