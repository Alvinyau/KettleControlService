/*     */ package org.pentaho.di.core.plugins;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.annotations.RepositoryPlugin;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannel;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.repository.RepositoryMeta;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PluginMainClassType(Repository.class)
/*     */ @PluginExtraClassTypes(classTypes={RepositoryMeta.class}, xmlNodeNames={"meta-classname"})
/*     */ @PluginAnnotationType(RepositoryPlugin.class)
/*     */ public class RepositoryPluginType
/*     */   extends BasePluginType
/*     */   implements PluginTypeInterface
/*     */ {
/*     */   private static RepositoryPluginType pluginType;
/*     */   
/*     */   private RepositoryPluginType()
/*     */   {
/*  59 */     super(RepositoryPlugin.class, "REPOSITORY_TYPE", "Repository type");
/*  60 */     populateFolders("repositories");
/*     */   }
/*     */   
/*     */   public static RepositoryPluginType getInstance() {
/*  64 */     if (pluginType == null) {
/*  65 */       pluginType = new RepositoryPluginType();
/*     */     }
/*  67 */     return pluginType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerNatives()
/*     */     throws KettlePluginException
/*     */   {
/*  77 */     String xmlFile = "kettle-repositories.xml";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  82 */       InputStream inputStream = getClass().getResourceAsStream(xmlFile);
/*  83 */       if (inputStream == null) {
/*  84 */         inputStream = getClass().getResourceAsStream("/" + xmlFile);
/*     */       }
/*  86 */       if (inputStream == null) {
/*  87 */         throw new KettlePluginException("Unable to find native repository type definition file: " + xmlFile);
/*     */       }
/*  89 */       Document document = XMLHandler.loadXMLFile(inputStream, null, true, false);
/*     */       
/*     */ 
/*     */ 
/*  93 */       Node repsNode = XMLHandler.getSubNode(document, "repositories");
/*  94 */       List<Node> repsNodes = XMLHandler.getNodes(repsNode, "repository");
/*  95 */       for (Node repNode : repsNodes) {
/*  96 */         registerPluginFromXmlResource(repNode, null, getClass(), true, null);
/*     */       }
/*     */     } catch (KettleXMLException e) {
/*  99 */       throw new KettlePluginException("Unable to read the kettle repositories XML config file: " + xmlFile, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerXmlPlugins()
/*     */     throws KettlePluginException
/*     */   {
/* 106 */     for (PluginFolderInterface folder : this.pluginFolders)
/*     */     {
/* 108 */       if (folder.isPluginXmlFolder()) {
/* 109 */         List<FileObject> pluginXmlFiles = findPluginXmlFiles(folder.getFolder());
/* 110 */         for (FileObject file : pluginXmlFiles) {
/*     */           try
/*     */           {
/* 113 */             Document document = XMLHandler.loadXMLFile(file);
/* 114 */             Node pluginNode = XMLHandler.getSubNode(document, "plugin");
/*     */             
/* 116 */             registerPluginFromXmlResource(pluginNode, KettleVFS.getFilename(file.getParent()), getClass(), false, file.getParent().getURL());
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 120 */             this.log.logError("Error found while reading repository plugin.xml file: " + file.getName().toString(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String extractCategory(Annotation annotation)
/*     */   {
/* 129 */     return "";
/*     */   }
/*     */   
/*     */   protected String extractDesc(Annotation annotation)
/*     */   {
/* 134 */     return ((RepositoryPlugin)annotation).description();
/*     */   }
/*     */   
/*     */   protected String extractID(Annotation annotation)
/*     */   {
/* 139 */     return ((RepositoryPlugin)annotation).id();
/*     */   }
/*     */   
/*     */   protected String extractName(Annotation annotation)
/*     */   {
/* 144 */     return ((RepositoryPlugin)annotation).name();
/*     */   }
/*     */   
/*     */   protected String extractImageFile(Annotation annotation)
/*     */   {
/* 149 */     return null;
/*     */   }
/*     */   
/*     */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*     */   {
/* 154 */     return false;
/*     */   }
/*     */   
/*     */   protected String extractI18nPackageName(Annotation annotation)
/*     */   {
/* 159 */     return ((RepositoryPlugin)annotation).i18nPackageName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation)
/*     */   {
/* 169 */     RepositoryPlugin repositoryPlugin = (RepositoryPlugin)annotation;
/*     */     
/* 171 */     classMap.put(RepositoryMeta.class, repositoryPlugin.metaClass());
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\RepositoryPluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */