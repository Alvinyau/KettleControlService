/*      */ package org.pentaho.di.job.entries.pgpdecryptfiles;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.vfs.AllFileSelector;
/*      */ import org.apache.commons.vfs.FileName;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.apache.commons.vfs.FileSelectInfo;
/*      */ import org.apache.commons.vfs.FileType;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.RowMetaAndData;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entries.pgpencryptfiles.GPG;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryPGPDecryptFiles
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   77 */   private static Class<?> PKG = JobEntryPGPDecryptFiles.class;
/*      */   
/*      */   private SimpleDateFormat daf;
/*      */   
/*      */   private GPG gpg;
/*      */   
/*      */   public boolean arg_from_previous;
/*      */   
/*      */   public boolean include_subfolders;
/*      */   public boolean add_result_filesname;
/*      */   public boolean destination_is_a_file;
/*      */   public boolean create_destination_folder;
/*      */   public String[] source_filefolder;
/*      */   public String[] passphrase;
/*      */   public String[] destination_filefolder;
/*      */   public String[] wildcard;
/*      */   private String nr_errors_less_than;
/*      */   private String success_condition;
/*   95 */   public String SUCCESS_IF_AT_LEAST_X_FILES_UN_ZIPPED = "success_when_at_least";
/*   96 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*   97 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*      */   
/*      */   private boolean add_date;
/*      */   
/*      */   private boolean add_time;
/*      */   private boolean SpecifyFormat;
/*      */   private String date_time_format;
/*      */   private boolean AddDateBeforeExtension;
/*      */   private boolean DoNotKeepFolderStructure;
/*      */   private String iffileexists;
/*      */   private String destinationFolder;
/*      */   private String ifmovedfileexists;
/*      */   private String moved_date_time_format;
/*      */   private boolean AddMovedDateBeforeExtension;
/*      */   private boolean add_moved_date;
/*      */   private boolean add_moved_time;
/*      */   private boolean SpecifyMoveFormat;
/*      */   public boolean create_move_to_folder;
/*      */   private String gpglocation;
/*  116 */   private int NrErrors = 0;
/*  117 */   private int NrSuccess = 0;
/*  118 */   private boolean successConditionBroken = false;
/*  119 */   private boolean successConditionBrokenExit = false;
/*  120 */   private int limitFiles = 0;
/*      */   
/*      */   public JobEntryPGPDecryptFiles(String n)
/*      */   {
/*  124 */     super(n, "");
/*  125 */     this.create_move_to_folder = false;
/*  126 */     this.SpecifyMoveFormat = false;
/*  127 */     this.add_moved_date = false;
/*  128 */     this.add_moved_time = false;
/*  129 */     this.AddMovedDateBeforeExtension = false;
/*  130 */     this.moved_date_time_format = null;
/*  131 */     this.gpglocation = null;
/*  132 */     this.ifmovedfileexists = "do_nothing";
/*  133 */     this.destinationFolder = null;
/*  134 */     this.DoNotKeepFolderStructure = false;
/*  135 */     this.arg_from_previous = false;
/*  136 */     this.source_filefolder = null;
/*  137 */     this.passphrase = null;
/*  138 */     this.destination_filefolder = null;
/*  139 */     this.wildcard = null;
/*  140 */     this.include_subfolders = false;
/*  141 */     this.add_result_filesname = false;
/*  142 */     this.destination_is_a_file = false;
/*  143 */     this.create_destination_folder = false;
/*  144 */     this.nr_errors_less_than = "10";
/*  145 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/*  146 */     this.add_date = false;
/*  147 */     this.add_time = false;
/*  148 */     this.SpecifyFormat = false;
/*  149 */     this.date_time_format = null;
/*  150 */     this.AddDateBeforeExtension = false;
/*  151 */     this.iffileexists = "do_nothing";
/*  152 */     setID(-1L);
/*      */   }
/*      */   
/*      */   public JobEntryPGPDecryptFiles()
/*      */   {
/*  157 */     this("");
/*      */   }
/*      */   
/*      */ 
/*      */   public Object clone()
/*      */   {
/*  163 */     JobEntryPGPDecryptFiles je = (JobEntryPGPDecryptFiles)super.clone();
/*  164 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  169 */     StringBuffer retval = new StringBuffer(300);
/*      */     
/*  171 */     retval.append(super.getXML());
/*  172 */     retval.append("      ").append(XMLHandler.addTagValue("gpglocation", this.gpglocation));
/*  173 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.arg_from_previous));
/*  174 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.include_subfolders));
/*  175 */     retval.append("      ").append(XMLHandler.addTagValue("add_result_filesname", this.add_result_filesname));
/*  176 */     retval.append("      ").append(XMLHandler.addTagValue("destination_is_a_file", this.destination_is_a_file));
/*  177 */     retval.append("      ").append(XMLHandler.addTagValue("create_destination_folder", this.create_destination_folder));
/*  178 */     retval.append("      ").append(XMLHandler.addTagValue("add_date", this.add_date));
/*  179 */     retval.append("      ").append(XMLHandler.addTagValue("add_time", this.add_time));
/*  180 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyFormat", this.SpecifyFormat));
/*  181 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_format", this.date_time_format));
/*  182 */     retval.append("      ").append(XMLHandler.addTagValue("nr_errors_less_than", this.nr_errors_less_than));
/*  183 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*  184 */     retval.append("      ").append(XMLHandler.addTagValue("AddDateBeforeExtension", this.AddDateBeforeExtension));
/*  185 */     retval.append("      ").append(XMLHandler.addTagValue("DoNotKeepFolderStructure", this.DoNotKeepFolderStructure));
/*  186 */     retval.append("      ").append(XMLHandler.addTagValue("iffileexists", this.iffileexists));
/*  187 */     retval.append("      ").append(XMLHandler.addTagValue("destinationFolder", this.destinationFolder));
/*  188 */     retval.append("      ").append(XMLHandler.addTagValue("ifmovedfileexists", this.ifmovedfileexists));
/*  189 */     retval.append("      ").append(XMLHandler.addTagValue("moved_date_time_format", this.moved_date_time_format));
/*  190 */     retval.append("      ").append(XMLHandler.addTagValue("create_move_to_folder", this.create_move_to_folder));
/*  191 */     retval.append("      ").append(XMLHandler.addTagValue("add_moved_date", this.add_moved_date));
/*  192 */     retval.append("      ").append(XMLHandler.addTagValue("add_moved_time", this.add_moved_time));
/*  193 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyMoveFormat", this.SpecifyMoveFormat));
/*  194 */     retval.append("      ").append(XMLHandler.addTagValue("AddMovedDateBeforeExtension", this.AddMovedDateBeforeExtension));
/*      */     
/*  196 */     retval.append("      <fields>").append(Const.CR);
/*  197 */     if (this.source_filefolder != null)
/*      */     {
/*  199 */       for (int i = 0; i < this.source_filefolder.length; i++)
/*      */       {
/*  201 */         retval.append("        <field>").append(Const.CR);
/*  202 */         retval.append("          ").append(XMLHandler.addTagValue("source_filefolder", this.source_filefolder[i]));
/*  203 */         retval.append("          ").append(XMLHandler.addTagValue("passphrase", Encr.encryptPasswordIfNotUsingVariables(this.passphrase[i])));
/*  204 */         retval.append("          ").append(XMLHandler.addTagValue("destination_filefolder", this.destination_filefolder[i]));
/*  205 */         retval.append("          ").append(XMLHandler.addTagValue("wildcard", this.wildcard[i]));
/*  206 */         retval.append("        </field>").append(Const.CR);
/*      */       }
/*      */     }
/*  209 */     retval.append("      </fields>").append(Const.CR);
/*      */     
/*  211 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*      */     throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  219 */       super.loadXML(entrynode, databases, slaveServers);
/*  220 */       this.gpglocation = XMLHandler.getTagValue(entrynode, "gpglocation");
/*  221 */       this.arg_from_previous = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/*  222 */       this.include_subfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/*  223 */       this.add_result_filesname = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_result_filesname"));
/*  224 */       this.destination_is_a_file = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "destination_is_a_file"));
/*  225 */       this.create_destination_folder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "create_destination_folder"));
/*  226 */       this.add_date = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_date"));
/*  227 */       this.add_time = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_time"));
/*  228 */       this.SpecifyFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyFormat"));
/*  229 */       this.AddDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddDateBeforeExtension"));
/*  230 */       this.DoNotKeepFolderStructure = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "DoNotKeepFolderStructure"));
/*  231 */       this.date_time_format = XMLHandler.getTagValue(entrynode, "date_time_format");
/*  232 */       this.nr_errors_less_than = XMLHandler.getTagValue(entrynode, "nr_errors_less_than");
/*  233 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/*  234 */       this.iffileexists = XMLHandler.getTagValue(entrynode, "iffileexists");
/*  235 */       this.destinationFolder = XMLHandler.getTagValue(entrynode, "destinationFolder");
/*  236 */       this.ifmovedfileexists = XMLHandler.getTagValue(entrynode, "ifmovedfileexists");
/*  237 */       this.moved_date_time_format = XMLHandler.getTagValue(entrynode, "moved_date_time_format");
/*  238 */       this.AddMovedDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddMovedDateBeforeExtension"));
/*  239 */       this.create_move_to_folder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "create_move_to_folder"));
/*  240 */       this.add_moved_date = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_moved_date"));
/*  241 */       this.add_moved_time = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_moved_time"));
/*  242 */       this.SpecifyMoveFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyMoveFormat"));
/*      */       
/*      */ 
/*  245 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*      */       
/*      */ 
/*  248 */       int nrFields = XMLHandler.countNodes(fields, "field");
/*  249 */       this.source_filefolder = new String[nrFields];
/*  250 */       this.passphrase = new String[nrFields];
/*  251 */       this.destination_filefolder = new String[nrFields];
/*  252 */       this.wildcard = new String[nrFields];
/*      */       
/*      */ 
/*  255 */       for (int i = 0; i < nrFields; i++)
/*      */       {
/*  257 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*      */         
/*  259 */         this.source_filefolder[i] = XMLHandler.getTagValue(fnode, "source_filefolder");
/*  260 */         this.passphrase[i] = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(fnode, "passphrase"));
/*  261 */         this.destination_filefolder[i] = XMLHandler.getTagValue(fnode, "destination_filefolder");
/*  262 */         this.wildcard[i] = XMLHandler.getTagValue(fnode, "wildcard");
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (KettleXMLException xe)
/*      */     {
/*  269 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.Exception.UnableLoadXML", new String[0]), xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  278 */       this.gpglocation = rep.getJobEntryAttributeString(id_jobentry, "gpglocation");
/*  279 */       this.arg_from_previous = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/*  280 */       this.include_subfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*  281 */       this.add_result_filesname = rep.getJobEntryAttributeBoolean(id_jobentry, "add_result_filesname");
/*  282 */       this.destination_is_a_file = rep.getJobEntryAttributeBoolean(id_jobentry, "destination_is_a_file");
/*  283 */       this.create_destination_folder = rep.getJobEntryAttributeBoolean(id_jobentry, "create_destination_folder");
/*  284 */       this.nr_errors_less_than = rep.getJobEntryAttributeString(id_jobentry, "nr_errors_less_than");
/*  285 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/*  286 */       this.add_date = rep.getJobEntryAttributeBoolean(id_jobentry, "add_date");
/*  287 */       this.add_time = rep.getJobEntryAttributeBoolean(id_jobentry, "add_time");
/*  288 */       this.SpecifyFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyFormat");
/*  289 */       this.date_time_format = rep.getJobEntryAttributeString(id_jobentry, "date_time_format");
/*  290 */       this.AddDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddDateBeforeExtension");
/*  291 */       this.DoNotKeepFolderStructure = rep.getJobEntryAttributeBoolean(id_jobentry, "DoNotKeepFolderStructure");
/*  292 */       this.iffileexists = rep.getJobEntryAttributeString(id_jobentry, "iffileexists");
/*  293 */       this.destinationFolder = rep.getJobEntryAttributeString(id_jobentry, "destinationFolder");
/*  294 */       this.ifmovedfileexists = rep.getJobEntryAttributeString(id_jobentry, "ifmovedfileexists");
/*  295 */       this.moved_date_time_format = rep.getJobEntryAttributeString(id_jobentry, "moved_date_time_format");
/*  296 */       this.AddMovedDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddMovedDateBeforeExtension");
/*  297 */       this.create_move_to_folder = rep.getJobEntryAttributeBoolean(id_jobentry, "create_move_to_folder");
/*  298 */       this.add_moved_date = rep.getJobEntryAttributeBoolean(id_jobentry, "add_moved_date");
/*  299 */       this.add_moved_time = rep.getJobEntryAttributeBoolean(id_jobentry, "add_moved_time");
/*  300 */       this.SpecifyMoveFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyMoveFormat");
/*      */       
/*      */ 
/*  303 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "source_filefolder");
/*  304 */       this.source_filefolder = new String[argnr];
/*  305 */       this.passphrase = new String[argnr];
/*  306 */       this.destination_filefolder = new String[argnr];
/*  307 */       this.wildcard = new String[argnr];
/*      */       
/*      */ 
/*  310 */       for (int a = 0; a < argnr; a++)
/*      */       {
/*  312 */         this.source_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_filefolder");
/*  313 */         this.passphrase[a] = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, a, "passphrase"));
/*  314 */         this.destination_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "destination_filefolder");
/*  315 */         this.wildcard[a] = rep.getJobEntryAttributeString(id_jobentry, a, "wildcard");
/*      */       }
/*      */       
/*      */     }
/*      */     catch (KettleException dbe)
/*      */     {
/*  321 */       throw new KettleException(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.Exception.UnableLoadRep", new String[0]) + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  329 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "gpglocation", this.gpglocation);
/*  330 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.arg_from_previous);
/*  331 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.include_subfolders);
/*  332 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_result_filesname", this.add_result_filesname);
/*  333 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destination_is_a_file", this.destination_is_a_file);
/*  334 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "create_destination_folder", this.create_destination_folder);
/*  335 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_errors_less_than", this.nr_errors_less_than);
/*  336 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*  337 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_date", this.add_date);
/*  338 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_time", this.add_time);
/*  339 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyFormat", this.SpecifyFormat);
/*  340 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_format", this.date_time_format);
/*  341 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddDateBeforeExtension", this.AddDateBeforeExtension);
/*  342 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "DoNotKeepFolderStructure", this.DoNotKeepFolderStructure);
/*  343 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "iffileexists", this.iffileexists);
/*  344 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destinationFolder", this.destinationFolder);
/*  345 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ifmovedfileexists", this.ifmovedfileexists);
/*  346 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "moved_date_time_format", this.moved_date_time_format);
/*  347 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_moved_date", this.add_moved_date);
/*  348 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_moved_time", this.add_moved_time);
/*  349 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyMoveFormat", this.SpecifyMoveFormat);
/*  350 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "create_move_to_folder", this.create_move_to_folder);
/*  351 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddMovedDateBeforeExtension", this.AddMovedDateBeforeExtension);
/*      */       
/*      */ 
/*  354 */       if (this.source_filefolder != null)
/*      */       {
/*  356 */         for (int i = 0; i < this.source_filefolder.length; i++)
/*      */         {
/*  358 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_filefolder", this.source_filefolder[i]);
/*  359 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "passphrase", Encr.encryptPasswordIfNotUsingVariables(this.passphrase[i]));
/*  360 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "destination_filefolder", this.destination_filefolder[i]);
/*  361 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "wildcard", this.wildcard[i]);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  368 */       throw new KettleException(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.Exception.UnableSaveRep", new String[0]) + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public Result execute(Result previousResult, int nr) throws KettleException {
/*      */     try {
/*  374 */       Result result = previousResult;
/*  375 */       List<RowMetaAndData> rows = result.getRows();
/*  376 */       RowMetaAndData resultRow = null;
/*  377 */       result.setNrErrors(1L);
/*  378 */       result.setResult(false);
/*      */       
/*  380 */       this.NrErrors = 0;
/*  381 */       this.NrSuccess = 0;
/*  382 */       this.successConditionBroken = false;
/*  383 */       this.successConditionBrokenExit = false;
/*  384 */       this.limitFiles = Const.toInt(environmentSubstitute(getNrErrorsLessThan()), 10);
/*      */       
/*  386 */       if ((this.include_subfolders) && 
/*  387 */         (isDetailed())) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.IncludeSubFoldersOn", new String[0]));
/*      */       }
/*      */       
/*  390 */       String MoveToFolder = environmentSubstitute(this.destinationFolder);
/*      */       
/*  392 */       String[] vsourcefilefolder = this.source_filefolder;
/*  393 */       String[] vpassphrase = this.passphrase;
/*  394 */       String[] vdestinationfilefolder = this.destination_filefolder;
/*  395 */       String[] vwildcard = this.wildcard;
/*      */       
/*  397 */       if (this.iffileexists.equals("move_file")) {
/*  398 */         if (Const.isEmpty(MoveToFolder)) {
/*  399 */           logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Error.MoveToFolderMissing", new String[0]));
/*  400 */           return result;
/*      */         }
/*  402 */         FileObject folder = null;
/*      */         try {
/*  404 */           folder = KettleVFS.getFileObject(MoveToFolder);
/*  405 */           Result localResult3; if (!folder.exists()) {
/*  406 */             if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Error.FolderMissing", new String[] { MoveToFolder }));
/*  407 */             if (this.create_move_to_folder) {
/*  408 */               folder.createFolder();
/*      */             } else {
/*  410 */               logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Error.FolderMissing", new String[] { MoveToFolder }));
/*  411 */               return result;
/*      */             }
/*      */           }
/*  414 */           if (!folder.getType().equals(FileType.FOLDER)) {
/*  415 */             logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Error.NotFolder", new String[] { MoveToFolder }));
/*  416 */             return result;
/*      */           }
/*      */         } catch (Exception e) {
/*  419 */           logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Error.GettingMoveToFolder", new String[] { MoveToFolder, ((Exception)e).getMessage() }));
/*  420 */           return result;
/*      */         } finally {
/*  422 */           if (folder != null) {
/*      */             try {
/*  424 */               folder.close();
/*      */             }
/*      */             catch (IOException ex) {}
/*      */           }
/*      */         }
/*      */       }
/*  430 */       this.gpg = new GPG(environmentSubstitute(this.gpglocation), this.log);
/*      */       
/*  432 */       if ((this.arg_from_previous) && 
/*  433 */         (isDetailed()))
/*  434 */         logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.ArgFromPrevious.Found", new String[] { (rows != null ? rows.size() : 0) + "" }));
/*      */       Object vsourcefilefolder_previous;
/*  436 */       int i; if ((this.arg_from_previous) && (rows != null)) {
/*  437 */         for (int iteration = 0; iteration < rows.size(); iteration++)
/*      */         {
/*  439 */           if (this.successConditionBroken) {
/*  440 */             if (!this.successConditionBrokenExit) {
/*  441 */               logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*  442 */               this.successConditionBrokenExit = true;
/*      */             }
/*  444 */             result.setNrErrors(this.NrErrors);
/*  445 */             displayResults();
/*  446 */             return result;
/*      */           }
/*      */           
/*  449 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*      */           
/*      */ 
/*  452 */           vsourcefilefolder_previous = resultRow.getString(0, null);
/*  453 */           String vwildcard_previous = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(resultRow.getString(1, null)));
/*  454 */           String vpassphrase_previous = resultRow.getString(2, null);
/*  455 */           String vdestinationfilefolder_previous = resultRow.getString(3, null);
/*      */           
/*      */ 
/*  458 */           if ((!Const.isEmpty((String)vsourcefilefolder_previous)) && (!Const.isEmpty(vdestinationfilefolder_previous))) {
/*  459 */             if (isDetailed()) {
/*  460 */               logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.ProcessingRow", new String[] { vsourcefilefolder_previous, vdestinationfilefolder_previous, vwildcard_previous }));
/*      */             }
/*  462 */             if (!ProcessFileFolder((String)vsourcefilefolder_previous, vpassphrase_previous, vdestinationfilefolder_previous, vwildcard_previous, this.parentJob, result, MoveToFolder))
/*      */             {
/*      */ 
/*      */ 
/*  466 */               updateErrors();
/*      */             }
/*      */             
/*      */           }
/*  470 */           else if (isDetailed()) {
/*  471 */             logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.IgnoringRow", new String[] { vsourcefilefolder[iteration], vdestinationfilefolder[iteration], vwildcard[iteration] }));
/*      */           }
/*      */           
/*      */         }
/*  475 */       } else if ((vsourcefilefolder != null) && (vdestinationfilefolder != null)) {
/*  476 */         for (i = 0; (i < vsourcefilefolder.length) && (!this.parentJob.isStopped()); i++)
/*      */         {
/*  478 */           if (this.successConditionBroken) {
/*  479 */             if (!this.successConditionBrokenExit) {
/*  480 */               logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*  481 */               this.successConditionBrokenExit = true;
/*      */             }
/*  483 */             result.setNrErrors(this.NrErrors);
/*  484 */             displayResults();
/*  485 */             return result;
/*      */           }
/*      */           
/*      */ 
/*  489 */           if ((!Const.isEmpty(vsourcefilefolder[i])) && (!Const.isEmpty(vdestinationfilefolder[i])))
/*      */           {
/*  491 */             if (isDetailed()) {
/*  492 */               logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.ProcessingRow", new String[] { vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i] }));
/*      */             }
/*  494 */             if (!ProcessFileFolder(vsourcefilefolder[i], Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(vpassphrase[i])), vdestinationfilefolder[i], vwildcard[i], this.parentJob, result, MoveToFolder))
/*      */             {
/*  496 */               updateErrors();
/*      */             }
/*      */             
/*      */           }
/*  500 */           else if (isDetailed()) {
/*  501 */             logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.IgnoringRow", new String[] { vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i] }));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  507 */       result.setNrErrors(this.NrErrors);
/*  508 */       result.setNrLinesWritten(this.NrSuccess);
/*  509 */       if (getSuccessStatus()) { result.setResult(true);
/*      */       }
/*  511 */       displayResults();
/*      */       
/*  513 */       return result;
/*      */     } finally {
/*  515 */       if (this.source_filefolder != null) this.source_filefolder = null;
/*  516 */       if (this.destination_filefolder != null) this.destination_filefolder = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private void displayResults() {
/*  521 */     if (isDetailed()) {
/*  522 */       logDetailed("=======================================");
/*  523 */       logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Info.FilesInError", new String[] { "" + this.NrErrors }));
/*  524 */       logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Info.FilesInSuccess", new String[] { "" + this.NrSuccess }));
/*  525 */       logDetailed("=======================================");
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean getSuccessStatus() {
/*  530 */     boolean retval = false;
/*      */     
/*  532 */     if (((this.NrErrors == 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrSuccess >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FILES_UN_ZIPPED))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*  535 */       retval = true;
/*      */     }
/*      */     
/*  538 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean ProcessFileFolder(String sourcefilefoldername, String passPhrase, String destinationfilefoldername, String wildcard, Job parentJob, Result result, String MoveToFolder)
/*      */   {
/*  545 */     boolean entrystatus = false;
/*  546 */     FileObject sourcefilefolder = null;
/*  547 */     FileObject destinationfilefolder = null;
/*  548 */     FileObject movetofolderfolder = null;
/*  549 */     FileObject Currentfile = null;
/*      */     
/*      */ 
/*  552 */     String realSourceFilefoldername = environmentSubstitute(sourcefilefoldername);
/*  553 */     String realDestinationFilefoldername = environmentSubstitute(destinationfilefoldername);
/*  554 */     String realWildcard = environmentSubstitute(wildcard);
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  559 */       sourcefilefolder = KettleVFS.getFileObject(realSourceFilefoldername);
/*  560 */       destinationfilefolder = KettleVFS.getFileObject(realDestinationFilefoldername);
/*  561 */       if (!Const.isEmpty(MoveToFolder)) { movetofolderfolder = KettleVFS.getFileObject(MoveToFolder);
/*      */       }
/*  563 */       if (sourcefilefolder.exists())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  568 */         if (CreateDestinationFolder(destinationfilefolder))
/*      */         {
/*      */ 
/*  571 */           if ((sourcefilefolder.getType().equals(FileType.FOLDER)) && (this.destination_is_a_file))
/*      */           {
/*      */ 
/*      */ 
/*  575 */             logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Forbidden", new String[0]), new Object[] { BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.CanNotMoveFolderToFile", new String[] { realSourceFilefoldername, realDestinationFilefoldername }) });
/*      */             
/*      */ 
/*  578 */             updateErrors();
/*      */ 
/*      */           }
/*  581 */           else if ((destinationfilefolder.getType().equals(FileType.FOLDER)) && (sourcefilefolder.getType().equals(FileType.FILE)))
/*      */           {
/*      */ 
/*      */ 
/*  585 */             String shortfilename = sourcefilefolder.getName().getBaseName();
/*      */             try
/*      */             {
/*  588 */               shortfilename = getDestinationFilename(sourcefilefolder.getName().getBaseName());
/*      */             } catch (Exception e) {
/*  590 */               logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.GettingFilename", new String[] { sourcefilefolder.getName().getBaseName(), e.toString() }));
/*  591 */               return entrystatus;
/*      */             }
/*      */             
/*      */ 
/*  595 */             String destinationfilenamefull = destinationfilefolder.toString() + Const.FILE_SEPARATOR + shortfilename;
/*  596 */             FileObject destinationfile = KettleVFS.getFileObject(destinationfilenamefull);
/*      */             
/*  598 */             entrystatus = DecryptFile(shortfilename, sourcefilefolder, passPhrase, destinationfile, movetofolderfolder, parentJob, result);
/*      */           } else { String destinationfilenamefull;
/*  600 */             if ((sourcefilefolder.getType().equals(FileType.FILE)) && (this.destination_is_a_file))
/*      */             {
/*      */ 
/*      */ 
/*  604 */               FileObject destinationfile = KettleVFS.getFileObject(realDestinationFilefoldername);
/*      */               
/*      */ 
/*  607 */               String shortfilename = destinationfile.getName().getBaseName();
/*      */               try {
/*  609 */                 shortfilename = getDestinationFilename(destinationfile.getName().getBaseName());
/*      */               }
/*      */               catch (Exception e) {
/*  612 */                 logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.GettingFilename", new String[] { sourcefilefolder.getName().getBaseName(), e.toString() }));
/*  613 */                 return entrystatus;
/*      */               }
/*      */               
/*  616 */               destinationfilenamefull = destinationfilefolder.getParent().toString() + Const.FILE_SEPARATOR + shortfilename;
/*  617 */               destinationfile = KettleVFS.getFileObject(destinationfilenamefull);
/*      */               
/*  619 */               entrystatus = DecryptFile(shortfilename, sourcefilefolder, passPhrase, destinationfile, movetofolderfolder, parentJob, result);
/*      */             }
/*      */             else
/*      */             {
/*  623 */               if (isDetailed()) {
/*  624 */                 logDetailed("  ");
/*  625 */                 logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FetchFolder", new String[] { sourcefilefolder.toString() }));
/*      */               }
/*      */               
/*  628 */               FileObject[] fileObjects = sourcefilefolder.findFiles(new AllFileSelector()
/*      */               {
/*      */                 public boolean traverseDescendents(FileSelectInfo info)
/*      */                 {
/*  632 */                   return (info.getDepth() == 0) || (JobEntryPGPDecryptFiles.this.include_subfolders);
/*      */                 }
/*      */                 
/*      */                 public boolean includeFile(FileSelectInfo info) {
/*  636 */                   FileObject fileObject = info.getFile();
/*      */                   try {
/*  638 */                     if (fileObject == null) return false;
/*      */                   }
/*      */                   catch (Exception ex)
/*      */                   {
/*  642 */                     return false;
/*      */                   }
/*      */                   finally
/*      */                   {
/*  646 */                     if (fileObject != null)
/*  647 */                       try { fileObject.close();fileObject = null;
/*      */                       } catch (IOException ex) {}
/*      */                   }
/*  650 */                   return true;
/*      */                 }
/*      */               });
/*      */               
/*      */ 
/*  655 */               if (fileObjects != null) {
/*  656 */                 for (int j = 0; (j < fileObjects.length) && (!parentJob.isStopped()); j++)
/*      */                 {
/*      */ 
/*  659 */                   if (this.successConditionBroken) {
/*  660 */                     if (!this.successConditionBrokenExit) {
/*  661 */                       logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*  662 */                       this.successConditionBrokenExit = true;
/*      */                     }
/*  664 */                     return false;
/*      */                   }
/*      */                   
/*  667 */                   Currentfile = fileObjects[j];
/*      */                   
/*  669 */                   if (!DecryptOneFile(Currentfile, sourcefilefolder, passPhrase, realDestinationFilefoldername, realWildcard, parentJob, result, movetofolderfolder))
/*      */                   {
/*      */ 
/*  672 */                     updateErrors();
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*  679 */           entrystatus = true;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  684 */           logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.DestinationFolderNotFound", new String[] { realDestinationFilefoldername }));
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/*  689 */         logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.SourceFileNotExists", new String[] { realSourceFilefoldername }));
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  694 */       logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.Exception.MoveProcess", new String[] { realSourceFilefoldername.toString(), destinationfilefolder.toString(), e.getMessage() }));
/*      */       
/*  696 */       updateErrors();
/*      */     }
/*      */     finally {
/*  699 */       if (sourcefilefolder != null) {
/*      */         try {
/*  701 */           sourcefilefolder.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  705 */       if (destinationfilefolder != null) {
/*      */         try {
/*  707 */           destinationfilefolder.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  711 */       if (Currentfile != null) {
/*      */         try {
/*  713 */           Currentfile.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  717 */       if (movetofolderfolder != null) {
/*      */         try {
/*  719 */           movetofolderfolder.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*  724 */     return entrystatus;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean DecryptFile(String shortfilename, FileObject sourcefilename, String passPharse, FileObject destinationfilename, FileObject movetofolderfolder, Job parentJob, Result result)
/*      */   {
/*  732 */     FileObject destinationfile = null;
/*  733 */     boolean retval = false;
/*      */     try {
/*  735 */       if (!destinationfilename.exists()) {
/*  736 */         this.gpg.decryptFile(sourcefilename, passPharse, destinationfilename);
/*      */         
/*  738 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileDecrypted", new String[] { sourcefilename.getName().toString(), destinationfilename.getName().toString() }));
/*      */         }
/*      */         
/*  741 */         if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  742 */           addFileToResultFilenames(destinationfilename.toString(), result, parentJob);
/*      */         }
/*  744 */         updateSuccess();
/*      */       }
/*      */       else
/*      */       {
/*  748 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileExists", new String[] { destinationfilename.toString() }));
/*  749 */         if (this.iffileexists.equals("overwrite_file")) {
/*  750 */           this.gpg.decryptFile(sourcefilename, passPharse, destinationfilename);
/*      */           
/*  752 */           if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileOverwrite", new String[] { destinationfilename.getName().toString() }));
/*      */           }
/*      */           
/*  755 */           if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  756 */             addFileToResultFilenames(destinationfilename.toString(), result, parentJob);
/*      */           }
/*  758 */           updateSuccess();
/*      */         } else {
/*      */           boolean bool1;
/*  761 */           if (this.iffileexists.equals("unique_name")) {
/*  762 */             String short_filename = shortfilename;
/*      */             
/*      */             try
/*      */             {
/*  766 */               short_filename = getMoveDestinationFilename(short_filename, "ddMMyyyy_HHmmssSSS");
/*      */             }
/*      */             catch (Exception e) {
/*  769 */               logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.GettingFilename", new String[] { short_filename }), e);
/*  770 */               return retval;
/*      */             }
/*      */             
/*      */ 
/*  774 */             String movetofilenamefull = destinationfilename.getParent().toString() + Const.FILE_SEPARATOR + short_filename;
/*  775 */             destinationfile = KettleVFS.getFileObject(movetofilenamefull);
/*      */             
/*  777 */             this.gpg.decryptFile(sourcefilename, passPharse, destinationfile);
/*      */             
/*  779 */             if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileDecrypted", new String[] { sourcefilename.getName().toString(), destinationfile.getName().toString() }));
/*      */             }
/*      */             
/*      */ 
/*  783 */             if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  784 */               addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */             }
/*      */             
/*  787 */             updateSuccess();
/*      */           }
/*  789 */           else if (this.iffileexists.equals("delete_file")) {
/*  790 */             destinationfilename.delete();
/*  791 */             if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileDeleted", new String[] { destinationfilename.getName().toString() }));
/*      */           }
/*  793 */           else if (this.iffileexists.equals("move_file")) {
/*  794 */             String short_filename = shortfilename;
/*      */             try
/*      */             {
/*  797 */               short_filename = getMoveDestinationFilename(short_filename, null);
/*      */             } catch (Exception e) {
/*  799 */               logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.GettingFilename", new String[] { short_filename }), e);
/*  800 */               return retval;
/*      */             }
/*      */             
/*  803 */             String movetofilenamefull = movetofolderfolder.toString() + Const.FILE_SEPARATOR + short_filename;
/*  804 */             destinationfile = KettleVFS.getFileObject(movetofilenamefull);
/*  805 */             if (!destinationfile.exists()) {
/*  806 */               sourcefilename.moveTo(destinationfile);
/*  807 */               if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileDecrypted", new String[] { sourcefilename.getName().toString(), destinationfile.getName().toString() }));
/*      */               }
/*      */               
/*  810 */               if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  811 */                 addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */               }
/*      */             }
/*  814 */             else if (this.ifmovedfileexists.equals("overwrite_file")) {
/*  815 */               sourcefilename.moveTo(destinationfile);
/*  816 */               if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileOverwrite", new String[] { destinationfile.getName().toString() }));
/*      */               }
/*      */               
/*  819 */               if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  820 */                 addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */               }
/*  822 */               updateSuccess();
/*  823 */             } else if (this.ifmovedfileexists.equals("unique_name")) {
/*  824 */               SimpleDateFormat daf = new SimpleDateFormat();
/*  825 */               Date now = new Date();
/*  826 */               daf.applyPattern("ddMMyyyy_HHmmssSSS");
/*  827 */               String dt = daf.format(now);
/*  828 */               short_filename = short_filename + "_" + dt;
/*      */               
/*  830 */               String destinationfilenamefull = movetofolderfolder.toString() + Const.FILE_SEPARATOR + short_filename;
/*  831 */               destinationfile = KettleVFS.getFileObject(destinationfilenamefull);
/*      */               
/*  833 */               sourcefilename.moveTo(destinationfile);
/*  834 */               if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileDecrypted", new String[] { destinationfile.getName().toString() }));
/*      */               }
/*      */               
/*  837 */               if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  838 */                 addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */               }
/*  840 */               updateSuccess();
/*  841 */             } else if (this.ifmovedfileexists.equals("fail"))
/*      */             {
/*  843 */               updateErrors();
/*      */             }
/*      */             
/*      */           }
/*  847 */           else if (this.iffileexists.equals("fail"))
/*      */           {
/*  849 */             updateErrors();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  855 */       updateErrors();
/*  856 */       logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.Exception.MoveProcessError", new String[] { sourcefilename.toString(), destinationfilename.toString(), e.getMessage() }));
/*      */     } finally {
/*  858 */       if (destinationfile != null) {
/*      */         try {
/*  860 */           destinationfile.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*  865 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean DecryptOneFile(FileObject Currentfile, FileObject sourcefilefolder, String passPhrase, String realDestinationFilefoldername, String realWildcard, Job parentJob, Result result, FileObject movetofolderfolder)
/*      */   {
/*  871 */     boolean entrystatus = false;
/*  872 */     FileObject file_name = null;
/*      */     try
/*      */     {
/*  875 */       if (!Currentfile.toString().equals(sourcefilefolder.toString()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  880 */         String sourceshortfilename = Currentfile.getName().getBaseName();
/*  881 */         String shortfilename = sourceshortfilename;
/*      */         try {
/*  883 */           shortfilename = getDestinationFilename(sourceshortfilename);
/*      */         }
/*      */         catch (Exception e) {
/*  886 */           logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.GettingFilename", new String[] { Currentfile.getName().getBaseName(), e.toString() }));
/*  887 */           return entrystatus;
/*      */         }
/*      */         
/*  890 */         int lenCurrent = sourceshortfilename.length();
/*  891 */         String short_filename_from_basefolder = shortfilename;
/*  892 */         if (!isDoNotKeepFolderStructure())
/*  893 */           short_filename_from_basefolder = Currentfile.toString().substring(sourcefilefolder.toString().length(), Currentfile.toString().length());
/*  894 */         short_filename_from_basefolder = short_filename_from_basefolder.substring(0, short_filename_from_basefolder.length() - lenCurrent) + shortfilename;
/*      */         
/*      */ 
/*  897 */         file_name = KettleVFS.getFileObject(realDestinationFilefoldername + Const.FILE_SEPARATOR + short_filename_from_basefolder);
/*      */         
/*      */ 
/*      */ 
/*  901 */         if (!Currentfile.getParent().toString().equals(sourcefilefolder.toString()))
/*      */         {
/*      */ 
/*      */ 
/*  905 */           if (this.include_subfolders)
/*      */           {
/*      */ 
/*  908 */             if (Currentfile.getType() != FileType.FOLDER)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  918 */               if (GetFileWildcard(sourceshortfilename, realWildcard))
/*      */               {
/*  920 */                 entrystatus = DecryptFile(shortfilename, Currentfile, passPhrase, file_name, movetofolderfolder, parentJob, result);
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*  929 */         else if (Currentfile.getType() != FileType.FOLDER)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  940 */           if (GetFileWildcard(sourceshortfilename, realWildcard))
/*      */           {
/*  942 */             entrystatus = DecryptFile(shortfilename, Currentfile, passPhrase, file_name, movetofolderfolder, parentJob, result);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  951 */       entrystatus = true;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  955 */       logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.Error", new String[] { e.toString() }));
/*      */     }
/*      */     finally
/*      */     {
/*  959 */       if (file_name != null)
/*      */       {
/*      */         try
/*      */         {
/*  963 */           file_name.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  970 */     return entrystatus;
/*      */   }
/*      */   
/*      */   private void updateErrors()
/*      */   {
/*  975 */     this.NrErrors += 1;
/*  976 */     if (checkIfSuccessConditionBroken())
/*      */     {
/*      */ 
/*  979 */       this.successConditionBroken = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean checkIfSuccessConditionBroken() {
/*  984 */     boolean retval = false;
/*  985 */     if (((this.NrErrors > 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*  988 */       retval = true;
/*      */     }
/*  990 */     return retval;
/*      */   }
/*      */   
/*      */   private void updateSuccess() {
/*  994 */     this.NrSuccess += 1;
/*      */   }
/*      */   
/*      */   private void addFileToResultFilenames(String fileaddentry, Result result, Job parentJob) {
/*      */     try {
/*  999 */       ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(fileaddentry), parentJob.getName(), toString());
/* 1000 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*      */       
/* 1002 */       if (isDebug()) {
/* 1003 */         logDebug(" ------ ");
/* 1004 */         logDebug(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FileAddedToResultFilesName", new String[] { fileaddentry }));
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1008 */       logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Error.AddingToFilenameResult", new String[0]), new Object[] { fileaddentry + "" + e.getMessage() });
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean CreateDestinationFolder(FileObject filefolder) {
/* 1013 */     FileObject folder = null;
/*      */     try
/*      */     {
/* 1016 */       if (this.destination_is_a_file) {
/* 1017 */         folder = filefolder.getParent();
/*      */       } else
/* 1019 */         folder = filefolder;
/*      */       boolean bool;
/* 1021 */       if (!folder.exists())
/*      */       {
/* 1023 */         if (this.create_destination_folder)
/*      */         {
/* 1025 */           if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FolderNotExist", new String[] { folder.getName().toString() }));
/* 1026 */           folder.createFolder();
/* 1027 */           if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FolderWasCreated", new String[] { folder.getName().toString() }));
/*      */         }
/*      */         else
/*      */         {
/* 1031 */           logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.FolderNotExist", new String[] { folder.getName().toString() }));
/* 1032 */           return false;
/*      */         }
/*      */       }
/* 1035 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/* 1038 */       logError(BaseMessages.getString(PKG, "JobPGPDecryptFiles.Log.CanNotCreateParentFolder", new String[] { folder.getName().toString() }), e);
/*      */     }
/*      */     finally
/*      */     {
/* 1042 */       if (folder != null) {
/*      */         try
/*      */         {
/* 1045 */           folder.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */     }
/* 1050 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*      */   {
/* 1063 */     Pattern pattern = null;
/* 1064 */     boolean getIt = true;
/*      */     
/* 1066 */     if (!Const.isEmpty(wildcard))
/*      */     {
/* 1068 */       pattern = Pattern.compile(wildcard);
/*      */       
/* 1070 */       if (pattern != null)
/*      */       {
/* 1072 */         Matcher matcher = pattern.matcher(selectedfile);
/* 1073 */         getIt = matcher.matches();
/*      */       }
/*      */     }
/*      */     
/* 1077 */     return getIt;
/*      */   }
/*      */   
/*      */   private String getDestinationFilename(String shortsourcefilename) throws Exception {
/* 1081 */     String shortfilename = shortsourcefilename;
/* 1082 */     int lenstring = shortsourcefilename.length();
/* 1083 */     int lastindexOfDot = shortfilename.lastIndexOf('.');
/* 1084 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */     }
/* 1086 */     if (isAddDateBeforeExtension()) {
/* 1087 */       shortfilename = shortfilename.substring(0, lastindexOfDot);
/*      */     }
/* 1089 */     if (this.daf == null) this.daf = new SimpleDateFormat();
/* 1090 */     Date now = new Date();
/*      */     
/* 1092 */     if ((isSpecifyFormat()) && (!Const.isEmpty(getDateTimeFormat())))
/*      */     {
/* 1094 */       this.daf.applyPattern(getDateTimeFormat());
/* 1095 */       String dt = this.daf.format(now);
/* 1096 */       shortfilename = shortfilename + dt;
/*      */     }
/*      */     else {
/* 1099 */       if (isAddDate())
/*      */       {
/* 1101 */         this.daf.applyPattern("yyyyMMdd");
/* 1102 */         String d = this.daf.format(now);
/* 1103 */         shortfilename = shortfilename + "_" + d;
/*      */       }
/* 1105 */       if (isAddTime())
/*      */       {
/* 1107 */         this.daf.applyPattern("HHmmssSSS");
/* 1108 */         String t = this.daf.format(now);
/* 1109 */         shortfilename = shortfilename + "_" + t;
/*      */       }
/*      */     }
/* 1112 */     if (isAddDateBeforeExtension()) {
/* 1113 */       shortfilename = shortfilename + shortsourcefilename.substring(lastindexOfDot, lenstring);
/*      */     }
/*      */     
/* 1116 */     return shortfilename;
/*      */   }
/*      */   
/*      */   private String getMoveDestinationFilename(String shortsourcefilename, String DateFormat) throws Exception {
/* 1120 */     String shortfilename = shortsourcefilename;
/* 1121 */     int lenstring = shortsourcefilename.length();
/* 1122 */     int lastindexOfDot = shortfilename.lastIndexOf('.');
/* 1123 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */     }
/* 1125 */     if (isAddMovedDateBeforeExtension()) {
/* 1126 */       shortfilename = shortfilename.substring(0, lastindexOfDot);
/*      */     }
/* 1128 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 1129 */     Date now = new Date();
/*      */     
/* 1131 */     if (DateFormat != null)
/*      */     {
/* 1133 */       daf.applyPattern(DateFormat);
/* 1134 */       String dt = daf.format(now);
/* 1135 */       shortfilename = shortfilename + dt;
/*      */ 
/*      */ 
/*      */     }
/* 1139 */     else if ((isSpecifyMoveFormat()) && (!Const.isEmpty(getMovedDateTimeFormat())))
/*      */     {
/* 1141 */       daf.applyPattern(getMovedDateTimeFormat());
/* 1142 */       String dt = daf.format(now);
/* 1143 */       shortfilename = shortfilename + dt;
/*      */     }
/*      */     else {
/* 1146 */       if (isAddMovedDate())
/*      */       {
/* 1148 */         daf.applyPattern("yyyyMMdd");
/* 1149 */         String d = daf.format(now);
/* 1150 */         shortfilename = shortfilename + "_" + d;
/*      */       }
/* 1152 */       if (isAddMovedTime())
/*      */       {
/* 1154 */         daf.applyPattern("HHmmssSSS");
/* 1155 */         String t = daf.format(now);
/* 1156 */         shortfilename = shortfilename + "_" + t;
/*      */       }
/*      */     }
/*      */     
/* 1160 */     if (isAddMovedDateBeforeExtension()) {
/* 1161 */       shortfilename = shortfilename + shortsourcefilename.substring(lastindexOfDot, lenstring);
/*      */     }
/*      */     
/* 1164 */     return shortfilename;
/*      */   }
/*      */   
/*      */   public void setAddDate(boolean adddate) {
/* 1168 */     this.add_date = adddate;
/*      */   }
/*      */   
/*      */   public boolean isAddDate()
/*      */   {
/* 1173 */     return this.add_date;
/*      */   }
/*      */   
/*      */   public boolean isAddMovedDate()
/*      */   {
/* 1178 */     return this.add_moved_date;
/*      */   }
/*      */   
/*      */   public void setAddMovedDate(boolean add_moved_date) {
/* 1182 */     this.add_moved_date = add_moved_date;
/*      */   }
/*      */   
/*      */   public boolean isAddMovedTime() {
/* 1186 */     return this.add_moved_time;
/*      */   }
/*      */   
/*      */   public void setAddMovedTime(boolean add_moved_time) {
/* 1190 */     this.add_moved_time = add_moved_time;
/*      */   }
/*      */   
/*      */   public void setIfFileExists(String iffileexists)
/*      */   {
/* 1195 */     this.iffileexists = iffileexists;
/*      */   }
/*      */   
/*      */   public String getIfFileExists() {
/* 1199 */     return this.iffileexists;
/*      */   }
/*      */   
/*      */   public void setIfMovedFileExists(String ifmovedfileexists) {
/* 1203 */     this.ifmovedfileexists = ifmovedfileexists;
/*      */   }
/*      */   
/*      */   public String getIfMovedFileExists() {
/* 1207 */     return this.ifmovedfileexists;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAddTime(boolean addtime)
/*      */   {
/* 1215 */     this.add_time = addtime;
/*      */   }
/*      */   
/*      */   public boolean isAddTime()
/*      */   {
/* 1220 */     return this.add_time;
/*      */   }
/*      */   
/*      */   public void setAddDateBeforeExtension(boolean AddDateBeforeExtension)
/*      */   {
/* 1225 */     this.AddDateBeforeExtension = AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public void setAddMovedDateBeforeExtension(boolean AddMovedDateBeforeExtension) {
/* 1229 */     this.AddMovedDateBeforeExtension = AddMovedDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isSpecifyFormat() {
/* 1233 */     return this.SpecifyFormat;
/*      */   }
/*      */   
/*      */   public void setSpecifyFormat(boolean SpecifyFormat) {
/* 1237 */     this.SpecifyFormat = SpecifyFormat;
/*      */   }
/*      */   
/*      */   public void setSpecifyMoveFormat(boolean SpecifyMoveFormat) {
/* 1241 */     this.SpecifyMoveFormat = SpecifyMoveFormat;
/*      */   }
/*      */   
/*      */   public boolean isSpecifyMoveFormat() {
/* 1245 */     return this.SpecifyMoveFormat;
/*      */   }
/*      */   
/*      */   public String getDateTimeFormat() {
/* 1249 */     return this.date_time_format;
/*      */   }
/*      */   
/*      */   public void setDateTimeFormat(String date_time_format) {
/* 1253 */     this.date_time_format = date_time_format;
/*      */   }
/*      */   
/*      */   public String getMovedDateTimeFormat()
/*      */   {
/* 1258 */     return this.moved_date_time_format;
/*      */   }
/*      */   
/*      */   public void setMovedDateTimeFormat(String moved_date_time_format) {
/* 1262 */     this.moved_date_time_format = moved_date_time_format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAddDateBeforeExtension()
/*      */   {
/* 1270 */     return this.AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isAddMovedDateBeforeExtension() {
/* 1274 */     return this.AddMovedDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isDoNotKeepFolderStructure() {
/* 1278 */     return this.DoNotKeepFolderStructure;
/*      */   }
/*      */   
/*      */   public void setDestinationFolder(String destinationFolder) {
/* 1282 */     this.destinationFolder = destinationFolder;
/*      */   }
/*      */   
/*      */   public String getDestinationFolder() {
/* 1286 */     return this.destinationFolder;
/*      */   }
/*      */   
/*      */   public void setGPGPLocation(String gpglocation) {
/* 1290 */     this.gpglocation = gpglocation;
/*      */   }
/*      */   
/*      */   public String getGPGLocation() {
/* 1294 */     return this.gpglocation;
/*      */   }
/*      */   
/*      */   public void setDoNotKeepFolderStructure(boolean DoNotKeepFolderStructure) {
/* 1298 */     this.DoNotKeepFolderStructure = DoNotKeepFolderStructure;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setIncludeSubfolders(boolean include_subfoldersin)
/*      */   {
/* 1304 */     this.include_subfolders = include_subfoldersin;
/*      */   }
/*      */   
/*      */   public void setAddresultfilesname(boolean add_result_filesnamein)
/*      */   {
/* 1309 */     this.add_result_filesname = add_result_filesnamein;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setArgFromPrevious(boolean argfrompreviousin)
/*      */   {
/* 1315 */     this.arg_from_previous = argfrompreviousin;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDestinationIsAFile(boolean destination_is_a_file)
/*      */   {
/* 1321 */     this.destination_is_a_file = destination_is_a_file;
/*      */   }
/*      */   
/*      */   public void setCreateDestinationFolder(boolean create_destination_folder)
/*      */   {
/* 1326 */     this.create_destination_folder = create_destination_folder;
/*      */   }
/*      */   
/*      */   public void setCreateMoveToFolder(boolean create_move_to_folder)
/*      */   {
/* 1331 */     this.create_move_to_folder = create_move_to_folder;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNrErrorsLessThan(String nr_errors_less_than)
/*      */   {
/* 1337 */     this.nr_errors_less_than = nr_errors_less_than;
/*      */   }
/*      */   
/*      */   public String getNrErrorsLessThan()
/*      */   {
/* 1342 */     return this.nr_errors_less_than;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSuccessCondition(String success_condition)
/*      */   {
/* 1348 */     this.success_condition = success_condition;
/*      */   }
/*      */   
/*      */   public String getSuccessCondition() {
/* 1352 */     return this.success_condition;
/*      */   }
/*      */   
/*      */   public boolean evaluates() {
/* 1356 */     return true;
/*      */   }
/*      */   
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {
/* 1360 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */     
/* 1362 */     if (!res)
/*      */     {
/* 1364 */       return;
/*      */     }
/*      */     
/* 1367 */     ValidatorContext ctx = new ValidatorContext();
/* 1368 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 1369 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*      */     
/* 1371 */     for (int i = 0; i < this.source_filefolder.length; i++)
/*      */     {
/* 1373 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*      */     }
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\pgpdecryptfiles\JobEntryPGPDecryptFiles.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */