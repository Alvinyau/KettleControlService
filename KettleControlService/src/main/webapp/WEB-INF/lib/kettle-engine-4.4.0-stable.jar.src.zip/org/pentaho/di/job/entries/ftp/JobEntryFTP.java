/*      */ package org.pentaho.di.job.entries.ftp;
/*      */ 
/*      */ import com.enterprisedt.net.ftp.FTPClient;
/*      */ import com.enterprisedt.net.ftp.FTPConnectMode;
/*      */ import com.enterprisedt.net.ftp.FTPException;
/*      */ import com.enterprisedt.net.ftp.FTPFile;
/*      */ import com.enterprisedt.net.ftp.FTPFileFactory;
/*      */ import com.enterprisedt.net.ftp.FTPFileParser;
/*      */ import com.enterprisedt.net.ftp.FTPTransferType;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.InetAddress;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.logging.LogChannelInterface;
/*      */ import org.pentaho.di.core.util.StringUtil;
/*      */ import org.pentaho.di.core.variables.VariableSpace;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.pentaho.di.resource.ResourceEntry;
/*      */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*      */ import org.pentaho.di.resource.ResourceReference;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryFTP
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   85 */   private static Class<?> PKG = JobEntryFTP.class;
/*      */   
/*   87 */   private static Logger log4j = Logger.getLogger(JobEntryFTP.class);
/*      */   
/*      */   private String serverName;
/*      */   
/*      */   private String userName;
/*      */   
/*      */   private String password;
/*      */   
/*      */   private String ftpDirectory;
/*      */   
/*      */   private String targetDirectory;
/*      */   
/*      */   private String wildcard;
/*      */   private boolean binaryMode;
/*      */   private int timeout;
/*      */   private boolean remove;
/*      */   private boolean onlyGettingNewFiles;
/*      */   private boolean activeConnection;
/*      */   private String controlEncoding;
/*  106 */   private static String LEGACY_CONTROL_ENCODING = "US-ASCII";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  111 */   private static String DEFAULT_CONTROL_ENCODING = "ISO-8859-1";
/*      */   
/*      */   private boolean movefiles;
/*      */   
/*      */   private String movetodirectory;
/*      */   
/*      */   private boolean adddate;
/*      */   
/*      */   private boolean addtime;
/*      */   
/*      */   private boolean SpecifyFormat;
/*      */   
/*      */   private String date_time_format;
/*      */   
/*      */   private boolean AddDateBeforeExtension;
/*      */   private boolean isaddresult;
/*      */   private boolean createmovefolder;
/*      */   private String port;
/*      */   private String proxyHost;
/*      */   private String proxyPort;
/*      */   private String proxyUsername;
/*      */   private String proxyPassword;
/*      */   private String socksProxyHost;
/*      */   private String socksProxyPort;
/*      */   private String socksProxyUsername;
/*      */   private String socksProxyPassword;
/*  137 */   public int ifFileExistsSkip = 0;
/*  138 */   public String SifFileExistsSkip = "ifFileExistsSkip";
/*      */   
/*  140 */   public int ifFileExistsCreateUniq = 1;
/*  141 */   public String SifFileExistsCreateUniq = "ifFileExistsCreateUniq";
/*      */   
/*  143 */   public int ifFileExistsFail = 2;
/*  144 */   public String SifFileExistsFail = "ifFileExistsFail";
/*      */   
/*      */   public int ifFileExists;
/*      */   
/*      */   public String SifFileExists;
/*  149 */   public String SUCCESS_IF_AT_LEAST_X_FILES_DOWNLOADED = "success_when_at_least";
/*  150 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*  151 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*      */   
/*      */   private String nr_limit;
/*      */   
/*      */   private String success_condition;
/*      */   
/*  157 */   long NrErrors = 0L;
/*  158 */   long NrfilesRetrieved = 0L;
/*  159 */   boolean successConditionBroken = false;
/*  160 */   int limitFiles = 0;
/*      */   
/*  162 */   String targetFilename = null;
/*      */   
/*  164 */   static String FILE_SEPARATOR = "/";
/*      */   
/*      */   public JobEntryFTP(String n)
/*      */   {
/*  168 */     super(n, "");
/*  169 */     this.nr_limit = "10";
/*  170 */     this.port = "21";
/*  171 */     this.socksProxyPort = "1080";
/*  172 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/*  173 */     this.ifFileExists = this.ifFileExistsSkip;
/*  174 */     this.SifFileExists = this.SifFileExistsSkip;
/*      */     
/*  176 */     this.serverName = null;
/*  177 */     this.movefiles = false;
/*  178 */     this.movetodirectory = null;
/*  179 */     this.adddate = false;
/*  180 */     this.addtime = false;
/*  181 */     this.SpecifyFormat = false;
/*  182 */     this.AddDateBeforeExtension = false;
/*  183 */     this.isaddresult = true;
/*  184 */     this.createmovefolder = false;
/*      */     
/*  186 */     setID(-1L);
/*  187 */     setControlEncoding(DEFAULT_CONTROL_ENCODING);
/*      */   }
/*      */   
/*      */   public JobEntryFTP()
/*      */   {
/*  192 */     this("");
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  197 */     JobEntryFTP je = (JobEntryFTP)super.clone();
/*  198 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  203 */     StringBuffer retval = new StringBuffer(128);
/*      */     
/*  205 */     retval.append(super.getXML());
/*  206 */     retval.append("      ").append(XMLHandler.addTagValue("port", this.port));
/*  207 */     retval.append("      ").append(XMLHandler.addTagValue("servername", this.serverName));
/*  208 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.userName));
/*  209 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(this.password)));
/*  210 */     retval.append("      ").append(XMLHandler.addTagValue("ftpdirectory", this.ftpDirectory));
/*  211 */     retval.append("      ").append(XMLHandler.addTagValue("targetdirectory", this.targetDirectory));
/*  212 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/*  213 */     retval.append("      ").append(XMLHandler.addTagValue("binary", this.binaryMode));
/*  214 */     retval.append("      ").append(XMLHandler.addTagValue("timeout", this.timeout));
/*  215 */     retval.append("      ").append(XMLHandler.addTagValue("remove", this.remove));
/*  216 */     retval.append("      ").append(XMLHandler.addTagValue("only_new", this.onlyGettingNewFiles));
/*  217 */     retval.append("      ").append(XMLHandler.addTagValue("active", this.activeConnection));
/*  218 */     retval.append("      ").append(XMLHandler.addTagValue("control_encoding", this.controlEncoding));
/*  219 */     retval.append("      ").append(XMLHandler.addTagValue("movefiles", this.movefiles));
/*  220 */     retval.append("      ").append(XMLHandler.addTagValue("movetodirectory", this.movetodirectory));
/*      */     
/*  222 */     retval.append("      ").append(XMLHandler.addTagValue("adddate", this.adddate));
/*  223 */     retval.append("      ").append(XMLHandler.addTagValue("addtime", this.addtime));
/*  224 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyFormat", this.SpecifyFormat));
/*  225 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_format", this.date_time_format));
/*  226 */     retval.append("      ").append(XMLHandler.addTagValue("AddDateBeforeExtension", this.AddDateBeforeExtension));
/*  227 */     retval.append("      ").append(XMLHandler.addTagValue("isaddresult", this.isaddresult));
/*  228 */     retval.append("      ").append(XMLHandler.addTagValue("createmovefolder", this.createmovefolder));
/*      */     
/*  230 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_host", this.proxyHost));
/*  231 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_port", this.proxyPort));
/*  232 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_username", this.proxyUsername));
/*  233 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword)));
/*  234 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_host", this.socksProxyHost));
/*  235 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_port", this.socksProxyPort));
/*  236 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_username", this.socksProxyUsername));
/*  237 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_password", Encr.encryptPasswordIfNotUsingVariables(this.socksProxyPassword)));
/*      */     
/*  239 */     retval.append("      ").append(XMLHandler.addTagValue("ifFileExists", this.SifFileExists));
/*      */     
/*  241 */     retval.append("      ").append(XMLHandler.addTagValue("nr_limit", this.nr_limit));
/*  242 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*      */     
/*  244 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  251 */       super.loadXML(entrynode, databases, slaveServers);
/*  252 */       this.port = XMLHandler.getTagValue(entrynode, "port");
/*  253 */       this.serverName = XMLHandler.getTagValue(entrynode, "servername");
/*  254 */       this.userName = XMLHandler.getTagValue(entrynode, "username");
/*  255 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/*  256 */       this.ftpDirectory = XMLHandler.getTagValue(entrynode, "ftpdirectory");
/*  257 */       this.targetDirectory = XMLHandler.getTagValue(entrynode, "targetdirectory");
/*  258 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/*  259 */       this.binaryMode = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "binary"));
/*  260 */       this.timeout = Const.toInt(XMLHandler.getTagValue(entrynode, "timeout"), 10000);
/*  261 */       this.remove = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "remove"));
/*  262 */       this.onlyGettingNewFiles = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "only_new"));
/*  263 */       this.activeConnection = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "active"));
/*  264 */       this.controlEncoding = XMLHandler.getTagValue(entrynode, "control_encoding");
/*  265 */       if (this.controlEncoding == null)
/*      */       {
/*      */ 
/*      */ 
/*  269 */         this.controlEncoding = LEGACY_CONTROL_ENCODING;
/*      */       }
/*  271 */       this.movefiles = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "movefiles"));
/*  272 */       this.movetodirectory = XMLHandler.getTagValue(entrynode, "movetodirectory");
/*      */       
/*  274 */       this.adddate = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "adddate"));
/*  275 */       this.addtime = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "addtime"));
/*  276 */       this.SpecifyFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyFormat"));
/*  277 */       this.date_time_format = XMLHandler.getTagValue(entrynode, "date_time_format");
/*  278 */       this.AddDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddDateBeforeExtension"));
/*      */       
/*  280 */       String addresult = XMLHandler.getTagValue(entrynode, "isaddresult");
/*      */       
/*  282 */       if (Const.isEmpty(addresult)) {
/*  283 */         this.isaddresult = true;
/*      */       } else {
/*  285 */         this.isaddresult = "Y".equalsIgnoreCase(addresult);
/*      */       }
/*  287 */       this.createmovefolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "createmovefolder"));
/*      */       
/*  289 */       this.proxyHost = XMLHandler.getTagValue(entrynode, "proxy_host");
/*  290 */       this.proxyPort = XMLHandler.getTagValue(entrynode, "proxy_port");
/*  291 */       this.proxyUsername = XMLHandler.getTagValue(entrynode, "proxy_username");
/*  292 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "proxy_password"));
/*  293 */       this.socksProxyHost = XMLHandler.getTagValue(entrynode, "socksproxy_host");
/*  294 */       this.socksProxyPort = XMLHandler.getTagValue(entrynode, "socksproxy_port");
/*  295 */       this.socksProxyUsername = XMLHandler.getTagValue(entrynode, "socksproxy_username");
/*  296 */       this.socksProxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "socksproxy_password"));
/*  297 */       this.SifFileExists = XMLHandler.getTagValue(entrynode, "ifFileExists");
/*  298 */       if (Const.isEmpty(this.SifFileExists))
/*      */       {
/*  300 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */ 
/*      */       }
/*  303 */       else if (this.SifFileExists.equals(this.SifFileExistsCreateUniq)) {
/*  304 */         this.ifFileExists = this.ifFileExistsCreateUniq;
/*  305 */       } else if (this.SifFileExists.equals(this.SifFileExistsFail)) {
/*  306 */         this.ifFileExists = this.ifFileExistsFail;
/*      */       } else {
/*  308 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */       }
/*      */       
/*      */ 
/*  312 */       this.nr_limit = XMLHandler.getTagValue(entrynode, "nr_limit");
/*  313 */       this.success_condition = Const.NVL(XMLHandler.getTagValue(entrynode, "success_condition"), this.SUCCESS_IF_NO_ERRORS);
/*      */ 
/*      */     }
/*      */     catch (KettleXMLException xe)
/*      */     {
/*  318 */       throw new KettleXMLException("Unable to load job entry of type 'ftp' from XML node", xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  327 */       this.port = rep.getJobEntryAttributeString(id_jobentry, "port");
/*  328 */       this.serverName = rep.getJobEntryAttributeString(id_jobentry, "servername");
/*  329 */       this.userName = rep.getJobEntryAttributeString(id_jobentry, "username");
/*  330 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/*  331 */       this.ftpDirectory = rep.getJobEntryAttributeString(id_jobentry, "ftpdirectory");
/*  332 */       this.targetDirectory = rep.getJobEntryAttributeString(id_jobentry, "targetdirectory");
/*  333 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/*  334 */       this.binaryMode = rep.getJobEntryAttributeBoolean(id_jobentry, "binary");
/*  335 */       this.timeout = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "timeout"));
/*  336 */       this.remove = rep.getJobEntryAttributeBoolean(id_jobentry, "remove");
/*  337 */       this.onlyGettingNewFiles = rep.getJobEntryAttributeBoolean(id_jobentry, "only_new");
/*  338 */       this.activeConnection = rep.getJobEntryAttributeBoolean(id_jobentry, "active");
/*  339 */       this.controlEncoding = rep.getJobEntryAttributeString(id_jobentry, "control_encoding");
/*  340 */       if (this.controlEncoding == null)
/*      */       {
/*      */ 
/*      */ 
/*  344 */         this.controlEncoding = LEGACY_CONTROL_ENCODING;
/*      */       }
/*      */       
/*  347 */       this.movefiles = rep.getJobEntryAttributeBoolean(id_jobentry, "movefiles");
/*  348 */       this.movetodirectory = rep.getJobEntryAttributeString(id_jobentry, "movetodirectory");
/*      */       
/*  350 */       this.adddate = rep.getJobEntryAttributeBoolean(id_jobentry, "adddate");
/*  351 */       this.addtime = rep.getJobEntryAttributeBoolean(id_jobentry, "adddate");
/*  352 */       this.SpecifyFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyFormat");
/*  353 */       this.date_time_format = rep.getJobEntryAttributeString(id_jobentry, "date_time_format");
/*  354 */       this.AddDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddDateBeforeExtension");
/*      */       
/*  356 */       String addToResult = rep.getStepAttributeString(id_jobentry, "add_to_result_filenames");
/*  357 */       if (Const.isEmpty(addToResult)) {
/*  358 */         this.isaddresult = true;
/*      */       } else {
/*  360 */         this.isaddresult = rep.getStepAttributeBoolean(id_jobentry, "add_to_result_filenames");
/*      */       }
/*  362 */       this.createmovefolder = rep.getJobEntryAttributeBoolean(id_jobentry, "createmovefolder");
/*      */       
/*  364 */       this.proxyHost = rep.getJobEntryAttributeString(id_jobentry, "proxy_host");
/*  365 */       this.proxyPort = rep.getJobEntryAttributeString(id_jobentry, "proxy_port");
/*  366 */       this.proxyUsername = rep.getJobEntryAttributeString(id_jobentry, "proxy_username");
/*  367 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "proxy_password"));
/*  368 */       this.socksProxyHost = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_host");
/*  369 */       this.socksProxyPort = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_port");
/*  370 */       this.socksProxyUsername = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_username");
/*  371 */       this.socksProxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "socksproxy_password"));
/*  372 */       this.SifFileExists = rep.getJobEntryAttributeString(id_jobentry, "ifFileExists");
/*  373 */       if (Const.isEmpty(this.SifFileExists))
/*      */       {
/*  375 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */ 
/*      */       }
/*  378 */       else if (this.SifFileExists.equals(this.SifFileExistsCreateUniq)) {
/*  379 */         this.ifFileExists = this.ifFileExistsCreateUniq;
/*  380 */       } else if (this.SifFileExists.equals(this.SifFileExistsFail)) {
/*  381 */         this.ifFileExists = this.ifFileExistsFail;
/*      */       } else {
/*  383 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */       }
/*  385 */       this.nr_limit = rep.getJobEntryAttributeString(id_jobentry, "nr_limit");
/*  386 */       this.success_condition = Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "success_condition"), this.SUCCESS_IF_NO_ERRORS);
/*      */ 
/*      */     }
/*      */     catch (KettleException dbe)
/*      */     {
/*  391 */       throw new KettleException("Unable to load job entry of type 'ftp' from the repository for id_jobentry=" + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  399 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "port", this.port);
/*  400 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "servername", this.serverName);
/*  401 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.userName);
/*  402 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/*  403 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ftpdirectory", this.ftpDirectory);
/*  404 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "targetdirectory", this.targetDirectory);
/*  405 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/*  406 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "binary", this.binaryMode);
/*  407 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "timeout", this.timeout);
/*  408 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remove", this.remove);
/*  409 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "only_new", this.onlyGettingNewFiles);
/*  410 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "active", this.activeConnection);
/*  411 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "control_encoding", this.controlEncoding);
/*      */       
/*  413 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "movefiles", this.movefiles);
/*  414 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "movetodirectory", this.movetodirectory);
/*      */       
/*  416 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "addtime", this.addtime);
/*  417 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "adddate", this.adddate);
/*  418 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyFormat", this.SpecifyFormat);
/*  419 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_format", this.date_time_format);
/*      */       
/*  421 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddDateBeforeExtension", this.AddDateBeforeExtension);
/*  422 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "isaddresult", this.isaddresult);
/*  423 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "createmovefolder", this.createmovefolder);
/*      */       
/*  425 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_host", this.proxyHost);
/*  426 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_port", this.proxyPort);
/*  427 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_username", this.proxyUsername);
/*  428 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword));
/*  429 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_host", this.socksProxyHost);
/*  430 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_port", this.socksProxyPort);
/*  431 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_username", this.socksProxyUsername);
/*  432 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_password", Encr.encryptPasswordIfNotUsingVariables(this.socksProxyPassword));
/*  433 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ifFileExists", this.SifFileExists);
/*      */       
/*  435 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_limit", this.nr_limit);
/*  436 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  440 */       throw new KettleException("Unable to save job entry of type 'ftp' to the repository for id_job=" + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLimit(String nr_limitin)
/*      */   {
/*  447 */     this.nr_limit = nr_limitin;
/*      */   }
/*      */   
/*      */   public String getLimit()
/*      */   {
/*  452 */     return this.nr_limit;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSuccessCondition(String success_condition)
/*      */   {
/*  458 */     this.success_condition = success_condition;
/*      */   }
/*      */   
/*      */   public String getSuccessCondition() {
/*  462 */     return this.success_condition;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCreateMoveFolder(boolean createmovefolderin)
/*      */   {
/*  468 */     this.createmovefolder = createmovefolderin;
/*      */   }
/*      */   
/*      */   public boolean isCreateMoveFolder()
/*      */   {
/*  473 */     return this.createmovefolder;
/*      */   }
/*      */   
/*      */   public void setAddDateBeforeExtension(boolean AddDateBeforeExtension)
/*      */   {
/*  478 */     this.AddDateBeforeExtension = AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isAddDateBeforeExtension()
/*      */   {
/*  483 */     return this.AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public void setAddToResult(boolean isaddresultin)
/*      */   {
/*  488 */     this.isaddresult = isaddresultin;
/*      */   }
/*      */   
/*      */   public boolean isAddToResult()
/*      */   {
/*  493 */     return this.isaddresult;
/*      */   }
/*      */   
/*      */   public void setDateInFilename(boolean adddate)
/*      */   {
/*  498 */     this.adddate = adddate;
/*      */   }
/*      */   
/*      */   public boolean isDateInFilename()
/*      */   {
/*  503 */     return this.adddate;
/*      */   }
/*      */   
/*      */   public void setTimeInFilename(boolean addtime)
/*      */   {
/*  508 */     this.addtime = addtime;
/*      */   }
/*      */   
/*      */   public boolean isTimeInFilename() {
/*  512 */     return this.addtime;
/*      */   }
/*      */   
/*      */   public boolean isSpecifyFormat() {
/*  516 */     return this.SpecifyFormat;
/*      */   }
/*      */   
/*      */   public void setSpecifyFormat(boolean SpecifyFormat) {
/*  520 */     this.SpecifyFormat = SpecifyFormat;
/*      */   }
/*      */   
/*      */   public String getDateTimeFormat() {
/*  524 */     return this.date_time_format;
/*      */   }
/*      */   
/*      */   public void setDateTimeFormat(String date_time_format) {
/*  528 */     this.date_time_format = date_time_format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMoveFiles()
/*      */   {
/*  536 */     return this.movefiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMoveFiles(boolean movefilesin)
/*      */   {
/*  543 */     this.movefiles = movefilesin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMoveToDirectory()
/*      */   {
/*  552 */     return this.movetodirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMoveToDirectory(String movetoin)
/*      */   {
/*  560 */     this.movetodirectory = movetoin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBinaryMode()
/*      */   {
/*  568 */     return this.binaryMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryMode(boolean binaryMode)
/*      */   {
/*  576 */     this.binaryMode = binaryMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFtpDirectory()
/*      */   {
/*  584 */     return this.ftpDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFtpDirectory(String directory)
/*      */   {
/*  592 */     this.ftpDirectory = directory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPassword()
/*      */   {
/*  600 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/*  608 */     this.password = password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerName()
/*      */   {
/*  616 */     return this.serverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerName(String serverName)
/*      */   {
/*  624 */     this.serverName = serverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPort()
/*      */   {
/*  632 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(String port)
/*      */   {
/*  640 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */   {
/*  650 */     return this.userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserName(String userName)
/*      */   {
/*  658 */     this.userName = userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWildcard()
/*      */   {
/*  666 */     return this.wildcard;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWildcard(String wildcard)
/*      */   {
/*  674 */     this.wildcard = wildcard;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTargetDirectory()
/*      */   {
/*  682 */     return this.targetDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTargetDirectory(String targetDirectory)
/*      */   {
/*  690 */     this.targetDirectory = targetDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimeout(int timeout)
/*      */   {
/*  698 */     this.timeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTimeout()
/*      */   {
/*  706 */     return this.timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemove(boolean remove)
/*      */   {
/*  714 */     this.remove = remove;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRemove()
/*      */   {
/*  722 */     return this.remove;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isOnlyGettingNewFiles()
/*      */   {
/*  730 */     return this.onlyGettingNewFiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOnlyGettingNewFiles(boolean onlyGettingNewFilesin)
/*      */   {
/*  738 */     this.onlyGettingNewFiles = onlyGettingNewFilesin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getControlEncoding()
/*      */   {
/*  748 */     return this.controlEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setControlEncoding(String encoding)
/*      */   {
/*  760 */     this.controlEncoding = encoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyHost()
/*      */   {
/*  769 */     return this.proxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyHost(String proxyHost)
/*      */   {
/*  777 */     this.proxyHost = proxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPassword(String proxyPassword)
/*      */   {
/*  785 */     this.proxyPassword = proxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyPassword()
/*      */   {
/*  793 */     return this.proxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocksProxyPassword(String socksProxyPassword)
/*      */   {
/*  801 */     this.socksProxyPassword = socksProxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSocksProxyPassword()
/*      */   {
/*  809 */     return this.socksProxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(String proxyPort)
/*      */   {
/*  817 */     this.proxyPort = proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyPort()
/*      */   {
/*  825 */     return this.proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getProxyUsername()
/*      */   {
/*  832 */     return this.proxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProxyUsername(String proxyUsername)
/*      */   {
/*  839 */     this.proxyUsername = proxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyUsername()
/*      */   {
/*  846 */     return this.socksProxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocksProxyUsername(String socksPoxyUsername)
/*      */   {
/*  853 */     this.socksProxyUsername = socksPoxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSocksProxyHost(String socksProxyHost)
/*      */   {
/*  861 */     this.socksProxyHost = socksProxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyHost()
/*      */   {
/*  868 */     return this.socksProxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocksProxyPort(String socksProxyPort)
/*      */   {
/*  875 */     this.socksProxyPort = socksProxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyPort()
/*      */   {
/*  882 */     return this.socksProxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */   public Result execute(Result previousResult, int nr)
/*      */   {
/*  888 */     log4j.info(BaseMessages.getString(PKG, "JobEntryFTP.Started", new String[] { this.serverName }));
/*      */     
/*  890 */     Result result = previousResult;
/*  891 */     result.setNrErrors(1L);
/*  892 */     result.setResult(false);
/*  893 */     this.NrErrors = 0L;
/*  894 */     this.NrfilesRetrieved = 0L;
/*  895 */     this.successConditionBroken = false;
/*  896 */     boolean exitjobentry = false;
/*  897 */     this.limitFiles = Const.toInt(environmentSubstitute(getLimit()), 10);
/*      */     
/*      */ 
/*      */ 
/*  901 */     if (this.movefiles)
/*      */     {
/*  903 */       if (Const.isEmpty(this.movetodirectory))
/*      */       {
/*  905 */         logError(BaseMessages.getString(PKG, "JobEntryFTP.MoveToFolderEmpty", new String[0]));
/*  906 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  911 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.Start", new String[0]));
/*      */     }
/*  913 */     FTPClient ftpclient = null;
/*  914 */     String realMoveToFolder = null;
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  919 */       ftpclient = new FTPClient();
/*  920 */       String realServername = environmentSubstitute(this.serverName);
/*  921 */       String realServerPort = environmentSubstitute(this.port);
/*  922 */       ftpclient.setRemoteAddr(InetAddress.getByName(realServername));
/*  923 */       if (!Const.isEmpty(realServerPort))
/*      */       {
/*  925 */         ftpclient.setRemotePort(Const.toInt(realServerPort, 21));
/*      */       }
/*      */       
/*  928 */       if (!Const.isEmpty(this.proxyHost))
/*      */       {
/*  930 */         String realProxy_host = environmentSubstitute(this.proxyHost);
/*  931 */         ftpclient.setRemoteAddr(InetAddress.getByName(realProxy_host));
/*  932 */         if (isDetailed()) {
/*  933 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.OpenedProxyConnectionOn", new String[] { realProxy_host }));
/*      */         }
/*      */         
/*  936 */         int port = Const.toInt(environmentSubstitute(this.proxyPort), 21);
/*  937 */         if (port != 0)
/*      */         {
/*  939 */           ftpclient.setRemotePort(port);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  944 */         ftpclient.setRemoteAddr(InetAddress.getByName(realServername));
/*      */         
/*  946 */         if (isDetailed()) {
/*  947 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.OpenedConnectionTo", new String[] { realServername }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  952 */       if (this.activeConnection) {
/*  953 */         ftpclient.setConnectMode(FTPConnectMode.ACTIVE);
/*  954 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.SetActive", new String[0]));
/*      */       }
/*      */       else {
/*  957 */         ftpclient.setConnectMode(FTPConnectMode.PASV);
/*  958 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.SetPassive", new String[0]));
/*      */         }
/*      */       }
/*      */       
/*  962 */       ftpclient.setTimeout(this.timeout);
/*  963 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.SetTimeout", new String[] { String.valueOf(this.timeout) }));
/*      */       }
/*  965 */       ftpclient.setControlEncoding(this.controlEncoding);
/*  966 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.SetEncoding", new String[] { this.controlEncoding }));
/*      */       }
/*      */       
/*  969 */       if (!Const.isEmpty(this.socksProxyHost)) {
/*  970 */         if (!Const.isEmpty(this.socksProxyPort)) {
/*  971 */           FTPClient.initSOCKS(environmentSubstitute(this.socksProxyPort), environmentSubstitute(this.socksProxyHost));
/*      */         }
/*      */         else {
/*  974 */           throw new FTPException(BaseMessages.getString(PKG, "JobEntryFTP.SocksProxy.PortMissingException", new String[] { environmentSubstitute(this.socksProxyHost), getName() }));
/*      */         }
/*      */         
/*  977 */         if ((!Const.isEmpty(this.socksProxyUsername)) && (!Const.isEmpty(this.socksProxyPassword))) {
/*  978 */           FTPClient.initSOCKSAuthentication(environmentSubstitute(this.socksProxyUsername), environmentSubstitute(this.socksProxyPassword));
/*      */         }
/*  980 */         else if (((!Const.isEmpty(this.socksProxyUsername)) && (Const.isEmpty(this.socksProxyPassword))) || ((Const.isEmpty(this.socksProxyUsername)) && (!Const.isEmpty(this.socksProxyPassword))))
/*      */         {
/*      */ 
/*  983 */           throw new FTPException(BaseMessages.getString(PKG, "JobEntryFTP.SocksProxy.IncompleteCredentials", new String[] { environmentSubstitute(this.socksProxyHost), getName() }));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  988 */       ftpclient.connect();
/*      */       
/*  990 */       String realUsername = environmentSubstitute(this.userName) + (!Const.isEmpty(this.proxyHost) ? "@" + realServername : "") + (!Const.isEmpty(this.proxyUsername) ? " " + environmentSubstitute(this.proxyUsername) : "");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  995 */       String realPassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password)) + (!Const.isEmpty(this.proxyPassword) ? " " + Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.proxyPassword)) : "");
/*      */       
/*      */ 
/*      */ 
/*  999 */       ftpclient.login(realUsername, realPassword);
/*      */       
/* 1001 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.LoggedIn", new String[] { realUsername }));
/*      */       }
/*      */       
/* 1004 */       hookInOtherParsers(ftpclient);
/*      */       
/*      */ 
/* 1007 */       if (!Const.isEmpty(this.ftpDirectory)) {
/* 1008 */         String realFtpDirectory = environmentSubstitute(this.ftpDirectory);
/* 1009 */         realFtpDirectory = normalizePath(realFtpDirectory);
/* 1010 */         ftpclient.chdir(realFtpDirectory);
/* 1011 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.ChangedDir", new String[] { realFtpDirectory }));
/*      */         }
/*      */       }
/*      */       
/* 1015 */       if ((this.movefiles) && (!Const.isEmpty(this.movetodirectory))) {
/* 1016 */         realMoveToFolder = environmentSubstitute(this.movetodirectory);
/* 1017 */         realMoveToFolder = normalizePath(realMoveToFolder);
/*      */         
/* 1019 */         boolean folderExist = true;
/* 1020 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.CheckMoveToFolder", new String[] { realMoveToFolder }));
/* 1021 */         String originalLocation = ftpclient.pwd();
/*      */         
/*      */         try
/*      */         {
/* 1025 */           ftpclient.chdir(realMoveToFolder);
/*      */           
/* 1027 */           if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.CheckMoveToFolderSwitchBack", new String[] { originalLocation }));
/* 1028 */           ftpclient.chdir(originalLocation);
/*      */         }
/*      */         catch (Exception e) {
/* 1031 */           folderExist = false;
/*      */         }
/*      */         
/*      */ 
/* 1035 */         if (!folderExist) {
/* 1036 */           if (this.createmovefolder) {
/* 1037 */             ftpclient.mkdir(realMoveToFolder);
/* 1038 */             if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.MoveToFolderCreated", new String[] { realMoveToFolder }));
/*      */           } else {
/* 1040 */             logError(BaseMessages.getString(PKG, "JobEntryFTP.MoveToFolderNotExist", new String[0]));
/* 1041 */             exitjobentry = true;
/* 1042 */             this.NrErrors += 1L;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1047 */       if (!exitjobentry)
/*      */       {
/*      */ 
/* 1050 */         FTPFile[] ftpFiles = ftpclient.dirDetails(null);
/*      */         
/*      */ 
/* 1053 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.FoundNFiles", new String[] { String.valueOf(ftpFiles.length) }));
/*      */         }
/*      */         
/* 1056 */         if (this.binaryMode)
/*      */         {
/* 1058 */           ftpclient.setType(FTPTransferType.BINARY);
/* 1059 */           if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.SetBinary", new String[0]));
/*      */         }
/*      */         else
/*      */         {
/* 1063 */           ftpclient.setType(FTPTransferType.ASCII);
/* 1064 */           if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.SetAscii", new String[0]));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1071 */         if (ftpFiles.length == 1)
/*      */         {
/* 1073 */           String translatedWildcard = environmentSubstitute(this.wildcard);
/* 1074 */           if ((!Const.isEmpty(translatedWildcard)) && 
/* 1075 */             (ftpFiles[0].getName().startsWith(translatedWildcard)))
/*      */           {
/* 1077 */             throw new FTPException(ftpFiles[0].getName());
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 1082 */         Pattern pattern = null;
/* 1083 */         if (!Const.isEmpty(this.wildcard)) {
/* 1084 */           String realWildcard = environmentSubstitute(this.wildcard);
/* 1085 */           pattern = Pattern.compile(realWildcard);
/*      */         }
/*      */         
/* 1088 */         if (!getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS)) {
/* 1089 */           this.limitFiles = Const.toInt(environmentSubstitute(getLimit()), 10);
/*      */         }
/*      */         
/* 1092 */         for (FTPFile ftpFile : ftpFiles)
/*      */         {
/*      */ 
/* 1095 */           if (this.parentJob.isStopped()) {
/* 1096 */             exitjobentry = true;
/* 1097 */             throw new Exception(BaseMessages.getString(PKG, "JobEntryFTP.JobStopped", new String[0]));
/*      */           }
/*      */           
/* 1100 */           if (this.successConditionBroken) {
/* 1101 */             throw new Exception(BaseMessages.getString(PKG, "JobEntryFTP.SuccesConditionBroken", new String[] { "" + this.NrErrors }));
/*      */           }
/*      */           
/* 1104 */           boolean getIt = true;
/*      */           
/* 1106 */           String filename = ftpFile.getName();
/* 1107 */           if (isDebug()) { logDebug(BaseMessages.getString(PKG, "JobEntryFTP.AnalysingFile", new String[] { filename }));
/*      */           }
/*      */           
/* 1110 */           if (ftpFile.isDir())
/*      */           {
/*      */ 
/* 1113 */             getIt = false;
/* 1114 */             if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.SkippingNotAFile", new String[] { filename }));
/*      */           }
/* 1116 */           if (getIt) {
/*      */             try
/*      */             {
/* 1119 */               if (pattern != null) {
/* 1120 */                 Matcher matcher = pattern.matcher(filename);
/* 1121 */                 getIt = matcher.matches();
/*      */               }
/* 1123 */               if (getIt) downloadFile(ftpclient, filename, realMoveToFolder, this.parentJob, result);
/*      */             }
/*      */             catch (Exception e) {
/* 1126 */               updateErrors();
/* 1127 */               logError(BaseMessages.getString(PKG, "JobFTP.UnexpectedError", new String[] { e.toString() }));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/* 1134 */       if ((!this.successConditionBroken) && (!exitjobentry)) updateErrors();
/* 1135 */       logError(BaseMessages.getString(PKG, "JobEntryFTP.ErrorGetting", new String[] { e.getMessage() }));
/*      */     }
/*      */     finally {
/* 1138 */       if (ftpclient != null) {
/*      */         try {
/* 1140 */           ftpclient.quit();
/*      */         }
/*      */         catch (Exception e) {
/* 1143 */           logError(BaseMessages.getString(PKG, "JobEntryFTP.ErrorQuitting", new String[] { e.getMessage() }));
/*      */         }
/*      */       }
/* 1146 */       FTPClient.clearSOCKS();
/*      */     }
/*      */     
/* 1149 */     result.setNrErrors(this.NrErrors);
/* 1150 */     result.setNrFilesRetrieved(this.NrfilesRetrieved);
/* 1151 */     if (getSuccessStatus()) result.setResult(true);
/* 1152 */     if (exitjobentry) result.setResult(false);
/* 1153 */     displayResults();
/* 1154 */     return result;
/*      */   }
/*      */   
/*      */   private void downloadFile(FTPClient ftpclient, String filename, String realMoveToFolder, Job parentJob, Result result) throws Exception {
/* 1158 */     String localFilename = filename;
/* 1159 */     this.targetFilename = returnTargetFilename(localFilename);
/*      */     
/* 1161 */     if ((!this.onlyGettingNewFiles) || ((this.onlyGettingNewFiles) && (needsDownload(this.targetFilename))))
/*      */     {
/*      */ 
/* 1164 */       if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.GettingFile", new String[] { filename, environmentSubstitute(this.targetDirectory) }));
/* 1165 */       ftpclient.get(this.targetFilename, filename);
/*      */       
/*      */ 
/* 1168 */       updateRetrievedFiles();
/* 1169 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.GotFile", new String[] { filename }));
/*      */       }
/*      */       
/* 1172 */       addFilenameToResultFilenames(result, parentJob, this.targetFilename);
/*      */       
/*      */ 
/* 1175 */       if (this.remove) {
/* 1176 */         ftpclient.delete(filename);
/* 1177 */         if ((isDetailed()) && 
/* 1178 */           (isDetailed())) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.DeletedFile", new String[] { filename }));
/*      */         }
/*      */       }
/* 1181 */       else if (this.movefiles)
/*      */       {
/* 1183 */         ftpclient.rename(filename, realMoveToFolder + FILE_SEPARATOR + filename);
/*      */         
/* 1185 */         if (isDetailed()) {
/* 1186 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.MovedFile", new String[] { filename, realMoveToFolder }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String normalizePath(String path)
/*      */     throws Exception
/*      */   {
/* 1200 */     String normalizedPath = path.replaceAll("\\\\", FILE_SEPARATOR);
/* 1201 */     while ((normalizedPath.endsWith("\\")) || (normalizedPath.endsWith(FILE_SEPARATOR))) {
/* 1202 */       normalizedPath = normalizedPath.substring(0, normalizedPath.length() - 1);
/*      */     }
/*      */     
/* 1205 */     return normalizedPath;
/*      */   }
/*      */   
/*      */   private void addFilenameToResultFilenames(Result result, Job parentJob, String filename) throws KettleException {
/* 1209 */     if (this.isaddresult) {
/* 1210 */       FileObject targetFile = null;
/*      */       try {
/* 1212 */         targetFile = KettleVFS.getFileObject(filename, this);
/*      */         
/*      */ 
/* 1215 */         ResultFile resultFile = new ResultFile(0, targetFile, parentJob.getJobname(), toString());
/* 1216 */         resultFile.setComment(BaseMessages.getString(PKG, "JobEntryFTP.Downloaded", new String[] { this.serverName }));
/* 1217 */         result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*      */         
/* 1219 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.FileAddedToResult", new String[] { filename }));
/*      */       } catch (Exception e) {
/* 1221 */         throw new KettleException(e);
/*      */       }
/*      */       finally {
/*      */         try {
/* 1225 */           targetFile.close();
/* 1226 */           targetFile = null;
/*      */         } catch (Exception e) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void displayResults() {
/* 1233 */     if (isDetailed()) {
/* 1234 */       logDetailed("=======================================");
/* 1235 */       logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.Log.Info.FilesInError", new String[] { "" + this.NrErrors }));
/* 1236 */       logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.Log.Info.FilesRetrieved", new String[] { "" + this.NrfilesRetrieved }));
/* 1237 */       logDetailed("=======================================");
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean getSuccessStatus() {
/* 1242 */     boolean retval = false;
/*      */     
/* 1244 */     if (((this.NrErrors == 0L) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrfilesRetrieved >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FILES_DOWNLOADED))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*      */ 
/* 1248 */       retval = true;
/*      */     }
/*      */     
/* 1251 */     return retval;
/*      */   }
/*      */   
/*      */   private void updateErrors() {
/* 1255 */     this.NrErrors += 1L;
/* 1256 */     if (checkIfSuccessConditionBroken())
/*      */     {
/*      */ 
/* 1259 */       this.successConditionBroken = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean checkIfSuccessConditionBroken() {
/* 1264 */     boolean retval = false;
/* 1265 */     if (((this.NrErrors > 0L) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/* 1268 */       retval = true;
/*      */     }
/* 1270 */     return retval;
/*      */   }
/*      */   
/*      */   private void updateRetrievedFiles() {
/* 1274 */     this.NrfilesRetrieved += 1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String returnTargetFilename(String filename)
/*      */   {
/* 1285 */     String retval = null;
/*      */     
/* 1287 */     if (filename != null) retval = filename; else {
/* 1288 */       return null;
/*      */     }
/* 1290 */     int lenstring = retval.length();
/* 1291 */     int lastindexOfDot = retval.lastIndexOf(".");
/* 1292 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */     }
/* 1294 */     if (isAddDateBeforeExtension()) { retval = retval.substring(0, lastindexOfDot);
/*      */     }
/* 1296 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 1297 */     Date now = new Date();
/*      */     
/* 1299 */     if ((this.SpecifyFormat) && (!Const.isEmpty(this.date_time_format)))
/*      */     {
/* 1301 */       daf.applyPattern(this.date_time_format);
/* 1302 */       String dt = daf.format(now);
/* 1303 */       retval = retval + dt;
/*      */     }
/*      */     else {
/* 1306 */       if (this.adddate)
/*      */       {
/* 1308 */         daf.applyPattern("yyyyMMdd");
/* 1309 */         String d = daf.format(now);
/* 1310 */         retval = retval + "_" + d;
/*      */       }
/* 1312 */       if (this.addtime)
/*      */       {
/* 1314 */         daf.applyPattern("HHmmssSSS");
/* 1315 */         String t = daf.format(now);
/* 1316 */         retval = retval + "_" + t;
/*      */       }
/*      */     }
/*      */     
/* 1320 */     if (isAddDateBeforeExtension()) {
/* 1321 */       retval = retval + retval.substring(lastindexOfDot, lenstring);
/*      */     }
/*      */     
/* 1324 */     retval = environmentSubstitute(this.targetDirectory) + Const.FILE_SEPARATOR + retval;
/* 1325 */     return retval;
/*      */   }
/*      */   
/*      */   public boolean evaluates()
/*      */   {
/* 1330 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean needsDownload(String filename)
/*      */   {
/* 1344 */     boolean retval = false;
/*      */     
/* 1346 */     File file = new File(filename);
/*      */     
/* 1348 */     if (!file.exists())
/*      */     {
/* 1350 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.LocalFileNotExists", new String[0]), new Object[] { filename });
/* 1351 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 1355 */     if (this.ifFileExists == this.ifFileExistsCreateUniq) {
/* 1356 */       if (isDebug()) { logDebug(toString(), new Object[] { BaseMessages.getString(PKG, "JobEntryFTP.LocalFileExists", new String[0]), filename });
/*      */       }
/*      */       
/* 1359 */       int lenstring = this.targetFilename.length();
/* 1360 */       int lastindexOfDot = this.targetFilename.lastIndexOf('.');
/* 1361 */       if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */       }
/* 1363 */       this.targetFilename = (this.targetFilename.substring(0, lastindexOfDot) + StringUtil.getFormattedDateTimeNow(true) + this.targetFilename.substring(lastindexOfDot, lenstring));
/*      */       
/*      */ 
/*      */ 
/* 1367 */       return true;
/*      */     }
/* 1369 */     if (this.ifFileExists == this.ifFileExistsFail) {
/* 1370 */       this.log.logError(BaseMessages.getString(PKG, "JobEntryFTP.LocalFileExists", new String[0]), new Object[] { filename });
/* 1371 */       updateErrors();
/*      */     }
/* 1373 */     else if (isDebug()) { logDebug(toString(), new Object[] { BaseMessages.getString(PKG, "JobEntryFTP.LocalFileExists", new String[0]), filename });
/*      */     }
/*      */     
/*      */ 
/* 1377 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActiveConnection()
/*      */   {
/* 1385 */     return this.activeConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setActiveConnection(boolean passive)
/*      */   {
/* 1393 */     this.activeConnection = passive;
/*      */   }
/*      */   
/*      */ 
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1399 */     JobEntryValidatorUtils.andValidator().validate(this, "serverName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1400 */     JobEntryValidatorUtils.andValidator().validate(this, "targetDirectory", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() }));
/*      */     
/* 1402 */     JobEntryValidatorUtils.andValidator().validate(this, "userName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1403 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */   }
/*      */   
/*      */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*      */   {
/* 1408 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 1409 */     if (!Const.isEmpty(this.serverName))
/*      */     {
/* 1411 */       String realServername = jobMeta.environmentSubstitute(this.serverName);
/* 1412 */       ResourceReference reference = new ResourceReference(this);
/* 1413 */       reference.getEntries().add(new ResourceEntry(realServername, ResourceEntry.ResourceType.SERVER));
/* 1414 */       references.add(reference);
/*      */     }
/* 1416 */     return references;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void hookInOtherParsers(FTPClient ftpClient)
/*      */     throws FTPException, IOException
/*      */   {
/* 1427 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Hooking.Parsers", new String[0]));
/* 1428 */     String system = ftpClient.system();
/* 1429 */     MVSFileParser parser = new MVSFileParser();
/* 1430 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Created.MVS.Parser", new String[0]));
/* 1431 */     FTPFileFactory factory = new FTPFileFactory(system);
/* 1432 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Created.Factory", new String[0]));
/* 1433 */     factory.addParser(parser);
/* 1434 */     ftpClient.setFTPFileFactory(factory);
/* 1435 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Get.Variable.Space", new String[0]));
/* 1436 */     VariableSpace vs = getVariables();
/* 1437 */     if (vs != null) {
/* 1438 */       if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Getting.Other.Parsers", new String[0]));
/* 1439 */       String otherParserNames = vs.getVariable("ftp.file.parser.class.names");
/* 1440 */       if (otherParserNames != null) {
/* 1441 */         if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Creating.Parsers", new String[0]));
/* 1442 */         String[] parserClasses = otherParserNames.split("|");
/* 1443 */         String cName = null;
/* 1444 */         Class<?> clazz = null;
/* 1445 */         Object parserInstance = null;
/* 1446 */         for (int i = 0; i < parserClasses.length; i++) {
/* 1447 */           cName = parserClasses[i].trim();
/* 1448 */           if (cName.length() > 0) {
/*      */             try {
/* 1450 */               clazz = Class.forName(cName);
/* 1451 */               parserInstance = clazz.newInstance();
/* 1452 */               if ((parserInstance instanceof FTPFileParser)) {
/* 1453 */                 if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Created.Other.Parser", new String[] { cName }));
/* 1454 */                 factory.addParser((FTPFileParser)parserInstance);
/*      */               }
/*      */             } catch (Exception ignored) {
/* 1457 */               if (this.log.isDebug()) {
/* 1458 */                 ignored.printStackTrace();
/* 1459 */                 logError(BaseMessages.getString(PKG, "JobEntryFTP.ERROR.Creating.Parser", new String[] { cName }));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftp\JobEntryFTP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */