/*     */ package org.pentaho.di.job.entries.evalfilesmetrics;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.AllFileSelector;
/*     */ import org.apache.commons.vfs.FileContent;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entries.simpleeval.JobEntrySimpleEval;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryEvalFilesMetrics
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  76 */   private static Class<?> PKG = JobEntryEvalFilesMetrics.class;
/*     */   
/*  78 */   public static final BigDecimal ONE = new BigDecimal(1);
/*     */   
/*  80 */   public static final String[] IncludeSubFoldersDesc = { BaseMessages.getString(PKG, "System.Combo.No", new String[0]), BaseMessages.getString(PKG, "System.Combo.Yes", new String[0]) };
/*  81 */   public static final String[] IncludeSubFoldersCodes = { "N", "Y" };
/*     */   
/*     */   private static final String YES = "Y";
/*     */   
/*     */   private static final String NO = "N";
/*  86 */   public static final String[] scaleDesc = { BaseMessages.getString(PKG, "JobEvalFilesMetrics.Bytes.Label", new String[0]), BaseMessages.getString(PKG, "JobEvalFilesMetrics.KBytes.Label", new String[0]), BaseMessages.getString(PKG, "JobEvalFilesMetrics.MBytes.Label", new String[0]), BaseMessages.getString(PKG, "JobEvalFilesMetrics.GBytes.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */   public static final String[] scaleCodes = { "bytes", "kbytes", "mbytes", "gbytes" };
/*     */   
/*     */ 
/*     */   public static final int SCALE_BYTES = 0;
/*     */   
/*     */ 
/*     */   public static final int SCALE_KBYTES = 1;
/*     */   
/*     */   public static final int SCALE_MBYTES = 2;
/*     */   
/*     */   public static final int SCALE_GBYTES = 3;
/*     */   
/*     */   public int scale;
/*     */   
/* 106 */   public static final String[] SourceFilesDesc = { BaseMessages.getString(PKG, "JobEvalFilesMetrics.SourceFiles.Files.Label", new String[0]), BaseMessages.getString(PKG, "JobEvalFilesMetrics.SourceFiles.FilenamesResult.Label", new String[0]), BaseMessages.getString(PKG, "JobEvalFilesMetrics.SourceFiles.PreviousResult.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 111 */   public static final String[] SourceFilesCodes = { "files", "filenamesresult", "previousresult" };
/*     */   
/*     */ 
/*     */   public static final int SOURCE_FILES_FILES = 0;
/*     */   
/*     */ 
/*     */   public static final int SOURCE_FILES_FILENAMES_RESULT = 1;
/*     */   
/*     */   public static final int SOURCE_FILES_PREVIOUS_RESULT = 2;
/*     */   
/*     */   public int sourceFiles;
/*     */   
/* 123 */   public static final String[] EvaluationTypeDesc = { BaseMessages.getString(PKG, "JobEvalFilesMetrics.EvaluationType.Size.Label", new String[0]), BaseMessages.getString(PKG, "JobEvalFilesMetrics.EvaluationType.Count.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/* 127 */   public static final String[] EvaluationTypeCodes = { "size", "count" };
/*     */   
/*     */   public static final int EVALUATE_TYPE_SIZE = 0;
/*     */   
/*     */   public static final int EVALUATE_TYPE_COUNT = 1;
/*     */   
/*     */   public int evaluationType;
/*     */   
/*     */   private String comparevalue;
/*     */   
/*     */   private String minvalue;
/*     */   
/*     */   private String maxvalue;
/*     */   
/*     */   public int successnumbercondition;
/*     */   
/*     */   private String resultFilenamesWildcard;
/*     */   
/*     */   public boolean arg_from_previous;
/*     */   
/*     */   public String[] source_filefolder;
/*     */   
/*     */   public String[] wildcard;
/*     */   
/*     */   public String[] includeSubFolders;
/*     */   private BigDecimal evaluationValue;
/*     */   private BigDecimal filesCount;
/*     */   private long nrErrors;
/*     */   private String ResultFieldFile;
/*     */   private String ResultFieldWildcard;
/*     */   private String ResultFieldIncludesubFolders;
/*     */   private BigDecimal compareValue;
/*     */   private BigDecimal minValue;
/*     */   private BigDecimal maxValue;
/*     */   
/*     */   public JobEntryEvalFilesMetrics(String n)
/*     */   {
/* 164 */     super(n, "");
/* 165 */     this.source_filefolder = null;
/* 166 */     this.wildcard = null;
/* 167 */     this.includeSubFolders = null;
/* 168 */     this.scale = 0;
/* 169 */     this.sourceFiles = 0;
/* 170 */     this.evaluationType = 0;
/* 171 */     this.successnumbercondition = 4;
/* 172 */     this.resultFilenamesWildcard = null;
/* 173 */     this.ResultFieldFile = null;
/* 174 */     this.ResultFieldWildcard = null;
/* 175 */     this.ResultFieldIncludesubFolders = null;
/* 176 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryEvalFilesMetrics()
/*     */   {
/* 181 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 186 */     JobEntryEvalFilesMetrics je = (JobEntryEvalFilesMetrics)super.clone();
/* 187 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 192 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 194 */     retval.append(super.getXML());
/* 195 */     retval.append("      ").append(XMLHandler.addTagValue("result_filenames_wildcard", this.resultFilenamesWildcard));
/* 196 */     retval.append("      ").append(XMLHandler.addTagValue("Result_field_file", this.ResultFieldFile));
/* 197 */     retval.append("      ").append(XMLHandler.addTagValue("Result_field_wildcard", this.ResultFieldWildcard));
/* 198 */     retval.append("      ").append(XMLHandler.addTagValue("Result_field_includesubfolders", this.ResultFieldIncludesubFolders));
/*     */     
/* 200 */     retval.append("      <fields>").append(Const.CR);
/* 201 */     if (this.source_filefolder != null)
/*     */     {
/* 203 */       for (int i = 0; i < this.source_filefolder.length; i++)
/*     */       {
/* 205 */         retval.append("        <field>").append(Const.CR);
/* 206 */         retval.append("          ").append(XMLHandler.addTagValue("source_filefolder", this.source_filefolder[i]));
/* 207 */         retval.append("          ").append(XMLHandler.addTagValue("wildcard", this.wildcard[i]));
/* 208 */         retval.append("          ").append(XMLHandler.addTagValue("include_subFolders", this.includeSubFolders[i]));
/* 209 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 212 */     retval.append("      </fields>").append(Const.CR);
/* 213 */     retval.append("      ").append(XMLHandler.addTagValue("comparevalue", this.comparevalue));
/* 214 */     retval.append("      ").append(XMLHandler.addTagValue("minvalue", this.minvalue));
/* 215 */     retval.append("      ").append(XMLHandler.addTagValue("maxvalue", this.maxvalue));
/* 216 */     retval.append("      ").append(XMLHandler.addTagValue("successnumbercondition", JobEntrySimpleEval.getSuccessNumberConditionCode(this.successnumbercondition)));
/* 217 */     retval.append("      ").append(XMLHandler.addTagValue("source_files", getSourceFilesCode(this.sourceFiles)));
/* 218 */     retval.append("      ").append(XMLHandler.addTagValue("evaluation_type", getEvaluationTypeCode(this.evaluationType)));
/* 219 */     retval.append("      ").append(XMLHandler.addTagValue("scale", getScaleCode(this.scale)));
/* 220 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public static String getIncludeSubFolders(String tt) {
/* 224 */     if (tt == null) return IncludeSubFoldersCodes[0];
/* 225 */     if (tt.equals(IncludeSubFoldersDesc[1])) {
/* 226 */       return IncludeSubFoldersCodes[1];
/*     */     }
/* 228 */     return IncludeSubFoldersCodes[0];
/*     */   }
/*     */   
/* 231 */   public static String getIncludeSubFoldersDesc(String tt) { if (tt == null) return IncludeSubFoldersDesc[0];
/* 232 */     if (tt.equals(IncludeSubFoldersCodes[1])) {
/* 233 */       return IncludeSubFoldersDesc[1];
/*     */     }
/* 235 */     return IncludeSubFoldersDesc[0];
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try {
/* 241 */       super.loadXML(entrynode, databases, slaveServers);
/*     */       
/* 243 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 246 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 247 */       this.source_filefolder = new String[nrFields];
/* 248 */       this.wildcard = new String[nrFields];
/* 249 */       this.includeSubFolders = new String[nrFields];
/*     */       
/* 251 */       for (int i = 0; i < nrFields; i++)
/*     */       {
/* 253 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 255 */         this.source_filefolder[i] = XMLHandler.getTagValue(fnode, "source_filefolder");
/* 256 */         this.wildcard[i] = XMLHandler.getTagValue(fnode, "wildcard");
/* 257 */         this.includeSubFolders[i] = XMLHandler.getTagValue(fnode, "include_subFolders");
/*     */       }
/*     */       
/* 260 */       this.resultFilenamesWildcard = XMLHandler.getTagValue(entrynode, "result_filenames_wildcard");
/* 261 */       this.ResultFieldFile = XMLHandler.getTagValue(entrynode, "result_field_file");
/* 262 */       this.ResultFieldWildcard = XMLHandler.getTagValue(entrynode, "result_field_wildcard");
/* 263 */       this.ResultFieldIncludesubFolders = XMLHandler.getTagValue(entrynode, "result_field_includesubfolders");
/* 264 */       this.comparevalue = XMLHandler.getTagValue(entrynode, "comparevalue");
/* 265 */       this.minvalue = XMLHandler.getTagValue(entrynode, "minvalue");
/* 266 */       this.maxvalue = XMLHandler.getTagValue(entrynode, "maxvalue");
/* 267 */       this.successnumbercondition = JobEntrySimpleEval.getSuccessNumberConditionByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "successnumbercondition"), ""));
/* 268 */       this.sourceFiles = getSourceFilesByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "source_files"), ""));
/* 269 */       this.evaluationType = getEvaluationTypeByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "evaluation_type"), ""));
/* 270 */       this.scale = getScaleByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "scale"), ""));
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 274 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.Exception.UnableLoadXML", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 283 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "source_filefolder");
/* 284 */       this.source_filefolder = new String[argnr];
/* 285 */       this.wildcard = new String[argnr];
/* 286 */       this.includeSubFolders = new String[argnr];
/*     */       
/* 288 */       for (int a = 0; a < argnr; a++)
/*     */       {
/* 290 */         this.source_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_filefolder");
/* 291 */         this.wildcard[a] = rep.getJobEntryAttributeString(id_jobentry, a, "wildcard");
/* 292 */         this.includeSubFolders[a] = rep.getJobEntryAttributeString(id_jobentry, a, "include_subFolders");
/*     */       }
/*     */       
/* 295 */       this.resultFilenamesWildcard = rep.getJobEntryAttributeString(id_jobentry, "result_filenames_wildcard");
/* 296 */       this.ResultFieldFile = rep.getJobEntryAttributeString(id_jobentry, "result_field_file");
/* 297 */       this.ResultFieldWildcard = rep.getJobEntryAttributeString(id_jobentry, "result_field_wildcard");
/* 298 */       this.ResultFieldIncludesubFolders = rep.getJobEntryAttributeString(id_jobentry, "result_field_includesubfolders");
/* 299 */       this.comparevalue = rep.getJobEntryAttributeString(id_jobentry, "comparevalue");
/* 300 */       this.minvalue = rep.getJobEntryAttributeString(id_jobentry, "minvalue");
/* 301 */       this.maxvalue = rep.getJobEntryAttributeString(id_jobentry, "maxvalue");
/* 302 */       this.successnumbercondition = JobEntrySimpleEval.getSuccessNumberConditionByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "successnumbercondition"), ""));
/* 303 */       this.sourceFiles = getSourceFilesByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "source_files"), ""));
/* 304 */       this.evaluationType = getEvaluationTypeByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "evaluation_type"), ""));
/* 305 */       this.scale = getScaleByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "scale"), ""));
/*     */ 
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 310 */       throw new KettleException(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.Exception.UnableLoadRep", new String[0]) + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 320 */       if (this.source_filefolder != null)
/*     */       {
/* 322 */         for (int i = 0; i < this.source_filefolder.length; i++)
/*     */         {
/* 324 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_filefolder", this.source_filefolder[i]);
/* 325 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "wildcard", this.wildcard[i]);
/* 326 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "include_subFolders", this.includeSubFolders[i]);
/*     */         }
/*     */       }
/*     */       
/* 330 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "result_filenames_wildcard", this.resultFilenamesWildcard);
/* 331 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "result_field_file", this.ResultFieldFile);
/* 332 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "result_field_wild", this.ResultFieldWildcard);
/* 333 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "result_field_includesubfolders", this.ResultFieldIncludesubFolders);
/* 334 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "comparevalue", this.comparevalue);
/* 335 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "minvalue", this.minvalue);
/* 336 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "maxvalue", this.maxvalue);
/* 337 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "successnumbercondition", JobEntrySimpleEval.getSuccessNumberConditionCode(this.successnumbercondition));
/* 338 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "scale", getScaleCode(this.scale));
/* 339 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "source_files", getSourceFilesCode(this.sourceFiles));
/* 340 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "evaluation_type", getEvaluationTypeCode(this.evaluationType));
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 344 */       throw new KettleException(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.Exception.UnableSaveRep", new String[0]) + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */     throws KettleException
/*     */   {
/* 351 */     Result result = previousResult;
/* 352 */     result.setNrErrors(1L);
/* 353 */     result.setResult(false);
/*     */     
/* 355 */     List<RowMetaAndData> rows = result.getRows();
/* 356 */     RowMetaAndData resultRow = null;
/*     */     try
/*     */     {
/* 359 */       initMetrics();
/*     */     } catch (Exception e) {
/* 361 */       logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.Init", new String[] { e.toString() }));
/* 362 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 366 */     String[] vsourcefilefolder = this.source_filefolder;
/* 367 */     String[] vwildcard = this.wildcard;
/* 368 */     String[] vincludeSubFolders = this.includeSubFolders;
/*     */     Pattern pattern;
/*     */     Iterator<ResultFile> it;
/* 371 */     switch (getSourceFiles())
/*     */     {
/*     */ 
/*     */     case 2: 
/* 375 */       String realResultFieldFile = environmentSubstitute(getResultFieldFile());
/* 376 */       String realResultFieldWildcard = environmentSubstitute(getResultFieldWildcard());
/* 377 */       String realResultFieldIncluseSubfolders = environmentSubstitute(getResultFieldIncludeSubfolders());
/*     */       
/* 379 */       int indexOfResultFieldFile = -1;
/* 380 */       if (Const.isEmpty(realResultFieldFile)) {
/* 381 */         logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.ResultFieldsFileMissing", new String[0]));
/* 382 */         return result;
/*     */       }
/*     */       
/* 385 */       int indexOfResultFieldWildcard = -1;
/* 386 */       int indexOfResultFieldIncludeSubfolders = -1;
/*     */       
/*     */ 
/* 389 */       if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.ArgFromPrevious.Found", new String[] { (rows != null ? rows.size() : 0) + "" }));
/*     */       }
/* 391 */       if ((rows != null) && (rows.size() > 0))
/*     */       {
/* 393 */         RowMetaAndData firstRow = (RowMetaAndData)rows.get(0);
/* 394 */         indexOfResultFieldFile = firstRow.getRowMeta().indexOfValue(realResultFieldFile);
/* 395 */         if (indexOfResultFieldFile == -1) {
/* 396 */           logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.CanNotFindField", new String[] { realResultFieldFile }));
/* 397 */           return result;
/*     */         }
/* 399 */         if (!Const.isEmpty(realResultFieldWildcard)) {
/* 400 */           indexOfResultFieldWildcard = firstRow.getRowMeta().indexOfValue(realResultFieldWildcard);
/* 401 */           if (indexOfResultFieldWildcard == -1) {
/* 402 */             logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.CanNotFindField", new String[] { realResultFieldWildcard }));
/* 403 */             return result;
/*     */           }
/*     */         }
/* 406 */         if (!Const.isEmpty(realResultFieldIncluseSubfolders)) {
/* 407 */           indexOfResultFieldIncludeSubfolders = firstRow.getRowMeta().indexOfValue(realResultFieldIncluseSubfolders);
/* 408 */           if (indexOfResultFieldIncludeSubfolders == -1) {
/* 409 */             logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.CanNotFindField", new String[] { realResultFieldIncluseSubfolders }));
/* 410 */             return result;
/*     */           }
/*     */         }
/*     */         
/* 414 */         for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++)
/*     */         {
/* 416 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*     */           
/*     */ 
/* 419 */           String vsourcefilefolder_previous = resultRow.getString(indexOfResultFieldFile, null);
/* 420 */           String vwildcard_previous = null;
/* 421 */           if (indexOfResultFieldWildcard > -1) {
/* 422 */             vwildcard_previous = resultRow.getString(indexOfResultFieldWildcard, null);
/*     */           }
/* 424 */           String vincludeSubFolders_previous = "N";
/* 425 */           if (indexOfResultFieldIncludeSubfolders > -1) {
/* 426 */             vincludeSubFolders_previous = resultRow.getString(indexOfResultFieldIncludeSubfolders, "N");
/*     */           }
/*     */           
/* 429 */           if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.ProcessingRow", new String[] { vsourcefilefolder_previous, vwildcard_previous }));
/*     */           }
/* 431 */           ProcessFileFolder(vsourcefilefolder_previous, vwildcard_previous, vincludeSubFolders_previous, this.parentJob, result);
/*     */         } }
/* 433 */       break;
/*     */     
/*     */ 
/*     */     case 1: 
/* 437 */       List<ResultFile> resultFiles = result.getResultFilesList();
/* 438 */       if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.ResultFilenames.Found", new String[] { (resultFiles != null ? resultFiles.size() : 0) + "" }));
/*     */       }
/* 440 */       if ((resultFiles != null) && (resultFiles.size() > 0))
/*     */       {
/* 442 */         pattern = null;
/* 443 */         String realPattern = environmentSubstitute(getResultFilenamesWildcard());
/* 444 */         if (!Const.isEmpty(realPattern)) {
/* 445 */           pattern = Pattern.compile(realPattern);
/*     */         }
/*     */         
/* 448 */         for (it = resultFiles.iterator(); (it.hasNext()) && (!this.parentJob.isStopped());) {
/* 449 */           ResultFile resultFile = (ResultFile)it.next();
/* 450 */           FileObject file = resultFile.getFile();
/*     */           try {
/* 452 */             if ((file != null) && (file.exists())) {
/* 453 */               boolean getIt = true;
/* 454 */               if (pattern != null) {
/* 455 */                 Matcher matcher = pattern.matcher(file.getName().getBaseName());
/* 456 */                 getIt = matcher.matches();
/*     */               }
/* 458 */               if (getIt) {
/* 459 */                 getFileSize(file, result, this.parentJob);
/*     */               }
/*     */             }
/*     */           } catch (Exception e) {
/* 463 */             incrementErrors();
/* 464 */             logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.GettingFileFromResultFilenames", new String[] { file.toString(), e.toString() }));
/*     */           } finally {
/* 466 */             if (file != null) try { file.close();
/*     */               } catch (Exception e) {}
/*     */           } } }
/* 469 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     default: 
/* 474 */       if ((vsourcefilefolder != null) && (vsourcefilefolder.length > 0)) {
/* 475 */         for (int i = 0; (i < vsourcefilefolder.length) && (!this.parentJob.isStopped()); i++)
/*     */         {
/* 477 */           if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.ProcessingRow", new String[] { vsourcefilefolder[i], vwildcard[i] }));
/*     */           }
/* 479 */           ProcessFileFolder(vsourcefilefolder[i], vwildcard[i], vincludeSubFolders[i], this.parentJob, result);
/*     */         }
/*     */       } else {
/* 482 */         logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.FilesGridEmpty", new String[0]));
/* 483 */         return result;
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/* 489 */     result.setResult(isSuccess());
/* 490 */     result.setNrErrors(getNrError());
/* 491 */     displayResults();
/*     */     
/* 493 */     return result;
/*     */   }
/*     */   
/* 496 */   private void displayResults() { if (isDetailed()) {
/* 497 */       logDetailed("=======================================");
/* 498 */       logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.Info.FilesCount", new String[] { String.valueOf(getFilesCount()) }));
/* 499 */       if (this.evaluationType == 0) {
/* 500 */         logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.Info.FilesSize", new String[] { String.valueOf(getEvaluationValue()) }));
/*     */       }
/* 502 */       logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.Info.NrErrors", new String[] { String.valueOf(getNrError()) }));
/* 503 */       logDetailed("=======================================");
/*     */     }
/*     */   }
/*     */   
/* 507 */   private long getNrError() { return this.nrErrors; }
/*     */   
/*     */   private BigDecimal getEvaluationValue() {
/* 510 */     return this.evaluationValue;
/*     */   }
/*     */   
/*     */   private BigDecimal getFilesCount() {
/* 514 */     return this.filesCount;
/*     */   }
/*     */   
/*     */   private boolean isSuccess() {
/* 518 */     boolean retval = false;
/*     */     
/* 520 */     switch (this.successnumbercondition) {
/*     */     case 0: 
/* 522 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValue", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.compareValue) }));
/* 523 */       retval = getEvaluationValue().compareTo(this.compareValue) == 0;
/* 524 */       break;
/*     */     case 1: 
/* 526 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValue", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.compareValue) }));
/* 527 */       retval = getEvaluationValue().compareTo(this.compareValue) != 0;
/* 528 */       break;
/*     */     case 2: 
/* 530 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValue", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.compareValue) }));
/* 531 */       retval = getEvaluationValue().compareTo(this.compareValue) < 0;
/* 532 */       break;
/*     */     case 3: 
/* 534 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValue", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.compareValue) }));
/* 535 */       retval = getEvaluationValue().compareTo(this.compareValue) <= 0;
/* 536 */       break;
/*     */     case 4: 
/* 538 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValue", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.compareValue) }));
/* 539 */       retval = getEvaluationValue().compareTo(this.compareValue) > 0;
/* 540 */       break;
/*     */     case 5: 
/* 542 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValue", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.compareValue) }));
/* 543 */       retval = getEvaluationValue().compareTo(this.compareValue) >= 0;
/* 544 */       break;
/*     */     case 6: 
/* 546 */       if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.CompareWithValues", new String[] { String.valueOf(this.evaluationValue), String.valueOf(this.minValue), String.valueOf(this.maxValue) }));
/* 547 */       retval = (getEvaluationValue().compareTo(this.minValue) >= 0) && (getEvaluationValue().compareTo(this.maxValue) <= 0);
/* 548 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 553 */     return retval;
/*     */   }
/*     */   
/* 556 */   private void initMetrics() throws Exception { this.evaluationValue = new BigDecimal(0);
/* 557 */     this.filesCount = new BigDecimal(0);
/* 558 */     this.nrErrors = 0L;
/*     */     
/* 560 */     if (this.successnumbercondition == 6) {
/* 561 */       this.minValue = new BigDecimal(environmentSubstitute(getMinValue()));
/* 562 */       this.maxValue = new BigDecimal(environmentSubstitute(getMaxValue()));
/*     */     } else {
/* 564 */       this.compareValue = new BigDecimal(environmentSubstitute(getCompareValue()));
/*     */     }
/*     */     
/* 567 */     if (this.evaluationType == 0) {
/* 568 */       int multyply = 1;
/* 569 */       switch (getScale()) {
/*     */       case 1: 
/* 571 */         multyply = 1024;
/* 572 */         break;
/*     */       case 2: 
/* 574 */         multyply = 1048576;
/* 575 */         break;
/*     */       case 3: 
/* 577 */         multyply = 1073741824;
/* 578 */         break;
/*     */       }
/*     */       
/*     */       
/*     */ 
/* 583 */       if (this.successnumbercondition == 6) {
/* 584 */         this.minValue = this.minValue.multiply(BigDecimal.valueOf(multyply));
/* 585 */         this.maxValue = this.maxValue.multiply(BigDecimal.valueOf(multyply));
/*     */       } else {
/* 587 */         this.compareValue = this.compareValue.multiply(BigDecimal.valueOf(multyply));
/*     */       }
/*     */     }
/* 590 */     this.arg_from_previous = (getSourceFiles() == 2);
/*     */   }
/*     */   
/* 593 */   private void incrementErrors() { this.nrErrors += 1L; }
/*     */   
/*     */   public int getSourceFiles()
/*     */   {
/* 597 */     return this.sourceFiles;
/*     */   }
/*     */   
/*     */   private void incrementFilesCount() {
/* 601 */     this.filesCount = this.filesCount.add(ONE);
/*     */   }
/*     */   
/*     */   public String getResultFieldFile() {
/* 605 */     return this.ResultFieldFile;
/*     */   }
/*     */   
/* 608 */   public void setResultFieldFile(String field) { this.ResultFieldFile = field; }
/*     */   
/*     */   public String getResultFieldWildcard() {
/* 611 */     return this.ResultFieldWildcard;
/*     */   }
/*     */   
/* 614 */   public void setResultFieldWildcard(String field) { this.ResultFieldWildcard = field; }
/*     */   
/*     */   public String getResultFieldIncludeSubfolders() {
/* 617 */     return this.ResultFieldIncludesubFolders;
/*     */   }
/*     */   
/* 620 */   public void setResultFieldIncludeSubfolders(String field) { this.ResultFieldIncludesubFolders = field; }
/*     */   
/*     */ 
/*     */   private void ProcessFileFolder(String sourcefilefoldername, String wildcard, String includeSubfolders, Job parentJob, Result result)
/*     */   {
/* 625 */     FileObject sourcefilefolder = null;
/* 626 */     FileObject CurrentFile = null;
/*     */     
/*     */ 
/* 629 */     String realSourceFilefoldername = environmentSubstitute(sourcefilefoldername);
/* 630 */     if (Const.isEmpty(realSourceFilefoldername))
/*     */     {
/* 632 */       logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.log.FileFolderEmpty", new String[0]));
/* 633 */       incrementErrors();
/* 634 */       return;
/*     */     }
/* 636 */     String realWildcard = environmentSubstitute(wildcard);
/* 637 */     final boolean include_subfolders = "Y".equalsIgnoreCase(includeSubfolders);
/*     */     try
/*     */     {
/* 640 */       sourcefilefolder = KettleVFS.getFileObject(realSourceFilefoldername);
/*     */       
/* 642 */       if (sourcefilefolder.exists())
/*     */       {
/* 644 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.FileExists", new String[] { sourcefilefolder.toString() }));
/*     */         }
/* 646 */         if (sourcefilefolder.getType() == FileType.FILE)
/*     */         {
/*     */ 
/* 649 */           getFileSize(sourcefilefolder, result, parentJob);
/*     */         }
/* 651 */         else if (sourcefilefolder.getType() == FileType.FOLDER)
/*     */         {
/*     */ 
/* 654 */           FileObject[] fileObjects = sourcefilefolder.findFiles(new AllFileSelector()
/*     */           {
/*     */             public boolean traverseDescendents(FileSelectInfo info) {
/* 657 */               return (info.getDepth() == 0) || (include_subfolders);
/*     */             }
/*     */             
/*     */             public boolean includeFile(FileSelectInfo info) {
/* 661 */               FileObject fileObject = info.getFile();
/*     */               try { boolean bool1;
/* 663 */                 if (fileObject == null) return false;
/* 664 */                 if (fileObject.getType() != FileType.FILE) return false;
/*     */               }
/*     */               catch (Exception ex) {
/* 667 */                 return false;
/*     */               } finally {
/* 669 */                 if (fileObject != null)
/* 670 */                   try { fileObject.close();
/*     */                   } catch (IOException ex) {}
/*     */               }
/* 673 */               return true;
/*     */             }
/*     */           });
/*     */           
/*     */ 
/* 678 */           if (fileObjects != null) {
/* 679 */             for (int j = 0; (j < fileObjects.length) && (!parentJob.isStopped()); j++)
/*     */             {
/* 681 */               CurrentFile = fileObjects[j];
/*     */               
/* 683 */               if (!CurrentFile.getParent().toString().equals(sourcefilefolder.toString()))
/*     */               {
/* 685 */                 if ((include_subfolders) && 
/* 686 */                   (GetFileWildcard(CurrentFile.getName().getBaseName(), realWildcard))) {
/* 687 */                   getFileSize(CurrentFile, result, parentJob);
/*     */                 }
/*     */                 
/*     */ 
/*     */               }
/* 692 */               else if (GetFileWildcard(CurrentFile.getName().getBaseName(), realWildcard)) {
/* 693 */                 getFileSize(CurrentFile, result, parentJob);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 699 */           incrementErrors();
/* 700 */           logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.UnknowFileFormat", new String[] { sourcefilefolder.toString() }));
/*     */         }
/*     */       } else {
/* 703 */         incrementErrors();
/* 704 */         logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.SourceFileNotExists", new String[] { realSourceFilefoldername }));
/*     */       }
/*     */     } catch (Exception e) {
/* 707 */       incrementErrors();
/* 708 */       logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.Exception.Processing", new String[] { realSourceFilefoldername.toString(), e.getMessage() }));
/*     */     }
/*     */     finally {
/* 711 */       if (sourcefilefolder != null) {
/*     */         try {
/* 713 */           sourcefilefolder.close();
/*     */         } catch (IOException ex) {}
/*     */       }
/* 716 */       if (CurrentFile != null) {
/*     */         try {
/* 718 */           CurrentFile.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void getFileSize(FileObject file, Result result, Job parentJob)
/*     */   {
/*     */     try {
/* 728 */       incrementFilesCount();
/* 729 */       if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.GetFile", new String[] { file.toString(), String.valueOf(getFilesCount()) }));
/* 730 */       switch (this.evaluationType) {
/*     */       case 0: 
/* 732 */         BigDecimal fileSize = BigDecimal.valueOf(file.getContent().getSize());
/* 733 */         this.evaluationValue = this.evaluationValue.add(fileSize);
/* 734 */         if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Log.AddedFileSize", new String[] { String.valueOf(fileSize), file.toString() }));
/*     */         break;
/*     */       default: 
/* 737 */         this.evaluationValue = this.evaluationValue.add(ONE);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 741 */       incrementErrors();
/* 742 */       logError(BaseMessages.getString(PKG, "JobEvalFilesMetrics.Error.GettingFileSize", new String[] { file.toString(), e.toString() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*     */   {
/* 755 */     Pattern pattern = null;
/* 756 */     boolean getIt = true;
/*     */     
/* 758 */     if (!Const.isEmpty(wildcard)) {
/* 759 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 761 */       if (pattern != null) {
/* 762 */         Matcher matcher = pattern.matcher(selectedfile);
/* 763 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 767 */     return getIt;
/*     */   }
/*     */   
/*     */   public void setMinValue(String minvalue) {
/* 771 */     this.minvalue = minvalue;
/*     */   }
/*     */   
/*     */   public String getMinValue() {
/* 775 */     return this.minvalue;
/*     */   }
/*     */   
/* 778 */   public void setCompareValue(String comparevalue) { this.comparevalue = comparevalue; }
/*     */   
/*     */   public String getCompareValue() {
/* 781 */     return this.comparevalue;
/*     */   }
/*     */   
/* 784 */   public void setResultFilenamesWildcard(String resultwildcard) { this.resultFilenamesWildcard = resultwildcard; }
/*     */   
/*     */   public String getResultFilenamesWildcard() {
/* 787 */     return this.resultFilenamesWildcard;
/*     */   }
/*     */   
/*     */   public void setMaxValue(String maxvalue) {
/* 791 */     this.maxvalue = maxvalue;
/*     */   }
/*     */   
/*     */ 
/* 795 */   public String getMaxValue() { return this.maxvalue; }
/*     */   
/*     */   public static int getScaleByDesc(String tt) {
/* 798 */     if (tt == null) {
/* 799 */       return 0;
/*     */     }
/* 801 */     for (int i = 0; i < scaleDesc.length; i++) {
/* 802 */       if (scaleDesc[i].equalsIgnoreCase(tt)) {
/* 803 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 807 */     return getScaleByCode(tt);
/*     */   }
/*     */   
/* 810 */   public static int getSourceFilesByDesc(String tt) { if (tt == null) {
/* 811 */       return 0;
/*     */     }
/* 813 */     for (int i = 0; i < SourceFilesDesc.length; i++) {
/* 814 */       if (SourceFilesDesc[i].equalsIgnoreCase(tt)) {
/* 815 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 819 */     return getSourceFilesByCode(tt);
/*     */   }
/*     */   
/*     */   public static int getEvaluationTypeByDesc(String tt) {
/* 823 */     if (tt == null) {
/* 824 */       return 0;
/*     */     }
/* 826 */     for (int i = 0; i < EvaluationTypeDesc.length; i++) {
/* 827 */       if (EvaluationTypeDesc[i].equalsIgnoreCase(tt)) {
/* 828 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 832 */     return getEvaluationTypeByCode(tt);
/*     */   }
/*     */   
/*     */   private static int getScaleByCode(String tt) {
/* 836 */     if (tt == null) {
/* 837 */       return 0;
/*     */     }
/* 839 */     for (int i = 0; i < scaleCodes.length; i++) {
/* 840 */       if (scaleCodes[i].equalsIgnoreCase(tt))
/* 841 */         return i;
/*     */     }
/* 843 */     return 0;
/*     */   }
/*     */   
/* 846 */   private static int getSourceFilesByCode(String tt) { if (tt == null) {
/* 847 */       return 0;
/*     */     }
/* 849 */     for (int i = 0; i < SourceFilesCodes.length; i++) {
/* 850 */       if (SourceFilesCodes[i].equalsIgnoreCase(tt))
/* 851 */         return i;
/*     */     }
/* 853 */     return 0;
/*     */   }
/*     */   
/*     */   private static int getEvaluationTypeByCode(String tt) {
/* 857 */     if (tt == null) {
/* 858 */       return 0;
/*     */     }
/* 860 */     for (int i = 0; i < EvaluationTypeCodes.length; i++) {
/* 861 */       if (EvaluationTypeCodes[i].equalsIgnoreCase(tt))
/* 862 */         return i;
/*     */     }
/* 864 */     return 0;
/*     */   }
/*     */   
/*     */   public static String getScaleDesc(int i) {
/* 868 */     if ((i < 0) || (i >= scaleDesc.length))
/* 869 */       return scaleDesc[0];
/* 870 */     return scaleDesc[i];
/*     */   }
/*     */   
/* 873 */   public static String getEvaluationTypeDesc(int i) { if ((i < 0) || (i >= EvaluationTypeDesc.length))
/* 874 */       return EvaluationTypeDesc[0];
/* 875 */     return EvaluationTypeDesc[i];
/*     */   }
/*     */   
/* 878 */   public static String getSourceFilesDesc(int i) { if ((i < 0) || (i >= SourceFilesDesc.length))
/* 879 */       return SourceFilesDesc[0];
/* 880 */     return SourceFilesDesc[i];
/*     */   }
/*     */   
/* 883 */   public static String getScaleCode(int i) { if ((i < 0) || (i >= scaleCodes.length))
/* 884 */       return scaleCodes[0];
/* 885 */     return scaleCodes[i];
/*     */   }
/*     */   
/* 888 */   public static String getSourceFilesCode(int i) { if ((i < 0) || (i >= SourceFilesCodes.length))
/* 889 */       return SourceFilesCodes[0];
/* 890 */     return SourceFilesCodes[i];
/*     */   }
/*     */   
/* 893 */   public static String getEvaluationTypeCode(int i) { if ((i < 0) || (i >= EvaluationTypeCodes.length))
/* 894 */       return EvaluationTypeCodes[0];
/* 895 */     return EvaluationTypeCodes[i];
/*     */   }
/*     */   
/* 898 */   public int getScale() { return this.scale; }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 903 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */     
/* 905 */     if (!res)
/*     */     {
/* 907 */       return;
/*     */     }
/*     */     
/* 910 */     ValidatorContext ctx = new ValidatorContext();
/* 911 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 912 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*     */     
/* 914 */     for (int i = 0; i < this.source_filefolder.length; i++)
/*     */     {
/* 916 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx); }
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 920 */     return true;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\evalfilesmetrics\JobEntryEvalFilesMetrics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */