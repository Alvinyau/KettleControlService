/*     */ package org.pentaho.di.job.entries.addresultfilenames;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileSelector;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryAddResultFilenames
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  71 */   private static Class<?> PKG = JobEntryAddResultFilenames.class;
/*     */   
/*     */   public boolean argFromPrevious;
/*     */   
/*     */   public boolean deleteallbefore;
/*     */   
/*     */   public boolean includeSubfolders;
/*     */   
/*     */   public String[] arguments;
/*     */   public String[] filemasks;
/*     */   
/*     */   public JobEntryAddResultFilenames(String n)
/*     */   {
/*  84 */     super(n, "");
/*  85 */     this.argFromPrevious = false;
/*  86 */     this.deleteallbefore = false;
/*  87 */     this.arguments = null;
/*     */     
/*  89 */     this.includeSubfolders = false;
/*  90 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryAddResultFilenames() {
/*  94 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  98 */     JobEntryAddResultFilenames je = (JobEntryAddResultFilenames)super.clone();
/*  99 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML() {
/* 103 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 105 */     retval.append(super.getXML());
/* 106 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.argFromPrevious));
/* 107 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.includeSubfolders));
/* 108 */     retval.append("      ").append(XMLHandler.addTagValue("delete_all_before", this.deleteallbefore));
/*     */     
/*     */ 
/* 111 */     retval.append("      <fields>").append(Const.CR);
/* 112 */     if (this.arguments != null) {
/* 113 */       for (int i = 0; i < this.arguments.length; i++) {
/* 114 */         retval.append("        <field>").append(Const.CR);
/* 115 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.arguments[i]));
/* 116 */         retval.append("          ").append(XMLHandler.addTagValue("filemask", this.filemasks[i]));
/* 117 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 120 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/* 122 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 129 */       super.loadXML(entrynode, databases, slaveServers);
/* 130 */       this.argFromPrevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/* 131 */       this.includeSubfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/* 132 */       this.deleteallbefore = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "delete_all_before"));
/*     */       
/*     */ 
/* 135 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 138 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 139 */       this.arguments = new String[nrFields];
/* 140 */       this.filemasks = new String[nrFields];
/*     */       
/*     */ 
/* 143 */       for (int i = 0; i < nrFields; i++) {
/* 144 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 146 */         this.arguments[i] = XMLHandler.getTagValue(fnode, "name");
/* 147 */         this.filemasks[i] = XMLHandler.getTagValue(fnode, "filemask");
/*     */       }
/*     */     } catch (KettleXMLException xe) {
/* 150 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.UnableToLoadFromXml", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 158 */       this.argFromPrevious = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/* 159 */       this.includeSubfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*     */       
/* 161 */       this.deleteallbefore = rep.getJobEntryAttributeBoolean(id_jobentry, "delete_all_before");
/*     */       
/*     */ 
/* 164 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "name");
/* 165 */       this.arguments = new String[argnr];
/* 166 */       this.filemasks = new String[argnr];
/*     */       
/*     */ 
/* 169 */       for (int a = 0; a < argnr; a++) {
/* 170 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "name");
/* 171 */         this.filemasks[a] = rep.getJobEntryAttributeString(id_jobentry, a, "filemask");
/*     */       }
/*     */     } catch (KettleException dbe) {
/* 174 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException {
/*     */     try {
/* 180 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.argFromPrevious);
/* 181 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.includeSubfolders);
/* 182 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "delete_all_before", this.deleteallbefore);
/*     */       
/*     */ 
/* 185 */       if (this.arguments != null) {
/* 186 */         for (int i = 0; i < this.arguments.length; i++) {
/* 187 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "name", this.arguments[i]);
/* 188 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "filemask", this.filemasks[i]);
/*     */         }
/*     */       }
/*     */     } catch (KettleDatabaseException dbe) {
/* 192 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public Result execute(Result result, int nr) throws KettleException {
/* 197 */     List<RowMetaAndData> rows = result.getRows();
/* 198 */     RowMetaAndData resultRow = null;
/*     */     
/* 200 */     int nrErrFiles = 0;
/* 201 */     result.setResult(true);
/*     */     
/*     */ 
/* 204 */     if (this.deleteallbefore)
/*     */     {
/*     */ 
/* 207 */       int size = result.getResultFiles().size();
/* 208 */       if (this.log.isBasic()) { logBasic(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.log.FilesFound", new String[] { "" + size }));
/*     */       }
/* 210 */       result.getResultFiles().clear();
/* 211 */       if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.log.DeletedFiles", new String[] { "" + size }));
/*     */       }
/*     */     }
/*     */     
/* 215 */     if (this.argFromPrevious)
/*     */     {
/* 217 */       if (this.log.isDetailed()) {
/* 218 */         logDetailed(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.FoundPreviousRows", new String[] { String.valueOf(rows != null ? rows.size() : 0) }));
/*     */       }
/*     */     }
/* 221 */     if ((this.argFromPrevious) && (rows != null))
/*     */     {
/* 223 */       for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++) {
/* 224 */         resultRow = (RowMetaAndData)rows.get(iteration);
/*     */         
/*     */ 
/* 227 */         String filefolder_previous = resultRow.getString(0, null);
/* 228 */         String fmasks_previous = resultRow.getString(1, null);
/*     */         
/*     */ 
/* 231 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.ProcessingRow", new String[] { filefolder_previous, fmasks_previous }));
/*     */         }
/* 233 */         if (!processFile(filefolder_previous, fmasks_previous, this.parentJob, result)) {
/* 234 */           nrErrFiles++;
/*     */         }
/*     */         
/*     */       }
/* 238 */     } else if (this.arguments != null)
/*     */     {
/* 240 */       for (int i = 0; (i < this.arguments.length) && (!this.parentJob.isStopped()); i++)
/*     */       {
/*     */ 
/* 243 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.ProcessingArg", new String[] { this.arguments[i], this.filemasks[i] }));
/* 244 */         if (!processFile(this.arguments[i], this.filemasks[i], this.parentJob, result)) {
/* 245 */           nrErrFiles++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 251 */     if (nrErrFiles > 0)
/*     */     {
/* 253 */       result.setResult(false);
/* 254 */       result.setNrErrors(nrErrFiles);
/*     */     }
/*     */     
/*     */ 
/* 258 */     return result;
/*     */   }
/*     */   
/*     */   private boolean processFile(String filename, String wildcard, Job parentJob, Result result)
/*     */   {
/* 263 */     boolean rcode = true;
/* 264 */     FileObject filefolder = null;
/* 265 */     String realFilefoldername = environmentSubstitute(filename);
/* 266 */     String realwildcard = environmentSubstitute(wildcard);
/*     */     try
/*     */     {
/* 269 */       filefolder = KettleVFS.getFileObject(realFilefoldername, this);
/*     */       
/* 271 */       if (filefolder.exists())
/*     */       {
/*     */ 
/* 274 */         if (filefolder.getType() == FileType.FILE)
/*     */         {
/*     */ 
/* 277 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.AddingFileToResult", new String[] { filefolder.toString() }));
/* 278 */           ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(filefolder.toString(), this), parentJob.getJobname(), toString());
/* 279 */           result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */         }
/*     */         else
/*     */         {
/* 283 */           FileObject[] list = filefolder.findFiles(new TextFileSelector(filefolder.toString(), realwildcard));
/*     */           
/* 285 */           for (int i = 0; (i < list.length) && (!parentJob.isStopped()); i++)
/*     */           {
/*     */ 
/* 288 */             if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.AddingFileToResult", new String[] { list[i].toString() }));
/* 289 */             ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(list[i].toString(), this), parentJob.getJobname(), toString());
/* 290 */             result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 296 */         if (this.log.isBasic()) logBasic(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.FileCanNotbeFound", new String[] { realFilefoldername }));
/* 297 */         rcode = false;
/*     */       }
/*     */     } catch (Exception e) {
/* 300 */       rcode = false;
/* 301 */       logError(BaseMessages.getString(PKG, "JobEntryAddResultFilenames.CouldNotProcess", new String[] { realFilefoldername, e.getMessage() }), e);
/*     */     } finally {
/* 303 */       if (filefolder != null) {
/*     */         try {
/* 305 */           filefolder.close();
/* 306 */           filefolder = null;
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 313 */     return rcode;
/*     */   }
/*     */   
/*     */   private class TextFileSelector
/*     */     implements FileSelector
/*     */   {
/* 319 */     String source_folder = null; String file_wildcard = null;
/*     */     
/*     */     public TextFileSelector(String sourcefolderin, String filewildcard)
/*     */     {
/* 323 */       if (!Const.isEmpty(sourcefolderin)) {
/* 324 */         this.source_folder = sourcefolderin;
/*     */       }
/* 326 */       if (!Const.isEmpty(filewildcard)) {
/* 327 */         this.file_wildcard = filewildcard;
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean includeFile(FileSelectInfo info) {
/* 332 */       boolean returncode = false;
/*     */       try
/*     */       {
/* 335 */         if (!info.getFile().toString().equals(this.source_folder))
/*     */         {
/*     */ 
/* 338 */           String short_filename = info.getFile().getName().getBaseName();
/*     */           
/* 340 */           if ((info.getFile().getParent().equals(info.getBaseFolder())) || ((!info.getFile().getParent().equals(info.getBaseFolder())) && (JobEntryAddResultFilenames.this.includeSubfolders)))
/*     */           {
/*     */ 
/* 343 */             if (((info.getFile().getType() == FileType.FILE) && (this.file_wildcard == null)) || ((info.getFile().getType() == FileType.FILE) && (this.file_wildcard != null) && (JobEntryAddResultFilenames.this.GetFileWildcard(short_filename, this.file_wildcard))))
/*     */             {
/* 345 */               returncode = true;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 351 */         JobEntryAddResultFilenames.this.logError("Error while finding files ... in [" + info.getFile().toString() + "]. Exception :" + e.getMessage());
/* 352 */         returncode = false;
/*     */       }
/* 354 */       return returncode;
/*     */     }
/*     */     
/*     */     public boolean traverseDescendents(FileSelectInfo info)
/*     */     {
/* 359 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*     */   {
/* 371 */     Pattern pattern = null;
/* 372 */     boolean getIt = true;
/*     */     
/* 374 */     if (!Const.isEmpty(wildcard))
/*     */     {
/* 376 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 378 */       if (pattern != null)
/*     */       {
/* 380 */         Matcher matcher = pattern.matcher(selectedfile);
/* 381 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 385 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIncludeSubfolders(boolean includeSubfolders)
/*     */   {
/* 391 */     this.includeSubfolders = includeSubfolders;
/*     */   }
/*     */   
/*     */   public void setArgumentsPrevious(boolean argFromPrevious)
/*     */   {
/* 396 */     this.argFromPrevious = argFromPrevious;
/*     */   }
/*     */   
/* 399 */   public void setDeleteAllBefore(boolean deleteallbefore) { this.deleteallbefore = deleteallbefore; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 406 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isArgFromPrevious()
/*     */   {
/* 413 */     return this.argFromPrevious;
/*     */   }
/*     */   
/*     */   public boolean deleteAllBefore()
/*     */   {
/* 418 */     return this.deleteallbefore;
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] getArguments()
/*     */   {
/* 424 */     return this.arguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getFilemasks()
/*     */   {
/* 431 */     return this.filemasks;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubfolders()
/*     */   {
/* 436 */     return this.includeSubfolders;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 441 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */     
/* 443 */     if (!res)
/*     */     {
/* 445 */       return;
/*     */     }
/*     */     
/* 448 */     ValidatorContext ctx = new ValidatorContext();
/* 449 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 450 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*     */     
/* 452 */     for (int i = 0; i < this.arguments.length; i++)
/*     */     {
/* 454 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\addresultfilenames\JobEntryAddResultFilenames.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */