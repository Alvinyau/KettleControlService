/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.prefs.BackingStoreException;
/*     */ import java.util.prefs.Preferences;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.pentaho.di.core.Counter;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.trans.step.BaseStepMeta;
/*     */ import org.pentaho.di.trans.step.StepDataInterface;
/*     */ import org.pentaho.di.trans.step.StepMetaInterface;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStepMeta
/*     */   extends BaseStepMeta
/*     */   implements StepMetaInterface
/*     */ {
/*     */   private static final String CONNECTION_NAME = "connection";
/*  59 */   private final PluginPropertyFactory propertyFactory = new PluginPropertyFactory(new KeyValueSet());
/*     */   
/*     */ 
/*     */   private DatabaseMeta dbMeta;
/*     */   
/*     */ 
/*     */   private StringPluginProperty connectionName;
/*     */   
/*     */ 
/*     */   public AbstractStepMeta()
/*     */   {
/*  70 */     this.connectionName = this.propertyFactory.createString("connection");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PluginPropertyFactory getPropertyFactory()
/*     */   {
/*  77 */     return this.propertyFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public KeyValueSet getProperties()
/*     */   {
/*  84 */     return this.propertyFactory.getProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveAsPreferences()
/*     */     throws BackingStoreException
/*     */   {
/*  94 */     Preferences node = Preferences.userNodeForPackage(getClass());
/*  95 */     getProperties().walk(new PluginPropertyHandler.SaveToPreferences(node));
/*  96 */     node.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readFromPreferences()
/*     */   {
/* 103 */     Preferences node = Preferences.userNodeForPackage(getClass());
/* 104 */     getProperties().walk(new PluginPropertyHandler.ReadFromPreferences(node));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadXML(Node node, List<DatabaseMeta> databaseMeta, Map<String, Counter> counters)
/*     */     throws KettleXMLException
/*     */   {
/* 114 */     getProperties().walk(new PluginPropertyHandler.LoadXml(node));
/* 115 */     initDbMeta(databaseMeta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initDbMeta(List<DatabaseMeta> databaseList)
/*     */   {
/* 123 */     if (!StringUtils.isEmpty((String)this.connectionName.getValue())) {
/* 124 */       this.dbMeta = DatabaseMeta.findDatabase(databaseList, (String)this.connectionName.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXML()
/*     */     throws KettleException
/*     */   {
/* 135 */     return PluginPropertyHandler.toXml(getProperties());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readRep(Repository repo, ObjectId stepId, List<DatabaseMeta> databaseList, Map<String, Counter> counters)
/*     */     throws KettleException
/*     */   {
/* 146 */     PluginPropertyHandler.walk(getProperties(), new PluginPropertyHandler.ReadFromRepository(repo, stepId));
/* 147 */     initDbMeta(databaseList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveRep(Repository repo, ObjectId transformationId, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/* 156 */     PluginPropertyHandler.SaveToRepository handler = new PluginPropertyHandler.SaveToRepository(repo, transformationId, stepId);
/* 157 */     PluginPropertyHandler.walk(getProperties(), handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StepDataInterface getStepData()
/*     */   {
/* 167 */     return new GenericStepData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StringPluginProperty getConnectionName()
/*     */   {
/* 174 */     return this.connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionName(StringPluginProperty connectionName)
/*     */   {
/* 182 */     this.connectionName = connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DatabaseMeta getDbMeta()
/*     */   {
/* 189 */     return this.dbMeta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDbMeta(DatabaseMeta dbMeta)
/*     */   {
/* 197 */     this.dbMeta = dbMeta;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\AbstractStepMeta.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */