/*      */ package org.pentaho.di.job.entries.getpop;
/*      */ 
/*      */ import com.sun.mail.imap.IMAPSSLStore;
/*      */ import com.sun.mail.pop3.POP3SSLStore;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.util.Date;
/*      */ import java.util.HashSet;
/*      */ import java.util.Properties;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Flags.Flag;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.Message.RecipientType;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Multipart;
/*      */ import javax.mail.Part;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.Store;
/*      */ import javax.mail.URLName;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ import javax.mail.search.AndTerm;
/*      */ import javax.mail.search.BodyTerm;
/*      */ import javax.mail.search.FlagTerm;
/*      */ import javax.mail.search.FromStringTerm;
/*      */ import javax.mail.search.NotTerm;
/*      */ import javax.mail.search.ReceivedDateTerm;
/*      */ import javax.mail.search.RecipientStringTerm;
/*      */ import javax.mail.search.SearchTerm;
/*      */ import javax.mail.search.SubjectTerm;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.logging.LogChannelInterface;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MailConnection
/*      */ {
/*   77 */   private static Class<?> PKG = JobEntryGetPOP.class;
/*      */   
/*      */   private String server;
/*      */   
/*      */   private int port;
/*      */   
/*      */   private String username;
/*      */   
/*      */   private String password;
/*      */   
/*      */   private boolean usessl;
/*      */   
/*      */   private boolean write;
/*      */   
/*      */   private boolean useproxy;
/*      */   
/*      */   private String proxyusername;
/*      */   
/*      */   private int protocol;
/*      */   
/*      */   private Properties prop;
/*   98 */   private Session session = null;
/*   99 */   private Store store = null;
/*  100 */   private Folder folder = null;
/*      */   
/*      */ 
/*      */   private Message[] messages;
/*      */   
/*      */ 
/*      */   private Message message;
/*      */   
/*      */ 
/*  109 */   private SearchTerm searchTerm = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int messagenr;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int nrSavedMessages;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int nrMovedMessages;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int nrDeletedMessages;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int nrSavedAttachedFiles;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  139 */   private Folder destinationIMAPFolder = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private LogChannelInterface log;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MailConnection(LogChannelInterface log, int protocol, String server, int port, String username, String password, boolean usessl, boolean useproxy, String proxyusername)
/*      */     throws KettleException
/*      */   {
/*  156 */     this.log = log;
/*      */     
/*      */     try
/*      */     {
/*  160 */       this.prop = System.getProperties();
/*      */     } catch (SecurityException s) {
/*  162 */       this.prop = new Properties();
/*      */     }
/*      */     
/*  165 */     this.port = port;
/*  166 */     this.server = server;
/*  167 */     this.username = username;
/*  168 */     this.password = password;
/*  169 */     this.usessl = usessl;
/*  170 */     this.protocol = protocol;
/*  171 */     this.nrSavedMessages = 0;
/*  172 */     this.nrDeletedMessages = 0;
/*  173 */     this.nrMovedMessages = 0;
/*  174 */     this.nrSavedAttachedFiles = 0;
/*  175 */     this.messagenr = -1;
/*  176 */     this.useproxy = useproxy;
/*  177 */     this.proxyusername = proxyusername;
/*      */     
/*      */     try
/*      */     {
/*  181 */       if (useproxy)
/*      */       {
/*      */ 
/*  184 */         this.prop.put("mail.imap.sasl.enable", "true");
/*  185 */         this.prop.put("mail.imap.sasl.authorizationid", proxyusername);
/*      */       }
/*      */       
/*  188 */       if (protocol == 0) {
/*  189 */         this.prop.setProperty("mail.pop3s.rsetbeforequit", "true");
/*  190 */         this.prop.setProperty("mail.pop3.rsetbeforequit", "true");
/*      */       }
/*      */       
/*  193 */       String protocolString = protocol == 0 ? "pop3" : "imap";
/*  194 */       if (usessl)
/*      */       {
/*  196 */         this.prop.setProperty("mail." + protocolString + ".socketFactory.class", "javax.net.ssl.SSLSocketFactory");
/*  197 */         this.prop.setProperty("mail." + protocolString + ".socketFactory.fallback", "false");
/*  198 */         this.prop.setProperty("mail." + protocolString + ".port", "" + port);
/*  199 */         this.prop.setProperty("mail." + protocolString + ".socketFactory.port", "" + port);
/*      */         
/*      */ 
/*  202 */         this.session = Session.getInstance(this.prop, null);
/*  203 */         this.session.setDebug(log.isDebug());
/*  204 */         if (this.port == -1) {
/*  205 */           this.port = (protocol == 0 ? 995 : 993);
/*      */         }
/*  207 */         URLName url = new URLName(protocolString, server, port, "", username, password);
/*  208 */         this.store = (protocol == 0 ? new POP3SSLStore(this.session, url) : new IMAPSSLStore(this.session, url));
/*  209 */         url = null;
/*      */       } else {
/*  211 */         this.session = Session.getInstance(this.prop, null);
/*  212 */         this.session.setDebug(log.isDebug());
/*  213 */         this.store = this.session.getStore(protocolString);
/*      */       }
/*      */       
/*  216 */       if (log.isDetailed()) log.logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.NewConnectionDefined", new String[0]));
/*      */     } catch (Exception e) {
/*  218 */       throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.NewConnection", new String[] { Const.NVL(this.server, "") }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isConnected()
/*      */   {
/*  227 */     return (this.store != null) && (this.store.isConnected());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isUseSSL()
/*      */   {
/*  234 */     return this.usessl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isUseProxy()
/*      */   {
/*  241 */     return this.useproxy;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getProxyUsername()
/*      */   {
/*  247 */     return this.proxyusername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Store getStore()
/*      */   {
/*  254 */     return this.store;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Folder getFolder()
/*      */   {
/*  261 */     return this.folder;
/*      */   }
/*      */   
/*      */ 
/*      */   public void connect()
/*      */     throws KettleException
/*      */   {
/*  268 */     if (this.log.isDetailed()) this.log.logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Connecting", new String[] { this.server, this.username, "" + this.port }));
/*      */     try {
/*  270 */       if (this.usessl)
/*      */       {
/*      */ 
/*  273 */         this.store.connect();
/*      */       }
/*  275 */       else if (this.port > -1) {
/*  276 */         this.store.connect(this.server, this.port, this.username, this.password);
/*      */       } else {
/*  278 */         this.store.connect(this.server, this.username, this.password);
/*      */       }
/*  280 */       if (this.log.isDetailed()) this.log.logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Connected", new String[] { this.server, this.username, "" + this.port }));
/*      */     } catch (Exception e) {
/*  282 */       throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.Connecting", new String[] { this.server, this.username, Const.NVL("" + this.port, "") }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void openFolder(boolean write)
/*      */     throws KettleException
/*      */   {
/*  292 */     openFolder(null, true, write);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void openFolder(String foldername, boolean write)
/*      */     throws KettleException
/*      */   {
/*  302 */     openFolder(foldername, false, write);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void openFolder(String foldername, boolean defaultFolder, boolean write)
/*      */     throws KettleException
/*      */   {
/*  313 */     this.write = write;
/*      */     try {
/*  315 */       if (getFolder() != null)
/*      */       {
/*      */ 
/*  318 */         closeFolder(true);
/*      */       }
/*      */       
/*      */ 
/*  322 */       if (defaultFolder)
/*      */       {
/*  324 */         this.folder = this.store.getDefaultFolder().getFolder("INBOX");
/*      */         
/*  326 */         if (this.folder == null) { throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.InvalidDefaultFolder.Label", new String[0]));
/*      */         }
/*  328 */         if ((this.folder.getType() & 0x1) == 0) {
/*  329 */           throw new KettleException(BaseMessages.getString(PKG, "MailConnection.DefaultFolderCanNotHoldMessage", new String[0]));
/*      */         }
/*      */       } else {
/*  332 */         if (this.protocol == 1) {
/*  333 */           this.folder = this.store.getFolder(foldername);
/*      */         }
/*  335 */         if ((this.folder == null) || (!this.folder.exists()))
/*  336 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.InvalidFolder.Label", new String[0]));
/*      */       }
/*  338 */       if (this.write) {
/*  339 */         if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "MailConnection.OpeningFolderInWriteMode.Label", new String[] { getFolderName() }));
/*  340 */         this.folder.open(2);
/*      */       } else {
/*  342 */         if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "MailConnection.OpeningFolderInReadMode.Label", new String[] { getFolderName() }));
/*  343 */         this.folder.open(1);
/*      */       }
/*      */       
/*  346 */       if (this.log.isDetailed()) this.log.logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderOpened.Label", new String[] { getFolderName() }));
/*  347 */       if (this.log.isDebug())
/*      */       {
/*  349 */         this.log.logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderOpened.Name", new String[] { getFolderName() }));
/*  350 */         this.log.logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderOpened.FullName", new String[] { this.folder.getFullName() }));
/*  351 */         this.log.logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderOpened.Url", new String[] { this.folder.getURLName().toString() }));
/*  352 */         this.log.logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderOpened.Subscribed", new String[] { "" + this.folder.isSubscribed() }));
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  356 */       throw new KettleException(defaultFolder ? BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.OpeningDefaultFolder", new String[0]) : BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.OpeningFolder", new String[] { foldername }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void clearFilters()
/*      */   {
/*  364 */     this.nrSavedMessages = 0;
/*  365 */     this.nrDeletedMessages = 0;
/*  366 */     this.nrMovedMessages = 0;
/*  367 */     this.nrSavedAttachedFiles = 0;
/*  368 */     if (this.searchTerm != null) {
/*  369 */       this.searchTerm = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void disconnect()
/*      */     throws KettleException
/*      */   {
/*  378 */     disconnect(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void closeFolder(boolean expunge)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  388 */       if ((this.folder != null) && (this.folder.isOpen())) {
/*  389 */         if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "MailConnection.ClosingFolder", new String[] { getFolderName() }));
/*  390 */         this.folder.close(expunge);
/*  391 */         this.folder = null;
/*  392 */         this.messages = null;
/*  393 */         this.message = null;
/*  394 */         this.messagenr = -1;
/*  395 */         if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "MailConnection.FolderClosed", new String[] { getFolderName() }));
/*      */       }
/*      */     } catch (Exception e) {
/*  398 */       throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.ClosingFolder", new String[] { getFolderName() }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addSearchTerm(SearchTerm Term)
/*      */   {
/*  408 */     if (this.searchTerm != null) {
/*  409 */       this.searchTerm = new AndTerm(this.searchTerm, Term);
/*      */     } else {
/*  411 */       this.searchTerm = Term;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSubjectTerm(String subject, boolean notTerm)
/*      */   {
/*  421 */     if (!Const.isEmpty(subject)) {
/*  422 */       if (notTerm) {
/*  423 */         addSearchTerm(new NotTerm(new SubjectTerm(subject)));
/*      */       } else {
/*  425 */         addSearchTerm(new SubjectTerm(subject));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setBodyTerm(String bodyfilter, boolean notTerm)
/*      */   {
/*  434 */     if (!Const.isEmpty(bodyfilter)) {
/*  435 */       if (notTerm) {
/*  436 */         addSearchTerm(new NotTerm(new BodyTerm(bodyfilter)));
/*      */       } else {
/*  438 */         addSearchTerm(new BodyTerm(bodyfilter));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSenderTerm(String sender, boolean notTerm)
/*      */   {
/*  447 */     if (!Const.isEmpty(sender)) {
/*  448 */       if (notTerm) {
/*  449 */         addSearchTerm(new NotTerm(new FromStringTerm(sender)));
/*      */       } else {
/*  451 */         addSearchTerm(new FromStringTerm(sender));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setReceipientTerm(String receipient)
/*      */   {
/*  460 */     if (!Const.isEmpty(receipient)) {
/*  461 */       addSearchTerm(new RecipientStringTerm(Message.RecipientType.TO, receipient));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceivedDateTermEQ(Date receiveddate)
/*      */   {
/*  470 */     if (this.protocol == 0) {
/*  471 */       this.log.logError(BaseMessages.getString(PKG, "MailConnection.Error.ReceivedDatePOP3Unsupported", new String[0]));
/*      */     } else {
/*  473 */       addSearchTerm(new ReceivedDateTerm(3, receiveddate));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceivedDateTermLT(Date futureDate)
/*      */   {
/*  482 */     if (this.protocol == 0) {
/*  483 */       this.log.logError(BaseMessages.getString(PKG, "MailConnection.Error.ReceivedDatePOP3Unsupported", new String[0]));
/*      */     } else {
/*  485 */       addSearchTerm(new ReceivedDateTerm(2, futureDate));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReceivedDateTermGT(Date pastDate)
/*      */   {
/*  494 */     if (this.protocol == 0) {
/*  495 */       this.log.logError(BaseMessages.getString(PKG, "MailConnection.Error.ReceivedDatePOP3Unsupported", new String[0]));
/*      */     } else {
/*  497 */       addSearchTerm(new ReceivedDateTerm(5, pastDate));
/*      */     }
/*      */   }
/*      */   
/*      */   public void setReceivedDateTermBetween(Date beginDate, Date endDate) {
/*  502 */     if (this.protocol == 0) {
/*  503 */       this.log.logError(BaseMessages.getString(PKG, "MailConnection.Error.ReceivedDatePOP3Unsupported", new String[0]));
/*      */     } else {
/*  505 */       addSearchTerm(new AndTerm(new ReceivedDateTerm(2, endDate), new ReceivedDateTerm(5, beginDate)));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setFlagTermNew()
/*      */   {
/*  512 */     addSearchTerm(new FlagTerm(new Flags(Flags.Flag.RECENT), true));
/*      */   }
/*      */   
/*  515 */   public void setFlagTermOld() { addSearchTerm(new FlagTerm(new Flags(Flags.Flag.RECENT), false)); }
/*      */   
/*      */   public void setFlagTermRead() {
/*  518 */     addSearchTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), true));
/*      */   }
/*      */   
/*  521 */   public void setFlagTermUnread() { addSearchTerm(new FlagTerm(new Flags(Flags.Flag.SEEN), false)); }
/*      */   
/*      */   public void setFlagTermFlagged() {
/*  524 */     addSearchTerm(new FlagTerm(new Flags(Flags.Flag.FLAGGED), true));
/*      */   }
/*      */   
/*  527 */   public void setFlagTermNotFlagged() { addSearchTerm(new FlagTerm(new Flags(Flags.Flag.FLAGGED), false)); }
/*      */   
/*      */   public void setFlagTermDraft() {
/*  530 */     addSearchTerm(new FlagTerm(new Flags(Flags.Flag.DRAFT), true));
/*      */   }
/*      */   
/*  533 */   public void setFlagTermNotDraft() { addSearchTerm(new FlagTerm(new Flags(Flags.Flag.DRAFT), false)); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void retrieveMessages()
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  543 */       if (this.searchTerm != null) {
/*  544 */         this.messages = this.folder.search(this.searchTerm);
/*      */       } else {
/*  546 */         this.messages = this.folder.getMessages();
/*      */       }
/*      */     } catch (Exception e) {
/*  549 */       this.messages = null;
/*  550 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.RetrieveMessages", new String[] { getFolderName() }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void disconnect(boolean expunge)
/*      */     throws KettleException
/*      */   {
/*  579 */     if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "MailConnection.ClosingConnection", new String[0]));
/*      */     try
/*      */     {
/*  582 */       closeFolder(expunge);
/*  583 */       clearFilters();
/*  584 */       if (this.store != null) { this.store.close();this.store = null; }
/*  585 */       if (this.session != null) this.session = null;
/*  586 */       if (this.destinationIMAPFolder != null) { this.destinationIMAPFolder.close(expunge);
/*      */       }
/*  588 */       if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "MailConnection.ConnectionClosed", new String[0]));
/*      */     } catch (Exception e) {
/*  590 */       throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.ClosingConnection", new String[0]), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void saveMessageContentToFile(String filename, String foldername)
/*      */     throws KettleException
/*      */   {
/*  603 */     OutputStream os = null;
/*      */     try {
/*  605 */       os = KettleVFS.getOutputStream(foldername + (foldername.endsWith("/") ? "" : "/") + filename, false);
/*  606 */       getMessage().writeTo(os);
/*  607 */       updateSavedMessagesCounter();
/*      */     } catch (Exception e) {
/*  609 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.SavingMessageContent", new String[] { "" + this.message.getMessageNumber(), filename, foldername }), e);
/*      */     }
/*      */     finally {
/*  612 */       if (os != null) {
/*      */         try {
/*  614 */           os.close();os = null;
/*      */         }
/*      */         catch (Exception e) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void saveAttachedFiles(String foldername)
/*      */     throws KettleException
/*      */   {
/*  625 */     saveAttachedFiles(foldername, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void saveAttachedFiles(String foldername, Pattern pattern)
/*      */     throws KettleException
/*      */   {
/*  635 */     Object content = null;
/*      */     try {
/*  637 */       content = getMessage().getContent();
/*  638 */       if ((content instanceof Multipart)) {
/*  639 */         handleMultipart(foldername, (Multipart)content, pattern);
/*      */       }
/*      */     } catch (Exception e) {
/*  642 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.SavingAttachedFiles", new String[] { "" + this.message.getMessageNumber(), foldername }), e);
/*      */     } finally {
/*  644 */       if (content != null) content = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleMultipart(String foldername, Multipart multipart, Pattern pattern) throws KettleException {
/*  649 */     try { int i = 0; for (int n = multipart.getCount(); i < n; i++) {
/*  650 */         handlePart(foldername, multipart.getBodyPart(i), pattern);
/*      */       }
/*      */     } catch (Exception e) {
/*  653 */       throw new KettleException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handlePart(String foldername, Part part, Pattern pattern) throws KettleException {
/*  658 */     try { String disposition = part.getDisposition();
/*      */       
/*      */ 
/*      */ 
/*  662 */       if ((disposition == null) || (disposition.length() < 1)) {
/*  663 */         disposition = "attachment";
/*      */       }
/*      */       
/*  666 */       if ((disposition.equalsIgnoreCase("attachment")) || (disposition.equalsIgnoreCase("inline"))) {
/*  667 */         String MimeText = null;
/*      */         try {
/*  669 */           MimeText = MimeUtility.decodeText(part.getFileName());
/*      */         } catch (Exception e) {}
/*  671 */         if (MimeText != null) {
/*  672 */           String filename = MimeUtility.decodeText(part.getFileName());
/*  673 */           if (isWildcardMatch(filename, pattern))
/*      */           {
/*      */ 
/*  676 */             saveFile(foldername, filename, part.getInputStream());
/*  677 */             updateSavedAttachedFilesCounter();
/*  678 */             if (this.log.isDetailed()) {
/*  679 */               this.log.logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.AttachedFileSaved", new String[] { filename, "" + getMessage().getMessageNumber(), foldername }));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  685 */       throw new KettleException(e);
/*      */     }
/*      */   }
/*      */   
/*  689 */   private static void saveFile(String foldername, String filename, InputStream input) throws KettleException { FileOutputStream fos = null;
/*  690 */     BufferedOutputStream bos = null;
/*  691 */     File file = null;
/*  692 */     BufferedInputStream bis = null;
/*      */     try {
/*  694 */       if (filename == null) {
/*  695 */         filename = File.createTempFile("xx", ".out").getName();
/*      */       }
/*      */       
/*  698 */       file = new File(foldername, filename);
/*  699 */       for (int i = 0; file.exists(); i++) {
/*  700 */         file = new File(foldername, filename + i);
/*      */       }
/*  702 */       fos = new FileOutputStream(file);
/*  703 */       bos = new BufferedOutputStream(fos);
/*  704 */       bis = new BufferedInputStream(input);
/*      */       int aByte;
/*  706 */       while ((aByte = bis.read()) != -1) {
/*  707 */         bos.write(aByte);
/*      */       }
/*      */     } catch (Exception e) {
/*  710 */       throw new KettleException(e);
/*      */     } finally {
/*      */       try {
/*  713 */         if (bos != null) { bos.flush();bos.close(); }
/*  714 */         if (bis != null) { bis.close();bis = null; }
/*  715 */         file = null;
/*      */       } catch (Exception e) {}
/*      */     } }
/*      */   
/*  719 */   private boolean isWildcardMatch(String filename, Pattern pattern) { boolean retval = true;
/*  720 */     if (pattern != null) {
/*  721 */       Matcher matcher = pattern.matcher(filename);
/*  722 */       retval = matcher.matches();
/*      */     }
/*  724 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */   public void deleteMessage()
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  733 */       this.message.setFlag(Flags.Flag.DELETED, true);
/*  734 */       updateDeletedMessagesCounter();
/*      */     } catch (Exception e) {
/*  736 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.DeletingMessage", new String[] { "" + getMessage().getMessageNumber() }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDestinationFolder(String foldername, boolean createFolder)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  748 */       this.destinationIMAPFolder = this.store.getFolder(foldername);
/*  749 */       if (!this.destinationIMAPFolder.exists()) {
/*  750 */         if (createFolder)
/*      */         {
/*  752 */           this.destinationIMAPFolder.create(1);
/*      */         } else {
/*  754 */           throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.FolderNotFound", new String[] { foldername }));
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  758 */       throw new KettleException(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void moveMessage()
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  769 */       this.folder.copyMessages(new Message[] { this.message }, this.destinationIMAPFolder);
/*  770 */       updatedMovedMessagesCounter();
/*      */       
/*  772 */       deleteMessage();
/*      */     } catch (Exception e) {
/*  774 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.MovingMessage", new String[] { "" + getMessage().getMessageNumber(), this.destinationIMAPFolder.getName() }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFolderName()
/*      */   {
/*  783 */     if (this.folder == null) return "";
/*  784 */     return this.folder.getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getServer()
/*      */   {
/*  791 */     return this.server;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getProtocol()
/*      */   {
/*  798 */     return this.protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Message[] getMessages()
/*      */   {
/*  805 */     return this.messages;
/*      */   }
/*      */   
/*  808 */   private void updateMessageNr() { this.messagenr += 1; }
/*      */   
/*      */   private int getMessageNr() {
/*  811 */     return this.messagenr;
/*      */   }
/*      */   
/*      */ 
/*      */   public void fetchNext()
/*      */     throws KettleException
/*      */   {
/*  818 */     updateMessageNr();
/*      */     try {
/*  820 */       this.message = this.messages[getMessageNr()];
/*      */     } catch (Exception e) {
/*  822 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.FetchingMessages", new String[0]), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Message getMessage()
/*      */   {
/*  830 */     return this.message;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getMessagesCount()
/*      */   {
/*  837 */     return this.messages.length;
/*      */   }
/*      */   
/*  840 */   public void updateSavedMessagesCounter() { this.nrSavedMessages += 1; }
/*      */   
/*      */   public int getSavedMessagesCounter() {
/*  843 */     return this.nrSavedMessages;
/*      */   }
/*      */   
/*  846 */   public int getSavedAttachedFilesCounter() { return this.nrSavedAttachedFiles; }
/*      */   
/*      */   public void updateSavedAttachedFilesCounter() {
/*  849 */     this.nrSavedAttachedFiles += 1;
/*      */   }
/*      */   
/*  852 */   public int getDeletedMessagesCounter() { return this.nrDeletedMessages; }
/*      */   
/*      */   private void updateDeletedMessagesCounter() {
/*  855 */     this.nrDeletedMessages += 1;
/*      */   }
/*      */   
/*  858 */   private void setDeletedMessagesCounter() { this.nrDeletedMessages = getMessagesCount(); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMovedMessagesCounter()
/*      */   {
/*  865 */     return this.nrMovedMessages;
/*      */   }
/*      */   
/*      */ 
/*      */   private void updatedMovedMessagesCounter()
/*      */   {
/*  871 */     this.nrMovedMessages += 1;
/*      */   }
/*      */   
/*      */ 
/*      */   private void setMovedMessagesCounter()
/*      */   {
/*  877 */     this.nrMovedMessages = getMessagesCount();
/*      */   }
/*      */   
/*      */ 
/*      */   public void deleteMessages(boolean setCounter)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  886 */       this.folder.setFlags(this.messages, new Flags(Flags.Flag.DELETED), true);
/*  887 */       if (setCounter) setDeletedMessagesCounter();
/*      */     } catch (Exception e) {
/*  889 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.DeletingMessage", new String[0]), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void moveMessages()
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  900 */       this.folder.copyMessages(this.messages, this.destinationIMAPFolder);
/*  901 */       deleteMessages(false);
/*  902 */       setMovedMessagesCounter();
/*      */     } catch (Exception e) {
/*  904 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.MovingMessages", new String[] { this.destinationIMAPFolder.getName() }), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean folderExists(String foldername)
/*      */   {
/*  914 */     boolean retval = false;
/*  915 */     Folder dfolder = null;
/*      */     try
/*      */     {
/*  918 */       dfolder = this.store.getFolder(foldername);
/*  919 */       if (dfolder.exists()) retval = true;
/*      */     }
/*      */     catch (Exception e) {}finally {
/*      */       try {
/*  923 */         if (dfolder != null) dfolder.close(false);
/*      */       } catch (Exception e) {}
/*      */     }
/*  926 */     return retval;
/*      */   }
/*      */   
/*  929 */   private HashSet<String> returnSubfolders(Folder folder) throws KettleException { HashSet<String> list = new HashSet();
/*      */     try {
/*  931 */       if ((folder.getType() & 0x2) != 0) {
/*  932 */         Folder[] f = folder.list();
/*  933 */         for (int i = 0; i < f.length; i++)
/*      */         {
/*  935 */           if ((f[i].getType() & 0x2) != 0) {
/*  936 */             list.add(f[i].getFullName());
/*  937 */             list.addAll(returnSubfolders(f[i]));
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (MessagingException m) {
/*  942 */       throw new KettleException(m);
/*      */     }
/*  944 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] returnAllFolders(Folder folder)
/*      */     throws KettleException
/*      */   {
/*  954 */     HashSet<String> list = new HashSet();
/*  955 */     list = returnSubfolders(folder);
/*  956 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String[] returnAllFolders()
/*      */     throws KettleException
/*      */   {
/*  964 */     return returnAllFolders(getFolder());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] returnAllFolders(String folder)
/*      */     throws KettleException
/*      */   {
/*  974 */     Folder dfolder = null;
/*  975 */     String[] retval = null;
/*      */     try {
/*  977 */       if (Const.isEmpty(folder))
/*      */       {
/*  979 */         dfolder = getStore().getDefaultFolder();
/*      */       } else {
/*  981 */         dfolder = getStore().getFolder(folder);
/*      */       }
/*  983 */       retval = returnAllFolders(dfolder);
/*      */     }
/*      */     catch (Exception e) {}finally {
/*      */       try {
/*  987 */         if (dfolder != null) dfolder.close(false);
/*      */       } catch (Exception e) {}
/*      */     }
/*  990 */     return retval;
/*      */   }
/*      */   
/*  993 */   public String getMessageBody() throws Exception { return getMessageBody(getMessage()); }
/*      */   
/*      */ 
/*      */ 
/*      */   private String getMessageBody(Part p)
/*      */     throws MessagingException, Exception
/*      */   {
/* 1000 */     if (p.isMimeType("text/*")) {
/* 1001 */       String s = (String)p.getContent();
/* 1002 */       return s;
/*      */     }
/*      */     
/* 1005 */     if (p.isMimeType("multipart/alternative"))
/*      */     {
/* 1007 */       Multipart mp = (Multipart)p.getContent();
/* 1008 */       String text = null;
/* 1009 */       for (int i = 0; i < mp.getCount(); i++) {
/* 1010 */         Part bp = mp.getBodyPart(i);
/* 1011 */         if ((bp.isMimeType("text/plain")) && 
/* 1012 */           (text == null)) {
/* 1013 */           text = getMessageBody(bp);
/*      */         }
/*      */       }
/* 1016 */       return text; }
/* 1017 */     if (p.isMimeType("multipart/*")) {
/* 1018 */       Multipart mp = (Multipart)p.getContent();
/* 1019 */       for (int i = 0; i < mp.getCount(); i++) {
/* 1020 */         String s = getMessageBody(mp.getBodyPart(i));
/* 1021 */         if (s != null) {
/* 1022 */           return s;
/*      */         }
/*      */       }
/*      */     }
/* 1026 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isMessageNew()
/*      */   {
/*      */     try
/*      */     {
/* 1035 */       return getMessage().isSet(Flags.Flag.RECENT);
/*      */     }
/*      */     catch (MessagingException e) {}
/* 1038 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMessageRead()
/*      */   {
/*      */     try
/*      */     {
/* 1049 */       return getMessage().isSet(Flags.Flag.SEEN);
/*      */     }
/*      */     catch (MessagingException e) {}
/* 1052 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMessageFlagged()
/*      */   {
/*      */     try
/*      */     {
/* 1063 */       return getMessage().isSet(Flags.Flag.FLAGGED);
/*      */     }
/*      */     catch (MessagingException e) {}
/* 1066 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMessageDeleted()
/*      */   {
/*      */     try
/*      */     {
/* 1076 */       return getMessage().isSet(Flags.Flag.DELETED);
/*      */     }
/*      */     catch (MessagingException e) {}
/* 1079 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMessageDraft()
/*      */   {
/*      */     try
/*      */     {
/* 1089 */       return getMessage().isSet(Flags.Flag.DRAFT);
/*      */     }
/*      */     catch (MessagingException e) {}
/* 1092 */     return false;
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1096 */     if (getServer() != null) return getServer();
/* 1097 */     return "-";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getAttachedFilesCount(Pattern pattern)
/*      */     throws KettleException
/*      */   {
/* 1105 */     Object content = null;
/* 1106 */     int retval = 0;
/*      */     try {
/* 1108 */       content = getMessage().getContent();
/* 1109 */       if ((content instanceof Multipart)) {
/* 1110 */         Multipart multipart = (Multipart)content;
/* 1111 */         int i = 0; for (int n = multipart.getCount(); i < n; i++) {
/* 1112 */           Part part = multipart.getBodyPart(i);
/* 1113 */           String disposition = part.getDisposition();
/*      */           
/* 1115 */           if ((disposition != null) && ((disposition.equalsIgnoreCase("attachment")) || (disposition.equalsIgnoreCase("inline"))))
/*      */           {
/* 1117 */             String MimeText = null;
/*      */             try {
/* 1119 */               MimeText = MimeUtility.decodeText(part.getFileName());
/*      */             } catch (Exception e) {}
/* 1121 */             if (MimeText != null) {
/* 1122 */               String filename = MimeUtility.decodeText(part.getFileName());
/* 1123 */               if (isWildcardMatch(filename, pattern)) retval++;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/* 1129 */       throw new KettleException(BaseMessages.getString(PKG, "MailConnection.Error.CountingAttachedFiles", new String[] { "" + this.message.getMessageNumber() }), e);
/*      */     }
/*      */     finally {
/* 1132 */       if (content != null) content = null;
/*      */     }
/* 1134 */     return retval;
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\getpop\MailConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */