/*     */ package org.pentaho.di.cluster;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.changed.ChangedFlag;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.variables.Variables;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.core.xml.XMLInterface;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.ObjectRevision;
/*     */ import org.pentaho.di.repository.RepositoryDirectory;
/*     */ import org.pentaho.di.repository.RepositoryDirectoryInterface;
/*     */ import org.pentaho.di.repository.RepositoryElementInterface;
/*     */ import org.pentaho.di.repository.RepositoryObjectType;
/*     */ import org.pentaho.di.shared.SharedObjectInterface;
/*     */ import org.pentaho.di.www.SlaveServerDetection;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterSchema
/*     */   extends ChangedFlag
/*     */   implements Cloneable, SharedObjectInterface, VariableSpace, RepositoryElementInterface, XMLInterface
/*     */ {
/*  61 */   private static Class<?> PKG = ClusterSchema.class;
/*     */   
/*     */   public static final String XML_TAG = "clusterschema";
/*     */   
/*  65 */   public static final RepositoryObjectType REPOSITORY_ELEMENT_TYPE = RepositoryObjectType.CLUSTER_SCHEMA;
/*     */   
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */   private List<SlaveServer> slaveServers;
/*     */   
/*     */ 
/*     */   private String basePort;
/*     */   
/*     */ 
/*     */   private boolean shared;
/*     */   
/*     */ 
/*     */   private String socketsBufferSize;
/*     */   
/*     */ 
/*     */   private String socketsFlushInterval;
/*     */   
/*     */ 
/*     */   private boolean socketsCompressed;
/*     */   
/*     */ 
/*     */   private boolean dynamic;
/*     */   
/*     */ 
/*  92 */   private VariableSpace variables = new Variables();
/*     */   
/*     */   private ObjectId id;
/*     */   
/*     */   private ObjectRevision objectRevision;
/*     */   
/*     */   private Date changedDate;
/*     */   
/*     */   public ClusterSchema()
/*     */   {
/* 102 */     this.id = null;
/* 103 */     this.slaveServers = new ArrayList();
/* 104 */     this.socketsBufferSize = "2000";
/* 105 */     this.socketsFlushInterval = "5000";
/* 106 */     this.socketsCompressed = true;
/* 107 */     this.basePort = "40000";
/* 108 */     this.dynamic = false;
/* 109 */     this.changedDate = new Date();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClusterSchema(String name, List<SlaveServer> slaveServers)
/*     */   {
/* 118 */     this.name = name;
/* 119 */     this.slaveServers = slaveServers;
/* 120 */     this.changedDate = new Date();
/*     */   }
/*     */   
/*     */   public ClusterSchema clone()
/*     */   {
/* 125 */     ClusterSchema clusterSchema = new ClusterSchema();
/* 126 */     clusterSchema.replaceMeta(this);
/* 127 */     return clusterSchema;
/*     */   }
/*     */   
/*     */ 
/*     */   public void replaceMeta(ClusterSchema clusterSchema)
/*     */   {
/* 133 */     this.name = clusterSchema.name;
/* 134 */     this.basePort = clusterSchema.basePort;
/* 135 */     this.socketsBufferSize = clusterSchema.socketsBufferSize;
/* 136 */     this.socketsCompressed = clusterSchema.socketsCompressed;
/* 137 */     this.socketsFlushInterval = clusterSchema.socketsFlushInterval;
/* 138 */     this.dynamic = clusterSchema.dynamic;
/*     */     
/* 140 */     this.slaveServers.clear();
/* 141 */     this.slaveServers.addAll(clusterSchema.slaveServers);
/*     */     
/* 143 */     this.shared = clusterSchema.shared;
/* 144 */     this.id = clusterSchema.id;
/* 145 */     setChanged(true);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 151 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 156 */     if (obj == null) return false;
/* 157 */     return this.name.equals(((ClusterSchema)obj).name);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 162 */     return this.name.hashCode();
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 167 */     StringBuffer xml = new StringBuffer(500);
/*     */     
/* 169 */     xml.append("        <").append("clusterschema").append(">").append(Const.CR);
/*     */     
/* 171 */     xml.append("          ").append(XMLHandler.addTagValue("name", this.name));
/* 172 */     xml.append("          ").append(XMLHandler.addTagValue("base_port", this.basePort));
/* 173 */     xml.append("          ").append(XMLHandler.addTagValue("sockets_buffer_size", this.socketsBufferSize));
/* 174 */     xml.append("          ").append(XMLHandler.addTagValue("sockets_flush_interval", this.socketsFlushInterval));
/* 175 */     xml.append("          ").append(XMLHandler.addTagValue("sockets_compressed", this.socketsCompressed));
/* 176 */     xml.append("          ").append(XMLHandler.addTagValue("dynamic", this.dynamic));
/*     */     
/* 178 */     xml.append("          <slaveservers>").append(Const.CR);
/* 179 */     for (int i = 0; i < this.slaveServers.size(); i++)
/*     */     {
/* 181 */       SlaveServer slaveServer = (SlaveServer)this.slaveServers.get(i);
/* 182 */       xml.append("            ").append(XMLHandler.addTagValue("name", slaveServer.getName()));
/*     */     }
/* 184 */     xml.append("          </slaveservers>").append(Const.CR);
/* 185 */     xml.append("        </").append("clusterschema").append(">").append(Const.CR);
/* 186 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public ClusterSchema(Node clusterSchemaNode, List<SlaveServer> referenceSlaveServers)
/*     */   {
/* 191 */     this();
/*     */     
/* 193 */     this.name = XMLHandler.getTagValue(clusterSchemaNode, "name");
/* 194 */     this.basePort = XMLHandler.getTagValue(clusterSchemaNode, "base_port");
/* 195 */     this.socketsBufferSize = XMLHandler.getTagValue(clusterSchemaNode, "sockets_buffer_size");
/* 196 */     this.socketsFlushInterval = XMLHandler.getTagValue(clusterSchemaNode, "sockets_flush_interval");
/* 197 */     this.socketsCompressed = "Y".equalsIgnoreCase(XMLHandler.getTagValue(clusterSchemaNode, "sockets_compressed"));
/* 198 */     this.dynamic = "Y".equalsIgnoreCase(XMLHandler.getTagValue(clusterSchemaNode, "dynamic"));
/*     */     
/* 200 */     Node slavesNode = XMLHandler.getSubNode(clusterSchemaNode, "slaveservers");
/* 201 */     int nrSlaves = XMLHandler.countNodes(slavesNode, "name");
/* 202 */     for (int i = 0; i < nrSlaves; i++)
/*     */     {
/* 204 */       Node serverNode = XMLHandler.getSubNodeByNr(slavesNode, "name", i);
/* 205 */       String serverName = XMLHandler.getNodeValue(serverNode);
/* 206 */       SlaveServer slaveServer = SlaveServer.findSlaveServer(referenceSlaveServers, serverName);
/* 207 */       if (slaveServer != null)
/*     */       {
/* 209 */         this.slaveServers.add(slaveServer);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 219 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 227 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<SlaveServer> getSlaveServers()
/*     */   {
/* 235 */     return this.slaveServers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSlaveServers(List<SlaveServer> slaveServers)
/*     */   {
/* 243 */     this.slaveServers = slaveServers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getSlaveServerStrings()
/*     */   {
/* 251 */     String[] strings = new String[this.slaveServers.size()];
/* 252 */     for (int i = 0; i < strings.length; i++)
/*     */     {
/* 254 */       strings[i] = ((SlaveServer)this.slaveServers.get(i)).toString();
/*     */     }
/* 256 */     return strings;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShared()
/*     */   {
/* 264 */     return this.shared;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShared(boolean shared)
/*     */   {
/* 272 */     this.shared = shared;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBasePort()
/*     */   {
/* 280 */     return this.basePort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBasePort(String basePort)
/*     */   {
/* 288 */     this.basePort = basePort;
/*     */   }
/*     */   
/*     */   public SlaveServer findMaster() throws KettleException
/*     */   {
/* 293 */     for (int i = 0; i < this.slaveServers.size(); i++)
/*     */     {
/* 295 */       SlaveServer slaveServer = (SlaveServer)this.slaveServers.get(i);
/* 296 */       if (slaveServer.isMaster()) return slaveServer;
/*     */     }
/* 298 */     if (this.slaveServers.size() > 0)
/*     */     {
/* 300 */       throw new KettleException(BaseMessages.getString(PKG, "ClusterSchema.NoMasterServerDefined", new String[] { this.name }));
/*     */     }
/* 302 */     throw new KettleException(BaseMessages.getString(PKG, "ClusterSchema.NoSlaveServerDefined", new String[] { this.name }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int findNrSlaves()
/*     */   {
/* 310 */     int nr = 0;
/* 311 */     for (int i = 0; i < this.slaveServers.size(); i++)
/*     */     {
/* 313 */       SlaveServer slaveServer = (SlaveServer)this.slaveServers.get(i);
/* 314 */       if (!slaveServer.isMaster()) nr++;
/*     */     }
/* 316 */     return nr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSocketsFlushInterval()
/*     */   {
/* 324 */     return this.socketsFlushInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocketsFlushInterval(String socketFlushInterval)
/*     */   {
/* 332 */     this.socketsFlushInterval = socketFlushInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSocketsBufferSize()
/*     */   {
/* 340 */     return this.socketsBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocketsBufferSize(String socketsBufferSize)
/*     */   {
/* 348 */     this.socketsBufferSize = socketsBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSocketsCompressed()
/*     */   {
/* 356 */     return this.socketsCompressed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocketsCompressed(boolean socketsCompressed)
/*     */   {
/* 364 */     this.socketsCompressed = socketsCompressed;
/*     */   }
/*     */   
/*     */   public SlaveServer findSlaveServer(String slaveServerName)
/*     */   {
/* 369 */     for (int i = 0; i < this.slaveServers.size(); i++)
/*     */     {
/* 371 */       SlaveServer slaveServer = (SlaveServer)this.slaveServers.get(i);
/* 372 */       if (slaveServer.getName().equalsIgnoreCase(slaveServerName)) return slaveServer;
/*     */     }
/* 374 */     return null;
/*     */   }
/*     */   
/*     */   public ObjectId getObjectId()
/*     */   {
/* 379 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setObjectId(ObjectId id)
/*     */   {
/* 384 */     this.id = id;
/*     */   }
/*     */   
/*     */   public void copyVariablesFrom(VariableSpace space)
/*     */   {
/* 389 */     this.variables.copyVariablesFrom(space);
/*     */   }
/*     */   
/*     */   public String environmentSubstitute(String aString)
/*     */   {
/* 394 */     return this.variables.environmentSubstitute(aString);
/*     */   }
/*     */   
/*     */   public String[] environmentSubstitute(String[] aString)
/*     */   {
/* 399 */     return this.variables.environmentSubstitute(aString);
/*     */   }
/*     */   
/*     */   public VariableSpace getParentVariableSpace()
/*     */   {
/* 404 */     return this.variables.getParentVariableSpace();
/*     */   }
/*     */   
/*     */   public void setParentVariableSpace(VariableSpace parent)
/*     */   {
/* 409 */     this.variables.setParentVariableSpace(parent);
/*     */   }
/*     */   
/*     */   public String getVariable(String variableName, String defaultValue)
/*     */   {
/* 414 */     return this.variables.getVariable(variableName, defaultValue);
/*     */   }
/*     */   
/*     */   public String getVariable(String variableName)
/*     */   {
/* 419 */     return this.variables.getVariable(variableName);
/*     */   }
/*     */   
/*     */   public boolean getBooleanValueOfVariable(String variableName, boolean defaultValue) {
/* 423 */     if (!Const.isEmpty(variableName))
/*     */     {
/* 425 */       String value = environmentSubstitute(variableName);
/* 426 */       if (!Const.isEmpty(value))
/*     */       {
/* 428 */         return ValueMeta.convertStringToBoolean(value).booleanValue();
/*     */       }
/*     */     }
/* 431 */     return defaultValue;
/*     */   }
/*     */   
/*     */   public void initializeVariablesFrom(VariableSpace parent)
/*     */   {
/* 436 */     this.variables.initializeVariablesFrom(parent);
/*     */   }
/*     */   
/*     */   public String[] listVariables()
/*     */   {
/* 441 */     return this.variables.listVariables();
/*     */   }
/*     */   
/*     */   public void setVariable(String variableName, String variableValue)
/*     */   {
/* 446 */     this.variables.setVariable(variableName, variableValue);
/*     */   }
/*     */   
/*     */   public void shareVariablesWith(VariableSpace space)
/*     */   {
/* 451 */     this.variables = space;
/*     */   }
/*     */   
/*     */   public void injectVariables(Map<String, String> prop)
/*     */   {
/* 456 */     this.variables.injectVariables(prop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDynamic()
/*     */   {
/* 463 */     return this.dynamic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDynamic(boolean dynamic)
/*     */   {
/* 470 */     this.dynamic = dynamic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<SlaveServer> getSlaveServersFromMasterOrLocal()
/*     */     throws KettleException
/*     */   {
/* 478 */     if (isDynamic())
/*     */     {
/*     */ 
/* 481 */       List<SlaveServer> dynamicSlaves = null;
/* 482 */       Exception exception = null;
/* 483 */       for (int i = 0; i < this.slaveServers.size(); i++) {
/* 484 */         SlaveServer slave = (SlaveServer)this.slaveServers.get(i);
/* 485 */         if ((slave.isMaster()) && (dynamicSlaves == null)) {
/*     */           try {
/* 487 */             List<SlaveServerDetection> detections = slave.getSlaveServerDetections();
/* 488 */             dynamicSlaves = new ArrayList();
/* 489 */             for (SlaveServerDetection detection : detections) {
/* 490 */               if (detection.isActive()) {
/* 491 */                 dynamicSlaves.add(detection.getSlaveServer());
/*     */               }
/*     */             }
/*     */           } catch (Exception e) {
/* 495 */             exception = e;
/*     */           }
/*     */         }
/*     */       }
/* 499 */       if ((dynamicSlaves == null) && (exception != null)) {
/* 500 */         throw new KettleException(exception);
/*     */       }
/* 502 */       return dynamicSlaves;
/*     */     }
/* 504 */     return this.slaveServers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RepositoryDirectoryInterface getRepositoryDirectory()
/*     */   {
/* 513 */     return new RepositoryDirectory();
/*     */   }
/*     */   
/*     */   public void setRepositoryDirectory(RepositoryDirectoryInterface repositoryDirectory) {}
/*     */   
/*     */   public RepositoryObjectType getRepositoryElementType()
/*     */   {
/* 520 */     return REPOSITORY_ELEMENT_TYPE;
/*     */   }
/*     */   
/*     */   public ObjectRevision getObjectRevision() {
/* 524 */     return this.objectRevision;
/*     */   }
/*     */   
/*     */   public void setObjectRevision(ObjectRevision objectRevision) {
/* 528 */     this.objectRevision = objectRevision;
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 533 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDescription(String description) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public Date getChangedDate()
/*     */   {
/* 544 */     return this.changedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setChangedDate(Date changedDate)
/*     */   {
/* 551 */     this.changedDate = changedDate;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\cluster\ClusterSchema.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */