/*      */ package org.pentaho.di.job.entries.movefiles;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.vfs.AllFileSelector;
/*      */ import org.apache.commons.vfs.FileName;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.apache.commons.vfs.FileSelectInfo;
/*      */ import org.apache.commons.vfs.FileType;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.RowMetaAndData;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.logging.LogChannelInterface;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryMoveFiles
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   72 */   private static Class<?> PKG = JobEntryMoveFiles.class;
/*      */   
/*      */   public boolean move_empty_folders;
/*      */   
/*      */   public boolean arg_from_previous;
/*      */   public boolean include_subfolders;
/*      */   public boolean add_result_filesname;
/*      */   public boolean destination_is_a_file;
/*      */   public boolean create_destination_folder;
/*      */   public String[] source_filefolder;
/*      */   public String[] destination_filefolder;
/*      */   public String[] wildcard;
/*      */   private String nr_errors_less_than;
/*      */   private String success_condition;
/*   86 */   public String SUCCESS_IF_AT_LEAST_X_FILES_UN_ZIPPED = "success_when_at_least";
/*   87 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*   88 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*      */   
/*      */   private boolean add_date;
/*      */   
/*      */   private boolean add_time;
/*      */   private boolean SpecifyFormat;
/*      */   private String date_time_format;
/*      */   private boolean AddDateBeforeExtension;
/*      */   private boolean DoNotKeepFolderStructure;
/*      */   private String iffileexists;
/*      */   private String destinationFolder;
/*      */   private String ifmovedfileexists;
/*      */   private String moved_date_time_format;
/*      */   private boolean AddMovedDateBeforeExtension;
/*      */   private boolean add_moved_date;
/*      */   private boolean add_moved_time;
/*      */   private boolean SpecifyMoveFormat;
/*      */   public boolean create_move_to_folder;
/*      */   public boolean simulate;
/*  107 */   int NrErrors = 0;
/*  108 */   int NrSuccess = 0;
/*  109 */   boolean successConditionBroken = false;
/*  110 */   boolean successConditionBrokenExit = false;
/*  111 */   int limitFiles = 0;
/*      */   
/*      */   public JobEntryMoveFiles(String n)
/*      */   {
/*  115 */     super(n, "");
/*  116 */     this.simulate = false;
/*  117 */     this.create_move_to_folder = false;
/*  118 */     this.SpecifyMoveFormat = false;
/*  119 */     this.add_moved_date = false;
/*  120 */     this.add_moved_time = false;
/*  121 */     this.AddMovedDateBeforeExtension = false;
/*  122 */     this.moved_date_time_format = null;
/*  123 */     this.ifmovedfileexists = "do_nothing";
/*  124 */     this.destinationFolder = null;
/*  125 */     this.DoNotKeepFolderStructure = false;
/*  126 */     this.move_empty_folders = true;
/*  127 */     this.arg_from_previous = false;
/*  128 */     this.source_filefolder = null;
/*  129 */     this.destination_filefolder = null;
/*  130 */     this.wildcard = null;
/*  131 */     this.include_subfolders = false;
/*  132 */     this.add_result_filesname = false;
/*  133 */     this.destination_is_a_file = false;
/*  134 */     this.create_destination_folder = false;
/*  135 */     this.nr_errors_less_than = "10";
/*  136 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/*  137 */     this.add_date = false;
/*  138 */     this.add_time = false;
/*  139 */     this.SpecifyFormat = false;
/*  140 */     this.date_time_format = null;
/*  141 */     this.AddDateBeforeExtension = false;
/*  142 */     this.iffileexists = "do_nothing";
/*  143 */     setID(-1L);
/*      */   }
/*      */   
/*      */   public JobEntryMoveFiles()
/*      */   {
/*  148 */     this("");
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  153 */     JobEntryMoveFiles je = (JobEntryMoveFiles)super.clone();
/*  154 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  159 */     StringBuffer retval = new StringBuffer(300);
/*      */     
/*  161 */     retval.append(super.getXML());
/*  162 */     retval.append("      ").append(XMLHandler.addTagValue("move_empty_folders", this.move_empty_folders));
/*  163 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.arg_from_previous));
/*  164 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.include_subfolders));
/*  165 */     retval.append("      ").append(XMLHandler.addTagValue("add_result_filesname", this.add_result_filesname));
/*  166 */     retval.append("      ").append(XMLHandler.addTagValue("destination_is_a_file", this.destination_is_a_file));
/*  167 */     retval.append("      ").append(XMLHandler.addTagValue("create_destination_folder", this.create_destination_folder));
/*  168 */     retval.append("      ").append(XMLHandler.addTagValue("add_date", this.add_date));
/*  169 */     retval.append("      ").append(XMLHandler.addTagValue("add_time", this.add_time));
/*  170 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyFormat", this.SpecifyFormat));
/*  171 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_format", this.date_time_format));
/*  172 */     retval.append("      ").append(XMLHandler.addTagValue("nr_errors_less_than", this.nr_errors_less_than));
/*  173 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*  174 */     retval.append("      ").append(XMLHandler.addTagValue("AddDateBeforeExtension", this.AddDateBeforeExtension));
/*  175 */     retval.append("      ").append(XMLHandler.addTagValue("DoNotKeepFolderStructure", this.DoNotKeepFolderStructure));
/*  176 */     retval.append("      ").append(XMLHandler.addTagValue("iffileexists", this.iffileexists));
/*  177 */     retval.append("      ").append(XMLHandler.addTagValue("destinationFolder", this.destinationFolder));
/*  178 */     retval.append("      ").append(XMLHandler.addTagValue("ifmovedfileexists", this.ifmovedfileexists));
/*  179 */     retval.append("      ").append(XMLHandler.addTagValue("moved_date_time_format", this.moved_date_time_format));
/*  180 */     retval.append("      ").append(XMLHandler.addTagValue("create_move_to_folder", this.create_move_to_folder));
/*  181 */     retval.append("      ").append(XMLHandler.addTagValue("add_moved_date", this.add_moved_date));
/*  182 */     retval.append("      ").append(XMLHandler.addTagValue("add_moved_time", this.add_moved_time));
/*  183 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyMoveFormat", this.SpecifyMoveFormat));
/*  184 */     retval.append("      ").append(XMLHandler.addTagValue("AddMovedDateBeforeExtension", this.AddMovedDateBeforeExtension));
/*  185 */     retval.append("      ").append(XMLHandler.addTagValue("simulate", this.simulate));
/*      */     
/*  187 */     retval.append("      <fields>").append(Const.CR);
/*  188 */     if (this.source_filefolder != null)
/*      */     {
/*  190 */       for (int i = 0; i < this.source_filefolder.length; i++)
/*      */       {
/*  192 */         retval.append("        <field>").append(Const.CR);
/*  193 */         retval.append("          ").append(XMLHandler.addTagValue("source_filefolder", this.source_filefolder[i]));
/*  194 */         retval.append("          ").append(XMLHandler.addTagValue("destination_filefolder", this.destination_filefolder[i]));
/*  195 */         retval.append("          ").append(XMLHandler.addTagValue("wildcard", this.wildcard[i]));
/*  196 */         retval.append("        </field>").append(Const.CR);
/*      */       }
/*      */     }
/*  199 */     retval.append("      </fields>").append(Const.CR);
/*      */     
/*  201 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*      */     throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  209 */       super.loadXML(entrynode, databases, slaveServers);
/*  210 */       this.move_empty_folders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "move_empty_folders"));
/*  211 */       this.arg_from_previous = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/*  212 */       this.include_subfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/*  213 */       this.add_result_filesname = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_result_filesname"));
/*  214 */       this.destination_is_a_file = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "destination_is_a_file"));
/*  215 */       this.create_destination_folder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "create_destination_folder"));
/*  216 */       this.add_date = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_date"));
/*  217 */       this.add_time = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_time"));
/*  218 */       this.SpecifyFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyFormat"));
/*  219 */       this.AddDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddDateBeforeExtension"));
/*  220 */       this.DoNotKeepFolderStructure = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "DoNotKeepFolderStructure"));
/*  221 */       this.date_time_format = XMLHandler.getTagValue(entrynode, "date_time_format");
/*  222 */       this.nr_errors_less_than = XMLHandler.getTagValue(entrynode, "nr_errors_less_than");
/*  223 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/*  224 */       this.iffileexists = XMLHandler.getTagValue(entrynode, "iffileexists");
/*  225 */       this.destinationFolder = XMLHandler.getTagValue(entrynode, "destinationFolder");
/*  226 */       this.ifmovedfileexists = XMLHandler.getTagValue(entrynode, "ifmovedfileexists");
/*  227 */       this.moved_date_time_format = XMLHandler.getTagValue(entrynode, "moved_date_time_format");
/*  228 */       this.AddMovedDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddMovedDateBeforeExtension"));
/*  229 */       this.create_move_to_folder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "create_move_to_folder"));
/*  230 */       this.add_moved_date = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_moved_date"));
/*  231 */       this.add_moved_time = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_moved_time"));
/*  232 */       this.SpecifyMoveFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyMoveFormat"));
/*  233 */       this.simulate = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "simulate"));
/*      */       
/*      */ 
/*  236 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*      */       
/*      */ 
/*  239 */       int nrFields = XMLHandler.countNodes(fields, "field");
/*  240 */       this.source_filefolder = new String[nrFields];
/*  241 */       this.destination_filefolder = new String[nrFields];
/*  242 */       this.wildcard = new String[nrFields];
/*      */       
/*      */ 
/*  245 */       for (int i = 0; i < nrFields; i++)
/*      */       {
/*  247 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*      */         
/*  249 */         this.source_filefolder[i] = XMLHandler.getTagValue(fnode, "source_filefolder");
/*  250 */         this.destination_filefolder[i] = XMLHandler.getTagValue(fnode, "destination_filefolder");
/*  251 */         this.wildcard[i] = XMLHandler.getTagValue(fnode, "wildcard");
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (KettleXMLException xe)
/*      */     {
/*  258 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobMoveFiles.Error.Exception.UnableLoadXML", new String[0]), xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  266 */       this.move_empty_folders = rep.getJobEntryAttributeBoolean(id_jobentry, "move_empty_folders");
/*  267 */       this.arg_from_previous = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/*  268 */       this.include_subfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*  269 */       this.add_result_filesname = rep.getJobEntryAttributeBoolean(id_jobentry, "add_result_filesname");
/*  270 */       this.destination_is_a_file = rep.getJobEntryAttributeBoolean(id_jobentry, "destination_is_a_file");
/*  271 */       this.create_destination_folder = rep.getJobEntryAttributeBoolean(id_jobentry, "create_destination_folder");
/*  272 */       this.nr_errors_less_than = rep.getJobEntryAttributeString(id_jobentry, "nr_errors_less_than");
/*  273 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/*  274 */       this.add_date = rep.getJobEntryAttributeBoolean(id_jobentry, "add_date");
/*  275 */       this.add_time = rep.getJobEntryAttributeBoolean(id_jobentry, "add_time");
/*  276 */       this.SpecifyFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyFormat");
/*  277 */       this.date_time_format = rep.getJobEntryAttributeString(id_jobentry, "date_time_format");
/*  278 */       this.AddDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddDateBeforeExtension");
/*  279 */       this.DoNotKeepFolderStructure = rep.getJobEntryAttributeBoolean(id_jobentry, "DoNotKeepFolderStructure");
/*  280 */       this.iffileexists = rep.getJobEntryAttributeString(id_jobentry, "iffileexists");
/*  281 */       this.destinationFolder = rep.getJobEntryAttributeString(id_jobentry, "destinationFolder");
/*  282 */       this.ifmovedfileexists = rep.getJobEntryAttributeString(id_jobentry, "ifmovedfileexists");
/*  283 */       this.moved_date_time_format = rep.getJobEntryAttributeString(id_jobentry, "moved_date_time_format");
/*  284 */       this.AddMovedDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddMovedDateBeforeExtension");
/*  285 */       this.create_move_to_folder = rep.getJobEntryAttributeBoolean(id_jobentry, "create_move_to_folder");
/*  286 */       this.add_moved_date = rep.getJobEntryAttributeBoolean(id_jobentry, "add_moved_date");
/*  287 */       this.add_moved_time = rep.getJobEntryAttributeBoolean(id_jobentry, "add_moved_time");
/*  288 */       this.SpecifyMoveFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyMoveFormat");
/*  289 */       this.simulate = rep.getJobEntryAttributeBoolean(id_jobentry, "simulate");
/*      */       
/*      */ 
/*      */ 
/*  293 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "source_filefolder");
/*  294 */       this.source_filefolder = new String[argnr];
/*  295 */       this.destination_filefolder = new String[argnr];
/*  296 */       this.wildcard = new String[argnr];
/*      */       
/*      */ 
/*  299 */       for (int a = 0; a < argnr; a++)
/*      */       {
/*  301 */         this.source_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_filefolder");
/*  302 */         this.destination_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "destination_filefolder");
/*  303 */         this.wildcard[a] = rep.getJobEntryAttributeString(id_jobentry, a, "wildcard");
/*      */       }
/*      */       
/*      */     }
/*      */     catch (KettleException dbe)
/*      */     {
/*  309 */       throw new KettleException(BaseMessages.getString(PKG, "JobMoveFiles.Error.Exception.UnableLoadRep", new String[0]) + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  318 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "move_empty_folders", this.move_empty_folders);
/*  319 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.arg_from_previous);
/*  320 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.include_subfolders);
/*  321 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_result_filesname", this.add_result_filesname);
/*  322 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destination_is_a_file", this.destination_is_a_file);
/*  323 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "create_destination_folder", this.create_destination_folder);
/*  324 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_errors_less_than", this.nr_errors_less_than);
/*  325 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*  326 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_date", this.add_date);
/*  327 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_time", this.add_time);
/*  328 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyFormat", this.SpecifyFormat);
/*  329 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_format", this.date_time_format);
/*  330 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddDateBeforeExtension", this.AddDateBeforeExtension);
/*  331 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "DoNotKeepFolderStructure", this.DoNotKeepFolderStructure);
/*  332 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "iffileexists", this.iffileexists);
/*  333 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destinationFolder", this.destinationFolder);
/*  334 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ifmovedfileexists", this.ifmovedfileexists);
/*  335 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "moved_date_time_format", this.moved_date_time_format);
/*  336 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_moved_date", this.add_moved_date);
/*  337 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_moved_time", this.add_moved_time);
/*  338 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyMoveFormat", this.SpecifyMoveFormat);
/*  339 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "create_move_to_folder", this.create_move_to_folder);
/*  340 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddMovedDateBeforeExtension", this.AddMovedDateBeforeExtension);
/*  341 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "simulate", this.simulate);
/*      */       
/*      */ 
/*  344 */       if (this.source_filefolder != null)
/*      */       {
/*  346 */         for (int i = 0; i < this.source_filefolder.length; i++)
/*      */         {
/*  348 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_filefolder", this.source_filefolder[i]);
/*  349 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "destination_filefolder", this.destination_filefolder[i]);
/*  350 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "wildcard", this.wildcard[i]);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  357 */       throw new KettleException(BaseMessages.getString(PKG, "JobMoveFiles.Error.Exception.UnableSaveRep", new String[0]) + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public Result execute(Result previousResult, int nr) throws KettleException {
/*  362 */     Result result = previousResult;
/*  363 */     List<RowMetaAndData> rows = result.getRows();
/*  364 */     RowMetaAndData resultRow = null;
/*  365 */     result.setNrErrors(1L);
/*  366 */     result.setResult(false);
/*      */     
/*  368 */     this.NrErrors = 0;
/*  369 */     this.NrSuccess = 0;
/*  370 */     this.successConditionBroken = false;
/*  371 */     this.successConditionBrokenExit = false;
/*  372 */     this.limitFiles = Const.toInt(environmentSubstitute(getNrErrorsLessThan()), 10);
/*      */     
/*  374 */     if (this.log.isDetailed()) {
/*  375 */       if (this.simulate) {
/*  376 */         logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.SimulationOn", new String[0]));
/*      */       }
/*  378 */       if (this.include_subfolders) {
/*  379 */         logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.IncludeSubFoldersOn", new String[0]));
/*      */       }
/*      */     }
/*      */     
/*  383 */     String MoveToFolder = environmentSubstitute(this.destinationFolder);
/*      */     
/*  385 */     String[] vsourcefilefolder = this.source_filefolder;
/*  386 */     String[] vdestinationfilefolder = this.destination_filefolder;
/*  387 */     String[] vwildcard = this.wildcard;
/*      */     
/*  389 */     if (this.iffileexists.equals("move_file")) {
/*  390 */       if (Const.isEmpty(MoveToFolder)) {
/*  391 */         logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.Error.MoveToFolderMissing", new String[0]));
/*  392 */         return result;
/*      */       }
/*  394 */       FileObject folder = null;
/*      */       try {
/*  396 */         folder = KettleVFS.getFileObject(MoveToFolder, this);
/*  397 */         Result localResult1; if (!folder.exists()) {
/*  398 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.Error.FolderMissing", new String[] { MoveToFolder }));
/*  399 */           if (this.create_move_to_folder) {
/*  400 */             folder.createFolder();
/*      */           } else {
/*  402 */             logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.Error.FolderMissing", new String[] { MoveToFolder }));
/*  403 */             return result;
/*      */           }
/*      */         }
/*  406 */         if (!folder.getType().equals(FileType.FOLDER)) {
/*  407 */           logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.Error.NotFolder", new String[] { MoveToFolder }));
/*  408 */           return result;
/*      */         }
/*      */       } catch (Exception e) {
/*  411 */         logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.Error.GettingMoveToFolder", new String[] { MoveToFolder, e.getMessage() }));
/*  412 */         return result;
/*      */       } finally {
/*  414 */         if (folder != null) {
/*      */           try {
/*  416 */             folder.close();
/*      */           }
/*      */           catch (IOException ex) {}
/*      */         }
/*      */       }
/*      */     }
/*  422 */     if ((this.arg_from_previous) && 
/*  423 */       (this.log.isDetailed())) {
/*  424 */       logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.ArgFromPrevious.Found", new String[] { (rows != null ? rows.size() : 0) + "" }));
/*      */     }
/*  426 */     if ((this.arg_from_previous) && (rows != null)) {
/*  427 */       for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++)
/*      */       {
/*  429 */         if (this.successConditionBroken) {
/*  430 */           if (!this.successConditionBrokenExit) {
/*  431 */             logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*  432 */             this.successConditionBrokenExit = true;
/*      */           }
/*  434 */           result.setNrErrors(this.NrErrors);
/*  435 */           displayResults();
/*  436 */           return result;
/*      */         }
/*      */         
/*  439 */         resultRow = (RowMetaAndData)rows.get(iteration);
/*      */         
/*      */ 
/*  442 */         String vsourcefilefolder_previous = resultRow.getString(0, null);
/*  443 */         String vdestinationfilefolder_previous = resultRow.getString(1, null);
/*  444 */         String vwildcard_previous = resultRow.getString(2, null);
/*      */         
/*  446 */         if ((!Const.isEmpty(vsourcefilefolder_previous)) && (!Const.isEmpty(vdestinationfilefolder_previous))) {
/*  447 */           if (this.log.isDetailed()) {
/*  448 */             logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.ProcessingRow", new String[] { vsourcefilefolder_previous, vdestinationfilefolder_previous, vwildcard_previous }));
/*      */           }
/*  450 */           if (!ProcessFileFolder(vsourcefilefolder_previous, vdestinationfilefolder_previous, vwildcard_previous, this.parentJob, result, MoveToFolder))
/*      */           {
/*      */ 
/*      */ 
/*  454 */             updateErrors();
/*      */           }
/*      */           
/*      */         }
/*  458 */         else if (this.log.isDetailed()) {
/*  459 */           logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.IgnoringRow", new String[] { vsourcefilefolder[iteration], vdestinationfilefolder[iteration], vwildcard[iteration] }));
/*      */         }
/*      */         
/*      */       }
/*  463 */     } else if ((vsourcefilefolder != null) && (vdestinationfilefolder != null)) {
/*  464 */       for (int i = 0; (i < vsourcefilefolder.length) && (!this.parentJob.isStopped()); i++)
/*      */       {
/*  466 */         if (this.successConditionBroken) {
/*  467 */           if (!this.successConditionBrokenExit) {
/*  468 */             logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*  469 */             this.successConditionBrokenExit = true;
/*      */           }
/*  471 */           result.setNrErrors(this.NrErrors);
/*  472 */           displayResults();
/*  473 */           return result;
/*      */         }
/*      */         
/*      */ 
/*  477 */         if ((!Const.isEmpty(vsourcefilefolder[i])) && (!Const.isEmpty(vdestinationfilefolder[i])))
/*      */         {
/*  479 */           if (this.log.isDetailed()) {
/*  480 */             logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.ProcessingRow", new String[] { vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i] }));
/*      */           }
/*  482 */           if (!ProcessFileFolder(vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i], this.parentJob, result, MoveToFolder))
/*      */           {
/*  484 */             updateErrors();
/*      */           }
/*      */           
/*      */         }
/*  488 */         else if (this.log.isDetailed()) {
/*  489 */           logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.IgnoringRow", new String[] { vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i] }));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  495 */     result.setNrErrors(this.NrErrors);
/*  496 */     result.setNrLinesWritten(this.NrSuccess);
/*  497 */     if (getSuccessStatus()) { result.setResult(true);
/*      */     }
/*  499 */     displayResults();
/*      */     
/*  501 */     return result;
/*      */   }
/*      */   
/*      */   private void displayResults() {
/*  505 */     if (this.log.isDetailed()) {
/*  506 */       logDetailed("=======================================");
/*  507 */       logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.Info.FilesInError", new String[] { "" + this.NrErrors }));
/*  508 */       logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.Info.FilesInSuccess", new String[] { "" + this.NrSuccess }));
/*  509 */       logDetailed("=======================================");
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean getSuccessStatus() {
/*  514 */     boolean retval = false;
/*      */     
/*  516 */     if (((this.NrErrors == 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrSuccess >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FILES_UN_ZIPPED))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*  519 */       retval = true;
/*      */     }
/*      */     
/*  522 */     return retval;
/*      */   }
/*      */   
/*      */   private boolean ProcessFileFolder(String sourcefilefoldername, String destinationfilefoldername, String wildcard, Job parentJob, Result result, String MoveToFolder)
/*      */   {
/*  527 */     boolean entrystatus = false;
/*  528 */     FileObject sourcefilefolder = null;
/*  529 */     FileObject destinationfilefolder = null;
/*  530 */     FileObject movetofolderfolder = null;
/*  531 */     FileObject Currentfile = null;
/*      */     
/*      */ 
/*  534 */     String realSourceFilefoldername = environmentSubstitute(sourcefilefoldername);
/*  535 */     String realDestinationFilefoldername = environmentSubstitute(destinationfilefoldername);
/*  536 */     String realWildcard = environmentSubstitute(wildcard);
/*      */     try
/*      */     {
/*  539 */       sourcefilefolder = KettleVFS.getFileObject(realSourceFilefoldername, this);
/*  540 */       destinationfilefolder = KettleVFS.getFileObject(realDestinationFilefoldername, this);
/*  541 */       if (!Const.isEmpty(MoveToFolder)) { movetofolderfolder = KettleVFS.getFileObject(MoveToFolder, this);
/*      */       }
/*  543 */       if (sourcefilefolder.exists())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  548 */         if (CreateDestinationFolder(destinationfilefolder))
/*      */         {
/*      */ 
/*  551 */           if ((sourcefilefolder.getType().equals(FileType.FOLDER)) && (this.destination_is_a_file))
/*      */           {
/*      */ 
/*      */ 
/*  555 */             this.log.logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.Forbidden", new String[0]), new Object[] { BaseMessages.getString(PKG, "JobMoveFiles.Log.CanNotMoveFolderToFile", new String[] { realSourceFilefoldername, realDestinationFilefoldername }) });
/*      */             
/*      */ 
/*  558 */             updateErrors();
/*      */ 
/*      */           }
/*  561 */           else if ((destinationfilefolder.getType().equals(FileType.FOLDER)) && (sourcefilefolder.getType().equals(FileType.FILE)))
/*      */           {
/*      */ 
/*      */ 
/*  565 */             String shortfilename = sourcefilefolder.getName().getBaseName();
/*      */             try
/*      */             {
/*  568 */               shortfilename = getDestinationFilename(shortfilename);
/*      */             } catch (Exception e) {
/*  570 */               logError(BaseMessages.getString(PKG, BaseMessages.getString(PKG, "JobMoveFiles.Error.GettingFilename", new String[] { sourcefilefolder.getName().getBaseName(), e.toString() }), new String[0]));
/*  571 */               return entrystatus;
/*      */             }
/*      */             
/*      */ 
/*  575 */             String destinationfilenamefull = KettleVFS.getFilename(destinationfilefolder) + Const.FILE_SEPARATOR + shortfilename;
/*  576 */             FileObject destinationfile = KettleVFS.getFileObject(destinationfilenamefull, this);
/*      */             
/*  578 */             entrystatus = MoveFile(shortfilename, sourcefilefolder, destinationfile, movetofolderfolder, parentJob, result);
/*      */           } else { String destinationfilenamefull;
/*  580 */             if ((sourcefilefolder.getType().equals(FileType.FILE)) && (this.destination_is_a_file))
/*      */             {
/*      */ 
/*      */ 
/*  584 */               FileObject destinationfile = KettleVFS.getFileObject(realDestinationFilefoldername, this);
/*      */               
/*      */ 
/*  587 */               String shortfilename = destinationfile.getName().getBaseName();
/*      */               try {
/*  589 */                 shortfilename = getDestinationFilename(shortfilename);
/*      */               }
/*      */               catch (Exception e) {
/*  592 */                 logError(BaseMessages.getString(PKG, BaseMessages.getString(PKG, "JobMoveFiles.Error.GettingFilename", new String[] { sourcefilefolder.getName().getBaseName(), e.toString() }), new String[0]));
/*  593 */                 return entrystatus;
/*      */               }
/*      */               
/*  596 */               destinationfilenamefull = KettleVFS.getFilename(destinationfile.getParent()) + Const.FILE_SEPARATOR + shortfilename;
/*  597 */               destinationfile = KettleVFS.getFileObject(destinationfilenamefull, this);
/*      */               
/*  599 */               entrystatus = MoveFile(shortfilename, sourcefilefolder, destinationfile, movetofolderfolder, parentJob, result);
/*      */             }
/*      */             else
/*      */             {
/*  603 */               if (this.log.isDetailed())
/*      */               {
/*  605 */                 logDetailed("  ");
/*  606 */                 logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FetchFolder", new String[] { sourcefilefolder.toString() }));
/*      */               }
/*      */               
/*  609 */               FileObject[] fileObjects = sourcefilefolder.findFiles(new AllFileSelector()
/*      */               {
/*      */                 public boolean traverseDescendents(FileSelectInfo info)
/*      */                 {
/*  613 */                   return true;
/*      */                 }
/*      */                 
/*      */                 public boolean includeFile(FileSelectInfo info) {
/*  617 */                   FileObject fileObject = info.getFile();
/*      */                   try {
/*  619 */                     if (fileObject == null) return false;
/*      */                   }
/*      */                   catch (Exception ex)
/*      */                   {
/*  623 */                     return false;
/*      */                   }
/*      */                   finally
/*      */                   {
/*  627 */                     if (fileObject != null) {
/*      */                       try {
/*  629 */                         fileObject.close();
/*      */                       } catch (IOException ex) {}
/*      */                     }
/*      */                   }
/*  633 */                   return true;
/*      */                 }
/*      */               });
/*      */               
/*      */ 
/*  638 */               if (fileObjects != null) {
/*  639 */                 for (int j = 0; (j < fileObjects.length) && (!parentJob.isStopped()); j++)
/*      */                 {
/*      */ 
/*  642 */                   if (this.successConditionBroken) {
/*  643 */                     if (!this.successConditionBrokenExit) {
/*  644 */                       logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*  645 */                       this.successConditionBrokenExit = true;
/*      */                     }
/*  647 */                     return false;
/*      */                   }
/*      */                   
/*  650 */                   Currentfile = fileObjects[j];
/*      */                   
/*  652 */                   if (!MoveOneFile(Currentfile, sourcefilefolder, realDestinationFilefoldername, realWildcard, parentJob, result, movetofolderfolder))
/*      */                   {
/*      */ 
/*  655 */                     updateErrors();
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  663 */           entrystatus = true;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  668 */           logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.DestinationFolderNotFound", new String[] { realDestinationFilefoldername }));
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/*  673 */         logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.SourceFileNotExists", new String[] { realSourceFilefoldername }));
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  678 */       logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.Exception.MoveProcess", new String[] { realSourceFilefoldername.toString(), destinationfilefolder.toString(), e.getMessage() }));
/*      */       
/*  680 */       updateErrors();
/*      */     }
/*      */     finally {
/*  683 */       if (sourcefilefolder != null) {
/*      */         try {
/*  685 */           sourcefilefolder.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  689 */       if (destinationfilefolder != null) {
/*      */         try {
/*  691 */           destinationfilefolder.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  695 */       if (Currentfile != null) {
/*      */         try {
/*  697 */           Currentfile.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  701 */       if (movetofolderfolder != null) {
/*      */         try {
/*  703 */           movetofolderfolder.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*  708 */     return entrystatus;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean MoveFile(String shortfilename, FileObject sourcefilename, FileObject destinationfilename, FileObject movetofolderfolder, Job parentJob, Result result)
/*      */   {
/*  716 */     FileObject destinationfile = null;
/*  717 */     boolean retval = false;
/*      */     try {
/*  719 */       if (!destinationfilename.exists()) {
/*  720 */         if (!this.simulate) sourcefilename.moveTo(destinationfilename);
/*  721 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileMoved", new String[] { sourcefilename.getName().toString(), destinationfilename.getName().toString() }));
/*      */         }
/*      */         
/*  724 */         if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  725 */           addFileToResultFilenames(destinationfilename.toString(), result, parentJob);
/*      */         }
/*  727 */         updateSuccess();
/*      */       }
/*      */       else
/*      */       {
/*  731 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileExists", new String[] { destinationfilename.toString() }));
/*  732 */         if (this.iffileexists.equals("overwrite_file")) {
/*  733 */           if (!this.simulate) sourcefilename.moveTo(destinationfilename);
/*  734 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileOverwrite", new String[] { destinationfilename.getName().toString() }));
/*      */           }
/*      */           
/*  737 */           if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  738 */             addFileToResultFilenames(destinationfilename.toString(), result, parentJob);
/*      */           }
/*  740 */           updateSuccess();
/*      */         } else {
/*      */           boolean bool1;
/*  743 */           if (this.iffileexists.equals("unique_name")) {
/*  744 */             String short_filename = shortfilename;
/*      */             
/*      */             try
/*      */             {
/*  748 */               short_filename = getMoveDestinationFilename(short_filename, "ddMMyyyy_HHmmssSSS");
/*      */             }
/*      */             catch (Exception e) {
/*  751 */               logError(BaseMessages.getString(PKG, BaseMessages.getString(PKG, "JobMoveFiles.Error.GettingFilename", new String[] { short_filename }), new String[0]), e);
/*  752 */               return retval;
/*      */             }
/*      */             
/*      */ 
/*  756 */             String movetofilenamefull = destinationfilename.getParent().toString() + Const.FILE_SEPARATOR + short_filename;
/*  757 */             destinationfile = KettleVFS.getFileObject(movetofilenamefull, this);
/*      */             
/*      */ 
/*  760 */             if (!this.simulate) sourcefilename.moveTo(destinationfile);
/*  761 */             if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileMoved", new String[] { sourcefilename.getName().toString(), destinationfile.getName().toString() }));
/*      */             }
/*      */             
/*      */ 
/*  765 */             if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  766 */               addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */             }
/*      */             
/*  769 */             updateSuccess();
/*      */           }
/*  771 */           else if (this.iffileexists.equals("delete_file")) {
/*  772 */             if (!this.simulate) destinationfilename.delete();
/*  773 */             if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileDeleted", new String[] { destinationfilename.getName().toString() }));
/*      */           }
/*  775 */           else if (this.iffileexists.equals("move_file")) {
/*  776 */             String short_filename = shortfilename;
/*      */             try
/*      */             {
/*  779 */               short_filename = getMoveDestinationFilename(short_filename, null);
/*      */             }
/*      */             catch (Exception e) {
/*  782 */               logError(BaseMessages.getString(PKG, BaseMessages.getString(PKG, "JobMoveFiles.Error.GettingFilename", new String[] { short_filename }), new String[0]), e);
/*  783 */               return retval;
/*      */             }
/*      */             
/*  786 */             String movetofilenamefull = movetofolderfolder.toString() + Const.FILE_SEPARATOR + short_filename;
/*  787 */             destinationfile = KettleVFS.getFileObject(movetofilenamefull, this);
/*  788 */             if (!destinationfile.exists()) {
/*  789 */               if (!this.simulate) sourcefilename.moveTo(destinationfile);
/*  790 */               if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileMoved", new String[] { sourcefilename.getName().toString(), destinationfile.getName().toString() }));
/*      */               }
/*      */               
/*  793 */               if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  794 */                 addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */               }
/*      */             }
/*  797 */             else if (this.ifmovedfileexists.equals("overwrite_file"))
/*      */             {
/*  799 */               if (!this.simulate) sourcefilename.moveTo(destinationfile);
/*  800 */               if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileOverwrite", new String[] { destinationfile.getName().toString() }));
/*      */               }
/*      */               
/*  803 */               if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  804 */                 addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */               }
/*  806 */               updateSuccess();
/*      */             }
/*  808 */             else if (this.ifmovedfileexists.equals("unique_name"))
/*      */             {
/*  810 */               SimpleDateFormat daf = new SimpleDateFormat();
/*  811 */               Date now = new Date();
/*  812 */               daf.applyPattern("ddMMyyyy_HHmmssSSS");
/*  813 */               String dt = daf.format(now);
/*  814 */               short_filename = short_filename + "_" + dt;
/*      */               
/*  816 */               String destinationfilenamefull = movetofolderfolder.toString() + Const.FILE_SEPARATOR + short_filename;
/*  817 */               destinationfile = KettleVFS.getFileObject(destinationfilenamefull, this);
/*      */               
/*  819 */               if (!this.simulate) sourcefilename.moveTo(destinationfile);
/*  820 */               if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileMoved", new String[] { destinationfile.getName().toString() }));
/*      */               }
/*      */               
/*  823 */               if ((this.add_result_filesname) && (!this.iffileexists.equals("fail")) && (!this.iffileexists.equals("do_nothing"))) {
/*  824 */                 addFileToResultFilenames(destinationfile.toString(), result, parentJob);
/*      */               }
/*  826 */               updateSuccess();
/*      */             }
/*  828 */             else if (this.ifmovedfileexists.equals("fail"))
/*      */             {
/*      */ 
/*  831 */               updateErrors();
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*  836 */           else if (this.iffileexists.equals("fail"))
/*      */           {
/*      */ 
/*  839 */             updateErrors();
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  844 */       logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.Exception.MoveProcessError", new String[] { sourcefilename.toString(), destinationfilename.toString(), e.getMessage() }));
/*      */     }
/*      */     finally
/*      */     {
/*  848 */       if (destinationfile != null) {
/*      */         try {
/*  850 */           destinationfile.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*  855 */     return retval;
/*      */   }
/*      */   
/*      */   private boolean MoveOneFile(FileObject Currentfile, FileObject sourcefilefolder, String realDestinationFilefoldername, String realWildcard, Job parentJob, Result result, FileObject movetofolderfolder)
/*      */   {
/*  860 */     boolean entrystatus = false;
/*  861 */     FileObject file_name = null;
/*      */     try
/*      */     {
/*  864 */       if (!Currentfile.toString().equals(sourcefilefolder.toString()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  869 */         String sourceshortfilename = Currentfile.getName().getBaseName();
/*  870 */         String shortfilename = sourceshortfilename;
/*      */         try {
/*  872 */           shortfilename = getDestinationFilename(sourceshortfilename);
/*      */         }
/*      */         catch (Exception e) {
/*  875 */           logError(BaseMessages.getString(PKG, BaseMessages.getString(PKG, "JobMoveFiles.Error.GettingFilename", new String[] { Currentfile.getName().getBaseName(), e.toString() }), new String[0]));
/*  876 */           return entrystatus;
/*      */         }
/*      */         
/*  879 */         int lenCurrent = sourceshortfilename.length();
/*  880 */         String short_filename_from_basefolder = shortfilename;
/*  881 */         if (!isDoNotKeepFolderStructure())
/*  882 */           short_filename_from_basefolder = Currentfile.toString().substring(sourcefilefolder.toString().length(), Currentfile.toString().length());
/*  883 */         short_filename_from_basefolder = short_filename_from_basefolder.substring(0, short_filename_from_basefolder.length() - lenCurrent) + shortfilename;
/*      */         
/*      */ 
/*  886 */         file_name = KettleVFS.getFileObject(realDestinationFilefoldername + Const.FILE_SEPARATOR + short_filename_from_basefolder, this);
/*      */         
/*      */ 
/*      */ 
/*  890 */         if (!Currentfile.getParent().toString().equals(sourcefilefolder.toString()))
/*      */         {
/*      */ 
/*      */ 
/*  894 */           if (this.include_subfolders)
/*      */           {
/*      */ 
/*  897 */             if (Currentfile.getType() == FileType.FOLDER)
/*      */             {
/*  899 */               if ((this.include_subfolders) && (this.move_empty_folders) && (Const.isEmpty(this.wildcard)))
/*      */               {
/*  901 */                 entrystatus = MoveFile(shortfilename, Currentfile, file_name, movetofolderfolder, parentJob, result);
/*      */ 
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*  907 */             else if (GetFileWildcard(sourceshortfilename, realWildcard))
/*      */             {
/*  909 */               entrystatus = MoveFile(shortfilename, Currentfile, file_name, movetofolderfolder, parentJob, result);
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*  918 */         else if (Currentfile.getType() == FileType.FOLDER)
/*      */         {
/*  920 */           if ((this.include_subfolders) && (this.move_empty_folders) && (Const.isEmpty(this.wildcard)))
/*      */           {
/*  922 */             entrystatus = MoveFile(shortfilename, Currentfile, file_name, movetofolderfolder, parentJob, result);
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */         }
/*  929 */         else if (GetFileWildcard(sourceshortfilename, realWildcard))
/*      */         {
/*  931 */           entrystatus = MoveFile(shortfilename, Currentfile, file_name, movetofolderfolder, parentJob, result);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  940 */       entrystatus = true;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  944 */       logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.Error", new String[] { e.toString() }));
/*      */     }
/*      */     finally
/*      */     {
/*  948 */       if (file_name != null)
/*      */       {
/*      */         try
/*      */         {
/*  952 */           file_name.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  959 */     return entrystatus;
/*      */   }
/*      */   
/*      */   private void updateErrors()
/*      */   {
/*  964 */     this.NrErrors += 1;
/*  965 */     if (checkIfSuccessConditionBroken())
/*      */     {
/*      */ 
/*  968 */       this.successConditionBroken = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean checkIfSuccessConditionBroken() {
/*  973 */     boolean retval = false;
/*  974 */     if (((this.NrErrors > 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*  977 */       retval = true;
/*      */     }
/*  979 */     return retval;
/*      */   }
/*      */   
/*      */   private void updateSuccess() {
/*  983 */     this.NrSuccess += 1;
/*      */   }
/*      */   
/*      */   private void addFileToResultFilenames(String fileaddentry, Result result, Job parentJob)
/*      */   {
/*      */     try {
/*  989 */       ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(fileaddentry, this), parentJob.getJobname(), toString());
/*  990 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*      */       
/*  992 */       if (this.log.isDebug())
/*      */       {
/*  994 */         logDebug(" ------ ");
/*  995 */         logDebug(BaseMessages.getString(PKG, "JobMoveFiles.Log.FileAddedToResultFilesName", new String[] { fileaddentry }));
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1000 */       this.log.logError(BaseMessages.getString(PKG, "JobMoveFiles.Error.AddingToFilenameResult", new String[0]), new Object[] { fileaddentry + "" + e.getMessage() });
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean CreateDestinationFolder(FileObject filefolder)
/*      */   {
/* 1006 */     FileObject folder = null;
/*      */     try
/*      */     {
/* 1009 */       if (this.destination_is_a_file) {
/* 1010 */         folder = filefolder.getParent();
/*      */       } else
/* 1012 */         folder = filefolder;
/*      */       boolean bool;
/* 1014 */       if (!folder.exists())
/*      */       {
/* 1016 */         if (this.create_destination_folder)
/*      */         {
/* 1018 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FolderNotExist", new String[] { folder.getName().toString() }));
/* 1019 */           folder.createFolder();
/* 1020 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobMoveFiles.Log.FolderWasCreated", new String[] { folder.getName().toString() }));
/*      */         }
/*      */         else
/*      */         {
/* 1024 */           logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.FolderNotExist", new String[] { folder.getName().toString() }));
/* 1025 */           return false;
/*      */         }
/*      */       }
/* 1028 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/* 1031 */       logError(BaseMessages.getString(PKG, "JobMoveFiles.Log.CanNotCreateParentFolder", new String[] { folder.getName().toString() }), e);
/*      */     }
/*      */     finally
/*      */     {
/* 1035 */       if (folder != null) {
/*      */         try
/*      */         {
/* 1038 */           folder.close();
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */     }
/* 1043 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*      */   {
/* 1056 */     Pattern pattern = null;
/* 1057 */     boolean getIt = true;
/*      */     
/* 1059 */     if (!Const.isEmpty(wildcard))
/*      */     {
/* 1061 */       pattern = Pattern.compile(wildcard);
/*      */       
/* 1063 */       if (pattern != null)
/*      */       {
/* 1065 */         Matcher matcher = pattern.matcher(selectedfile);
/* 1066 */         getIt = matcher.matches();
/*      */       }
/*      */     }
/*      */     
/* 1070 */     return getIt;
/*      */   }
/*      */   
/*      */   private String getDestinationFilename(String shortsourcefilename) throws Exception {
/* 1074 */     String shortfilename = shortsourcefilename;
/* 1075 */     int lenstring = shortsourcefilename.length();
/* 1076 */     int lastindexOfDot = shortfilename.lastIndexOf('.');
/* 1077 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */     }
/* 1079 */     if (isAddDateBeforeExtension()) {
/* 1080 */       shortfilename = shortfilename.substring(0, lastindexOfDot);
/*      */     }
/*      */     
/* 1083 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 1084 */     Date now = new Date();
/*      */     
/* 1086 */     if ((isSpecifyFormat()) && (!Const.isEmpty(getDateTimeFormat())))
/*      */     {
/* 1088 */       daf.applyPattern(getDateTimeFormat());
/* 1089 */       String dt = daf.format(now);
/* 1090 */       shortfilename = shortfilename + dt;
/*      */     }
/*      */     else {
/* 1093 */       if (isAddDate())
/*      */       {
/* 1095 */         daf.applyPattern("yyyyMMdd");
/* 1096 */         String d = daf.format(now);
/* 1097 */         shortfilename = shortfilename + "_" + d;
/*      */       }
/* 1099 */       if (isAddTime())
/*      */       {
/* 1101 */         daf.applyPattern("HHmmssSSS");
/* 1102 */         String t = daf.format(now);
/* 1103 */         shortfilename = shortfilename + "_" + t;
/*      */       }
/*      */     }
/* 1106 */     if (isAddDateBeforeExtension()) {
/* 1107 */       shortfilename = shortfilename + shortsourcefilename.substring(lastindexOfDot, lenstring);
/*      */     }
/*      */     
/* 1110 */     return shortfilename;
/*      */   }
/*      */   
/*      */   private String getMoveDestinationFilename(String shortsourcefilename, String DateFormat) throws Exception {
/* 1114 */     String shortfilename = shortsourcefilename;
/* 1115 */     int lenstring = shortsourcefilename.length();
/* 1116 */     int lastindexOfDot = shortfilename.lastIndexOf('.');
/* 1117 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */     }
/* 1119 */     if (isAddMovedDateBeforeExtension()) {
/* 1120 */       shortfilename = shortfilename.substring(0, lastindexOfDot);
/*      */     }
/* 1122 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 1123 */     Date now = new Date();
/*      */     
/* 1125 */     if (DateFormat != null)
/*      */     {
/* 1127 */       daf.applyPattern(DateFormat);
/* 1128 */       String dt = daf.format(now);
/* 1129 */       shortfilename = shortfilename + dt;
/*      */ 
/*      */ 
/*      */     }
/* 1133 */     else if ((isSpecifyMoveFormat()) && (!Const.isEmpty(getMovedDateTimeFormat())))
/*      */     {
/* 1135 */       daf.applyPattern(getMovedDateTimeFormat());
/* 1136 */       String dt = daf.format(now);
/* 1137 */       shortfilename = shortfilename + dt;
/*      */     }
/*      */     else {
/* 1140 */       if (isAddMovedDate())
/*      */       {
/* 1142 */         daf.applyPattern("yyyyMMdd");
/* 1143 */         String d = daf.format(now);
/* 1144 */         shortfilename = shortfilename + "_" + d;
/*      */       }
/* 1146 */       if (isAddMovedTime())
/*      */       {
/* 1148 */         daf.applyPattern("HHmmssSSS");
/* 1149 */         String t = daf.format(now);
/* 1150 */         shortfilename = shortfilename + "_" + t;
/*      */       }
/*      */     }
/*      */     
/* 1154 */     if (isAddMovedDateBeforeExtension()) {
/* 1155 */       shortfilename = shortfilename + shortsourcefilename.substring(lastindexOfDot, lenstring);
/*      */     }
/*      */     
/* 1158 */     return shortfilename;
/*      */   }
/*      */   
/*      */   public void setAddDate(boolean adddate) {
/* 1162 */     this.add_date = adddate;
/*      */   }
/*      */   
/*      */   public boolean isAddDate()
/*      */   {
/* 1167 */     return this.add_date;
/*      */   }
/*      */   
/*      */   public boolean isAddMovedDate()
/*      */   {
/* 1172 */     return this.add_moved_date;
/*      */   }
/*      */   
/*      */   public void setAddMovedDate(boolean add_moved_date) {
/* 1176 */     this.add_moved_date = add_moved_date;
/*      */   }
/*      */   
/*      */   public boolean isAddMovedTime() {
/* 1180 */     return this.add_moved_time;
/*      */   }
/*      */   
/*      */   public void setAddMovedTime(boolean add_moved_time) {
/* 1184 */     this.add_moved_time = add_moved_time;
/*      */   }
/*      */   
/*      */   public void setIfFileExists(String iffileexists)
/*      */   {
/* 1189 */     this.iffileexists = iffileexists;
/*      */   }
/*      */   
/*      */   public String getIfFileExists() {
/* 1193 */     return this.iffileexists;
/*      */   }
/*      */   
/*      */   public void setIfMovedFileExists(String ifmovedfileexists) {
/* 1197 */     this.ifmovedfileexists = ifmovedfileexists;
/*      */   }
/*      */   
/*      */   public String getIfMovedFileExists() {
/* 1201 */     return this.ifmovedfileexists;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAddTime(boolean addtime)
/*      */   {
/* 1209 */     this.add_time = addtime;
/*      */   }
/*      */   
/*      */   public boolean isAddTime()
/*      */   {
/* 1214 */     return this.add_time;
/*      */   }
/*      */   
/*      */   public void setAddDateBeforeExtension(boolean AddDateBeforeExtension)
/*      */   {
/* 1219 */     this.AddDateBeforeExtension = AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public void setAddMovedDateBeforeExtension(boolean AddMovedDateBeforeExtension) {
/* 1223 */     this.AddMovedDateBeforeExtension = AddMovedDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isSpecifyFormat() {
/* 1227 */     return this.SpecifyFormat;
/*      */   }
/*      */   
/*      */   public void setSpecifyFormat(boolean SpecifyFormat) {
/* 1231 */     this.SpecifyFormat = SpecifyFormat;
/*      */   }
/*      */   
/*      */   public void setSpecifyMoveFormat(boolean SpecifyMoveFormat) {
/* 1235 */     this.SpecifyMoveFormat = SpecifyMoveFormat;
/*      */   }
/*      */   
/*      */   public boolean isSpecifyMoveFormat() {
/* 1239 */     return this.SpecifyMoveFormat;
/*      */   }
/*      */   
/*      */   public String getDateTimeFormat() {
/* 1243 */     return this.date_time_format;
/*      */   }
/*      */   
/*      */   public void setDateTimeFormat(String date_time_format) {
/* 1247 */     this.date_time_format = date_time_format;
/*      */   }
/*      */   
/*      */   public String getMovedDateTimeFormat()
/*      */   {
/* 1252 */     return this.moved_date_time_format;
/*      */   }
/*      */   
/*      */   public void setMovedDateTimeFormat(String moved_date_time_format) {
/* 1256 */     this.moved_date_time_format = moved_date_time_format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAddDateBeforeExtension()
/*      */   {
/* 1264 */     return this.AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isAddMovedDateBeforeExtension() {
/* 1268 */     return this.AddMovedDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isDoNotKeepFolderStructure() {
/* 1272 */     return this.DoNotKeepFolderStructure;
/*      */   }
/*      */   
/*      */   public void setDestinationFolder(String destinationFolder) {
/* 1276 */     this.destinationFolder = destinationFolder;
/*      */   }
/*      */   
/*      */   public String getDestinationFolder() {
/* 1280 */     return this.destinationFolder;
/*      */   }
/*      */   
/*      */   public void setDoNotKeepFolderStructure(boolean DoNotKeepFolderStructure) {
/* 1284 */     this.DoNotKeepFolderStructure = DoNotKeepFolderStructure;
/*      */   }
/*      */   
/*      */   public void setMoveEmptyFolders(boolean move_empty_foldersin)
/*      */   {
/* 1289 */     this.move_empty_folders = move_empty_foldersin;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setIncludeSubfolders(boolean include_subfoldersin)
/*      */   {
/* 1295 */     this.include_subfolders = include_subfoldersin;
/*      */   }
/*      */   
/*      */   public void setAddresultfilesname(boolean add_result_filesnamein)
/*      */   {
/* 1300 */     this.add_result_filesname = add_result_filesnamein;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setArgFromPrevious(boolean argfrompreviousin)
/*      */   {
/* 1306 */     this.arg_from_previous = argfrompreviousin;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDestinationIsAFile(boolean destination_is_a_file)
/*      */   {
/* 1312 */     this.destination_is_a_file = destination_is_a_file;
/*      */   }
/*      */   
/*      */   public void setCreateDestinationFolder(boolean create_destination_folder)
/*      */   {
/* 1317 */     this.create_destination_folder = create_destination_folder;
/*      */   }
/*      */   
/*      */   public void setCreateMoveToFolder(boolean create_move_to_folder)
/*      */   {
/* 1322 */     this.create_move_to_folder = create_move_to_folder;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setNrErrorsLessThan(String nr_errors_less_than)
/*      */   {
/* 1328 */     this.nr_errors_less_than = nr_errors_less_than;
/*      */   }
/*      */   
/*      */   public String getNrErrorsLessThan()
/*      */   {
/* 1333 */     return this.nr_errors_less_than;
/*      */   }
/*      */   
/*      */   public void setSimulate(boolean simulate)
/*      */   {
/* 1338 */     this.simulate = simulate;
/*      */   }
/*      */   
/*      */   public void setSuccessCondition(String success_condition)
/*      */   {
/* 1343 */     this.success_condition = success_condition;
/*      */   }
/*      */   
/*      */   public String getSuccessCondition() {
/* 1347 */     return this.success_condition;
/*      */   }
/*      */   
/*      */ 
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1353 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */     
/* 1355 */     if (!res)
/*      */     {
/* 1357 */       return;
/*      */     }
/*      */     
/* 1360 */     ValidatorContext ctx = new ValidatorContext();
/* 1361 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 1362 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*      */     
/* 1364 */     for (int i = 0; i < this.source_filefolder.length; i++)
/*      */     {
/* 1366 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean evaluates() {
/* 1371 */     return true;
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\movefiles\JobEntryMoveFiles.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */