/*      */ package org.pentaho.di.job.entries.mail;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipOutputStream;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.activation.FileDataSource;
/*      */ import javax.activation.URLDataSource;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.Message.RecipientType;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.SendFailedException;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.Transport;
/*      */ import javax.mail.internet.InternetAddress;
/*      */ import javax.mail.internet.MimeBodyPart;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.internet.MimeMultipart;
/*      */ import org.apache.commons.vfs.FileName;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.apache.commons.vfs.FileType;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.gui.JobTracker;
/*      */ import org.pentaho.di.core.logging.LogChannelInterface;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobEntryResult;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.pentaho.di.resource.ResourceEntry;
/*      */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*      */ import org.pentaho.di.resource.ResourceReference;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryMail
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   92 */   private static Class<?> PKG = JobEntryMail.class;
/*      */   
/*      */ 
/*      */   private String server;
/*      */   
/*      */ 
/*      */   private String destination;
/*      */   
/*      */ 
/*      */   private String destinationCc;
/*      */   
/*      */   private String destinationBCc;
/*      */   
/*      */   private String replyAddress;
/*      */   
/*      */   private String replyName;
/*      */   
/*      */   private String subject;
/*      */   
/*      */   private boolean includeDate;
/*      */   
/*      */   private String contactPerson;
/*      */   
/*      */   private String contactPhone;
/*      */   
/*      */   private String comment;
/*      */   
/*      */   private boolean includingFiles;
/*      */   
/*      */   private int[] fileType;
/*      */   
/*      */   private boolean zipFiles;
/*      */   
/*      */   private String zipFilename;
/*      */   
/*      */   private boolean usingAuthentication;
/*      */   
/*      */   private String authenticationUser;
/*      */   
/*      */   private String authenticationPassword;
/*      */   
/*      */   private boolean onlySendComment;
/*      */   
/*      */   private boolean useHTML;
/*      */   
/*      */   private boolean usingSecureAuthentication;
/*      */   
/*      */   private boolean usePriority;
/*      */   
/*      */   private String port;
/*      */   
/*      */   private String priority;
/*      */   
/*      */   private String importance;
/*      */   
/*      */   private String secureConnectionType;
/*      */   
/*      */   private String encoding;
/*      */   
/*      */   private String replyToAddresses;
/*      */   
/*      */   public String[] embeddedimages;
/*      */   
/*      */   public String[] contentids;
/*      */   
/*      */ 
/*      */   public JobEntryMail(String n)
/*      */   {
/*  160 */     super(n, "");
/*  161 */     allocate(0);
/*      */   }
/*      */   
/*      */   public JobEntryMail()
/*      */   {
/*  166 */     this("");
/*  167 */     allocate(0);
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  172 */     JobEntryMail je = (JobEntryMail)super.clone();
/*  173 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  178 */     StringBuffer retval = new StringBuffer(300);
/*      */     
/*  180 */     retval.append(super.getXML());
/*      */     
/*  182 */     retval.append("      ").append(XMLHandler.addTagValue("server", this.server));
/*  183 */     retval.append("      ").append(XMLHandler.addTagValue("port", this.port));
/*  184 */     retval.append("      ").append(XMLHandler.addTagValue("destination", this.destination));
/*  185 */     retval.append("      ").append(XMLHandler.addTagValue("destinationCc", this.destinationCc));
/*  186 */     retval.append("      ").append(XMLHandler.addTagValue("destinationBCc", this.destinationBCc));
/*  187 */     retval.append("      ").append(XMLHandler.addTagValue("replyto", this.replyAddress));
/*  188 */     retval.append("      ").append(XMLHandler.addTagValue("replytoname", this.replyName));
/*  189 */     retval.append("      ").append(XMLHandler.addTagValue("subject", this.subject));
/*  190 */     retval.append("      ").append(XMLHandler.addTagValue("include_date", this.includeDate));
/*  191 */     retval.append("      ").append(XMLHandler.addTagValue("contact_person", this.contactPerson));
/*  192 */     retval.append("      ").append(XMLHandler.addTagValue("contact_phone", this.contactPhone));
/*  193 */     retval.append("      ").append(XMLHandler.addTagValue("comment", this.comment));
/*  194 */     retval.append("      ").append(XMLHandler.addTagValue("include_files", this.includingFiles));
/*  195 */     retval.append("      ").append(XMLHandler.addTagValue("zip_files", this.zipFiles));
/*  196 */     retval.append("      ").append(XMLHandler.addTagValue("zip_name", this.zipFilename));
/*      */     
/*  198 */     retval.append("      ").append(XMLHandler.addTagValue("use_auth", this.usingAuthentication));
/*  199 */     retval.append("      ").append(XMLHandler.addTagValue("use_secure_auth", this.usingSecureAuthentication));
/*  200 */     retval.append("      ").append(XMLHandler.addTagValue("auth_user", this.authenticationUser));
/*  201 */     retval.append("      ").append(XMLHandler.addTagValue("auth_password", Encr.encryptPasswordIfNotUsingVariables(this.authenticationPassword)));
/*      */     
/*  203 */     retval.append("      ").append(XMLHandler.addTagValue("only_comment", this.onlySendComment));
/*  204 */     retval.append("      ").append(XMLHandler.addTagValue("use_HTML", this.useHTML));
/*  205 */     retval.append("      ").append(XMLHandler.addTagValue("use_Priority", this.usePriority));
/*      */     
/*  207 */     retval.append("      ").append(XMLHandler.addTagValue("encoding", this.encoding));
/*  208 */     retval.append("      ").append(XMLHandler.addTagValue("priority", this.priority));
/*  209 */     retval.append("      ").append(XMLHandler.addTagValue("importance", this.importance));
/*      */     
/*  211 */     retval.append("      ").append(XMLHandler.addTagValue("secureconnectiontype", this.secureConnectionType));
/*  212 */     retval.append("      ").append(XMLHandler.addTagValue("replyToAddresses", this.replyToAddresses));
/*      */     
/*  214 */     retval.append("      <filetypes>");
/*  215 */     if (this.fileType != null) {
/*  216 */       for (int i = 0; i < this.fileType.length; i++)
/*      */       {
/*  218 */         retval.append("        ").append(XMLHandler.addTagValue("filetype", ResultFile.getTypeCode(this.fileType[i]))); }
/*      */     }
/*  220 */     retval.append("      </filetypes>");
/*      */     
/*  222 */     retval.append("      <embeddedimages>").append(Const.CR);
/*  223 */     if (this.embeddedimages != null) {
/*  224 */       for (int i = 0; i < this.embeddedimages.length; i++) {
/*  225 */         retval.append("        <embeddedimage>").append(Const.CR);
/*  226 */         retval.append("          ").append(XMLHandler.addTagValue("image_name", this.embeddedimages[i]));
/*  227 */         retval.append("          ").append(XMLHandler.addTagValue("content_id", this.contentids[i]));
/*  228 */         retval.append("        </embeddedimage>").append(Const.CR);
/*      */       }
/*      */     }
/*  231 */     retval.append("      </embeddedimages>").append(Const.CR);
/*      */     
/*  233 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void allocate(int nrFileTypes)
/*      */   {
/*  238 */     this.fileType = new int[nrFileTypes];
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  245 */       super.loadXML(entrynode, databases, slaveServers);
/*  246 */       setServer(XMLHandler.getTagValue(entrynode, "server"));
/*  247 */       setPort(XMLHandler.getTagValue(entrynode, "port"));
/*  248 */       setDestination(XMLHandler.getTagValue(entrynode, "destination"));
/*  249 */       setDestinationCc(XMLHandler.getTagValue(entrynode, "destinationCc"));
/*  250 */       setDestinationBCc(XMLHandler.getTagValue(entrynode, "destinationBCc"));
/*  251 */       setReplyAddress(XMLHandler.getTagValue(entrynode, "replyto"));
/*  252 */       setReplyName(XMLHandler.getTagValue(entrynode, "replytoname"));
/*  253 */       setSubject(XMLHandler.getTagValue(entrynode, "subject"));
/*  254 */       setIncludeDate("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_date")));
/*  255 */       setContactPerson(XMLHandler.getTagValue(entrynode, "contact_person"));
/*  256 */       setContactPhone(XMLHandler.getTagValue(entrynode, "contact_phone"));
/*  257 */       setComment(XMLHandler.getTagValue(entrynode, "comment"));
/*  258 */       setIncludingFiles("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_files")));
/*      */       
/*  260 */       setUsingAuthentication("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "use_auth")));
/*  261 */       setUsingSecureAuthentication("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "use_secure_auth")));
/*  262 */       setAuthenticationUser(XMLHandler.getTagValue(entrynode, "auth_user"));
/*  263 */       setAuthenticationPassword(Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "auth_password")));
/*      */       
/*  265 */       setOnlySendComment("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "only_comment")));
/*  266 */       setUseHTML("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "use_HTML")));
/*      */       
/*  268 */       setUsePriority("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "use_Priority")));
/*      */       
/*      */ 
/*  271 */       setEncoding(XMLHandler.getTagValue(entrynode, "encoding"));
/*  272 */       setPriority(XMLHandler.getTagValue(entrynode, "priority"));
/*  273 */       setImportance(XMLHandler.getTagValue(entrynode, "importance"));
/*  274 */       setSecureConnectionType(XMLHandler.getTagValue(entrynode, "secureconnectiontype"));
/*      */       
/*      */ 
/*  277 */       Node ftsnode = XMLHandler.getSubNode(entrynode, "filetypes");
/*  278 */       int nrTypes = XMLHandler.countNodes(ftsnode, "filetype");
/*  279 */       allocate(nrTypes);
/*  280 */       for (int i = 0; i < nrTypes; i++)
/*      */       {
/*  282 */         Node ftnode = XMLHandler.getSubNodeByNr(ftsnode, "filetype", i);
/*  283 */         this.fileType[i] = ResultFile.getType(XMLHandler.getNodeValue(ftnode));
/*      */       }
/*      */       
/*  286 */       setZipFiles("Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "zip_files")));
/*  287 */       setZipFilename(XMLHandler.getTagValue(entrynode, "zip_name"));
/*  288 */       setReplyToAddresses(XMLHandler.getTagValue(entrynode, "replyToAddresses"));
/*      */       
/*  290 */       Node images = XMLHandler.getSubNode(entrynode, "embeddedimages");
/*      */       
/*      */ 
/*  293 */       int nrImages = XMLHandler.countNodes(images, "embeddedimage");
/*  294 */       this.embeddedimages = new String[nrImages];
/*  295 */       this.contentids = new String[nrImages];
/*      */       
/*      */ 
/*  298 */       for (int i = 0; i < nrImages; i++) {
/*  299 */         Node fnode = XMLHandler.getSubNodeByNr(images, "embeddedimage", i);
/*      */         
/*  301 */         this.embeddedimages[i] = XMLHandler.getTagValue(fnode, "image_name");
/*  302 */         this.contentids[i] = XMLHandler.getTagValue(fnode, "content_id");
/*      */       }
/*      */       
/*      */     }
/*      */     catch (KettleException xe)
/*      */     {
/*  308 */       throw new KettleXMLException("Unable to load job entry of type 'mail' from XML node", xe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  318 */       this.server = rep.getJobEntryAttributeString(id_jobentry, "server");
/*  319 */       this.port = rep.getJobEntryAttributeString(id_jobentry, "port");
/*  320 */       this.destination = rep.getJobEntryAttributeString(id_jobentry, "destination");
/*  321 */       this.destinationCc = rep.getJobEntryAttributeString(id_jobentry, "destinationCc");
/*  322 */       this.destinationBCc = rep.getJobEntryAttributeString(id_jobentry, "destinationBCc");
/*  323 */       this.replyAddress = rep.getJobEntryAttributeString(id_jobentry, "replyto");
/*  324 */       this.replyName = rep.getJobEntryAttributeString(id_jobentry, "replytoname");
/*  325 */       this.subject = rep.getJobEntryAttributeString(id_jobentry, "subject");
/*  326 */       this.includeDate = rep.getJobEntryAttributeBoolean(id_jobentry, "include_date");
/*  327 */       this.contactPerson = rep.getJobEntryAttributeString(id_jobentry, "contact_person");
/*  328 */       this.contactPhone = rep.getJobEntryAttributeString(id_jobentry, "contact_phone");
/*  329 */       this.comment = rep.getJobEntryAttributeString(id_jobentry, "comment");
/*  330 */       this.encoding = rep.getJobEntryAttributeString(id_jobentry, "encoding");
/*  331 */       this.priority = rep.getJobEntryAttributeString(id_jobentry, "priority");
/*  332 */       this.importance = rep.getJobEntryAttributeString(id_jobentry, "importance");
/*  333 */       this.includingFiles = rep.getJobEntryAttributeBoolean(id_jobentry, "include_files");
/*  334 */       this.usingAuthentication = rep.getJobEntryAttributeBoolean(id_jobentry, "use_auth");
/*  335 */       this.usingSecureAuthentication = rep.getJobEntryAttributeBoolean(id_jobentry, "use_secure_auth");
/*  336 */       this.authenticationUser = rep.getJobEntryAttributeString(id_jobentry, "auth_user");
/*  337 */       this.authenticationPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "auth_password"));
/*  338 */       this.onlySendComment = rep.getJobEntryAttributeBoolean(id_jobentry, "only_comment");
/*  339 */       this.useHTML = rep.getJobEntryAttributeBoolean(id_jobentry, "use_HTML");
/*  340 */       this.usePriority = rep.getJobEntryAttributeBoolean(id_jobentry, "use_Priority");
/*  341 */       this.secureConnectionType = rep.getJobEntryAttributeString(id_jobentry, "secureconnectiontype");
/*      */       
/*      */ 
/*  344 */       int nrTypes = rep.countNrJobEntryAttributes(id_jobentry, "file_type");
/*  345 */       allocate(nrTypes);
/*      */       
/*  347 */       for (int i = 0; i < nrTypes; i++)
/*      */       {
/*  349 */         String typeCode = rep.getJobEntryAttributeString(id_jobentry, i, "file_type");
/*  350 */         this.fileType[i] = ResultFile.getType(typeCode);
/*      */       }
/*      */       
/*  353 */       this.zipFiles = rep.getJobEntryAttributeBoolean(id_jobentry, "zip_files");
/*  354 */       this.zipFilename = rep.getJobEntryAttributeString(id_jobentry, "zip_name");
/*  355 */       this.replyToAddresses = rep.getJobEntryAttributeString(id_jobentry, "replyToAddresses");
/*      */       
/*      */ 
/*      */ 
/*  359 */       int imagesnr = rep.countNrJobEntryAttributes(id_jobentry, "embeddedimage");
/*  360 */       this.embeddedimages = new String[imagesnr];
/*  361 */       this.contentids = new String[imagesnr];
/*      */       
/*      */ 
/*  364 */       for (int a = 0; a < imagesnr; a++) {
/*  365 */         this.embeddedimages[a] = rep.getJobEntryAttributeString(id_jobentry, a, "embeddedimage");
/*  366 */         this.contentids[a] = rep.getJobEntryAttributeString(id_jobentry, a, "contentid");
/*      */       }
/*      */       
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  372 */       throw new KettleException("Unable to load job entry of type 'mail' from the repository with id_jobentry=" + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void saveRep(Repository rep, ObjectId id_job)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  382 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "server", this.server);
/*  383 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "port", this.port);
/*  384 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destination", this.destination);
/*  385 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destinationCc", this.destinationCc);
/*  386 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destinationBCc", this.destinationBCc);
/*  387 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "replyto", this.replyAddress);
/*  388 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "replytoname", this.replyName);
/*  389 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "subject", this.subject);
/*  390 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_date", this.includeDate);
/*  391 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "contact_person", this.contactPerson);
/*  392 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "contact_phone", this.contactPhone);
/*  393 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "comment", this.comment);
/*  394 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "encoding", this.encoding);
/*  395 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "priority", this.priority);
/*  396 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "importance", this.importance);
/*      */       
/*      */ 
/*  399 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_files", this.includingFiles);
/*  400 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "use_auth", this.usingAuthentication);
/*  401 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "use_secure_auth", this.usingSecureAuthentication);
/*  402 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "auth_user", this.authenticationUser);
/*  403 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "auth_password", Encr.encryptPasswordIfNotUsingVariables(this.authenticationPassword));
/*      */       
/*  405 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "only_comment", this.onlySendComment);
/*  406 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "use_HTML", this.useHTML);
/*  407 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "use_Priority", this.usePriority);
/*  408 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "secureconnectiontype", this.secureConnectionType);
/*      */       
/*  410 */       if (this.fileType != null)
/*      */       {
/*  412 */         for (int i = 0; i < this.fileType.length; i++)
/*      */         {
/*  414 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "file_type", ResultFile.getTypeCode(this.fileType[i]));
/*      */         }
/*      */       }
/*      */       
/*  418 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "zip_files", this.zipFiles);
/*  419 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "zip_name", this.zipFilename);
/*  420 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "replyToAddresses", this.replyToAddresses);
/*      */       
/*      */ 
/*  423 */       if (this.embeddedimages != null) {
/*  424 */         for (int i = 0; i < this.embeddedimages.length; i++) {
/*  425 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "embeddedimage", this.embeddedimages[i]);
/*  426 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "contentid", this.contentids[i]);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  432 */       throw new KettleException("Unable to save job entry of type 'mail' to the repository for id_job=" + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setServer(String s)
/*      */   {
/*  439 */     this.server = s;
/*      */   }
/*      */   
/*      */   public String getServer()
/*      */   {
/*  444 */     return this.server;
/*      */   }
/*      */   
/*      */   public void setDestination(String dest)
/*      */   {
/*  449 */     this.destination = dest;
/*      */   }
/*      */   
/*      */   public void setDestinationCc(String destCc)
/*      */   {
/*  454 */     this.destinationCc = destCc;
/*      */   }
/*      */   
/*      */   public void setDestinationBCc(String destBCc)
/*      */   {
/*  459 */     this.destinationBCc = destBCc;
/*      */   }
/*      */   
/*      */   public String getDestination()
/*      */   {
/*  464 */     return this.destination;
/*      */   }
/*      */   
/*      */   public String getDestinationCc()
/*      */   {
/*  469 */     return this.destinationCc;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getDestinationBCc()
/*      */   {
/*  475 */     return this.destinationBCc;
/*      */   }
/*      */   
/*      */   public void setReplyAddress(String reply)
/*      */   {
/*  480 */     this.replyAddress = reply;
/*      */   }
/*      */   
/*      */   public String getReplyAddress() {
/*  484 */     return this.replyAddress;
/*      */   }
/*      */   
/*      */   public void setReplyName(String replyname)
/*      */   {
/*  489 */     this.replyName = replyname;
/*      */   }
/*      */   
/*      */   public String getReplyName() {
/*  493 */     return this.replyName;
/*      */   }
/*      */   
/*      */   public void setSubject(String subj)
/*      */   {
/*  498 */     this.subject = subj;
/*      */   }
/*      */   
/*      */   public String getSubject()
/*      */   {
/*  503 */     return this.subject;
/*      */   }
/*      */   
/*      */   public void setIncludeDate(boolean incl)
/*      */   {
/*  508 */     this.includeDate = incl;
/*      */   }
/*      */   
/*      */   public boolean getIncludeDate()
/*      */   {
/*  513 */     return this.includeDate;
/*      */   }
/*      */   
/*      */   public void setContactPerson(String person)
/*      */   {
/*  518 */     this.contactPerson = person;
/*      */   }
/*      */   
/*      */   public String getContactPerson()
/*      */   {
/*  523 */     return this.contactPerson;
/*      */   }
/*      */   
/*      */   public void setContactPhone(String phone)
/*      */   {
/*  528 */     this.contactPhone = phone;
/*      */   }
/*      */   
/*      */   public String getContactPhone()
/*      */   {
/*  533 */     return this.contactPhone;
/*      */   }
/*      */   
/*      */   public void setComment(String comm)
/*      */   {
/*  538 */     this.comment = comm;
/*      */   }
/*      */   
/*      */   public String getComment()
/*      */   {
/*  543 */     return this.comment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getFileType()
/*      */   {
/*  552 */     return this.fileType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFileType(int[] fileType)
/*      */   {
/*  561 */     this.fileType = fileType;
/*      */   }
/*      */   
/*      */   public boolean isIncludingFiles()
/*      */   {
/*  566 */     return this.includingFiles;
/*      */   }
/*      */   
/*      */   public void setIncludingFiles(boolean includeFiles)
/*      */   {
/*  571 */     this.includingFiles = includeFiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getZipFilename()
/*      */   {
/*  579 */     return this.zipFilename;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setZipFilename(String zipFilename)
/*      */   {
/*  587 */     this.zipFilename = zipFilename;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isZipFiles()
/*      */   {
/*  595 */     return this.zipFiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setZipFiles(boolean zipFiles)
/*      */   {
/*  603 */     this.zipFiles = zipFiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthenticationPassword()
/*      */   {
/*  611 */     return this.authenticationPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthenticationPassword(String authenticationPassword)
/*      */   {
/*  619 */     this.authenticationPassword = authenticationPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getAuthenticationUser()
/*      */   {
/*  627 */     return this.authenticationUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAuthenticationUser(String authenticationUser)
/*      */   {
/*  635 */     this.authenticationUser = authenticationUser;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUsingAuthentication()
/*      */   {
/*  643 */     return this.usingAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUsingAuthentication(boolean usingAuthentication)
/*      */   {
/*  651 */     this.usingAuthentication = usingAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isOnlySendComment()
/*      */   {
/*  659 */     return this.onlySendComment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOnlySendComment(boolean onlySendComment)
/*      */   {
/*  667 */     this.onlySendComment = onlySendComment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUseHTML()
/*      */   {
/*  675 */     return this.useHTML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseHTML(boolean useHTML)
/*      */   {
/*  683 */     this.useHTML = useHTML;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  691 */     return this.encoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSecureConnectionType()
/*      */   {
/*  700 */     return this.secureConnectionType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSecureConnectionType(String secureConnectionType)
/*      */   {
/*  708 */     this.secureConnectionType = secureConnectionType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEncoding(String encoding)
/*      */   {
/*  717 */     this.encoding = encoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReplyToAddresses(String replyToAddresses)
/*      */   {
/*  726 */     this.replyToAddresses = replyToAddresses;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getReplyToAddresses()
/*      */   {
/*  734 */     return this.replyToAddresses;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUsePriority(boolean usePriority)
/*      */   {
/*  743 */     this.usePriority = usePriority;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUsePriority()
/*      */   {
/*  751 */     return this.usePriority;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPriority()
/*      */   {
/*  760 */     return this.priority;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImportance(String importance)
/*      */   {
/*  768 */     this.importance = importance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getImportance()
/*      */   {
/*  777 */     return this.importance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPriority(String priority)
/*      */   {
/*  785 */     this.priority = priority;
/*      */   }
/*      */   
/*      */ 
/*      */   public Result execute(Result result, int nr)
/*      */   {
/*  791 */     File masterZipfile = null;
/*      */     
/*      */ 
/*      */ 
/*  795 */     Properties props = new Properties();
/*  796 */     if (Const.isEmpty(this.server))
/*      */     {
/*  798 */       logError(BaseMessages.getString(PKG, "JobMail.Error.HostNotSpecified", new String[0]));
/*      */       
/*  800 */       result.setNrErrors(1L);
/*  801 */       result.setResult(false);
/*  802 */       return result;
/*      */     }
/*      */     
/*  805 */     String protocol = "smtp";
/*  806 */     if (this.usingSecureAuthentication)
/*      */     {
/*  808 */       if (this.secureConnectionType.equals("TLS"))
/*      */       {
/*      */ 
/*  811 */         props.put("mail.smtp.starttls.enable", "true");
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  816 */         protocol = "smtps";
/*      */         
/*      */ 
/*      */ 
/*  820 */         props.put("mail.smtps.quitwait", "false");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  825 */     props.put("mail." + protocol + ".host", environmentSubstitute(this.server));
/*  826 */     if (!Const.isEmpty(this.port)) {
/*  827 */       props.put("mail." + protocol + ".port", environmentSubstitute(this.port));
/*      */     }
/*  829 */     if (this.log.isDebug()) {
/*  830 */       props.put("mail.debug", "true");
/*      */     }
/*  832 */     if (this.usingAuthentication)
/*      */     {
/*  834 */       props.put("mail." + protocol + ".auth", "true");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  850 */     Session session = Session.getInstance(props);
/*  851 */     session.setDebug(this.log.isDebug());
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  856 */       Message msg = new MimeMessage(session);
/*      */       
/*      */ 
/*  859 */       if (this.usePriority)
/*      */       {
/*  861 */         String priority_int = "1";
/*  862 */         if (this.priority.equals("low"))
/*      */         {
/*  864 */           priority_int = "3";
/*      */         }
/*  866 */         if (this.priority.equals("normal"))
/*      */         {
/*  868 */           priority_int = "2";
/*      */         }
/*      */         
/*  871 */         msg.setHeader("X-Priority", priority_int);
/*  872 */         msg.setHeader("Importance", this.importance);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  878 */       String sender_address = environmentSubstitute(this.replyAddress);
/*  879 */       if (!Const.isEmpty(sender_address))
/*      */       {
/*  881 */         String sender_name = environmentSubstitute(this.replyName);
/*  882 */         if (!Const.isEmpty(sender_name)) sender_address = sender_name + '<' + sender_address + '>';
/*  883 */         msg.setFrom(new InternetAddress(sender_address));
/*      */       }
/*      */       else {
/*  886 */         throw new MessagingException(BaseMessages.getString(PKG, "JobMail.Error.ReplyEmailNotFilled", new String[0]));
/*      */       }
/*      */       
/*      */ 
/*  890 */       String reply_to_address = environmentSubstitute(this.replyToAddresses);
/*  891 */       if (!Const.isEmpty(reply_to_address))
/*      */       {
/*      */ 
/*  894 */         String[] reply_Address_List = environmentSubstitute(reply_to_address).split(" ");
/*  895 */         InternetAddress[] address = new InternetAddress[reply_Address_List.length];
/*  896 */         for (int i = 0; i < reply_Address_List.length; i++)
/*  897 */           address[i] = new InternetAddress(reply_Address_List[i]);
/*  898 */         msg.setReplyTo(address);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  903 */       String[] destinations = environmentSubstitute(this.destination).split(" ");
/*  904 */       InternetAddress[] address = new InternetAddress[destinations.length];
/*  905 */       for (int i = 0; i < destinations.length; i++)
/*  906 */         address[i] = new InternetAddress(destinations[i]);
/*  907 */       msg.setRecipients(Message.RecipientType.TO, address);
/*      */       
/*  909 */       String realCC = environmentSubstitute(getDestinationCc());
/*  910 */       if (!Const.isEmpty(realCC))
/*      */       {
/*      */ 
/*  913 */         String[] destinationsCc = realCC.split(" ");
/*  914 */         InternetAddress[] addressCc = new InternetAddress[destinationsCc.length];
/*  915 */         for (int i = 0; i < destinationsCc.length; i++) {
/*  916 */           addressCc[i] = new InternetAddress(destinationsCc[i]);
/*      */         }
/*  918 */         msg.setRecipients(Message.RecipientType.CC, addressCc);
/*      */       }
/*      */       
/*  921 */       String realBCc = environmentSubstitute(getDestinationBCc());
/*  922 */       if (!Const.isEmpty(realBCc))
/*      */       {
/*      */ 
/*  925 */         String[] destinationsBCc = realBCc.split(" ");
/*  926 */         InternetAddress[] addressBCc = new InternetAddress[destinationsBCc.length];
/*  927 */         for (int i = 0; i < destinationsBCc.length; i++) {
/*  928 */           addressBCc[i] = new InternetAddress(destinationsBCc[i]);
/*      */         }
/*  930 */         msg.setRecipients(Message.RecipientType.BCC, addressBCc);
/*      */       }
/*  932 */       String realSubject = environmentSubstitute(this.subject);
/*  933 */       if (!Const.isEmpty(realSubject))
/*      */       {
/*  935 */         msg.setSubject(realSubject);
/*      */       }
/*      */       
/*  938 */       msg.setSentDate(new Date());
/*  939 */       StringBuffer messageText = new StringBuffer();
/*  940 */       String endRow = isUseHTML() ? "<br>" : Const.CR;
/*  941 */       String realComment = environmentSubstitute(this.comment);
/*  942 */       if (!Const.isEmpty(realComment))
/*      */       {
/*  944 */         messageText.append(realComment).append(Const.CR).append(Const.CR);
/*      */       }
/*  946 */       if (!this.onlySendComment)
/*      */       {
/*      */ 
/*  949 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.Job", new String[0])).append(endRow);
/*  950 */         messageText.append("-----").append(endRow);
/*  951 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.JobName", new String[0]) + "    : ").append(this.parentJob.getJobMeta().getName()).append(endRow);
/*  952 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.JobDirectory", new String[0]) + "  : ").append(this.parentJob.getJobMeta().getRepositoryDirectory()).append(endRow);
/*  953 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.JobEntry", new String[0]) + "   : ").append(getName()).append(endRow);
/*  954 */         messageText.append(Const.CR);
/*      */       }
/*      */       
/*  957 */       if (this.includeDate)
/*      */       {
/*  959 */         messageText.append(endRow).append(BaseMessages.getString(PKG, "JobMail.Log.Comment.MsgDate", new String[0]) + ": ").append(XMLHandler.date2string(new Date())).append(endRow).append(endRow);
/*      */       }
/*  961 */       if ((!this.onlySendComment) && (result != null))
/*      */       {
/*  963 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.PreviousResult", new String[0]) + ":").append(endRow);
/*  964 */         messageText.append("-----------------").append(endRow);
/*  965 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.JobEntryNr", new String[0]) + "         : ").append(result.getEntryNr()).append(endRow);
/*  966 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.Errors", new String[0]) + "               : ").append(result.getNrErrors()).append(endRow);
/*  967 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.LinesRead", new String[0]) + "           : ").append(result.getNrLinesRead()).append(endRow);
/*  968 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.LinesWritten", new String[0]) + "        : ").append(result.getNrLinesWritten()).append(endRow);
/*  969 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.LinesInput", new String[0]) + "          : ").append(result.getNrLinesInput()).append(endRow);
/*  970 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.LinesOutput", new String[0]) + "         : ").append(result.getNrLinesOutput()).append(endRow);
/*  971 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.LinesUpdated", new String[0]) + "        : ").append(result.getNrLinesUpdated()).append(endRow);
/*  972 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.LinesRejected", new String[0]) + "       : ").append(result.getNrLinesRejected()).append(endRow);
/*  973 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.Status", new String[0]) + "  : ").append(result.getExitStatus()).append(endRow);
/*  974 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.Result", new String[0]) + "               : ").append(result.getResult()).append(endRow);
/*  975 */         messageText.append(endRow);
/*      */       }
/*      */       
/*  978 */       if ((!this.onlySendComment) && ((!Const.isEmpty(environmentSubstitute(this.contactPerson))) || (!Const.isEmpty(environmentSubstitute(this.contactPhone)))))
/*      */       {
/*      */ 
/*      */ 
/*  982 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.ContactInfo", new String[0]) + " :").append(endRow);
/*  983 */         messageText.append("---------------------").append(endRow);
/*  984 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.PersonToContact", new String[0]) + " : ").append(environmentSubstitute(this.contactPerson)).append(endRow);
/*  985 */         messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.Tel", new String[0]) + "  : ").append(environmentSubstitute(this.contactPhone)).append(endRow);
/*  986 */         messageText.append(endRow);
/*      */       }
/*      */       
/*      */ 
/*  990 */       if (!this.onlySendComment)
/*      */       {
/*  992 */         JobTracker jobTracker = this.parentJob.getJobTracker();
/*  993 */         if (jobTracker != null)
/*      */         {
/*  995 */           messageText.append(BaseMessages.getString(PKG, "JobMail.Log.Comment.PathToJobentry", new String[0]) + ":").append(endRow);
/*  996 */           messageText.append("------------------------").append(endRow);
/*      */           
/*  998 */           addBacktracking(jobTracker, messageText);
/*  999 */           if (isUseHTML()) {
/* 1000 */             messageText.replace(0, messageText.length(), messageText.toString().replace(Const.CR, endRow));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1005 */       MimeMultipart parts = new MimeMultipart();
/* 1006 */       MimeBodyPart part1 = new MimeBodyPart();
/*      */       
/* 1008 */       int nrattachedFiles = 0;
/*      */       
/*      */ 
/*      */ 
/* 1012 */       if (this.useHTML)
/*      */       {
/* 1014 */         if (!Const.isEmpty(getEncoding()))
/*      */         {
/* 1016 */           part1.setContent(messageText.toString(), "text/html; charset=" + getEncoding());
/*      */         }
/*      */         else {
/* 1019 */           part1.setContent(messageText.toString(), "text/html; charset=ISO-8859-1");
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/* 1024 */         part1.setText(messageText.toString());
/*      */       }
/* 1026 */       parts.addBodyPart(part1);
/*      */       
/* 1028 */       if ((this.includingFiles) && (result != null))
/*      */       {
/* 1030 */         List<ResultFile> resultFiles = result.getResultFilesList();
/* 1031 */         if ((resultFiles != null) && (!resultFiles.isEmpty()))
/*      */         {
/* 1033 */           if (!this.zipFiles)
/*      */           {
/*      */ 
/*      */ 
/* 1037 */             for (ResultFile resultFile : resultFiles)
/*      */             {
/* 1039 */               FileObject file = resultFile.getFile();
/* 1040 */               if ((file != null) && (file.exists()))
/*      */               {
/* 1042 */                 boolean found = false;
/* 1043 */                 for (int i = 0; i < this.fileType.length; i++)
/*      */                 {
/* 1045 */                   if (this.fileType[i] == resultFile.getType())
/* 1046 */                     found = true;
/*      */                 }
/* 1048 */                 if (found)
/*      */                 {
/*      */ 
/* 1051 */                   MimeBodyPart files = new MimeBodyPart();
/* 1052 */                   URLDataSource fds = new URLDataSource(file.getURL());
/*      */                   
/*      */ 
/* 1055 */                   files.setDataHandler(new DataHandler(fds));
/*      */                   
/* 1057 */                   files.setFileName(file.getName().getBaseName());
/*      */                   
/*      */ 
/* 1060 */                   files.addHeader("Content-Transfer-Encoding", "base64");
/*      */                   
/*      */ 
/* 1063 */                   parts.addBodyPart(files);
/* 1064 */                   nrattachedFiles++;
/* 1065 */                   logBasic("Added file '" + fds.getName() + "' to the mail message.");
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1072 */             masterZipfile = new File(System.getProperty("java.io.tmpdir") + Const.FILE_SEPARATOR + environmentSubstitute(this.zipFilename));
/*      */             
/* 1074 */             ZipOutputStream zipOutputStream = null;
/*      */             try
/*      */             {
/* 1077 */               zipOutputStream = new ZipOutputStream(new FileOutputStream(masterZipfile));
/*      */               
/* 1079 */               for (ResultFile resultFile : resultFiles)
/*      */               {
/* 1081 */                 boolean found = false;
/* 1082 */                 for (int i = 0; i < this.fileType.length; i++)
/*      */                 {
/* 1084 */                   if (this.fileType[i] == resultFile.getType())
/* 1085 */                     found = true;
/*      */                 }
/* 1087 */                 if (found)
/*      */                 {
/* 1089 */                   FileObject file = resultFile.getFile();
/* 1090 */                   ZipEntry zipEntry = new ZipEntry(file.getName().getBaseName());
/* 1091 */                   zipOutputStream.putNextEntry(zipEntry);
/*      */                   
/*      */ 
/* 1094 */                   BufferedInputStream inputStream = new BufferedInputStream(KettleVFS.getInputStream(file));
/*      */                   try {
/*      */                     int c;
/* 1097 */                     while ((c = inputStream.read()) >= 0)
/*      */                     {
/* 1099 */                       zipOutputStream.write(c);
/*      */                     }
/*      */                   } finally {
/* 1102 */                     inputStream.close();
/*      */                   }
/* 1104 */                   zipOutputStream.closeEntry();
/* 1105 */                   nrattachedFiles++;
/* 1106 */                   logBasic("Added file '" + file.getName().getURI() + "' to the mail message in a zip archive.");
/*      */                 }
/*      */               }
/*      */             }
/*      */             catch (Exception e)
/*      */             {
/* 1112 */               logError("Error zipping attachement files into file [" + masterZipfile.getPath() + "] : " + e.toString());
/*      */               
/* 1114 */               logError(Const.getStackTracker(e));
/* 1115 */               result.setNrErrors(1L);
/*      */             }
/*      */             finally {
/* 1118 */               if (zipOutputStream != null)
/*      */               {
/*      */                 try
/*      */                 {
/* 1122 */                   zipOutputStream.finish();
/* 1123 */                   zipOutputStream.close();
/*      */                 }
/*      */                 catch (IOException e) {
/* 1126 */                   logError("Unable to close attachement zip file archive : " + e.toString());
/* 1127 */                   logError(Const.getStackTracker(e));
/* 1128 */                   result.setNrErrors(1L);
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/* 1134 */             if (result.getNrErrors() == 0L)
/*      */             {
/*      */ 
/* 1137 */               MimeBodyPart files = new MimeBodyPart();
/* 1138 */               FileDataSource fds = new FileDataSource(masterZipfile);
/*      */               
/* 1140 */               files.setDataHandler(new DataHandler(fds));
/*      */               
/* 1142 */               files.setFileName(fds.getName());
/*      */               
/* 1144 */               parts.addBodyPart(files);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1150 */       int nrEmbeddedImages = 0;
/* 1151 */       if ((this.embeddedimages != null) && (this.embeddedimages.length > 0)) {
/* 1152 */         FileObject imageFile = null;
/* 1153 */         for (int i = 0; i < this.embeddedimages.length; i++) {
/* 1154 */           String realImageFile = environmentSubstitute(this.embeddedimages[i]);
/* 1155 */           String realcontenID = environmentSubstitute(this.contentids[i]);
/* 1156 */           if (messageText.indexOf("cid:" + realcontenID) < 0) {
/* 1157 */             if (this.log.isDebug()) this.log.logDebug("Image [" + realImageFile + "] is not used in message body!");
/*      */           } else {
/*      */             try {
/* 1160 */               boolean found = false;
/* 1161 */               imageFile = KettleVFS.getFileObject(realImageFile, this);
/* 1162 */               if ((imageFile.exists()) && (imageFile.getType() == FileType.FILE)) {
/* 1163 */                 found = true;
/*      */               } else
/* 1165 */                 this.log.logError("We can not find [" + realImageFile + "] or it is not a file");
/* 1166 */               if (found)
/*      */               {
/* 1168 */                 MimeBodyPart messageBodyPart = new MimeBodyPart();
/*      */                 
/* 1170 */                 URLDataSource fds = new URLDataSource(imageFile.getURL());
/* 1171 */                 messageBodyPart.setDataHandler(new DataHandler(fds));
/*      */                 
/* 1173 */                 messageBodyPart.setHeader("Content-ID", "<" + realcontenID + ">");
/*      */                 
/* 1175 */                 parts.addBodyPart(messageBodyPart);
/* 1176 */                 nrEmbeddedImages++;
/* 1177 */                 this.log.logBasic("Image '" + fds.getName() + "' was embedded in message.");
/*      */               }
/*      */             } catch (Exception e) {
/* 1180 */               this.log.logError("Error embedding image [" + realImageFile + "] in message : " + e.toString());
/* 1181 */               this.log.logError(Const.getStackTracker(e));
/* 1182 */               result.setNrErrors(1L);
/*      */             } finally {
/* 1184 */               if (imageFile != null) {
/* 1185 */                 try { imageFile.close();
/*      */                 } catch (Exception e) {}
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1192 */       if ((nrEmbeddedImages > 0) && (nrattachedFiles == 0))
/*      */       {
/*      */ 
/*      */ 
/* 1196 */         parts.setSubType("related");
/*      */       }
/*      */       
/* 1199 */       msg.setContent(parts);
/*      */       
/* 1201 */       Transport transport = null;
/*      */       try
/*      */       {
/* 1204 */         transport = session.getTransport(protocol);
/* 1205 */         if (this.usingAuthentication)
/*      */         {
/* 1207 */           if (!Const.isEmpty(this.port))
/*      */           {
/* 1209 */             transport.connect(environmentSubstitute(Const.NVL(this.server, "")), Integer.parseInt(environmentSubstitute(Const.NVL(this.port, ""))), environmentSubstitute(Const.NVL(this.authenticationUser, "")), environmentSubstitute(Const.NVL(this.authenticationPassword, "")));
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1214 */             transport.connect(environmentSubstitute(Const.NVL(this.server, "")), environmentSubstitute(Const.NVL(this.authenticationUser, "")), environmentSubstitute(Const.NVL(this.authenticationPassword, "")));
/*      */           }
/*      */           
/*      */         }
/*      */         else {
/* 1219 */           transport.connect();
/*      */         }
/* 1221 */         transport.sendMessage(msg, msg.getAllRecipients());
/*      */       }
/*      */       finally {
/* 1224 */         if (transport != null) {
/* 1225 */           transport.close();
/*      */         }
/*      */       }
/*      */     } catch (IOException e) {
/* 1229 */       logError("Problem while sending message: " + e.toString());
/* 1230 */       result.setNrErrors(1L);
/*      */     }
/*      */     catch (MessagingException mex) {
/* 1233 */       logError("Problem while sending message: " + mex.toString());
/* 1234 */       result.setNrErrors(1L);
/*      */       
/* 1236 */       Exception ex = mex;
/*      */       do
/*      */       {
/* 1239 */         if ((ex instanceof SendFailedException))
/*      */         {
/* 1241 */           SendFailedException sfex = (SendFailedException)ex;
/*      */           
/* 1243 */           Address[] invalid = sfex.getInvalidAddresses();
/* 1244 */           if (invalid != null)
/*      */           {
/* 1246 */             logError("    ** Invalid Addresses");
/* 1247 */             for (int i = 0; i < invalid.length; i++)
/*      */             {
/* 1249 */               logError("         " + invalid[i]);
/* 1250 */               result.setNrErrors(1L);
/*      */             }
/*      */           }
/*      */           
/* 1254 */           Address[] validUnsent = sfex.getValidUnsentAddresses();
/* 1255 */           if (validUnsent != null)
/*      */           {
/* 1257 */             logError("    ** ValidUnsent Addresses");
/* 1258 */             for (int i = 0; i < validUnsent.length; i++)
/*      */             {
/* 1260 */               logError("         " + validUnsent[i]);
/* 1261 */               result.setNrErrors(1L);
/*      */             }
/*      */           }
/*      */           
/* 1265 */           Address[] validSent = sfex.getValidSentAddresses();
/* 1266 */           if (validSent != null)
/*      */           {
/*      */ 
/* 1269 */             for (int i = 0; i < validSent.length; i++)
/*      */             {
/* 1271 */               logError("         " + validSent[i]);
/* 1272 */               result.setNrErrors(1L);
/*      */             }
/*      */           }
/*      */         }
/* 1276 */         if ((ex instanceof MessagingException))
/*      */         {
/* 1278 */           ex = ((MessagingException)ex).getNextException();
/*      */         }
/*      */         else {
/* 1281 */           ex = null;
/*      */         }
/* 1283 */       } while (ex != null);
/*      */     }
/*      */     finally {
/* 1286 */       if ((masterZipfile != null) && (masterZipfile.exists()))
/*      */       {
/* 1288 */         masterZipfile.delete();
/*      */       }
/*      */     }
/*      */     
/* 1292 */     if (result.getNrErrors() > 0L)
/*      */     {
/* 1294 */       result.setResult(false);
/*      */     }
/*      */     else {
/* 1297 */       result.setResult(true);
/*      */     }
/*      */     
/* 1300 */     return result;
/*      */   }
/*      */   
/*      */   private void addBacktracking(JobTracker jobTracker, StringBuffer messageText)
/*      */   {
/* 1305 */     addBacktracking(jobTracker, messageText, 0);
/*      */   }
/*      */   
/*      */   private void addBacktracking(JobTracker jobTracker, StringBuffer messageText, int level)
/*      */   {
/* 1310 */     int nr = jobTracker.nrJobTrackers();
/*      */     
/* 1312 */     messageText.append(Const.rightPad(" ", level * 2));
/* 1313 */     messageText.append(Const.NVL(jobTracker.getJobName(), "-"));
/* 1314 */     JobEntryResult jer = jobTracker.getJobEntryResult();
/* 1315 */     if (jer != null)
/*      */     {
/* 1317 */       messageText.append(" : ");
/* 1318 */       if (jer.getJobEntryName() != null)
/*      */       {
/* 1320 */         messageText.append(" : ");
/* 1321 */         messageText.append(jer.getJobEntryName());
/*      */       }
/* 1323 */       if (jer.getResult() != null)
/*      */       {
/* 1325 */         messageText.append(" : ");
/* 1326 */         messageText.append("[" + jer.getResult().toString() + "]");
/*      */       }
/* 1328 */       if (jer.getReason() != null)
/*      */       {
/* 1330 */         messageText.append(" : ");
/* 1331 */         messageText.append(jer.getReason());
/*      */       }
/* 1333 */       if (jer.getComment() != null)
/*      */       {
/* 1335 */         messageText.append(" : ");
/* 1336 */         messageText.append(jer.getComment());
/*      */       }
/* 1338 */       if (jer.getLogDate() != null)
/*      */       {
/* 1340 */         messageText.append(" (");
/* 1341 */         messageText.append(XMLHandler.date2string(jer.getLogDate()));
/* 1342 */         messageText.append(')');
/*      */       }
/*      */     }
/* 1345 */     messageText.append(Const.CR);
/*      */     
/* 1347 */     for (int i = 0; i < nr; i++)
/*      */     {
/* 1349 */       JobTracker jt = jobTracker.getJobTracker(i);
/* 1350 */       addBacktracking(jt, messageText, level + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean evaluates()
/*      */   {
/* 1356 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isUnconditional()
/*      */   {
/* 1361 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUsingSecureAuthentication()
/*      */   {
/* 1369 */     return this.usingSecureAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUsingSecureAuthentication(boolean usingSecureAuthentication)
/*      */   {
/* 1377 */     this.usingSecureAuthentication = usingSecureAuthentication;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPort()
/*      */   {
/* 1385 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(String port)
/*      */   {
/* 1393 */     this.port = port;
/*      */   }
/*      */   
/*      */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*      */   {
/* 1398 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 1399 */     String realServername = jobMeta.environmentSubstitute(this.server);
/* 1400 */     ResourceReference reference = new ResourceReference(this);
/* 1401 */     reference.getEntries().add(new ResourceEntry(realServername, ResourceEntry.ResourceType.SERVER));
/* 1402 */     references.add(reference);
/* 1403 */     return references;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1410 */     JobEntryValidatorUtils.andValidator().validate(this, "server", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1411 */     JobEntryValidatorUtils.andValidator().validate(this, "replyAddress", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.emailValidator() }));
/*      */     
/* 1413 */     JobEntryValidatorUtils.andValidator().validate(this, "destination", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*      */     
/* 1415 */     if (this.usingAuthentication)
/*      */     {
/* 1417 */       JobEntryValidatorUtils.andValidator().validate(this, "authenticationUser", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1418 */       JobEntryValidatorUtils.andValidator().validate(this, "authenticationPassword", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */     }
/*      */     
/* 1421 */     JobEntryValidatorUtils.andValidator().validate(this, "port", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\mail\JobEntryMail.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */