package org.pentaho.di.imp.rule;

public enum ImportRuleSubject
{
  TRANSFORMATION,  JOB,  DATABASE_CONNECTION;
  
  private ImportRuleSubject() {}
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rule\ImportRuleSubject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */