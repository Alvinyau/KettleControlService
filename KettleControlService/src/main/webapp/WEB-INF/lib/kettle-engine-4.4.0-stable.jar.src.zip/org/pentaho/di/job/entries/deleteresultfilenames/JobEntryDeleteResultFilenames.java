/*     */ package org.pentaho.di.job.entries.deleteresultfilenames;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDeleteResultFilenames
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  68 */   private static Class<?> PKG = JobEntryDeleteResultFilenames.class;
/*     */   
/*     */   private String foldername;
/*     */   private boolean specifywildcard;
/*     */   private String wildcard;
/*     */   private String wildcardexclude;
/*     */   
/*     */   public JobEntryDeleteResultFilenames(String n)
/*     */   {
/*  77 */     super(n, "");
/*  78 */     this.foldername = null;
/*  79 */     this.wildcardexclude = null;
/*  80 */     this.wildcard = null;
/*  81 */     this.specifywildcard = false;
/*  82 */     setID(-1L);
/*     */   }
/*     */   
/*     */ 
/*     */   public JobEntryDeleteResultFilenames()
/*     */   {
/*  88 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  93 */     JobEntryDeleteResultFilenames je = (JobEntryDeleteResultFilenames)super.clone();
/*  94 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  99 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 101 */     retval.append(super.getXML());
/* 102 */     retval.append("      ").append(XMLHandler.addTagValue("foldername", this.foldername));
/* 103 */     retval.append("      ").append(XMLHandler.addTagValue("specify_wildcard", this.specifywildcard));
/* 104 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/* 105 */     retval.append("      ").append(XMLHandler.addTagValue("wildcardexclude", this.wildcardexclude));
/*     */     
/*     */ 
/* 108 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 115 */       super.loadXML(entrynode, databases, slaveServers);
/* 116 */       this.foldername = XMLHandler.getTagValue(entrynode, "foldername");
/* 117 */       this.specifywildcard = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "specify_wildcard"));
/* 118 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/* 119 */       this.wildcardexclude = XMLHandler.getTagValue(entrynode, "wildcardexclude");
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/*     */ 
/* 126 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.CanNotLoadFromXML", new String[] { xe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 134 */       this.foldername = rep.getJobEntryAttributeString(id_jobentry, "foldername");
/* 135 */       this.specifywildcard = rep.getJobEntryAttributeBoolean(id_jobentry, "specify_wildcard");
/* 136 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/* 137 */       this.wildcardexclude = rep.getJobEntryAttributeString(id_jobentry, "wildcardexclude");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 141 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.CanNotLoadFromRep", new String[] { "" + id_jobentry, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 149 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "foldername", this.foldername);
/* 150 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "specify_wildcard", this.specifywildcard);
/* 151 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/* 152 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcardexclude", this.wildcardexclude);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 156 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.CanNotSaveToRep", new String[] { "" + id_job, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setSpecifyWildcard(boolean specifywildcard)
/*     */   {
/* 162 */     this.specifywildcard = specifywildcard;
/*     */   }
/*     */   
/*     */   public boolean isSpecifyWildcard()
/*     */   {
/* 167 */     return this.specifywildcard;
/*     */   }
/*     */   
/*     */   public void setFoldername(String foldername) {
/* 171 */     this.foldername = foldername;
/*     */   }
/*     */   
/*     */   public String getFoldername()
/*     */   {
/* 176 */     return this.foldername;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getWildcard()
/*     */   {
/* 182 */     return this.wildcard;
/*     */   }
/*     */   
/*     */   public String getWildcardExclude()
/*     */   {
/* 187 */     return this.wildcardexclude;
/*     */   }
/*     */   
/*     */   public String getRealWildcard()
/*     */   {
/* 192 */     return environmentSubstitute(getWildcard());
/*     */   }
/*     */   
/*     */   public void setWildcard(String wildcard) {
/* 196 */     this.wildcard = wildcard;
/*     */   }
/*     */   
/*     */   public void setWildcardExclude(String wildcardexclude) {
/* 200 */     this.wildcardexclude = wildcardexclude;
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 206 */     Result result = previousResult;
/* 207 */     result.setResult(false);
/*     */     
/* 209 */     if (previousResult != null)
/*     */     {
/*     */       try
/*     */       {
/* 213 */         int size = previousResult.getResultFiles().size();
/* 214 */         if (this.log.isBasic())
/* 215 */           logBasic(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.log.FilesFound", new String[] { "" + size }));
/* 216 */         Iterator<ResultFile> it; if (!this.specifywildcard)
/*     */         {
/*     */ 
/* 219 */           previousResult.getResultFiles().clear();
/* 220 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.log.DeletedFiles", new String[] { "" + size }));
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 225 */           List<ResultFile> resultFiles = result.getResultFilesList();
/* 226 */           if ((resultFiles != null) && (resultFiles.size() > 0))
/*     */           {
/* 228 */             for (it = resultFiles.iterator(); (it.hasNext()) && (!this.parentJob.isStopped());)
/*     */             {
/* 230 */               ResultFile resultFile = (ResultFile)it.next();
/* 231 */               FileObject file = resultFile.getFile();
/* 232 */               if ((file != null) && (file.exists()))
/*     */               {
/* 234 */                 if ((CheckFileWildcard(file.getName().getBaseName(), environmentSubstitute(this.wildcard), true)) && (!CheckFileWildcard(file.getName().getBaseName(), environmentSubstitute(this.wildcardexclude), false)))
/*     */                 {
/*     */ 
/*     */ 
/* 238 */                   result.getResultFiles().remove(resultFile.getFile().toString());
/*     */                   
/* 240 */                   if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.log.DeletedFile", new String[] { file.toString() }));
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 247 */         result.setResult(true);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 251 */         logError(BaseMessages.getString(PKG, "JobEntryDeleteResultFilenames.Error", new String[] { e.toString() }));
/*     */       }
/*     */     }
/* 254 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean CheckFileWildcard(String selectedfile, String wildcard, boolean include)
/*     */   {
/* 264 */     Pattern pattern = null;
/* 265 */     boolean getIt = include;
/*     */     
/* 267 */     if (!Const.isEmpty(wildcard))
/*     */     {
/* 269 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 271 */       if (pattern != null)
/*     */       {
/* 273 */         Matcher matcher = pattern.matcher(selectedfile);
/* 274 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 278 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 284 */     return true;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 289 */     ValidatorContext ctx = new ValidatorContext();
/* 290 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 291 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileDoesNotExistValidator() });
/* 292 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\deleteresultfilenames\JobEntryDeleteResultFilenames.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */