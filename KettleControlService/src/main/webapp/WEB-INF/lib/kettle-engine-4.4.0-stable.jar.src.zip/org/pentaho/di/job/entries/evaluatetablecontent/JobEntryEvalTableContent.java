/*     */ package org.pentaho.di.job.entries.evaluatetablecontent;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.Database;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryEvalTableContent
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  64 */   private static Class<?> PKG = JobEntryEvalTableContent.class;
/*     */   
/*     */   public boolean isAddRowsResult;
/*     */   
/*     */   public boolean isClearResultList;
/*     */   
/*     */   public boolean isUseVars;
/*     */   
/*     */   public boolean iscustomSQL;
/*     */   
/*     */   public String customSQL;
/*     */   
/*     */   private DatabaseMeta connection;
/*     */   
/*     */   public String tablename;
/*     */   
/*     */   public String schemaname;
/*     */   
/*     */   private static final String selectCount = "SELECT count(*) FROM ";
/*     */   
/*  84 */   public static final String[] successConditionsDesc = { BaseMessages.getString(PKG, "JobEntryEvalTableContent.SuccessWhenRowCountEqual.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryEvalTableContent.SuccessWhenRowCountDifferent.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryEvalTableContent.SuccessWhenRowCountSmallerThan.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryEvalTableContent.SuccessWhenRowCountSmallerOrEqualThan.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryEvalTableContent.SuccessWhenRowCountGreaterThan.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryEvalTableContent.SuccessWhenRowCountGreaterOrEqual.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   public static final String[] successConditionsCode = { "rows_count_equal", "rows_count_different", "rows_count_smaller", "rows_count_smaller_equal", "rows_count_greater", "rows_count_greater_equal" };
/*     */   
/*     */ 
/*     */   public static final int SUCCESS_CONDITION_ROWS_COUNT_EQUAL = 0;
/*     */   
/*     */   public static final int SUCCESS_CONDITION_ROWS_COUNT_DIFFERENT = 1;
/*     */   
/*     */   public static final int SUCCESS_CONDITION_ROWS_COUNT_SMALLER = 2;
/*     */   
/*     */   public static final int SUCCESS_CONDITION_ROWS_COUNT_SMALLER_EQUAL = 3;
/*     */   
/*     */   public static final int SUCCESS_CONDITION_ROWS_COUNT_GREATER = 4;
/*     */   
/*     */   public static final int SUCCESS_CONDITION_ROWS_COUNT_GREATER_EQUAL = 5;
/*     */   
/*     */   public String limit;
/*     */   
/*     */   public int successCondition;
/*     */   
/*     */ 
/*     */   public JobEntryEvalTableContent(String n)
/*     */   {
/* 115 */     super(n, "");
/* 116 */     this.limit = "0";
/* 117 */     this.successCondition = 4;
/* 118 */     this.iscustomSQL = false;
/* 119 */     this.isUseVars = false;
/* 120 */     this.isAddRowsResult = false;
/* 121 */     this.isClearResultList = true;
/* 122 */     this.customSQL = null;
/* 123 */     this.schemaname = null;
/* 124 */     this.tablename = null;
/* 125 */     this.connection = null;
/* 126 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryEvalTableContent()
/*     */   {
/* 131 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 136 */     JobEntryEvalTableContent je = (JobEntryEvalTableContent)super.clone();
/* 137 */     return je;
/*     */   }
/*     */   
/* 140 */   public int getSuccessCobdition() { return this.successCondition; }
/*     */   
/*     */   public static int getSuccessConditionByDesc(String tt) {
/* 143 */     if (tt == null) {
/* 144 */       return 0;
/*     */     }
/* 146 */     for (int i = 0; i < successConditionsDesc.length; i++) {
/* 147 */       if (successConditionsDesc[i].equalsIgnoreCase(tt)) {
/* 148 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 152 */     return getSuccessConditionByCode(tt);
/*     */   }
/*     */   
/*     */   public String getXML() {
/* 156 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/* 158 */     retval.append(super.getXML());
/* 159 */     retval.append("      ").append(XMLHandler.addTagValue("connection", this.connection == null ? null : this.connection.getName()));
/* 160 */     retval.append("      ").append(XMLHandler.addTagValue("schemaname", this.schemaname));
/* 161 */     retval.append("      ").append(XMLHandler.addTagValue("tablename", this.tablename));
/* 162 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", getSuccessConditionCode(this.successCondition)));
/* 163 */     retval.append("      ").append(XMLHandler.addTagValue("limit", this.limit));
/* 164 */     retval.append("      ").append(XMLHandler.addTagValue("is_custom_sql", this.iscustomSQL));
/* 165 */     retval.append("      ").append(XMLHandler.addTagValue("is_usevars", this.isUseVars));
/* 166 */     retval.append("      ").append(XMLHandler.addTagValue("custom_sql", this.customSQL));
/* 167 */     retval.append("      ").append(XMLHandler.addTagValue("add_rows_result", this.isAddRowsResult));
/* 168 */     retval.append("      ").append(XMLHandler.addTagValue("clear_result_rows", this.isClearResultList));
/*     */     
/* 170 */     return retval.toString();
/*     */   }
/*     */   
/* 173 */   private static String getSuccessConditionCode(int i) { if ((i < 0) || (i >= successConditionsCode.length))
/* 174 */       return successConditionsCode[0];
/* 175 */     return successConditionsCode[i];
/*     */   }
/*     */   
/* 178 */   private static int getSucessConditionByCode(String tt) { if (tt == null) {
/* 179 */       return 0;
/*     */     }
/* 181 */     for (int i = 0; i < successConditionsCode.length; i++) {
/* 182 */       if (successConditionsCode[i].equalsIgnoreCase(tt))
/* 183 */         return i;
/*     */     }
/* 185 */     return 0;
/*     */   }
/*     */   
/* 188 */   public static String getSuccessConditionDesc(int i) { if ((i < 0) || (i >= successConditionsDesc.length))
/* 189 */       return successConditionsDesc[0];
/* 190 */     return successConditionsDesc[i];
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try {
/* 196 */       super.loadXML(entrynode, databases, slaveServers);
/* 197 */       String dbname = XMLHandler.getTagValue(entrynode, "connection");
/* 198 */       this.connection = DatabaseMeta.findDatabase(databases, dbname);
/* 199 */       this.schemaname = XMLHandler.getTagValue(entrynode, "schemaname");
/* 200 */       this.tablename = XMLHandler.getTagValue(entrynode, "tablename");
/* 201 */       this.successCondition = getSucessConditionByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "success_condition"), ""));
/* 202 */       this.limit = Const.NVL(XMLHandler.getTagValue(entrynode, "limit"), "0");
/* 203 */       this.iscustomSQL = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "is_custom_sql"));
/* 204 */       this.isUseVars = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "is_usevars"));
/* 205 */       this.customSQL = XMLHandler.getTagValue(entrynode, "custom_sql");
/* 206 */       this.isAddRowsResult = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_rows_result"));
/* 207 */       this.isClearResultList = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "clear_result_rows"));
/*     */ 
/*     */     }
/*     */     catch (KettleException e)
/*     */     {
/* 212 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryEvalTableContent.UnableLoadXML", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 220 */       this.connection = rep.loadDatabaseMetaFromJobEntryAttribute(id_jobentry, "connection", "id_database", databases);
/*     */       
/* 222 */       this.schemaname = rep.getJobEntryAttributeString(id_jobentry, "schemaname");
/* 223 */       this.tablename = rep.getJobEntryAttributeString(id_jobentry, "tablename");
/* 224 */       this.successCondition = getSuccessConditionByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "success_condition"), ""));
/* 225 */       this.limit = rep.getJobEntryAttributeString(id_jobentry, "limit");
/* 226 */       this.iscustomSQL = rep.getJobEntryAttributeBoolean(id_jobentry, "is_custom_sql");
/* 227 */       this.isUseVars = rep.getJobEntryAttributeBoolean(id_jobentry, "is_usevars");
/* 228 */       this.isAddRowsResult = rep.getJobEntryAttributeBoolean(id_jobentry, "add_rows_result");
/* 229 */       this.isClearResultList = rep.getJobEntryAttributeBoolean(id_jobentry, "clear_result_rows");
/*     */       
/*     */ 
/* 232 */       this.customSQL = rep.getJobEntryAttributeString(id_jobentry, "custom_sql");
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 236 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryEvalTableContent.UnableLoadRep", new String[] { "" + id_jobentry }), dbe);
/*     */     }
/*     */   }
/*     */   
/* 240 */   private static int getSuccessConditionByCode(String tt) { if (tt == null) {
/* 241 */       return 0;
/*     */     }
/* 243 */     for (int i = 0; i < successConditionsCode.length; i++) {
/* 244 */       if (successConditionsCode[i].equalsIgnoreCase(tt))
/* 245 */         return i;
/*     */     }
/* 247 */     return 0;
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 254 */       rep.saveDatabaseMetaJobEntryAttribute(id_job, getObjectId(), "connection", "id_database", this.connection);
/*     */       
/* 256 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "schemaname", this.schemaname);
/* 257 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "tablename", this.tablename);
/* 258 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", getSuccessConditionCode(this.successCondition));
/* 259 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "limit", this.limit);
/* 260 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "custom_sql", this.customSQL);
/* 261 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "is_custom_sql", this.iscustomSQL);
/* 262 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "is_usevars", this.isUseVars);
/* 263 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_rows_result", this.isAddRowsResult);
/* 264 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "clear_result_rows", this.isClearResultList);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 268 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryEvalTableContent.UnableSaveRep", new String[] { "" + id_job }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setDatabase(DatabaseMeta database)
/*     */   {
/* 274 */     this.connection = database;
/*     */   }
/*     */   
/*     */   public DatabaseMeta getDatabase()
/*     */   {
/* 279 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 284 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 289 */     return false;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 294 */     Result result = previousResult;
/* 295 */     result.setResult(false);
/* 296 */     result.setNrErrors(1L);
/* 297 */     String countSQLStatement = null;
/* 298 */     long rowsCount = 0L;
/*     */     
/* 300 */     boolean successOK = false;
/*     */     
/* 302 */     int nrRowsLimit = Const.toInt(environmentSubstitute(this.limit), 0);
/* 303 */     if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Log.nrRowsLimit", new String[] { "" + nrRowsLimit }));
/*     */     }
/*     */     
/* 306 */     if (this.connection != null)
/*     */     {
/* 308 */       Database db = new Database(this, this.connection);
/* 309 */       db.shareVariablesWith(this);
/*     */       try
/*     */       {
/* 312 */         db.connect();
/*     */         
/* 314 */         if (this.iscustomSQL)
/*     */         {
/* 316 */           String realCustomSQL = this.customSQL;
/* 317 */           if (this.isUseVars) realCustomSQL = environmentSubstitute(realCustomSQL);
/* 318 */           if (this.log.isDebug()) { logDebug(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Log.EnteredCustomSQL", new String[] { realCustomSQL }));
/*     */           }
/* 320 */           if (!Const.isEmpty(realCustomSQL))
/*     */           {
/* 322 */             countSQLStatement = realCustomSQL;
/*     */           } else {
/* 324 */             logError(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Error.NoCustomSQL", new String[0]));
/*     */           }
/*     */         }
/*     */         else {
/* 328 */           String realTablename = environmentSubstitute(this.tablename);
/* 329 */           String realSchemaname = environmentSubstitute(this.schemaname);
/*     */           
/* 331 */           if (!Const.isEmpty(realTablename))
/*     */           {
/* 333 */             if (!Const.isEmpty(realSchemaname))
/*     */             {
/* 335 */               countSQLStatement = "SELECT count(*) FROM " + db.getDatabaseMeta().getQuotedSchemaTableCombination(realSchemaname, realTablename);
/*     */             }
/*     */             else {
/* 338 */               countSQLStatement = "SELECT count(*) FROM " + db.getDatabaseMeta().quoteField(realTablename);
/*     */             }
/*     */           } else {
/* 341 */             logError(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Error.NoTableName", new String[0]));
/*     */           }
/*     */         }
/* 344 */         if (countSQLStatement != null)
/*     */         {
/* 346 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Log.RunSQLStatement", new String[] { countSQLStatement }));
/*     */           }
/* 348 */           if (this.iscustomSQL)
/*     */           {
/* 350 */             if (this.isClearResultList) { result.getRows().clear();
/*     */             }
/* 352 */             List<Object[]> ar = db.getRows(countSQLStatement, 0);
/* 353 */             if (ar != null)
/*     */             {
/* 355 */               rowsCount = ar.size();
/*     */               
/*     */ 
/* 358 */               RowMetaInterface rowMeta = db.getQueryFields(countSQLStatement, false);
/*     */               
/* 360 */               List<RowMetaAndData> rows = new ArrayList();
/* 361 */               for (int i = 0; i < ar.size(); i++)
/*     */               {
/* 363 */                 rows.add(new RowMetaAndData(rowMeta, (Object[])ar.get(i)));
/*     */               }
/* 365 */               if ((this.isAddRowsResult) && (this.iscustomSQL) && (rows != null)) { result.getRows().addAll(rows);
/*     */               }
/*     */             }
/* 368 */             else if (this.log.isDebug()) { logDebug(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Log.customSQLreturnedNothing", new String[] { countSQLStatement }));
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 373 */             RowMetaAndData row = db.getOneRow(countSQLStatement);
/* 374 */             if (row != null)
/*     */             {
/* 376 */               rowsCount = row.getInteger(0).longValue();
/*     */             }
/*     */           }
/* 379 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Log.NrRowsReturned", new String[] { "" + rowsCount }));
/* 380 */           switch (this.successCondition)
/*     */           {
/*     */           case 0: 
/* 383 */             successOK = rowsCount == nrRowsLimit;
/* 384 */             break;
/*     */           case 1: 
/* 386 */             successOK = rowsCount != nrRowsLimit;
/* 387 */             break;
/*     */           case 2: 
/* 389 */             successOK = rowsCount < nrRowsLimit;
/* 390 */             break;
/*     */           case 3: 
/* 392 */             successOK = rowsCount <= nrRowsLimit;
/* 393 */             break;
/*     */           case 4: 
/* 395 */             successOK = rowsCount > nrRowsLimit;
/* 396 */             break;
/*     */           case 5: 
/* 398 */             successOK = rowsCount >= nrRowsLimit;
/*     */           
/*     */ 
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       catch (KettleException dbe)
/*     */       {
/* 407 */         logError(BaseMessages.getString(PKG, "JobEntryEvalTableContent.Error.RunningEntry", new String[] { dbe.getMessage() }));
/*     */       } finally {
/* 409 */         if (db != null) db.disconnect();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 414 */       logError(BaseMessages.getString(PKG, "JobEntryEvalTableContent.NoDbConnection", new String[0]));
/*     */     }
/*     */     
/* 417 */     if (successOK)
/*     */     {
/* 419 */       result.setResult(true);
/* 420 */       result.setNrErrors(0L);
/*     */     }
/* 422 */     result.setNrLinesRead(rowsCount);
/* 423 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 428 */   public DatabaseMeta[] getUsedDatabaseConnections() { return new DatabaseMeta[] { this.connection }; }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 431 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 432 */     if (this.connection != null) {
/* 433 */       ResourceReference reference = new ResourceReference(this);
/* 434 */       reference.getEntries().add(new ResourceEntry(this.connection.getHostname(), ResourceEntry.ResourceType.SERVER));
/* 435 */       reference.getEntries().add(new ResourceEntry(this.connection.getDatabaseName(), ResourceEntry.ResourceType.DATABASENAME));
/* 436 */       references.add(reference);
/*     */     }
/* 438 */     return references;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 443 */     JobEntryValidatorUtils.andValidator().validate(this, "WaitForSQL", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\evaluatetablecontent\JobEntryEvalTableContent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */