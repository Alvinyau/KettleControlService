/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.row.RowMeta;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.repository.RepositoryAttributeInterface;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.pentaho.di.trans.Trans;
/*     */ import org.pentaho.di.trans.step.StepMeta;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransLogTable
/*     */   extends BaseLogTable
/*     */   implements Cloneable, LogTableInterface
/*     */ {
/*  54 */   private static Class<?> PKG = TransLogTable.class;
/*     */   public static final String XML_TAG = "trans-log-table";
/*     */   private String logInterval;
/*     */   private String logSizeLimit;
/*     */   private List<StepMeta> steps;
/*     */   
/*  60 */   public static enum ID { ID_BATCH("ID_BATCH"), 
/*  61 */     CHANNEL_ID("CHANNEL_ID"), 
/*  62 */     TRANSNAME("TRANSNAME"), 
/*  63 */     STATUS("STATUS"), 
/*  64 */     LINES_READ("LINES_READ"), 
/*  65 */     LINES_WRITTEN("LINES_WRITTEN"), 
/*  66 */     LINES_UPDATED("LINES_UPDATED"), 
/*  67 */     LINES_INPUT("LINES_INPUT"), 
/*  68 */     LINES_OUTPUT("LINES_OUTPUT"), 
/*  69 */     LINES_REJECTED("LINES_REJECTED"), 
/*  70 */     ERRORS("ERRORS"), 
/*  71 */     STARTDATE("STARTDATE"), 
/*  72 */     ENDDATE("ENDDATE"), 
/*  73 */     LOGDATE("LOGDATE"), 
/*  74 */     DEPDATE("DEPDATE"), 
/*  75 */     REPLAYDATE("REPLAYDATE"), 
/*  76 */     LOG_FIELD("LOG_FIELD");
/*     */     
/*     */     private String id;
/*     */     
/*  80 */     private ID(String id) { this.id = id; }
/*     */     
/*     */     public String toString()
/*     */     {
/*  84 */       return this.id;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransLogTable(VariableSpace space, HasDatabasesInterface databasesInterface, List<StepMeta> steps)
/*     */   {
/*  95 */     super(space, databasesInterface, null, null, null);
/*  96 */     this.steps = steps;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/* 102 */       TransLogTable table = (TransLogTable)super.clone();
/* 103 */       table.fields = new ArrayList();
/* 104 */       for (LogTableField field : this.fields) {
/* 105 */         table.fields.add((LogTableField)field.clone());
/*     */       }
/* 107 */       return table;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/* 110 */     return null;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 115 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 117 */     retval.append(XMLHandler.openTag("trans-log-table"));
/* 118 */     retval.append(XMLHandler.addTagValue("connection", this.connectionName));
/* 119 */     retval.append(XMLHandler.addTagValue("schema", this.schemaName));
/* 120 */     retval.append(XMLHandler.addTagValue("table", this.tableName));
/* 121 */     retval.append(XMLHandler.addTagValue("size_limit_lines", this.logSizeLimit));
/* 122 */     retval.append(XMLHandler.addTagValue("interval", this.logInterval));
/* 123 */     retval.append(XMLHandler.addTagValue("timeout_days", this.timeoutInDays));
/* 124 */     retval.append(super.getFieldsXML());
/* 125 */     retval.append(XMLHandler.closeTag("trans-log-table")).append(Const.CR);
/*     */     
/* 127 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node node, List<DatabaseMeta> databases, List<StepMeta> steps) {
/* 131 */     this.connectionName = XMLHandler.getTagValue(node, "connection");
/* 132 */     this.schemaName = XMLHandler.getTagValue(node, "schema");
/* 133 */     this.tableName = XMLHandler.getTagValue(node, "table");
/* 134 */     this.logSizeLimit = XMLHandler.getTagValue(node, "size_limit_lines");
/* 135 */     this.logInterval = XMLHandler.getTagValue(node, "interval");
/* 136 */     this.timeoutInDays = XMLHandler.getTagValue(node, "timeout_days");
/*     */     
/* 138 */     int nr = XMLHandler.countNodes(node, "field");
/* 139 */     for (int i = 0; i < nr; i++) {
/* 140 */       Node fieldNode = XMLHandler.getSubNodeByNr(node, "field", i);
/* 141 */       String id = XMLHandler.getTagValue(fieldNode, "id");
/* 142 */       LogTableField field = findField(id);
/* 143 */       if ((field == null) && (i < this.fields.size())) {
/* 144 */         field = (LogTableField)this.fields.get(i);
/*     */       }
/* 146 */       if (field != null) {
/* 147 */         field.setFieldName(XMLHandler.getTagValue(fieldNode, "name"));
/* 148 */         field.setEnabled("Y".equalsIgnoreCase(XMLHandler.getTagValue(fieldNode, "enabled")));
/* 149 */         field.setSubject(StepMeta.findStep(steps, XMLHandler.getTagValue(fieldNode, "subject")));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveToRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 155 */     super.saveToRepository(attributeInterface);
/*     */     
/*     */ 
/*     */ 
/* 159 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_INTERVAL, this.logInterval);
/* 160 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_SIZE_LIMIT, this.logSizeLimit);
/*     */   }
/*     */   
/*     */   public void loadFromRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 164 */     super.loadFromRepository(attributeInterface);
/*     */     
/* 166 */     this.logInterval = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_INTERVAL);
/* 167 */     this.logSizeLimit = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_SIZE_LIMIT);
/*     */     
/* 169 */     for (int i = 0; i < getFields().size(); i++) {
/* 170 */       String id = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_FIELD_ID + i);
/*     */       
/*     */ 
/*     */ 
/* 174 */       if (id != null) {
/* 175 */         LogTableField field = findField(id);
/* 176 */         if (field.isSubjectAllowed())
/*     */         {
/*     */ 
/*     */ 
/* 180 */           String stepname = (String)field.getSubject();
/* 181 */           if (!Const.isEmpty(stepname)) {
/* 182 */             field.setSubject(StepMeta.findStep(this.steps, stepname));
/*     */           } else {
/* 184 */             field.setSubject(null);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static TransLogTable getDefault(VariableSpace space, HasDatabasesInterface databasesInterface, List<StepMeta> steps)
/*     */   {
/* 193 */     TransLogTable table = new TransLogTable(space, databasesInterface, steps);
/*     */     
/* 195 */     table.fields.add(new LogTableField(ID.ID_BATCH.id, true, false, "ID_BATCH", BaseMessages.getString(PKG, "TransLogTable.FieldName.BatchID", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.BatchID", new String[0]), 5, 8));
/* 196 */     table.fields.add(new LogTableField(ID.CHANNEL_ID.id, true, false, "CHANNEL_ID", BaseMessages.getString(PKG, "TransLogTable.FieldName.ChannelID", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.ChannelID", new String[0]), 2, 255));
/* 197 */     table.fields.add(new LogTableField(ID.TRANSNAME.id, true, false, "TRANSNAME", BaseMessages.getString(PKG, "TransLogTable.FieldName.TransName", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.TransName", new String[0]), 2, 255));
/* 198 */     table.fields.add(new LogTableField(ID.STATUS.id, true, false, "STATUS", BaseMessages.getString(PKG, "TransLogTable.FieldName.Status", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.Status", new String[0]), 2, 15));
/* 199 */     table.fields.add(new LogTableField(ID.LINES_READ.id, true, true, "LINES_READ", BaseMessages.getString(PKG, "TransLogTable.FieldName.LinesRead", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LinesRead", new String[0]), 5, 18));
/* 200 */     table.fields.add(new LogTableField(ID.LINES_WRITTEN.id, true, true, "LINES_WRITTEN", BaseMessages.getString(PKG, "TransLogTable.FieldName.LinesWritten", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LinesWritten", new String[0]), 5, 18));
/* 201 */     table.fields.add(new LogTableField(ID.LINES_UPDATED.id, true, true, "LINES_UPDATED", BaseMessages.getString(PKG, "TransLogTable.FieldName.LinesUpdated", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LinesUpdated", new String[0]), 5, 18));
/* 202 */     table.fields.add(new LogTableField(ID.LINES_INPUT.id, true, true, "LINES_INPUT", BaseMessages.getString(PKG, "TransLogTable.FieldName.LinesInput", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LinesInput", new String[0]), 5, 18));
/* 203 */     table.fields.add(new LogTableField(ID.LINES_OUTPUT.id, true, true, "LINES_OUTPUT", BaseMessages.getString(PKG, "TransLogTable.FieldName.LinesOutput", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LinesOutput", new String[0]), 5, 18));
/* 204 */     table.fields.add(new LogTableField(ID.LINES_REJECTED.id, true, true, "LINES_REJECTED", BaseMessages.getString(PKG, "TransLogTable.FieldName.LinesRejected", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LinesRejected", new String[0]), 5, 18));
/* 205 */     table.fields.add(new LogTableField(ID.ERRORS.id, true, false, "ERRORS", BaseMessages.getString(PKG, "TransLogTable.FieldName.Errors", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.Errors", new String[0]), 5, 18));
/* 206 */     table.fields.add(new LogTableField(ID.STARTDATE.id, true, false, "STARTDATE", BaseMessages.getString(PKG, "TransLogTable.FieldName.StartDateRange", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.StartDateRange", new String[0]), 3, -1));
/* 207 */     table.fields.add(new LogTableField(ID.ENDDATE.id, true, false, "ENDDATE", BaseMessages.getString(PKG, "TransLogTable.FieldName.EndDateRange", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.EndDateRange", new String[0]), 3, -1));
/* 208 */     table.fields.add(new LogTableField(ID.LOGDATE.id, true, false, "LOGDATE", BaseMessages.getString(PKG, "TransLogTable.FieldName.LogDate", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LogDate", new String[0]), 3, -1));
/* 209 */     table.fields.add(new LogTableField(ID.DEPDATE.id, true, false, "DEPDATE", BaseMessages.getString(PKG, "TransLogTable.FieldName.DepDate", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.DepDate", new String[0]), 3, -1));
/* 210 */     table.fields.add(new LogTableField(ID.REPLAYDATE.id, true, false, "REPLAYDATE", BaseMessages.getString(PKG, "TransLogTable.FieldName.ReplayDate", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.ReplayDate", new String[0]), 3, -1));
/* 211 */     table.fields.add(new LogTableField(ID.LOG_FIELD.id, true, false, "LOG_FIELD", BaseMessages.getString(PKG, "TransLogTable.FieldName.LogField", new String[0]), BaseMessages.getString(PKG, "TransLogTable.FieldDescription.LogField", new String[0]), 2, 9999999));
/*     */     
/* 213 */     table.findField(ID.ID_BATCH).setKey(true);
/* 214 */     table.findField(ID.LOGDATE).setLogDateField(true);
/* 215 */     table.findField(ID.LOG_FIELD).setLogField(true);
/* 216 */     table.findField(ID.CHANNEL_ID).setVisible(false);
/* 217 */     table.findField(ID.TRANSNAME).setVisible(false);
/* 218 */     table.findField(ID.STATUS).setStatusField(true);
/* 219 */     table.findField(ID.ERRORS).setErrorsField(true);
/* 220 */     table.findField(ID.TRANSNAME).setNameField(true);
/*     */     
/* 222 */     return table;
/*     */   }
/*     */   
/*     */   public LogTableField findField(ID id) {
/* 226 */     return super.findField(id.id);
/*     */   }
/*     */   
/*     */   public Object getSubject(ID id) {
/* 230 */     return super.getSubject(id.id);
/*     */   }
/*     */   
/*     */   public String getSubjectString(ID id) {
/* 234 */     return super.getSubjectString(id.id);
/*     */   }
/*     */   
/*     */   public void setBatchIdUsed(boolean use) {
/* 238 */     findField(ID.ID_BATCH).setEnabled(use);
/*     */   }
/*     */   
/*     */   public boolean isBatchIdUsed() {
/* 242 */     return findField(ID.ID_BATCH).isEnabled();
/*     */   }
/*     */   
/*     */   public void setLogFieldUsed(boolean use) {
/* 246 */     findField(ID.LOG_FIELD).setEnabled(use);
/*     */   }
/*     */   
/*     */   public boolean isLogFieldUsed() {
/* 250 */     return findField(ID.LOG_FIELD).isEnabled();
/*     */   }
/*     */   
/*     */   public String getStepnameRead() {
/* 254 */     return getSubjectString(ID.LINES_READ);
/*     */   }
/*     */   
/*     */   public void setStepRead(StepMeta read) {
/* 258 */     findField(ID.LINES_READ).setSubject(read);
/*     */   }
/*     */   
/*     */   public String getStepnameWritten() {
/* 262 */     return getSubjectString(ID.LINES_WRITTEN);
/*     */   }
/*     */   
/*     */   public void setStepWritten(StepMeta written) {
/* 266 */     findField(ID.LINES_WRITTEN).setSubject(written);
/*     */   }
/*     */   
/*     */   public String getStepnameInput() {
/* 270 */     return getSubjectString(ID.LINES_INPUT);
/*     */   }
/*     */   
/*     */   public void setStepInput(StepMeta input) {
/* 274 */     findField(ID.LINES_INPUT).setSubject(input);
/*     */   }
/*     */   
/*     */   public String getStepnameOutput() {
/* 278 */     return getSubjectString(ID.LINES_OUTPUT);
/*     */   }
/*     */   
/*     */   public void setStepOutput(StepMeta output) {
/* 282 */     findField(ID.LINES_OUTPUT).setSubject(output);
/*     */   }
/*     */   
/*     */   public String getStepnameUpdated() {
/* 286 */     return getSubjectString(ID.LINES_UPDATED);
/*     */   }
/*     */   
/*     */   public void setStepUpdate(StepMeta update) {
/* 290 */     findField(ID.LINES_UPDATED).setSubject(update);
/*     */   }
/*     */   
/*     */   public String getStepnameRejected() {
/* 294 */     return getSubjectString(ID.LINES_REJECTED);
/*     */   }
/*     */   
/*     */   public void setStepRejected(StepMeta rejected) {
/* 298 */     findField(ID.LINES_REJECTED).setSubject(rejected);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogInterval(String logInterval)
/*     */   {
/* 309 */     this.logInterval = logInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLogInterval()
/*     */   {
/* 320 */     return this.logInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getLogSizeLimit()
/*     */   {
/* 327 */     return this.logSizeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogSizeLimit(String logSizeLimit)
/*     */   {
/* 334 */     this.logSizeLimit = logSizeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowMetaAndData getLogRecord(LogStatus status, Object subject, Object parent)
/*     */   {
/* 344 */     if ((subject == null) || ((subject instanceof Trans))) {
/* 345 */       Trans trans = (Trans)subject;
/* 346 */       Result result = null;
/* 347 */       if (trans != null) { result = trans.getResult();
/*     */       }
/* 349 */       RowMetaAndData row = new RowMetaAndData();
/*     */       
/* 351 */       for (LogTableField field : this.fields) {
/* 352 */         if (field.isEnabled()) {
/* 353 */           Object value = null;
/* 354 */           if (trans != null)
/*     */           {
/* 356 */             switch (ID.valueOf(field.getId())) {
/* 357 */             case ID_BATCH:  value = new Long(trans.getBatchId()); break;
/* 358 */             case CHANNEL_ID:  value = trans.getLogChannelId(); break;
/* 359 */             case TRANSNAME:  value = trans.getName(); break;
/* 360 */             case STATUS:  value = status.getStatus(); break;
/* 361 */             case LINES_READ:  value = new Long(result.getNrLinesRead()); break;
/* 362 */             case LINES_WRITTEN:  value = new Long(result.getNrLinesWritten()); break;
/* 363 */             case LINES_INPUT:  value = new Long(result.getNrLinesInput()); break;
/* 364 */             case LINES_OUTPUT:  value = new Long(result.getNrLinesOutput()); break;
/* 365 */             case LINES_UPDATED:  value = new Long(result.getNrLinesUpdated()); break;
/* 366 */             case LINES_REJECTED:  value = new Long(result.getNrLinesRejected()); break;
/* 367 */             case ERRORS:  value = new Long(result.getNrErrors()); break;
/* 368 */             case STARTDATE:  value = trans.getStartDate(); break;
/* 369 */             case LOGDATE:  value = trans.getLogDate(); break;
/* 370 */             case ENDDATE:  value = trans.getEndDate(); break;
/* 371 */             case DEPDATE:  value = trans.getDepDate(); break;
/* 372 */             case REPLAYDATE:  value = trans.getCurrentDate(); break;
/*     */             case LOG_FIELD: 
/* 374 */               value = getLogBuffer(trans, trans.getLogChannelId(), status, this.logSizeLimit);
/*     */             }
/*     */             
/*     */           }
/*     */           
/* 379 */           row.addValue(field.getFieldName(), field.getDataType(), value);
/* 380 */           row.getRowMeta().getValueMeta(row.size() - 1).setLength(field.getLength());
/*     */         }
/*     */       }
/*     */       
/* 384 */       return row;
/*     */     }
/*     */     
/* 387 */     return null;
/*     */   }
/*     */   
/*     */   public String getLogTableCode()
/*     */   {
/* 392 */     return "TRANS";
/*     */   }
/*     */   
/*     */   public String getLogTableType() {
/* 396 */     return BaseMessages.getString(PKG, "TransLogTable.Type.Description", new String[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionNameVariable() {
/* 400 */     return "KETTLE_TRANS_LOG_DB";
/*     */   }
/*     */   
/*     */   public String getSchemaNameVariable() {
/* 404 */     return "KETTLE_TRANS_LOG_SCHEMA";
/*     */   }
/*     */   
/*     */   public String getTableNameVariable() {
/* 408 */     return "KETTLE_TRANS_LOG_TABLE";
/*     */   }
/*     */   
/*     */   public List<RowMetaInterface> getRecommendedIndexes() {
/* 412 */     List<RowMetaInterface> indexes = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/* 416 */     if (isBatchIdUsed()) {
/* 417 */       RowMetaInterface batchIndex = new RowMeta();
/* 418 */       LogTableField keyField = getKeyField();
/*     */       
/* 420 */       ValueMetaInterface keyMeta = new ValueMeta(keyField.getFieldName(), keyField.getDataType());
/* 421 */       keyMeta.setLength(keyField.getLength());
/* 422 */       batchIndex.addValueMeta(keyMeta);
/*     */       
/* 424 */       indexes.add(batchIndex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 429 */     RowMetaInterface lookupIndex = new RowMeta();
/* 430 */     LogTableField errorsField = findField(ID.ERRORS);
/* 431 */     if (errorsField != null) {
/* 432 */       ValueMetaInterface valueMeta = new ValueMeta(errorsField.getFieldName(), errorsField.getDataType());
/* 433 */       valueMeta.setLength(errorsField.getLength());
/* 434 */       lookupIndex.addValueMeta(valueMeta);
/*     */     }
/* 436 */     LogTableField statusField = findField(ID.STATUS);
/* 437 */     if (statusField != null) {
/* 438 */       ValueMetaInterface valueMeta = new ValueMeta(statusField.getFieldName(), statusField.getDataType());
/* 439 */       valueMeta.setLength(statusField.getLength());
/* 440 */       lookupIndex.addValueMeta(valueMeta);
/*     */     }
/* 442 */     LogTableField transNameField = findField(ID.TRANSNAME);
/* 443 */     if (transNameField != null) {
/* 444 */       ValueMetaInterface valueMeta = new ValueMeta(transNameField.getFieldName(), transNameField.getDataType());
/* 445 */       valueMeta.setLength(transNameField.getLength());
/* 446 */       lookupIndex.addValueMeta(valueMeta);
/*     */     }
/*     */     
/* 449 */     indexes.add(lookupIndex);
/*     */     
/* 451 */     return indexes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\TransLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */