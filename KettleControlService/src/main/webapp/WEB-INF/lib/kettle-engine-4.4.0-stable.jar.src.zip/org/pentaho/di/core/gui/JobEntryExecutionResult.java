package org.pentaho.di.core.gui;

public class JobEntryExecutionResult {}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\JobEntryExecutionResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */