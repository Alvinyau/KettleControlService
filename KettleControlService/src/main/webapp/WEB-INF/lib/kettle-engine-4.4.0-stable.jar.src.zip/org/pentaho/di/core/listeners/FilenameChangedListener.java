package org.pentaho.di.core.listeners;

public abstract interface FilenameChangedListener
{
  public abstract void filenameChanged(Object paramObject, String paramString1, String paramString2);
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\listeners\FilenameChangedListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */