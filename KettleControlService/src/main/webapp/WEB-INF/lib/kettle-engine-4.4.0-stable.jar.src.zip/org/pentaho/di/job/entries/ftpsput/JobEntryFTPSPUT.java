/*     */ package org.pentaho.di.job.entries.ftpsput;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.encryption.Encr;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entries.ftpsget.FTPSConnection;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFTPSPUT
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  70 */   private static Class<?> PKG = JobEntryFTPSPUT.class;
/*     */   
/*     */   private String serverName;
/*     */   
/*     */   private String serverPort;
/*     */   
/*     */   private String userName;
/*     */   
/*     */   private String password;
/*     */   
/*     */   private String remoteDirectory;
/*     */   
/*     */   private String localDirectory;
/*     */   private String wildcard;
/*     */   private boolean binaryMode;
/*     */   private int timeout;
/*     */   private boolean remove;
/*     */   private boolean onlyPuttingNewFiles;
/*     */   private boolean activeConnection;
/*     */   private String proxyHost;
/*     */   private String proxyPort;
/*     */   private String proxyUsername;
/*     */   private String proxyPassword;
/*     */   private int connectionType;
/*     */   
/*     */   public JobEntryFTPSPUT(String n)
/*     */   {
/*  97 */     super(n, "");
/*  98 */     this.serverName = null;
/*  99 */     this.serverPort = "21";
/* 100 */     this.remoteDirectory = null;
/* 101 */     this.localDirectory = null;
/* 102 */     this.connectionType = 0;
/* 103 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryFTPSPUT()
/*     */   {
/* 108 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 113 */     JobEntryFTPSPUT je = (JobEntryFTPSPUT)super.clone();
/* 114 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 119 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/* 121 */     retval.append(super.getXML());
/*     */     
/* 123 */     retval.append("      ").append(XMLHandler.addTagValue("servername", this.serverName));
/* 124 */     retval.append("      ").append(XMLHandler.addTagValue("serverport", this.serverPort));
/* 125 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.userName));
/* 126 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(getPassword())));
/* 127 */     retval.append("      ").append(XMLHandler.addTagValue("remoteDirectory", this.remoteDirectory));
/* 128 */     retval.append("      ").append(XMLHandler.addTagValue("localDirectory", this.localDirectory));
/* 129 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/* 130 */     retval.append("      ").append(XMLHandler.addTagValue("binary", this.binaryMode));
/* 131 */     retval.append("      ").append(XMLHandler.addTagValue("timeout", this.timeout));
/* 132 */     retval.append("      ").append(XMLHandler.addTagValue("remove", this.remove));
/* 133 */     retval.append("      ").append(XMLHandler.addTagValue("only_new", this.onlyPuttingNewFiles));
/* 134 */     retval.append("      ").append(XMLHandler.addTagValue("active", this.activeConnection));
/*     */     
/* 136 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_host", this.proxyHost));
/* 137 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_port", this.proxyPort));
/* 138 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_username", this.proxyUsername));
/* 139 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_password", this.proxyPassword));
/* 140 */     retval.append("      ").append(XMLHandler.addTagValue("connection_type", FTPSConnection.getConnectionTypeCode(this.connectionType)));
/*     */     
/* 142 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 149 */       super.loadXML(entrynode, databases, slaveServers);
/* 150 */       this.serverName = XMLHandler.getTagValue(entrynode, "servername");
/* 151 */       this.serverPort = XMLHandler.getTagValue(entrynode, "serverport");
/* 152 */       this.userName = XMLHandler.getTagValue(entrynode, "username");
/* 153 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/* 154 */       this.remoteDirectory = XMLHandler.getTagValue(entrynode, "remoteDirectory");
/* 155 */       this.localDirectory = XMLHandler.getTagValue(entrynode, "localDirectory");
/* 156 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/* 157 */       this.binaryMode = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "binary"));
/* 158 */       this.timeout = Const.toInt(XMLHandler.getTagValue(entrynode, "timeout"), 10000);
/* 159 */       this.remove = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "remove"));
/* 160 */       this.onlyPuttingNewFiles = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "only_new"));
/* 161 */       this.activeConnection = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "active"));
/*     */       
/* 163 */       this.proxyHost = XMLHandler.getTagValue(entrynode, "proxy_host");
/* 164 */       this.proxyPort = XMLHandler.getTagValue(entrynode, "proxy_port");
/* 165 */       this.proxyUsername = XMLHandler.getTagValue(entrynode, "proxy_username");
/* 166 */       this.proxyPassword = XMLHandler.getTagValue(entrynode, "proxy_password");
/* 167 */       this.connectionType = FTPSConnection.getConnectionTypeByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "connection_type"), ""));
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 171 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobFTPSPUT.Log.UnableToLoadFromXml", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 179 */       this.serverName = rep.getJobEntryAttributeString(id_jobentry, "servername");
/* 180 */       int intServerPort = (int)rep.getJobEntryAttributeInteger(id_jobentry, "serverport");
/* 181 */       this.serverPort = rep.getJobEntryAttributeString(id_jobentry, "serverport");
/* 182 */       if ((intServerPort > 0) && (Const.isEmpty(this.serverPort))) { this.serverPort = Integer.toString(intServerPort);
/*     */       }
/* 184 */       this.userName = rep.getJobEntryAttributeString(id_jobentry, "username");
/* 185 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/* 186 */       this.remoteDirectory = rep.getJobEntryAttributeString(id_jobentry, "remoteDirectory");
/* 187 */       this.localDirectory = rep.getJobEntryAttributeString(id_jobentry, "localDirectory");
/* 188 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/* 189 */       this.binaryMode = rep.getJobEntryAttributeBoolean(id_jobentry, "binary");
/* 190 */       this.timeout = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "timeout"));
/* 191 */       this.remove = rep.getJobEntryAttributeBoolean(id_jobentry, "remove");
/* 192 */       this.onlyPuttingNewFiles = rep.getJobEntryAttributeBoolean(id_jobentry, "only_new");
/* 193 */       this.activeConnection = rep.getJobEntryAttributeBoolean(id_jobentry, "active");
/*     */       
/*     */ 
/* 196 */       this.proxyHost = rep.getJobEntryAttributeString(id_jobentry, "proxy_host");
/* 197 */       this.proxyPort = rep.getJobEntryAttributeString(id_jobentry, "proxy_port");
/* 198 */       this.proxyUsername = rep.getJobEntryAttributeString(id_jobentry, "proxy_username");
/* 199 */       this.proxyPassword = rep.getJobEntryAttributeString(id_jobentry, "proxy_password");
/* 200 */       this.connectionType = FTPSConnection.getConnectionTypeByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "connection_type"), ""));
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 204 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPSPUT.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 212 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "servername", this.serverName);
/* 213 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "serverport", this.serverPort);
/* 214 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.userName);
/* 215 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/* 216 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remoteDirectory", this.remoteDirectory);
/* 217 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "localDirectory", this.localDirectory);
/* 218 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/* 219 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "binary", this.binaryMode);
/* 220 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "timeout", this.timeout);
/* 221 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remove", this.remove);
/* 222 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "only_new", this.onlyPuttingNewFiles);
/* 223 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "active", this.activeConnection);
/*     */       
/* 225 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_host", this.proxyHost);
/* 226 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_port", this.proxyPort);
/* 227 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_username", this.proxyUsername);
/* 228 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_password", this.proxyPassword);
/* 229 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "connection_type", FTPSConnection.getConnectionType(this.connectionType));
/*     */ 
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 234 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPSPUT.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBinaryMode()
/*     */   {
/* 243 */     return this.binaryMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBinaryMode(boolean binaryMode)
/*     */   {
/* 251 */     this.binaryMode = binaryMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 258 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 266 */     return this.timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isOnlyPuttingNewFiles()
/*     */   {
/* 273 */     return this.onlyPuttingNewFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnlyPuttingNewFiles(boolean onlyPuttingNewFiles)
/*     */   {
/* 281 */     this.onlyPuttingNewFiles = onlyPuttingNewFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRemoteDirectory()
/*     */   {
/* 289 */     return this.remoteDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteDirectory(String directory)
/*     */   {
/* 297 */     this.remoteDirectory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 305 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 313 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServerName()
/*     */   {
/* 321 */     return this.serverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServerName(String serverName)
/*     */   {
/* 329 */     this.serverName = serverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 337 */     return this.userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserName(String userName)
/*     */   {
/* 345 */     this.userName = userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWildcard()
/*     */   {
/* 353 */     return this.wildcard;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWildcard(String wildcard)
/*     */   {
/* 361 */     this.wildcard = wildcard;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalDirectory()
/*     */   {
/* 369 */     return this.localDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalDirectory(String directory)
/*     */   {
/* 377 */     this.localDirectory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemove(boolean remove)
/*     */   {
/* 385 */     this.remove = remove;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRemove()
/*     */   {
/* 393 */     return this.remove;
/*     */   }
/*     */   
/*     */   public String getServerPort() {
/* 397 */     return this.serverPort;
/*     */   }
/*     */   
/*     */   public void setServerPort(String serverPort) {
/* 401 */     this.serverPort = serverPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActiveConnection()
/*     */   {
/* 409 */     return this.activeConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActiveConnection(boolean activeConnection)
/*     */   {
/* 417 */     this.activeConnection = activeConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxyHost()
/*     */   {
/* 425 */     return this.proxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyHost(String proxyHost)
/*     */   {
/* 433 */     this.proxyHost = proxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxyPassword()
/*     */   {
/* 441 */     return this.proxyPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyPassword(String proxyPassword)
/*     */   {
/* 449 */     this.proxyPassword = proxyPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxyPort()
/*     */   {
/* 457 */     return this.proxyPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getConnectionType()
/*     */   {
/* 464 */     return this.connectionType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionType(int type)
/*     */   {
/* 473 */     this.connectionType = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyPort(String proxyPort)
/*     */   {
/* 482 */     this.proxyPort = proxyPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getProxyUsername()
/*     */   {
/* 489 */     return this.proxyUsername;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProxyUsername(String proxyUsername)
/*     */   {
/* 496 */     this.proxyUsername = proxyUsername;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 501 */     Result result = previousResult;
/* 502 */     result.setResult(false);
/* 503 */     long filesput = 0L;
/*     */     
/* 505 */     if (isDetailed()) {
/* 506 */       logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.Starting", new String[0]));
/*     */     }
/*     */     
/* 509 */     String realServerName = environmentSubstitute(this.serverName);
/* 510 */     String realServerPort = environmentSubstitute(this.serverPort);
/* 511 */     String realUsername = environmentSubstitute(this.userName);
/* 512 */     String realPassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password));
/* 513 */     String realRemoteDirectory = environmentSubstitute(this.remoteDirectory);
/* 514 */     String realWildcard = environmentSubstitute(this.wildcard);
/* 515 */     String realLocalDirectory = environmentSubstitute(this.localDirectory);
/*     */     
/*     */ 
/* 518 */     FTPSConnection connection = null;
/*     */     
/*     */     try
/*     */     {
/* 522 */       int realPort = Const.toInt(environmentSubstitute(realServerPort), 0);
/*     */       
/* 524 */       connection = new FTPSConnection(getConnectionType(), realServerName, realPort, realUsername, realPassword);
/*     */       
/* 526 */       if (!Const.isEmpty(this.proxyHost)) {
/* 527 */         String realProxy_host = environmentSubstitute(this.proxyHost);
/* 528 */         String realProxy_username = environmentSubstitute(this.proxyUsername);
/* 529 */         String realProxy_password = environmentSubstitute(this.proxyPassword);
/* 530 */         connection.setProxyHost(realProxy_host);
/* 531 */         if (!Const.isEmpty(realProxy_username)) {
/* 532 */           connection.setProxyUser(realProxy_username);
/*     */         }
/* 534 */         if (!Const.isEmpty(realProxy_password)) {
/* 535 */           connection.setProxyPassword(realProxy_password);
/*     */         }
/* 537 */         if (isDetailed()) {
/* 538 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTPSPUT.OpenedProxyConnectionOn", new String[] { realProxy_host }));
/*     */         }
/* 540 */         int proxyport = Const.toInt(environmentSubstitute(this.proxyPort), 21);
/* 541 */         if (proxyport != 0) {
/* 542 */           connection.setProxyPort(proxyport);
/*     */         }
/*     */       }
/* 545 */       else if (isDetailed()) {
/* 546 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPSPUT.OpenedConnectionTo", new String[] { realServerName }));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 552 */       if (this.activeConnection) {
/* 553 */         connection.setPassiveMode(false);
/* 554 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.SetActiveConnection", new String[0]));
/*     */       } else {
/* 556 */         connection.setPassiveMode(true);
/* 557 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.SetPassiveConnection", new String[0]));
/*     */         }
/*     */       }
/*     */       
/* 561 */       if (isBinaryMode()) {
/* 562 */         connection.setBinaryMode(true);
/* 563 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.BinaryMod", new String[0]));
/*     */         }
/*     */       }
/*     */       
/* 567 */       connection.setTimeOut(this.timeout);
/* 568 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.SetTimeout", new Object[] { Integer.valueOf(this.timeout) }));
/*     */       }
/*     */       
/* 571 */       connection.connect();
/* 572 */       if (isDetailed())
/*     */       {
/* 574 */         logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.Logged", new String[] { realUsername }));
/* 575 */         logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.WorkingDirectory", new String[] { connection.getWorkingDirectory() }));
/*     */       }
/*     */       
/*     */ 
/* 579 */       if (!Const.isEmpty(realRemoteDirectory)) {
/* 580 */         connection.changeDirectory(realRemoteDirectory);
/* 581 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.ChangedDirectory", new String[] { realRemoteDirectory }));
/*     */       }
/* 583 */       realRemoteDirectory = Const.NVL(realRemoteDirectory, "/");
/*     */       
/* 585 */       ArrayList<String> myFileList = new ArrayList();
/* 586 */       File localFiles = new File(realLocalDirectory);
/* 587 */       File[] children = localFiles.listFiles();
/* 588 */       for (int i = 0; i < children.length; i++)
/*     */       {
/* 590 */         if (!children[i].isDirectory()) {
/* 591 */           myFileList.add(children[i].getName());
/*     */         }
/*     */       }
/*     */       
/* 595 */       String[] filelist = new String[myFileList.size()];
/* 596 */       myFileList.toArray(filelist);
/*     */       
/*     */ 
/* 599 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.FoundFileLocalDirectory", new Object[] { Integer.valueOf(filelist.length), realLocalDirectory }));
/*     */       }
/* 601 */       Pattern pattern = null;
/* 602 */       if (!Const.isEmpty(realWildcard)) {
/* 603 */         pattern = Pattern.compile(realWildcard);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 609 */       for (int i = 0; (i < filelist.length) && (!this.parentJob.isStopped()); i++) {
/* 610 */         boolean getIt = true;
/*     */         
/*     */ 
/* 613 */         if (pattern != null) {
/* 614 */           Matcher matcher = pattern.matcher(filelist[i]);
/* 615 */           getIt = matcher.matches();
/*     */         }
/*     */         
/* 618 */         if (getIt)
/*     */         {
/* 620 */           boolean fileExist = connection.isFileExists(filelist[i]);
/*     */           
/* 622 */           if (isDebug()) {
/* 623 */             if (fileExist) {
/* 624 */               logDebug(BaseMessages.getString(PKG, "JobFTPSPUT.Log.FileExists", new String[] { filelist[i] }));
/*     */             } else {
/* 626 */               logDebug(BaseMessages.getString(PKG, "JobFTPSPUT.Log.FileDoesNotExists", new String[] { filelist[i] }));
/*     */             }
/*     */           }
/* 629 */           if ((!fileExist) || ((!this.onlyPuttingNewFiles) && (fileExist)))
/*     */           {
/* 631 */             String localFilename = realLocalDirectory + Const.FILE_SEPARATOR + filelist[i];
/* 632 */             if (isDebug()) { logDebug(BaseMessages.getString(PKG, "JobFTPSPUT.Log.PuttingFileToRemoteDirectory", new String[] { localFilename, realRemoteDirectory }));
/*     */             }
/* 634 */             connection.uploadFile(localFilename, filelist[i]);
/*     */             
/* 636 */             filesput += 1L;
/*     */             
/*     */ 
/* 639 */             if (this.remove) {
/* 640 */               new File(localFilename).delete();
/* 641 */               if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPSPUT.Log.DeletedFile", new String[] { localFilename }));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 647 */       result.setResult(true);
/* 648 */       result.setNrLinesOutput(filesput);
/* 649 */       if (isDetailed()) logDebug(BaseMessages.getString(PKG, "JobFTPSPUT.Log.WeHavePut", new Object[] { Long.valueOf(filesput) }));
/*     */     } catch (Exception e) {
/* 651 */       result.setNrErrors(1L);
/* 652 */       logError(BaseMessages.getString(PKG, "JobFTPSPUT.Log.ErrorPuttingFiles", new String[] { e.getMessage() }));
/* 653 */       logError(Const.getStackTracker(e));
/*     */     } finally {
/* 655 */       if (connection != null) {
/*     */         try
/*     */         {
/* 658 */           connection.disconnect();
/*     */         } catch (Exception e) {
/* 660 */           logError(BaseMessages.getString(PKG, "JobFTPSPUT.Log.ErrorQuitingFTP", new String[] { e.getMessage() }));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 665 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 670 */   public boolean evaluates() { return true; }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 673 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 674 */     if (!Const.isEmpty(this.serverName)) {
/* 675 */       String realServerName = jobMeta.environmentSubstitute(this.serverName);
/* 676 */       ResourceReference reference = new ResourceReference(this);
/* 677 */       reference.getEntries().add(new ResourceEntry(realServerName, ResourceEntry.ResourceType.SERVER));
/* 678 */       references.add(reference);
/*     */     }
/* 680 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 686 */     JobEntryValidatorUtils.andValidator().validate(this, "serverName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 687 */     JobEntryValidatorUtils.andValidator().validate(this, "localDirectory", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() }));
/*     */     
/* 689 */     JobEntryValidatorUtils.andValidator().validate(this, "userName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 690 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/* 691 */     JobEntryValidatorUtils.andValidator().validate(this, "serverPort", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftpsput\JobEntryFTPSPUT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */