/*     */ package org.pentaho.di.imp.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.logging.JobLogTable;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*     */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobHasJobLogConfiguredImportRule
/*     */   extends BaseImportRule
/*     */   implements ImportRuleInterface
/*     */ {
/*     */   private String schemaName;
/*     */   private String tableName;
/*     */   private String connectionName;
/*     */   
/*     */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*     */   {
/*  57 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*     */     
/*  59 */     if (!isEnabled()) {
/*  60 */       return feedback;
/*     */     }
/*  62 */     if (!(subject instanceof JobMeta)) {
/*  63 */       return feedback;
/*     */     }
/*     */     
/*  66 */     JobMeta jobMeta = (JobMeta)subject;
/*  67 */     JobLogTable jobLogTable = jobMeta.getJobLogTable();
/*     */     
/*  69 */     if (!jobLogTable.isDefined()) {
/*  70 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The logging table is not defined"));
/*     */     } else {
/*  72 */       if (!Const.isEmpty(this.schemaName)) {
/*  73 */         if (this.schemaName.equals(jobLogTable.getSchemaName())) {
/*  74 */           feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "The schema name is set to: " + this.schemaName));
/*     */         } else {
/*  76 */           feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The schema name is not set to: " + this.schemaName));
/*     */         }
/*     */       }
/*     */       
/*  80 */       if (!Const.isEmpty(this.tableName)) {
/*  81 */         if (this.tableName.equals(jobLogTable.getTableName())) {
/*  82 */           feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "The table name is set to: " + this.tableName));
/*     */         } else {
/*  84 */           feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The table name is not set to: " + this.tableName));
/*     */         }
/*     */       }
/*     */       
/*  88 */       if (!Const.isEmpty(this.connectionName)) {
/*  89 */         if (this.connectionName.equals(jobLogTable.getDatabaseMeta().getName())) {
/*  90 */           feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "The database connection used for logging is: " + this.connectionName));
/*     */         } else {
/*  92 */           feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The database connection used for logging is not: " + this.connectionName));
/*     */         }
/*     */       }
/*     */       
/*  96 */       if (feedback.isEmpty()) {
/*  97 */         feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "The logging table is correctly defined"));
/*     */       }
/*     */     }
/*     */     
/* 101 */     return feedback;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getXML()
/*     */   {
/* 107 */     StringBuilder xml = new StringBuilder();
/* 108 */     xml.append(XMLHandler.openTag(XML_TAG));
/*     */     
/* 110 */     xml.append(super.getXML());
/*     */     
/* 112 */     xml.append(XMLHandler.addTagValue("schema_name", this.schemaName));
/* 113 */     xml.append(XMLHandler.addTagValue("table_name", this.tableName));
/* 114 */     xml.append(XMLHandler.addTagValue("connection_name", this.connectionName));
/*     */     
/* 116 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 117 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node ruleNode) throws KettleException
/*     */   {
/* 122 */     super.loadXML(ruleNode);
/*     */     
/* 124 */     this.schemaName = XMLHandler.getTagValue(ruleNode, "schema_name");
/* 125 */     this.tableName = XMLHandler.getTagValue(ruleNode, "table_name");
/* 126 */     this.connectionName = XMLHandler.getTagValue(ruleNode, "connection_name");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSchemaName()
/*     */   {
/* 133 */     return this.schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 141 */     this.schemaName = schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTableName()
/*     */   {
/* 148 */     return this.tableName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTableName(String tableName)
/*     */   {
/* 156 */     this.tableName = tableName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionName()
/*     */   {
/* 163 */     return this.connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionName(String connectionName)
/*     */   {
/* 171 */     this.connectionName = connectionName;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\JobHasJobLogConfiguredImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */