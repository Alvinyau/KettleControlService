package org.pentaho.di.core.playlist;

import org.apache.commons.vfs.FileObject;
import org.pentaho.di.core.exception.KettleException;

public abstract interface FilePlayList
{
  public abstract boolean isProcessingNeeded(FileObject paramFileObject, long paramLong, String paramString)
    throws KettleException;
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\playlist\FilePlayList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */