/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.prefs.Preferences;
/*     */ import org.apache.commons.collections.Predicate;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringListPluginProperty
/*     */   extends KeyValue<List<String>>
/*     */   implements PluginProperty, Iterable<String>
/*     */ {
/*     */   private static final long serialVersionUID = 2003662016166396542L;
/*     */   public static final String VALUE_XML_TAG_NAME = "value";
/*     */   public static final char SEPARATOR_CHAR = ',';
/*     */   
/*     */   public StringListPluginProperty(String key)
/*     */   {
/*  63 */     super(key, new ArrayList());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String asString(List<String> list)
/*     */   {
/*  72 */     if (list == null) {
/*  73 */       return "";
/*     */     }
/*  75 */     return StringUtils.join(list, ',');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> fromString(String input)
/*     */   {
/*  84 */     List<String> result = new ArrayList();
/*  85 */     if (StringUtils.isBlank(input)) {
/*  86 */       return result;
/*     */     }
/*  88 */     for (String value : StringUtils.split(input, ',')) {
/*  89 */       result.add(value);
/*     */     }
/*  91 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendXml(StringBuilder builder)
/*     */   {
/* 100 */     if (!evaluate()) {
/* 101 */       return;
/*     */     }
/* 103 */     String value = asString((List)getValue());
/* 104 */     builder.append(XMLHandler.addTagValue(getKey(), value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate()
/*     */   {
/* 113 */     return CollectionPredicates.NOT_NULL_OR_EMPTY_COLLECTION.evaluate(getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadXml(Node node)
/*     */   {
/* 122 */     String stringValue = XMLHandler.getTagValue(node, getKey());
/* 123 */     List<String> values = fromString(stringValue);
/* 124 */     setValue(values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromPreferences(Preferences node)
/*     */   {
/* 133 */     String stringValue = node.get(getKey(), asString((List)getValue()));
/* 134 */     setValue(fromString(stringValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromRepositoryStep(Repository repository, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/* 144 */     String stringValue = repository.getStepAttributeString(stepId, getKey());
/* 145 */     setValue(fromString(stringValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToPreferences(Preferences node)
/*     */   {
/* 154 */     node.put(getKey(), asString((List)getValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToRepositoryStep(Repository repository, ObjectId transformationId, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/* 165 */     String stringValue = asString((List)getValue());
/* 166 */     repository.saveStepAttribute(transformationId, stepId, getKey(), stringValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValues(String... values)
/*     */   {
/* 174 */     if (getValue() == null) {
/* 175 */       setValue(new ArrayList());
/*     */     }
/* 177 */     for (String value : values) {
/* 178 */       ((List)getValue()).add(value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<String> iterator()
/*     */     throws IllegalStateException
/*     */   {
/* 188 */     assertValueNotNull();
/* 189 */     return ((List)getValue()).iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 196 */     assertValueNotNull();
/* 197 */     return ((List)getValue()).isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */     throws IllegalStateException
/*     */   {
/* 206 */     assertValueNotNull();
/* 207 */     return ((List)getValue()).size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void assertValueNotNull()
/*     */     throws IllegalStateException
/*     */   {
/* 217 */     if (getValue() == null) {
/* 218 */       throw new IllegalStateException("Value is null");
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\StringListPluginProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */