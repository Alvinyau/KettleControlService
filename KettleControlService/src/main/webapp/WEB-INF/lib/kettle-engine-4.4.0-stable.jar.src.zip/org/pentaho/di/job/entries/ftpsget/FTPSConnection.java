/*     */ package org.pentaho.di.job.entries.ftpsget;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.vfs.FileContent;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.ftp4che.FTPConnection;
/*     */ import org.ftp4che.FTPConnectionFactory;
/*     */ import org.ftp4che.event.FTPEvent;
/*     */ import org.ftp4che.event.FTPListener;
/*     */ import org.ftp4che.reply.Reply;
/*     */ import org.ftp4che.util.ftpfile.FTPFile;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FTPSConnection
/*     */   implements FTPListener
/*     */ {
/*  51 */   private static Class<?> PKG = JobEntryFTPSGet.class;
/*     */   
/*     */   public static final String HOME_FOLDER = "/";
/*     */   
/*     */   public static final String COMMAND_SUCCESSUL = "COMMAND SUCCESSFUL";
/*     */   
/*     */   public static final int CONNECTION_TYPE_FTP = 0;
/*     */   
/*     */   public static final int CONNECTION_TYPE_FTP_IMPLICIT_SSL = 1;
/*     */   public static final int CONNECTION_TYPE_FTP_AUTH_SSL = 2;
/*     */   public static final int CONNECTION_TYPE_FTP_IMPLICIT_SSL_WITH_CRYPTED = 3;
/*     */   public static final int CONNECTION_TYPE_FTP_AUTH_TLS = 4;
/*     */   public static final int CONNECTION_TYPE_FTP_IMPLICIT_TLS = 5;
/*     */   public static final int CONNECTION_TYPE_FTP_IMPLICIT_TLS_WITH_CRYPTED = 6;
/*  65 */   public static final String[] connection_type_Desc = { BaseMessages.getString(PKG, "JobFTPS.ConnectionType.FTP", new String[0]), BaseMessages.getString(PKG, "JobFTPS.ConnectionType.ImplicitSSL", new String[0]), BaseMessages.getString(PKG, "JobFTPS.ConnectionType.AuthSSL", new String[0]), BaseMessages.getString(PKG, "JobFTPS.ConnectionType.ImplicitSSLCrypted", new String[0]), BaseMessages.getString(PKG, "JobFTPS.ConnectionType.AuthTLS", new String[0]), BaseMessages.getString(PKG, "JobFTPS.ConnectionType.ImplicitTLS", new String[0]), BaseMessages.getString(PKG, "JobFTPS.ConnectionType.ImplicitTLSCrypted", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   public static final String[] connection_type_Code = { "FTP_CONNECTION", "IMPLICIT_SSL_FTP_CONNECTION", "AUTH_SSL_FTP_CONNECTION", "IMPLICIT_SSL_WITH_CRYPTED_DATA_FTP_CONNECTION", "AUTH_TLS_FTP_CONNECTION", "IMPLICIT_TLS_FTP_CONNECTION", "IMPLICIT_TLS_WITH_CRYPTED_DATA_FTP_CONNECTION" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   private FTPConnection connection = null;
/*  86 */   private ArrayList<String> replies = new ArrayList();
/*     */   
/*     */   private String hostName;
/*     */   private int portNumber;
/*     */   private String userName;
/*     */   private String passWord;
/*     */   private int connectionType;
/*     */   private int timeOut;
/*     */   private boolean passiveMode;
/*     */   private String proxyHost;
/*     */   private String proxyUser;
/*     */   private String proxyPassword;
/*     */   private int proxyPort;
/*     */   
/*     */   public FTPSConnection(int connectionType, String hostname, int port, String username, String password)
/*     */   {
/* 102 */     this.hostName = hostname;
/* 103 */     this.portNumber = port;
/* 104 */     this.userName = username;
/* 105 */     this.passWord = password;
/* 106 */     this.connectionType = connectionType;
/* 107 */     this.passiveMode = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyHost(String proxyhost)
/*     */   {
/* 118 */     this.proxyHost = proxyhost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyPort(int proxyport)
/*     */   {
/* 129 */     this.proxyPort = proxyport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyUser(String username)
/*     */   {
/* 139 */     this.proxyUser = username;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyPassword(String password)
/*     */   {
/* 149 */     this.proxyPassword = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 159 */       this.connection = FTPConnectionFactory.getInstance(getProperties(this.hostName, this.portNumber, this.userName, this.passWord, this.connectionType, this.timeOut, this.passiveMode));
/*     */       
/* 161 */       this.connection.addFTPStatusListener(this);
/* 162 */       this.connection.connect();
/*     */     } catch (Exception e) {
/* 164 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.Connecting", new String[] { this.hostName }), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Properties getProperties(String hostname, int port, String username, String password, int connectionType, int timeout, boolean passiveMode) {
/* 169 */     Properties pt = new Properties();
/* 170 */     pt.setProperty("connection.host", hostname);
/* 171 */     pt.setProperty("connection.port", String.valueOf(port));
/* 172 */     pt.setProperty("user.login", username);
/* 173 */     pt.setProperty("user.password", password);
/* 174 */     pt.setProperty("connection.type", getConnectionType(connectionType));
/* 175 */     pt.setProperty("connection.timeout", String.valueOf(timeout));
/* 176 */     pt.setProperty("connection.passive", String.valueOf(passiveMode));
/*     */     
/* 178 */     if (this.proxyHost != null) pt.setProperty("proxy.host", this.proxyHost);
/* 179 */     if (this.proxyPort != 0) pt.setProperty("proxy.port", String.valueOf(this.proxyPort));
/* 180 */     if (this.proxyUser != null) pt.setProperty("proxy.user", this.proxyUser);
/* 181 */     if (this.proxyPassword != null) { pt.setProperty("proxy.pass", this.proxyPassword);
/*     */     }
/* 183 */     return pt;
/*     */   }
/*     */   
/*     */   public static String getConnectionTypeDesc(String tt) {
/* 187 */     if (Const.isEmpty(tt)) return connection_type_Desc[0];
/* 188 */     if (tt.equalsIgnoreCase(connection_type_Code[1])) {
/* 189 */       return connection_type_Desc[1];
/*     */     }
/* 191 */     return connection_type_Desc[0];
/*     */   }
/*     */   
/* 194 */   public static String getConnectionTypeCode(String tt) { if (tt == null) return connection_type_Code[0];
/* 195 */     if (tt.equals(connection_type_Desc[1])) {
/* 196 */       return connection_type_Code[1];
/*     */     }
/* 198 */     return connection_type_Code[0];
/*     */   }
/*     */   
/* 201 */   public static String getConnectionTypeDesc(int i) { if ((i < 0) || (i >= connection_type_Desc.length))
/* 202 */       return connection_type_Desc[0];
/* 203 */     return connection_type_Desc[i];
/*     */   }
/*     */   
/* 206 */   public static String getConnectionType(int i) { return connection_type_Code[i]; }
/*     */   
/*     */   public static int getConnectionTypeByDesc(String tt) {
/* 209 */     if (tt == null) { return 0;
/*     */     }
/* 211 */     for (int i = 0; i < connection_type_Desc.length; i++) {
/* 212 */       if (connection_type_Desc[i].equalsIgnoreCase(tt)) {
/* 213 */         return i;
/*     */       }
/*     */     }
/* 216 */     return 0;
/*     */   }
/*     */   
/* 219 */   public static int getConnectionTypeByCode(String tt) { if (tt == null) {
/* 220 */       return 0;
/*     */     }
/* 222 */     for (int i = 0; i < connection_type_Code.length; i++) {
/* 223 */       if (connection_type_Code[i].equalsIgnoreCase(tt))
/* 224 */         return i;
/*     */     }
/* 226 */     return 0;
/*     */   }
/*     */   
/* 229 */   public static String getConnectionTypeCode(int i) { if ((i < 0) || (i >= connection_type_Code.length))
/* 230 */       return connection_type_Code[0];
/* 231 */     return connection_type_Code[i];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBinaryMode(boolean type)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 245 */       this.connection.setTransferType(true);
/*     */     } catch (Exception e) {
/* 247 */       throw new KettleException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassiveMode(boolean passivemode)
/*     */   {
/* 259 */     this.passiveMode = passivemode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPassiveMode()
/*     */   {
/* 270 */     return this.passiveMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeOut(int timeout)
/*     */   {
/* 280 */     this.timeOut = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeOut()
/*     */   {
/* 290 */     return this.timeOut;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getReplies() {
/* 294 */     return this.replies;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionType(int connectiontype)
/*     */   {
/* 305 */     this.connectionType = connectiontype;
/*     */   }
/*     */   
/*     */   public int getConnectionType() {
/* 309 */     return this.connectionType;
/*     */   }
/*     */   
/*     */   public void connectionStatusChanged(FTPEvent arg0) {}
/*     */   
/*     */   public void replyMessageArrived(FTPEvent event) {
/* 315 */     this.replies = new ArrayList();
/* 316 */     for (String e : event.getReply().getLines()) {
/* 317 */       if (!e.trim().equals("")) {
/* 318 */         e = e.substring(3).trim().replace("\n", "");
/* 319 */         if (!e.toUpperCase().contains("COMMAND SUCCESSFUL")) {
/* 320 */           e = e.substring(1).trim();
/* 321 */           this.replies.add(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeDirectory(String directory)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 336 */       this.connection.changeDirectory(directory);
/*     */     } catch (Exception f) {
/* 338 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.ChangingFolder", new String[] { directory }), f);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createDirectory(String directory)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 351 */       this.connection.makeDirectory(directory);
/*     */     } catch (Exception f) {
/* 353 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.CreationFolder", new String[] { directory }), f);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<FTPFile> getFileList(String folder) throws KettleException {
/*     */     try {
/* 359 */       if (this.connection != null) {
/* 360 */         return this.connection.getDirectoryListing(folder);
/*     */       }
/*     */       
/* 363 */       return null;
/*     */     }
/*     */     catch (Exception e) {
/* 366 */       throw new KettleException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void downloadFile(FTPFile file, String localFilename)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 381 */       File localFile = new File(localFilename);
/* 382 */       writeToFile(this.connection.downloadStream(file), localFile);
/*     */     } catch (Exception e) {
/* 384 */       throw new KettleException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeToFile(InputStream is, File file) throws KettleException {
/* 389 */     try { DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
/*     */       int c;
/* 391 */       while ((c = is.read()) != -1) {
/* 392 */         out.writeByte(c);
/*     */       }
/* 394 */       is.close();
/* 395 */       out.close();
/*     */     } catch (IOException e) {
/* 397 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.WritingToFile", new String[] { file.getName() }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void uploadFile(String localFileName, String shortFileName)
/*     */     throws KettleException
/*     */   {
/* 412 */     FileObject file = null;
/*     */     try
/*     */     {
/* 415 */       file = KettleVFS.getFileObject(localFileName);
/* 416 */       this.connection.uploadStream(file.getContent().getInputStream(), new FTPFile(new File(shortFileName)));
/*     */     } catch (Exception e) {
/* 418 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.UuploadingFile", new String[] { localFileName }), e);
/*     */     } finally {
/* 420 */       if (file != null) {
/*     */         try {
/* 422 */           file.close();
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFileNames()
/*     */     throws KettleException
/*     */   {
/* 435 */     ArrayList<String> list = null;
/*     */     try {
/* 437 */       List<FTPFile> fileList = getFileList(getWorkingDirectory());
/* 438 */       list = new ArrayList();
/* 439 */       Iterator<FTPFile> it = fileList.iterator();
/* 440 */       while (it.hasNext()) {
/* 441 */         FTPFile file = (FTPFile)it.next();
/* 442 */         if (!file.isDirectory()) {
/* 443 */           list.add(file.getName());
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 447 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.RetrievingFilenames", new String[0]), e);
/*     */     }
/* 449 */     return list == null ? null : (String[])list.toArray(new String[list.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteFile(FTPFile file)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 461 */       this.connection.deleteFile(file);
/*     */     } catch (Exception e) {
/* 463 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.DeletingFile", new String[] { file.getName() }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteFile(String filename)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 476 */       this.connection.deleteFile(new FTPFile(getWorkingDirectory(), filename));
/*     */     } catch (Exception e) {
/* 478 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.DeletingFile", new String[] { filename }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void moveToFolder(FTPFile fromFile, String targetFoldername)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 493 */       this.connection.renameFile(fromFile, new FTPFile(targetFoldername, fromFile.getName()));
/*     */     } catch (Exception e) {
/* 495 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPS.Error.MovingFileToFolder", new String[] { fromFile.getName(), targetFoldername }), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectoryExists(String directory)
/*     */   {
/* 508 */     String currectDirectory = null;
/* 509 */     boolean retval = false;
/*     */     try
/*     */     {
/* 512 */       currectDirectory = this.connection.getWorkDirectory();
/*     */       
/* 514 */       this.connection.changeDirectory(directory);
/* 515 */       retval = true;
/*     */     }
/*     */     catch (Exception e) {}finally
/*     */     {
/* 519 */       if (currectDirectory != null) {
/*     */         try {
/* 521 */           this.connection.changeDirectory(currectDirectory);
/*     */         } catch (Exception e) {}
/*     */       }
/*     */     }
/* 525 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFileExists(String filename)
/*     */   {
/* 539 */     boolean retval = false;
/*     */     try {
/* 541 */       FTPFile file = new FTPFile(new File(filename));
/*     */       
/* 543 */       this.connection.getModificationTime(file);
/* 544 */       retval = true;
/*     */     } catch (Exception e) {}
/* 546 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWorkingDirectory()
/*     */     throws Exception
/*     */   {
/* 558 */     return this.connection.getWorkDirectory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 567 */     if (this.connection != null) this.connection.disconnect();
/* 568 */     if (this.replies != null) this.replies.clear();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftpsget\FTPSConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */