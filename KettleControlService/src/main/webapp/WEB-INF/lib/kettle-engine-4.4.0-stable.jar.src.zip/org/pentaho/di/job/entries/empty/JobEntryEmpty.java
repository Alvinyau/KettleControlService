/*    */ package org.pentaho.di.job.entries.empty;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.pentaho.di.cluster.SlaveServer;
/*    */ import org.pentaho.di.core.CheckResultInterface;
/*    */ import org.pentaho.di.core.Result;
/*    */ import org.pentaho.di.core.database.DatabaseMeta;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.exception.KettleXMLException;
/*    */ import org.pentaho.di.job.JobMeta;
/*    */ import org.pentaho.di.job.entry.JobEntryBase;
/*    */ import org.pentaho.di.job.entry.JobEntryInterface;
/*    */ import org.pentaho.di.repository.Repository;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobEntryEmpty
/*    */   extends JobEntryBase
/*    */   implements JobEntryInterface
/*    */ {
/*    */   public Result execute(Result prev_result, int nr)
/*    */     throws KettleException
/*    */   {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*    */     throws KettleXMLException
/*    */   {}
/*    */   
/*    */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {}
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\empty\JobEntryEmpty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */