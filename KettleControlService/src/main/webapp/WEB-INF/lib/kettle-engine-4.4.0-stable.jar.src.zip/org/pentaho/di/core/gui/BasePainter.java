/*     */ package org.pentaho.di.core.gui;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.NotePadMeta;
/*     */ import org.pentaho.di.trans.step.errorhandling.StreamIcon;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasePainter
/*     */ {
/*  40 */   public final double theta = Math.toRadians(11.0D);
/*     */   
/*     */   protected static final int MINI_ICON_SIZE = 16;
/*     */   
/*     */   protected static final int MINI_ICON_MARGIN = 5;
/*     */   
/*     */   protected static final int MINI_ICON_TRIANGLE_BASE = 10;
/*     */   
/*     */   protected static final int MINI_ICON_DISTANCE = 7;
/*     */   
/*     */   protected static final int MINI_ICON_SKEW = 0;
/*     */   
/*     */   protected Point area;
/*     */   
/*     */   protected ScrollBarInterface hori;
/*     */   
/*     */   protected ScrollBarInterface vert;
/*     */   
/*     */   protected List<AreaOwner> areaOwners;
/*     */   
/*     */   protected Point offset;
/*     */   
/*     */   protected Point drop_candidate;
/*     */   
/*     */   protected int iconsize;
/*     */   
/*     */   protected int gridSize;
/*     */   protected Rectangle selrect;
/*     */   protected int linewidth;
/*     */   protected float magnification;
/*     */   protected float translationX;
/*     */   protected float translationY;
/*     */   protected boolean shadow;
/*     */   protected Object subject;
/*     */   protected GCInterface gc;
/*     */   protected int shadowSize;
/*     */   private String noteFontName;
/*     */   private int noteFontHeight;
/*     */   
/*     */   public BasePainter(GCInterface gc, Object subject, Point area, ScrollBarInterface hori, ScrollBarInterface vert, Point drop_candidate, Rectangle selrect, List<AreaOwner> areaOwners, int iconsize, int linewidth, int gridsize, int shadowSize, boolean antiAliasing, String noteFontName, int noteFontHeight)
/*     */   {
/*  81 */     this.gc = gc;
/*  82 */     this.subject = subject;
/*  83 */     this.area = area;
/*  84 */     this.hori = hori;
/*  85 */     this.vert = vert;
/*     */     
/*  87 */     this.selrect = selrect;
/*  88 */     this.drop_candidate = drop_candidate;
/*     */     
/*  90 */     this.areaOwners = areaOwners;
/*  91 */     areaOwners.clear();
/*     */     
/*     */ 
/*  94 */     this.iconsize = iconsize;
/*  95 */     this.linewidth = linewidth;
/*  96 */     this.gridSize = gridsize;
/*     */     
/*  98 */     this.shadowSize = shadowSize;
/*  99 */     this.shadow = (shadowSize > 0);
/*     */     
/* 101 */     this.magnification = 1.0F;
/*     */     
/* 103 */     gc.setAntialias(antiAliasing);
/*     */     
/* 105 */     this.noteFontName = noteFontName;
/* 106 */     this.noteFontHeight = noteFontHeight;
/*     */   }
/*     */   
/*     */   public static GCInterface.EImage getStreamIconImage(StreamIcon streamIcon) {
/* 110 */     switch (streamIcon) {
/* 111 */     case TRUE:  return GCInterface.EImage.TRUE;
/* 112 */     case FALSE:  return GCInterface.EImage.FALSE;
/* 113 */     case ERROR:  return GCInterface.EImage.ERROR;
/* 114 */     case INFO:  return GCInterface.EImage.INFO;
/* 115 */     case TARGET:  return GCInterface.EImage.TARGET;
/* 116 */     case INPUT:  return GCInterface.EImage.INPUT;
/* 117 */     case OUTPUT:  return GCInterface.EImage.OUTPUT; }
/* 118 */     return GCInterface.EImage.ARROW;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawNote(NotePadMeta notePadMeta)
/*     */   {
/* 124 */     if (notePadMeta.isSelected()) {
/* 125 */       this.gc.setLineWidth(2);
/*     */     } else {
/* 127 */       this.gc.setLineWidth(1);
/*     */     }
/*     */     Point ext;
/*     */     Point ext;
/* 131 */     if (Const.isEmpty(notePadMeta.getNote()))
/*     */     {
/* 133 */       ext = new Point(10, 10);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 138 */       this.gc.setFont(Const.NVL(notePadMeta.getFontName(), this.noteFontName), notePadMeta.getFontSize() == -1 ? this.noteFontHeight : notePadMeta.getFontSize(), notePadMeta.isFontBold(), notePadMeta.isFontItalic());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */       ext = this.gc.textExtent(notePadMeta.getNote());
/*     */     }
/* 146 */     Point p = new Point(ext.x, ext.y);
/* 147 */     Point loc = notePadMeta.getLocation();
/* 148 */     Point note = real2screen(loc.x, loc.y);
/* 149 */     int margin = 5;
/* 150 */     p.x += 2 * margin;
/* 151 */     p.y += 2 * margin;
/* 152 */     int width = notePadMeta.width;
/* 153 */     int height = notePadMeta.height;
/* 154 */     if (p.x > width) width = p.x;
/* 155 */     if (p.y > height) { height = p.y;
/*     */     }
/* 157 */     int[] noteshape = { note.x, note.y, note.x + width + 2 * margin, note.y, note.x + width + 2 * margin, note.y + height, note.x + width, note.y + height + 2 * margin, note.x + width, note.y + height, note.x + width + 2 * margin, note.y + height, note.x + width, note.y + height + 2 * margin, note.x, note.y + height + 2 * margin };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     if (notePadMeta.isDrawShadow())
/*     */     {
/* 170 */       int s = this.shadowSize;
/* 171 */       int[] shadowa = { note.x + s, note.y + s, note.x + width + 2 * margin + s, note.y + s, note.x + width + 2 * margin + s, note.y + height + s, note.x + width + s, note.y + height + 2 * margin + s, note.x + s, note.y + height + 2 * margin + s };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */       this.gc.setBackground(GCInterface.EColor.LIGHTGRAY);
/* 178 */       this.gc.fillPolygon(shadowa);
/*     */     }
/* 180 */     this.gc.setBackground(notePadMeta.getBackGroundColorRed(), notePadMeta.getBackGroundColorGreen(), notePadMeta.getBackGroundColorBlue());
/* 181 */     this.gc.setForeground(notePadMeta.getBorderColorRed(), notePadMeta.getBorderColorGreen(), notePadMeta.getBorderColorBlue());
/*     */     
/* 183 */     this.gc.fillPolygon(noteshape);
/* 184 */     this.gc.drawPolygon(noteshape);
/*     */     
/* 186 */     if (!Const.isEmpty(notePadMeta.getNote()))
/*     */     {
/* 188 */       this.gc.setForeground(notePadMeta.getFontColorRed(), notePadMeta.getFontColorGreen(), notePadMeta.getFontColorBlue());
/* 189 */       this.gc.drawText(notePadMeta.getNote(), note.x + margin, note.y + margin, true);
/*     */     }
/*     */     
/* 192 */     notePadMeta.width = width;
/* 193 */     notePadMeta.height = height;
/*     */     
/* 195 */     if (notePadMeta.isSelected()) this.gc.setLineWidth(1); else { this.gc.setLineWidth(2);
/*     */     }
/*     */     
/*     */ 
/* 199 */     if (!this.shadow) {
/* 200 */       this.areaOwners.add(new AreaOwner(AreaOwner.AreaType.NOTE, note.x, note.y, width, height, this.offset, this.subject, notePadMeta));
/*     */     }
/*     */   }
/*     */   
/*     */   protected Point real2screen(int x, int y)
/*     */   {
/* 206 */     Point screen = new Point(x + this.offset.x, y + this.offset.y);
/*     */     
/* 208 */     return screen;
/*     */   }
/*     */   
/*     */   protected Point getThumb(Point area, Point transMax)
/*     */   {
/* 213 */     Point resizedMax = magnifyPoint(transMax);
/*     */     
/* 215 */     Point thumb = new Point(0, 0);
/* 216 */     if (resizedMax.x <= area.x) {
/* 217 */       thumb.x = 100;
/*     */     } else {
/* 219 */       thumb.x = ((int)Math.floor(100.0D * area.x / resizedMax.x));
/*     */     }
/* 221 */     if (resizedMax.y <= area.y) {
/* 222 */       thumb.y = 100;
/*     */     } else {
/* 224 */       thumb.y = ((int)Math.floor(100.0D * area.y / resizedMax.y));
/*     */     }
/* 226 */     return thumb;
/*     */   }
/*     */   
/*     */   protected Point magnifyPoint(Point p) {
/* 230 */     return new Point(Math.round(p.x * this.magnification), Math.round(p.y * this.magnification));
/*     */   }
/*     */   
/*     */   protected Point getOffset(Point thumb, Point area)
/*     */   {
/* 235 */     Point p = new Point(0, 0);
/*     */     
/* 237 */     if ((this.hori == null) || (this.vert == null)) { return p;
/*     */     }
/* 239 */     Point sel = new Point(this.hori.getSelection(), this.vert.getSelection());
/*     */     
/* 241 */     if ((thumb.x == 0) || (thumb.y == 0)) { return p;
/*     */     }
/* 243 */     p.x = Math.round(-sel.x * area.x / thumb.x / this.magnification);
/* 244 */     p.y = Math.round(-sel.y * area.y / thumb.y / this.magnification);
/*     */     
/* 246 */     return p;
/*     */   }
/*     */   
/*     */   protected void drawRect(Rectangle rect)
/*     */   {
/* 251 */     if (rect == null) return;
/* 252 */     this.gc.setLineStyle(GCInterface.ELineStyle.DASHDOT);
/* 253 */     this.gc.setLineWidth(this.linewidth);
/* 254 */     this.gc.setForeground(GCInterface.EColor.GRAY);
/*     */     
/* 256 */     Point s = real2screen(rect.x, rect.y);
/* 257 */     if (rect.width < 0) {
/* 258 */       s.x += rect.width;
/*     */     }
/* 260 */     if (rect.height < 0) {
/* 261 */       s.y += rect.height;
/*     */     }
/* 263 */     this.gc.drawRectangle(s.x, s.y, Math.abs(rect.width), Math.abs(rect.height));
/* 264 */     this.gc.setLineStyle(GCInterface.ELineStyle.SOLID);
/*     */   }
/*     */   
/*     */   protected void drawGrid() {
/* 268 */     Point bounds = this.gc.getDeviceBounds();
/* 269 */     for (int x = 0; x < bounds.x; x += this.gridSize) {
/* 270 */       for (int y = 0; y < bounds.y; y += this.gridSize) {
/* 271 */         this.gc.drawPoint(x + this.offset.x % this.gridSize, y + this.offset.y % this.gridSize);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected int calcArrowLength()
/*     */   {
/* 278 */     return 19 + (this.linewidth - 1) * 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getMagnification()
/*     */   {
/* 286 */     return this.magnification;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMagnification(float magnification)
/*     */   {
/* 293 */     this.magnification = magnification;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\BasePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */