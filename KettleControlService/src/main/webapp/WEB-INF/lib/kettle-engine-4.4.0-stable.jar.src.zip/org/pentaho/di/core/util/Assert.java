/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.Predicate;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Assert
/*     */ {
/*     */   private static final int INPUT_MAX_WIDTH = 30;
/*     */   
/*     */   public static void assertTrue(Object input, Predicate predicate)
/*     */     throws IllegalArgumentException
/*     */   {
/*  57 */     if (predicate.evaluate(input)) {
/*  58 */       return;
/*     */     }
/*  60 */     StringBuilder builder = new StringBuilder();
/*  61 */     builder.append("Predicate rejected input [predicate=");
/*  62 */     builder.append(predicate);
/*  63 */     builder.append(", input=");
/*  64 */     builder.append(StringUtils.abbreviate(String.valueOf(input), 30));
/*  65 */     builder.append("]");
/*  66 */     throw new IllegalArgumentException(builder.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertTrue(boolean bool)
/*     */     throws IllegalArgumentException
/*     */   {
/*  76 */     assertTrue(bool, "Value cannot be false", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertTrue(boolean bool, String message, Object... args)
/*     */     throws IllegalArgumentException
/*     */   {
/*  91 */     if (bool) {
/*  92 */       return;
/*     */     }
/*  94 */     if ((args != null) && (args.length > 0)) {
/*  95 */       throw new IllegalArgumentException(MessageFormat.format(message, args));
/*     */     }
/*  97 */     throw new IllegalArgumentException(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(boolean bool)
/*     */     throws IllegalArgumentException
/*     */   {
/* 107 */     assertFalse(bool, "Value cannot be true", new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(boolean bool, String message, Object... args)
/*     */     throws IllegalArgumentException
/*     */   {
/* 122 */     if (!bool) {
/* 123 */       return;
/*     */     }
/* 125 */     if ((args != null) && (args.length > 0)) {
/* 126 */       throw new IllegalArgumentException(MessageFormat.format(message, args));
/*     */     }
/* 128 */     throw new IllegalArgumentException(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(Object input, Predicate predicate)
/*     */     throws IllegalArgumentException
/*     */   {
/* 140 */     if (!predicate.evaluate(input)) {
/* 141 */       return;
/*     */     }
/* 143 */     StringBuilder builder = new StringBuilder();
/* 144 */     builder.append("Predicate didn't rejected input [predicate=");
/* 145 */     builder.append(predicate);
/* 146 */     builder.append(", input=");
/* 147 */     builder.append(StringUtils.abbreviate(String.valueOf(input), 30));
/* 148 */     builder.append("]");
/* 149 */     throw new IllegalArgumentException(builder.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNullOrEmpty(Collection<?> collection)
/*     */     throws IllegalArgumentException
/*     */   {
/* 159 */     if ((collection == null) || (collection.isEmpty())) {
/* 160 */       throw new IllegalArgumentException("Collection cannot be null or empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNullOrEmpty(Collection<?> collection, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 174 */     if ((collection == null) || (collection.isEmpty())) {
/* 175 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNullOrEmpty(Object[] array)
/*     */     throws IllegalArgumentException
/*     */   {
/* 186 */     if ((array == null) || (array.length == 0)) {
/* 187 */       throw new IllegalArgumentException("Array cannot be null or empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNullOrEmpty(Object[] array, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 201 */     if ((array == null) || (array.length == 0)) {
/* 202 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNullOrEmpty(Map<?, ?> map)
/*     */     throws IllegalArgumentException
/*     */   {
/* 213 */     if ((map == null) || (map.isEmpty())) {
/* 214 */       throw new IllegalArgumentException("Map cannot be null or empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNullOrEmpty(Map<?, ?> map, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 227 */     if ((map == null) || (map.isEmpty())) {
/* 228 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEmpty(String input)
/*     */     throws IllegalArgumentException
/*     */   {
/* 239 */     if (StringUtils.isEmpty(input)) {
/* 240 */       throw new IllegalArgumentException("Input cannot be null or empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEmpty(String input, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 253 */     if (StringUtils.isEmpty(input)) {
/* 254 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotBlank(String input)
/*     */     throws IllegalArgumentException
/*     */   {
/* 265 */     if (StringUtils.isBlank(input)) {
/* 266 */       throw new IllegalArgumentException("Input cannot be null or empty");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotBlank(String input, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 279 */     if (StringUtils.isBlank(input)) {
/* 280 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(Object input)
/*     */     throws IllegalArgumentException
/*     */   {
/* 291 */     if (input == null) {
/* 292 */       throw new IllegalArgumentException("Input cannot be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(Object input, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 305 */     if (input == null) {
/* 306 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNull(Object input)
/*     */     throws IllegalArgumentException
/*     */   {
/* 317 */     if (input != null) {
/* 318 */       throw new IllegalArgumentException("Input must be null");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNull(Object input, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 331 */     if (input != null) {
/* 332 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertGreaterZero(Integer value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 343 */     assertGreaterZero(value, "Value must be greater than 0");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertGreaterZero(Double value)
/*     */     throws IllegalArgumentException
/*     */   {
/* 353 */     assertGreaterZero(value, "Value must be greater than 0");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertGreaterZero(Double value, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 365 */     if ((value == null) || (value.doubleValue() <= 0.0D)) {
/* 366 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertGreaterZero(Integer value, String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 379 */     if ((value == null) || (value.intValue() <= 0)) {
/* 380 */       throw new IllegalArgumentException(message);
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\Assert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */