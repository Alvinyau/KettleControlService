/*    */ package org.pentaho.di.core.plugins;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Map;
/*    */ import org.pentaho.di.core.annotations.KettleLifecyclePlugin;
/*    */ import org.pentaho.di.core.exception.KettlePluginException;
/*    */ import org.pentaho.di.core.lifecycle.KettleLifecycleListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ @PluginMainClassType(KettleLifecycleListener.class)
/*    */ @PluginAnnotationType(KettleLifecyclePlugin.class)
/*    */ public class KettleLifecyclePluginType
/*    */   extends BasePluginType
/*    */   implements PluginTypeInterface
/*    */ {
/*    */   private static KettleLifecyclePluginType pluginType;
/*    */   
/*    */   private KettleLifecyclePluginType()
/*    */   {
/* 21 */     super(KettleLifecyclePlugin.class, "KETTLE LIFECYCLE LISTENERS", "Kettle Lifecycle Listener Plugin Type");
/*    */     
/*    */ 
/* 24 */     populateFolders(null);
/*    */   }
/*    */   
/*    */   public static synchronized KettleLifecyclePluginType getInstance() {
/* 28 */     if (pluginType == null) {
/* 29 */       pluginType = new KettleLifecyclePluginType();
/*    */     }
/* 31 */     return pluginType;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void registerNatives()
/*    */     throws KettlePluginException
/*    */   {}
/*    */   
/*    */ 
/*    */   protected void registerXmlPlugins()
/*    */     throws KettlePluginException
/*    */   {}
/*    */   
/*    */   protected String extractID(Annotation annotation)
/*    */   {
/* 46 */     return ((KettleLifecyclePlugin)annotation).id();
/*    */   }
/*    */   
/*    */   protected String extractName(Annotation annotation)
/*    */   {
/* 51 */     return ((KettleLifecyclePlugin)annotation).name();
/*    */   }
/*    */   
/*    */   protected String extractDesc(Annotation annotation)
/*    */   {
/* 56 */     return "";
/*    */   }
/*    */   
/*    */ 
/*    */   protected String extractCategory(Annotation annotation)
/*    */   {
/* 62 */     return "";
/*    */   }
/*    */   
/*    */ 
/*    */   protected String extractImageFile(Annotation annotation)
/*    */   {
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*    */   {
/* 73 */     return ((KettleLifecyclePlugin)annotation).isSeparateClassLoaderNeeded();
/*    */   }
/*    */   
/*    */ 
/*    */   protected String extractI18nPackageName(Annotation annotation)
/*    */   {
/* 79 */     return null;
/*    */   }
/*    */   
/*    */   protected void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation)
/*    */   {
/* 84 */     classMap.put(KettleLifecyclePlugin.class, clazz.getName());
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\KettleLifecyclePluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */