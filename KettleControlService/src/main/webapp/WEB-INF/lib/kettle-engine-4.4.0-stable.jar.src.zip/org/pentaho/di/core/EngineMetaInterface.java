package org.pentaho.di.core;

import java.util.Date;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.repository.ObjectId;
import org.pentaho.di.repository.RepositoryDirectoryInterface;
import org.pentaho.di.repository.RepositoryElementInterface;

public abstract interface EngineMetaInterface
  extends RepositoryElementInterface
{
  public abstract void setFilename(String paramString);
  
  public abstract String getName();
  
  public abstract void nameFromFilename();
  
  public abstract void clearChanged();
  
  public abstract String getXML()
    throws KettleException;
  
  public abstract String getFileType();
  
  public abstract String[] getFilterNames();
  
  public abstract String[] getFilterExtensions();
  
  public abstract String getDefaultExtension();
  
  public abstract void setObjectId(ObjectId paramObjectId);
  
  public abstract Date getCreatedDate();
  
  public abstract void setCreatedDate(Date paramDate);
  
  public abstract boolean canSave();
  
  public abstract String getCreatedUser();
  
  public abstract void setCreatedUser(String paramString);
  
  public abstract Date getModifiedDate();
  
  public abstract void setModifiedDate(Date paramDate);
  
  public abstract void setModifiedUser(String paramString);
  
  public abstract String getModifiedUser();
  
  public abstract RepositoryDirectoryInterface getRepositoryDirectory();
  
  public abstract String getFilename();
  
  public abstract void saveSharedObjects()
    throws KettleException;
  
  public abstract void setInternalKettleVariables();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\EngineMetaInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */