/*     */ package org.pentaho.di.job.entries.copymoveresultfilenames;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileUtil;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryCopyMoveResultFilenames
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  74 */   private static Class<?> PKG = JobEntryCopyMoveResultFilenames.class;
/*     */   
/*     */   private String foldername;
/*     */   private boolean specifywildcard;
/*     */   private String wildcard;
/*     */   private String wildcardexclude;
/*     */   private String destination_folder;
/*     */   private String nr_errors_less_than;
/*  82 */   public String SUCCESS_IF_AT_LEAST_X_FILES_UN_ZIPPED = "success_when_at_least";
/*  83 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*  84 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*     */   
/*     */   private String success_condition;
/*     */   
/*     */   private Pattern wildcardPattern;
/*     */   
/*     */   private Pattern wildcardExcludePattern;
/*     */   
/*     */   private boolean add_date;
/*     */   
/*     */   private boolean add_time;
/*     */   private boolean SpecifyFormat;
/*     */   private String date_time_format;
/*     */   private boolean AddDateBeforeExtension;
/*     */   private String action;
/*     */   private boolean OverwriteFile;
/*     */   private boolean CreateDestinationFolder;
/*     */   boolean RemovedSourceFilename;
/*     */   boolean AddDestinationFilename;
/* 103 */   int NrErrors = 0;
/* 104 */   private int NrSuccess = 0;
/* 105 */   boolean successConditionBroken = false;
/* 106 */   boolean successConditionBrokenExit = false;
/* 107 */   int limitFiles = 0;
/*     */   
/*     */   public JobEntryCopyMoveResultFilenames(String n)
/*     */   {
/* 111 */     super(n, "");
/* 112 */     this.RemovedSourceFilename = true;
/* 113 */     this.AddDestinationFilename = true;
/* 114 */     this.CreateDestinationFolder = false;
/* 115 */     this.foldername = null;
/* 116 */     this.wildcardexclude = null;
/* 117 */     this.wildcard = null;
/* 118 */     this.specifywildcard = false;
/*     */     
/* 120 */     this.OverwriteFile = false;
/* 121 */     this.add_date = false;
/* 122 */     this.add_time = false;
/* 123 */     this.SpecifyFormat = false;
/* 124 */     this.date_time_format = null;
/* 125 */     this.AddDateBeforeExtension = false;
/* 126 */     this.destination_folder = null;
/* 127 */     this.nr_errors_less_than = "10";
/*     */     
/* 129 */     this.action = "copy";
/* 130 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/* 131 */     setID(-1L);
/*     */   }
/*     */   
/*     */ 
/*     */   public JobEntryCopyMoveResultFilenames()
/*     */   {
/* 137 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 142 */     JobEntryCopyMoveResultFilenames je = (JobEntryCopyMoveResultFilenames)super.clone();
/* 143 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 148 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 150 */     retval.append(super.getXML());
/* 151 */     retval.append("      ").append(XMLHandler.addTagValue("foldername", this.foldername));
/* 152 */     retval.append("      ").append(XMLHandler.addTagValue("specify_wildcard", this.specifywildcard));
/* 153 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/* 154 */     retval.append("      ").append(XMLHandler.addTagValue("wildcardexclude", this.wildcardexclude));
/* 155 */     retval.append("      ").append(XMLHandler.addTagValue("destination_folder", this.destination_folder));
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("nr_errors_less_than", this.nr_errors_less_than));
/* 157 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/* 158 */     retval.append("      ").append(XMLHandler.addTagValue("add_date", this.add_date));
/* 159 */     retval.append("      ").append(XMLHandler.addTagValue("add_time", this.add_time));
/* 160 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyFormat", this.SpecifyFormat));
/* 161 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_format", this.date_time_format));
/* 162 */     retval.append("      ").append(XMLHandler.addTagValue("action", this.action));
/* 163 */     retval.append("      ").append(XMLHandler.addTagValue("AddDateBeforeExtension", this.AddDateBeforeExtension));
/* 164 */     retval.append("      ").append(XMLHandler.addTagValue("OverwriteFile", this.OverwriteFile));
/* 165 */     retval.append("      ").append(XMLHandler.addTagValue("CreateDestinationFolder", this.CreateDestinationFolder));
/* 166 */     retval.append("      ").append(XMLHandler.addTagValue("RemovedSourceFilename", this.RemovedSourceFilename));
/* 167 */     retval.append("      ").append(XMLHandler.addTagValue("AddDestinationFilename", this.AddDestinationFilename));
/*     */     
/*     */ 
/*     */ 
/* 171 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 178 */       super.loadXML(entrynode, databases, slaveServers);
/* 179 */       this.foldername = XMLHandler.getTagValue(entrynode, "foldername");
/* 180 */       this.specifywildcard = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "specify_wildcard"));
/* 181 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/* 182 */       this.wildcardexclude = XMLHandler.getTagValue(entrynode, "wildcardexclude");
/* 183 */       this.destination_folder = XMLHandler.getTagValue(entrynode, "destination_folder");
/* 184 */       this.nr_errors_less_than = XMLHandler.getTagValue(entrynode, "nr_errors_less_than");
/* 185 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/* 186 */       this.add_date = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_date"));
/* 187 */       this.add_time = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_time"));
/* 188 */       this.SpecifyFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyFormat"));
/* 189 */       this.AddDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddDateBeforeExtension"));
/*     */       
/* 191 */       this.date_time_format = XMLHandler.getTagValue(entrynode, "date_time_format");
/* 192 */       this.action = XMLHandler.getTagValue(entrynode, "action");
/*     */       
/* 194 */       this.OverwriteFile = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "OverwriteFile"));
/* 195 */       this.CreateDestinationFolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "CreateDestinationFolder"));
/* 196 */       this.RemovedSourceFilename = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "RemovedSourceFilename"));
/* 197 */       this.AddDestinationFilename = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddDestinationFilename"));
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/*     */ 
/*     */ 
/* 205 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.CanNotLoadFromXML", new String[] { xe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 213 */       this.foldername = rep.getJobEntryAttributeString(id_jobentry, "foldername");
/* 214 */       this.specifywildcard = rep.getJobEntryAttributeBoolean(id_jobentry, "specify_wildcard");
/* 215 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/* 216 */       this.wildcardexclude = rep.getJobEntryAttributeString(id_jobentry, "wildcardexclude");
/* 217 */       this.destination_folder = rep.getJobEntryAttributeString(id_jobentry, "destination_folder");
/* 218 */       this.nr_errors_less_than = rep.getJobEntryAttributeString(id_jobentry, "nr_errors_less_than");
/* 219 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/* 220 */       this.add_date = rep.getJobEntryAttributeBoolean(id_jobentry, "add_date");
/* 221 */       this.add_time = rep.getJobEntryAttributeBoolean(id_jobentry, "add_time");
/* 222 */       this.SpecifyFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyFormat");
/* 223 */       this.date_time_format = rep.getJobEntryAttributeString(id_jobentry, "date_time_format");
/* 224 */       this.AddDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddDateBeforeExtension");
/* 225 */       this.action = rep.getJobEntryAttributeString(id_jobentry, "action");
/*     */       
/* 227 */       this.OverwriteFile = rep.getJobEntryAttributeBoolean(id_jobentry, "OverwriteFile");
/* 228 */       this.CreateDestinationFolder = rep.getJobEntryAttributeBoolean(id_jobentry, "CreateDestinationFolder");
/* 229 */       this.RemovedSourceFilename = rep.getJobEntryAttributeBoolean(id_jobentry, "RemovedSourceFilename");
/* 230 */       this.AddDestinationFilename = rep.getJobEntryAttributeBoolean(id_jobentry, "AddDestinationFilename");
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/*     */ 
/*     */ 
/* 238 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.CanNotLoadFromRep", new String[] { "" + id_jobentry, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 246 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "foldername", this.foldername);
/* 247 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "specify_wildcard", this.specifywildcard);
/* 248 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/* 249 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcardexclude", this.wildcardexclude);
/*     */       
/* 251 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destination_folder", this.destination_folder);
/* 252 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_errors_less_than", this.nr_errors_less_than);
/* 253 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/* 254 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_date", this.add_date);
/* 255 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_time", this.add_time);
/* 256 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyFormat", this.SpecifyFormat);
/* 257 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_format", this.date_time_format);
/* 258 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddDateBeforeExtension", this.AddDateBeforeExtension);
/* 259 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "action", this.action);
/*     */       
/* 261 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "OverwriteFile", this.OverwriteFile);
/* 262 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "CreateDestinationFolder", this.CreateDestinationFolder);
/* 263 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "RemovedSourceFilename", this.RemovedSourceFilename);
/* 264 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddDestinationFilename", this.AddDestinationFilename);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/*     */ 
/* 271 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.CanNotSaveToRep", new String[] { "" + id_job, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setSpecifyWildcard(boolean specifywildcard)
/*     */   {
/* 277 */     this.specifywildcard = specifywildcard;
/*     */   }
/*     */   
/*     */   public boolean isSpecifyWildcard()
/*     */   {
/* 282 */     return this.specifywildcard;
/*     */   }
/*     */   
/*     */   public void setFoldername(String foldername) {
/* 286 */     this.foldername = foldername;
/*     */   }
/*     */   
/*     */   public String getFoldername()
/*     */   {
/* 291 */     return this.foldername;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getWildcard()
/*     */   {
/* 297 */     return this.wildcard;
/*     */   }
/*     */   
/*     */   public String getWildcardExclude()
/*     */   {
/* 302 */     return this.wildcardexclude;
/*     */   }
/*     */   
/*     */   public String getRealWildcard()
/*     */   {
/* 307 */     return environmentSubstitute(getWildcard());
/*     */   }
/*     */   
/*     */   public void setWildcard(String wildcard) {
/* 311 */     this.wildcard = wildcard;
/*     */   }
/*     */   
/*     */   public void setWildcardExclude(String wildcardexclude) {
/* 315 */     this.wildcardexclude = wildcardexclude;
/*     */   }
/*     */   
/*     */   public void setAddDate(boolean adddate)
/*     */   {
/* 320 */     this.add_date = adddate;
/*     */   }
/*     */   
/*     */   public boolean isAddDate()
/*     */   {
/* 325 */     return this.add_date;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAddTime(boolean addtime)
/*     */   {
/* 331 */     this.add_time = addtime;
/*     */   }
/*     */   
/*     */   public boolean isAddTime()
/*     */   {
/* 336 */     return this.add_time;
/*     */   }
/*     */   
/*     */   public void setAddDateBeforeExtension(boolean AddDateBeforeExtension)
/*     */   {
/* 341 */     this.AddDateBeforeExtension = AddDateBeforeExtension;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAddDateBeforeExtension()
/*     */   {
/* 347 */     return this.AddDateBeforeExtension;
/*     */   }
/*     */   
/*     */   public boolean isOverwriteFile() {
/* 351 */     return this.OverwriteFile;
/*     */   }
/*     */   
/*     */   public void setOverwriteFile(boolean OverwriteFile)
/*     */   {
/* 356 */     this.OverwriteFile = OverwriteFile;
/*     */   }
/*     */   
/*     */   public void setCreateDestinationFolder(boolean CreateDestinationFolder) {
/* 360 */     this.CreateDestinationFolder = CreateDestinationFolder;
/*     */   }
/*     */   
/*     */   public boolean isCreateDestinationFolder() {
/* 364 */     return this.CreateDestinationFolder;
/*     */   }
/*     */   
/*     */   public boolean isRemovedSourceFilename() {
/* 368 */     return this.RemovedSourceFilename;
/*     */   }
/*     */   
/*     */   public void setRemovedSourceFilename(boolean RemovedSourceFilename) {
/* 372 */     this.RemovedSourceFilename = RemovedSourceFilename;
/*     */   }
/*     */   
/*     */   public void setAddDestinationFilename(boolean AddDestinationFilename) {
/* 376 */     this.AddDestinationFilename = AddDestinationFilename;
/*     */   }
/*     */   
/*     */   public boolean isAddDestinationFilename() {
/* 380 */     return this.AddDestinationFilename;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSpecifyFormat()
/*     */   {
/* 386 */     return this.SpecifyFormat;
/*     */   }
/*     */   
/*     */   public void setSpecifyFormat(boolean SpecifyFormat)
/*     */   {
/* 391 */     this.SpecifyFormat = SpecifyFormat;
/*     */   }
/*     */   
/*     */   public void setDestinationFolder(String destinationFolder)
/*     */   {
/* 396 */     this.destination_folder = destinationFolder;
/*     */   }
/*     */   
/*     */   public String getDestinationFolder()
/*     */   {
/* 401 */     return this.destination_folder;
/*     */   }
/*     */   
/*     */   public void setNrErrorsLessThan(String nr_errors_less_than)
/*     */   {
/* 406 */     this.nr_errors_less_than = nr_errors_less_than;
/*     */   }
/*     */   
/*     */   public String getNrErrorsLessThan()
/*     */   {
/* 411 */     return this.nr_errors_less_than;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSuccessCondition(String success_condition)
/*     */   {
/* 417 */     this.success_condition = success_condition;
/*     */   }
/*     */   
/*     */   public String getSuccessCondition() {
/* 421 */     return this.success_condition;
/*     */   }
/*     */   
/*     */   public void setAction(String action)
/*     */   {
/* 426 */     this.action = action;
/*     */   }
/*     */   
/*     */   public String getAction()
/*     */   {
/* 431 */     return this.action;
/*     */   }
/*     */   
/*     */   public String getDateTimeFormat()
/*     */   {
/* 436 */     return this.date_time_format;
/*     */   }
/*     */   
/*     */   public void setDateTimeFormat(String date_time_format) {
/* 440 */     this.date_time_format = date_time_format;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr) {
/* 444 */     Result result = previousResult;
/* 445 */     result.setNrErrors(1L);
/* 446 */     result.setResult(false);
/* 447 */     String realdestinationFolder = environmentSubstitute(getDestinationFolder());
/* 448 */     if (!Const.isEmpty(this.wildcard)) {
/* 449 */       this.wildcardPattern = Pattern.compile(environmentSubstitute(this.wildcard));
/*     */     }
/* 451 */     if (!Const.isEmpty(this.wildcardexclude)) {
/* 452 */       this.wildcardExcludePattern = Pattern.compile(environmentSubstitute(this.wildcardexclude));
/*     */     }
/*     */     
/* 455 */     if (!CreateDestinationFolder(realdestinationFolder))
/*     */     {
/* 457 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 461 */     if (previousResult != null)
/*     */     {
/* 463 */       this.NrErrors = 0;
/* 464 */       this.limitFiles = Const.toInt(environmentSubstitute(getNrErrorsLessThan()), 10);
/* 465 */       this.NrErrors = 0;
/* 466 */       this.NrSuccess = 0;
/* 467 */       this.successConditionBroken = false;
/* 468 */       this.successConditionBrokenExit = false;
/*     */       
/* 470 */       FileObject file = null;
/*     */       
/*     */       try
/*     */       {
/* 474 */         int size = result.getResultFiles().size();
/* 475 */         if (this.log.isBasic()) { logBasic(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.log.FilesFound", new String[] { "" + size }));
/*     */         }
/* 477 */         List<ResultFile> resultFiles = result.getResultFilesList();
/* 478 */         if ((resultFiles != null) && (resultFiles.size() > 0))
/*     */         {
/* 480 */           for (it = resultFiles.iterator(); (it.hasNext()) && (!this.parentJob.isStopped());)
/*     */           {
/* 482 */             if (this.successConditionBroken)
/*     */             {
/* 484 */               logError(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/* 485 */               throw new Exception(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*     */             }
/*     */             
/* 488 */             ResultFile resultFile = (ResultFile)it.next();
/* 489 */             file = resultFile.getFile();
/* 490 */             if ((file != null) && (file.exists()))
/*     */             {
/* 492 */               if ((!this.specifywildcard) || ((CheckFileWildcard(file.getName().getBaseName(), this.wildcardPattern, true)) && (!CheckFileWildcard(file.getName().getBaseName(), this.wildcardExcludePattern, false)) && (this.specifywildcard)))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 498 */                 if (!processFile(file, realdestinationFolder, result, this.parentJob))
/*     */                 {
/*     */ 
/* 501 */                   updateErrors();
/*     */                 }
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/* 507 */               logError(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.log.ErrorCanNotFindFile", new String[] { file.toString() }));
/*     */               
/* 509 */               updateErrors();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/*     */         Iterator<ResultFile> it;
/* 516 */         logError(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Error", new String[] { e.toString() }));
/*     */       }
/*     */       finally
/*     */       {
/* 520 */         if (file != null) {
/*     */           try
/*     */           {
/* 523 */             file.close();
/* 524 */             file = null;
/*     */           }
/*     */           catch (Exception ex) {}
/*     */         }
/*     */       }
/*     */     }
/* 530 */     result.setNrErrors(this.NrErrors);
/* 531 */     result.setNrLinesWritten(this.NrSuccess);
/* 532 */     if (getSuccessStatus()) { result.setResult(true);
/*     */     }
/* 534 */     return result;
/*     */   }
/*     */   
/*     */   private void updateErrors() {
/* 538 */     this.NrErrors += 1;
/* 539 */     if (checkIfSuccessConditionBroken())
/*     */     {
/*     */ 
/* 542 */       this.successConditionBroken = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkIfSuccessConditionBroken() {
/* 547 */     boolean retval = false;
/* 548 */     if (((this.NrErrors > 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/*     */ 
/* 551 */       retval = true;
/*     */     }
/* 553 */     return retval;
/*     */   }
/*     */   
/*     */   private boolean getSuccessStatus()
/*     */   {
/* 558 */     boolean retval = false;
/*     */     
/* 560 */     if (((this.NrErrors == 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrSuccess >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FILES_UN_ZIPPED))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/*     */ 
/*     */ 
/* 564 */       retval = true;
/*     */     }
/*     */     
/* 567 */     return retval;
/*     */   }
/*     */   
/*     */   private boolean CreateDestinationFolder(String foldername)
/*     */   {
/* 572 */     FileObject folder = null;
/*     */     try
/*     */     {
/* 575 */       folder = KettleVFS.getFileObject(foldername, this);
/*     */       boolean bool;
/* 577 */       if (!folder.exists())
/*     */       {
/* 579 */         logError(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Log.FolderNotExists", new String[] { foldername }));
/* 580 */         if (isCreateDestinationFolder()) {
/* 581 */           folder.createFolder();
/*     */         } else
/* 583 */           return false;
/* 584 */         if (this.log.isBasic()) { logBasic(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Log.FolderCreated", new String[] { foldername }));
/*     */         }
/*     */       }
/* 587 */       else if (this.log.isDetailed()) {
/* 588 */         logDetailed(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Log.FolderExists", new String[] { foldername }));
/*     */       }
/* 590 */       return true;
/*     */     }
/*     */     catch (Exception e) {
/* 593 */       logError(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Log.CanNotCreatedFolder", new String[] { foldername, e.toString() }));
/*     */     }
/*     */     finally
/*     */     {
/* 597 */       if (folder != null) {
/*     */         try
/*     */         {
/* 600 */           folder.close();
/* 601 */           folder = null;
/*     */         }
/*     */         catch (Exception ex) {}
/*     */       }
/*     */     }
/* 606 */     return false;
/*     */   }
/*     */   
/*     */   private boolean processFile(FileObject sourcefile, String destinationFolder, Result result, Job parentJob)
/*     */   {
/* 611 */     boolean retval = false;
/* 612 */     boolean filexists = false;
/*     */     
/*     */     try
/*     */     {
/* 616 */       String shortfilename = getDestinationFilename(sourcefile.getName().getBaseName());
/*     */       
/* 618 */       String destinationFilename = destinationFolder + Const.FILE_SEPARATOR + shortfilename;
/* 619 */       FileObject destinationfile = KettleVFS.getFileObject(destinationFilename, this);
/* 620 */       filexists = destinationfile.exists();
/* 621 */       if (filexists)
/*     */       {
/* 623 */         if (this.log.isDetailed())
/* 624 */           logDetailed(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Log.FileExists", new String[] { destinationFilename }));
/*     */       }
/* 626 */       if ((!filexists) || ((filexists) && (isOverwriteFile())))
/*     */       {
/* 628 */         if (getAction().equals("copy"))
/*     */         {
/*     */ 
/* 631 */           FileUtil.copyContent(sourcefile, destinationfile);
/* 632 */           if (this.log.isDetailed()) {
/* 633 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.log.CopiedFile", new String[] { sourcefile.toString(), destinationFolder }));
/*     */           }
/*     */         } else {
/* 636 */           sourcefile.moveTo(destinationfile);
/* 637 */           if (this.log.isDetailed()) {
/* 638 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.log.MovedFile", new String[] { sourcefile.toString(), destinationFolder }));
/*     */           }
/*     */         }
/* 641 */         if (isRemovedSourceFilename())
/*     */         {
/*     */ 
/* 644 */           result.getResultFiles().remove(sourcefile.toString());
/* 645 */           if (this.log.isDetailed())
/* 646 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.RemovedFileFromResult", new String[] { sourcefile.toString() }));
/*     */         }
/* 648 */         if (isAddDestinationFilename())
/*     */         {
/*     */ 
/* 651 */           ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(destinationfile.toString(), this), parentJob.getJobname(), toString());
/* 652 */           result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/* 653 */           if (this.log.isDetailed())
/* 654 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.AddedFileToResult", new String[] { destinationfile.toString() }));
/*     */         }
/*     */       }
/* 657 */       retval = true;
/*     */     }
/*     */     catch (Exception e) {
/* 660 */       logError(BaseMessages.getString(PKG, "JobEntryCopyMoveResultFilenames.Log.ErrorProcessing", new String[] { e.toString() }));
/*     */     }
/*     */     
/* 663 */     return retval;
/*     */   }
/*     */   
/*     */   private String getDestinationFilename(String shortsourcefilename) throws Exception
/*     */   {
/* 668 */     String shortfilename = shortsourcefilename;
/* 669 */     int lenstring = shortsourcefilename.length();
/* 670 */     int lastindexOfDot = shortfilename.lastIndexOf('.');
/* 671 */     if (isAddDateBeforeExtension()) {
/* 672 */       shortfilename = shortfilename.substring(0, lastindexOfDot);
/*     */     }
/*     */     
/* 675 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 676 */     Date now = new Date();
/*     */     
/* 678 */     if ((isSpecifyFormat()) && (!Const.isEmpty(getDateTimeFormat())))
/*     */     {
/* 680 */       daf.applyPattern(getDateTimeFormat());
/* 681 */       String dt = daf.format(now);
/* 682 */       shortfilename = shortfilename + dt;
/*     */     }
/*     */     else {
/* 685 */       if (isAddDate())
/*     */       {
/* 687 */         daf.applyPattern("yyyyMMdd");
/* 688 */         String d = daf.format(now);
/* 689 */         shortfilename = shortfilename + "_" + d;
/*     */       }
/* 691 */       if (isAddTime())
/*     */       {
/* 693 */         daf.applyPattern("HHmmssSSS");
/* 694 */         String t = daf.format(now);
/* 695 */         shortfilename = shortfilename + "_" + t;
/*     */       }
/*     */     }
/* 698 */     if (isAddDateBeforeExtension()) {
/* 699 */       shortfilename = shortfilename + shortsourcefilename.substring(lastindexOfDot, lenstring);
/*     */     }
/*     */     
/* 702 */     return shortfilename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean CheckFileWildcard(String selectedfile, Pattern pattern, boolean include)
/*     */   {
/* 713 */     boolean getIt = include;
/* 714 */     if (pattern != null) {
/* 715 */       Matcher matcher = pattern.matcher(selectedfile);
/* 716 */       getIt = matcher.matches();
/*     */     }
/* 718 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 725 */     return true;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 730 */     ValidatorContext ctx = new ValidatorContext();
/* 731 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 732 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileDoesNotExistValidator() });
/* 733 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\copymoveresultfilenames\JobEntryCopyMoveResultFilenames.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */