/*     */ package org.pentaho.di.job.entries.mailvalidator;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.trans.steps.mailvalidator.MailValidation;
/*     */ import org.pentaho.di.trans.steps.mailvalidator.MailValidationResult;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryMailValidator
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  61 */   private static Class<?> PKG = JobEntryMailValidator.class;
/*     */   
/*     */   private boolean smtpCheck;
/*     */   private String timeout;
/*     */   private String defaultSMTP;
/*     */   private String emailSender;
/*     */   private String emailAddress;
/*     */   
/*     */   public JobEntryMailValidator(String n, String scr)
/*     */   {
/*  71 */     super(n, "");
/*  72 */     this.emailAddress = null;
/*  73 */     this.smtpCheck = false;
/*  74 */     this.timeout = "0";
/*  75 */     this.defaultSMTP = null;
/*  76 */     this.emailSender = "noreply@domain.com";
/*     */   }
/*     */   
/*     */   public JobEntryMailValidator()
/*     */   {
/*  81 */     this("", "");
/*     */   }
/*     */   
/*     */   public void setSMTPCheck(boolean smtpcheck)
/*     */   {
/*  86 */     this.smtpCheck = smtpcheck;
/*     */   }
/*     */   
/*     */   public boolean isSMTPCheck() {
/*  90 */     return this.smtpCheck;
/*     */   }
/*     */   
/*     */   public String getEmailAddress()
/*     */   {
/*  95 */     return this.emailAddress;
/*     */   }
/*     */   
/*     */   public void setEmailAddress(String emailAddress) {
/*  99 */     this.emailAddress = emailAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTimeOut()
/*     */   {
/* 107 */     return this.timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeOut(String timeout)
/*     */   {
/* 115 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDefaultSMTP()
/*     */   {
/* 123 */     return this.defaultSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDefaultSMTP(String defaultSMTP)
/*     */   {
/* 130 */     this.defaultSMTP = defaultSMTP;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String geteMailSender()
/*     */   {
/* 137 */     return this.emailSender;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void seteMailSender(String emailSender)
/*     */   {
/* 144 */     this.emailSender = emailSender;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 149 */     JobEntryMailValidator je = (JobEntryMailValidator)super.clone();
/* 150 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 155 */     StringBuffer retval = new StringBuffer();
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("smtpCheck", this.smtpCheck));
/* 157 */     retval.append("      ").append(XMLHandler.addTagValue("timeout", this.timeout));
/* 158 */     retval.append("      ").append(XMLHandler.addTagValue("defaultSMTP", this.defaultSMTP));
/* 159 */     retval.append("      ").append(XMLHandler.addTagValue("emailSender", this.emailSender));
/* 160 */     retval.append("      ").append(XMLHandler.addTagValue("emailAddress", this.emailAddress));
/*     */     
/* 162 */     retval.append(super.getXML());
/*     */     
/* 164 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 171 */       super.loadXML(entrynode, databases, slaveServers);
/* 172 */       this.smtpCheck = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "smtpCheck"));
/* 173 */       this.timeout = XMLHandler.getTagValue(entrynode, "timeout");
/* 174 */       this.defaultSMTP = XMLHandler.getTagValue(entrynode, "defaultSMTP");
/* 175 */       this.emailSender = XMLHandler.getTagValue(entrynode, "emailSender");
/* 176 */       this.emailAddress = XMLHandler.getTagValue(entrynode, "emailAddress");
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 181 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryMailValidator.Meta.UnableToLoadFromXML", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 189 */       this.smtpCheck = rep.getJobEntryAttributeBoolean(id_jobentry, "smtpCheck");
/* 190 */       this.timeout = rep.getJobEntryAttributeString(id_jobentry, "timeout");
/* 191 */       this.defaultSMTP = rep.getJobEntryAttributeString(id_jobentry, "defaultSMTP");
/* 192 */       this.emailSender = rep.getJobEntryAttributeString(id_jobentry, "emailSender");
/* 193 */       this.emailAddress = rep.getJobEntryAttributeString(id_jobentry, "emailAddress");
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 197 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryMailValidator.Meta.UnableToLoadFromRep", new String[0]) + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 208 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "smtpCheck", this.smtpCheck);
/* 209 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "timeout", this.timeout);
/* 210 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "defaultSMTP", this.defaultSMTP);
/* 211 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "emailSender", this.emailSender);
/* 212 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "emailAddress", this.emailAddress);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 216 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryMailValidator.Meta.UnableToSaveToRep", new String[0]) + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 229 */     Result result = previousResult;
/* 230 */     result.setNrErrors(1L);
/* 231 */     result.setResult(false);
/*     */     
/* 233 */     String realEmailAddress = environmentSubstitute(this.emailAddress);
/* 234 */     if (Const.isEmpty(realEmailAddress))
/*     */     {
/* 236 */       logError(BaseMessages.getString(PKG, "JobEntryMailValidator.Error.EmailEmpty", new String[0]));
/* 237 */       return result;
/*     */     }
/* 239 */     String realSender = environmentSubstitute(this.emailSender);
/* 240 */     if (this.smtpCheck)
/*     */     {
/*     */ 
/* 243 */       if (Const.isEmpty(realSender))
/*     */       {
/* 245 */         logError(BaseMessages.getString(PKG, "JobEntryMailValidator.Error.EmailSenderEmpty", new String[0]));
/* 246 */         return result;
/*     */       }
/*     */     }
/*     */     
/* 250 */     String realDefaultSMTP = environmentSubstitute(this.defaultSMTP);
/* 251 */     int timeOut = Const.toInt(environmentSubstitute(this.timeout), 0);
/*     */     
/*     */ 
/* 254 */     String[] mailsCheck = realEmailAddress.split(" ");
/* 255 */     boolean exitloop = false;
/* 256 */     boolean mailIsValid = false;
/* 257 */     String MailError = null;
/* 258 */     for (int i = 0; (i < mailsCheck.length) && (!exitloop); i++)
/*     */     {
/* 260 */       String email = mailsCheck[i];
/* 261 */       if (this.log.isDetailed()) {
/* 262 */         logDetailed(BaseMessages.getString(PKG, "JobEntryMailValidator.CheckingMail", new String[] { email }));
/*     */       }
/*     */       
/* 265 */       MailValidationResult resultValidator = MailValidation.isAddressValid(this.log, email, realSender, realDefaultSMTP, timeOut, this.smtpCheck);
/*     */       
/* 267 */       mailIsValid = resultValidator.isValide();
/* 268 */       MailError = resultValidator.getErrorMessage();
/*     */       
/* 270 */       if (this.log.isDetailed())
/*     */       {
/* 272 */         if (mailIsValid) {
/* 273 */           logDetailed(BaseMessages.getString(PKG, "JobEntryMailValidator.MailValid", new String[] { email }));
/*     */         }
/*     */         else {
/* 276 */           logDetailed(BaseMessages.getString(PKG, "JobEntryMailValidator.MailNotValid", new String[] { email }));
/* 277 */           logDetailed(MailError);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 282 */       if (!resultValidator.isValide()) { exitloop = true;
/*     */       }
/*     */     }
/* 285 */     result.setResult(mailIsValid);
/* 286 */     if (mailIsValid) { result.setNrErrors(0L);
/*     */     }
/*     */     
/*     */ 
/* 290 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 295 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 301 */     JobEntryValidatorUtils.andValidator().validate(this, "emailAddress", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 302 */     JobEntryValidatorUtils.andValidator().validate(this, "emailSender", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.emailValidator() }));
/*     */     
/* 304 */     if (isSMTPCheck())
/*     */     {
/* 306 */       JobEntryValidatorUtils.andValidator().validate(this, "defaultSMTP", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\mailvalidator\JobEntryMailValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */