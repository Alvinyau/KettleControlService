/*      */ package org.pentaho.di.job.entries.ftpdelete;
/*      */ 
/*      */ import com.enterprisedt.net.ftp.FTPClient;
/*      */ import com.enterprisedt.net.ftp.FTPConnectMode;
/*      */ import com.enterprisedt.net.ftp.FTPException;
/*      */ import com.trilead.ssh2.Connection;
/*      */ import com.trilead.ssh2.HTTPProxyData;
/*      */ import com.trilead.ssh2.SFTPv3Client;
/*      */ import com.trilead.ssh2.SFTPv3DirectoryEntry;
/*      */ import com.trilead.ssh2.SFTPv3FileAttributes;
/*      */ import java.io.File;
/*      */ import java.io.PrintStream;
/*      */ import java.net.InetAddress;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Vector;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.log4j.Logger;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.RowMetaAndData;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entries.ftpsget.FTPSConnection;
/*      */ import org.pentaho.di.job.entries.sftp.SFTPClient;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.pentaho.di.resource.ResourceEntry;
/*      */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*      */ import org.pentaho.di.resource.ResourceReference;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryFTPDelete
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   82 */   private static Class<?> PKG = JobEntryFTPDelete.class;
/*      */   
/*   84 */   private static Logger log4j = Logger.getLogger(JobEntryFTPDelete.class);
/*      */   
/*      */   private String serverName;
/*      */   
/*      */   private String port;
/*      */   
/*      */   private String userName;
/*      */   
/*      */   private String password;
/*      */   
/*      */   private String ftpDirectory;
/*      */   
/*      */   private String wildcard;
/*      */   
/*      */   private int timeout;
/*      */   
/*      */   private boolean activeConnection;
/*      */   
/*      */   private boolean publicpublickey;
/*      */   
/*      */   private String keyFilename;
/*      */   private String keyFilePass;
/*      */   private boolean useproxy;
/*      */   private String proxyHost;
/*      */   private String proxyPort;
/*      */   private String proxyUsername;
/*      */   private String proxyPassword;
/*      */   private String socksProxyHost;
/*      */   private String socksProxyPort;
/*      */   private String socksProxyUsername;
/*      */   private String socksProxyPassword;
/*      */   private String protocol;
/*      */   public static final String PROTOCOL_FTP = "FTP";
/*      */   public static final String PROTOCOL_FTPS = "FTPS";
/*      */   public static final String PROTOCOL_SFTP = "SFTP";
/*      */   public static final String PROTOCOL_SSH = "SSH";
/*  120 */   public String SUCCESS_IF_AT_LEAST_X_FILES_DOWNLOADED = "success_when_at_least";
/*  121 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*  122 */   public String SUCCESS_IF_ALL_FILES_DOWNLOADED = "success_is_all_files_downloaded";
/*      */   
/*      */   private String nr_limit_success;
/*      */   
/*      */   private String success_condition;
/*      */   
/*      */   private boolean copyprevious;
/*      */   private int FTPSConnectionType;
/*  130 */   long NrErrors = 0L;
/*  131 */   long NrfilesDeleted = 0L;
/*  132 */   boolean successConditionBroken = false;
/*      */   
/*  134 */   String targetFilename = null;
/*  135 */   int limitFiles = 0;
/*      */   
/*  137 */   FTPClient ftpclient = null;
/*  138 */   FTPSConnection ftpsclient = null;
/*  139 */   SFTPClient sftpclient = null;
/*  140 */   SFTPv3Client sshclient = null;
/*      */   
/*      */   public JobEntryFTPDelete(String n)
/*      */   {
/*  144 */     super(n, "");
/*  145 */     this.copyprevious = false;
/*  146 */     this.protocol = "FTP";
/*  147 */     this.port = "21";
/*  148 */     this.socksProxyPort = "1080";
/*  149 */     this.nr_limit_success = "10";
/*  150 */     this.success_condition = this.SUCCESS_IF_ALL_FILES_DOWNLOADED;
/*  151 */     this.publicpublickey = false;
/*  152 */     this.keyFilename = null;
/*  153 */     this.keyFilePass = null;
/*  154 */     this.serverName = null;
/*  155 */     this.FTPSConnectionType = 0;
/*  156 */     setID(-1L);
/*      */   }
/*      */   
/*      */   public JobEntryFTPDelete()
/*      */   {
/*  161 */     this("");
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  166 */     JobEntryFTPDelete je = (JobEntryFTPDelete)super.clone();
/*  167 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  172 */     StringBuffer retval = new StringBuffer(128);
/*      */     
/*  174 */     retval.append(super.getXML());
/*  175 */     retval.append("      ").append(XMLHandler.addTagValue("protocol", this.protocol));
/*  176 */     retval.append("      ").append(XMLHandler.addTagValue("servername", this.serverName));
/*  177 */     retval.append("      ").append(XMLHandler.addTagValue("port", this.port));
/*  178 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.userName));
/*  179 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(getPassword())));
/*  180 */     retval.append("      ").append(XMLHandler.addTagValue("ftpdirectory", this.ftpDirectory));
/*  181 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/*  182 */     retval.append("      ").append(XMLHandler.addTagValue("timeout", this.timeout));
/*  183 */     retval.append("      ").append(XMLHandler.addTagValue("active", this.activeConnection));
/*      */     
/*      */ 
/*  186 */     retval.append("      ").append(XMLHandler.addTagValue("useproxy", this.useproxy));
/*  187 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_host", this.proxyHost));
/*  188 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_port", this.proxyPort));
/*  189 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_username", this.proxyUsername));
/*  190 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword)));
/*      */     
/*  192 */     retval.append("      ").append(XMLHandler.addTagValue("publicpublickey", this.publicpublickey));
/*  193 */     retval.append("      ").append(XMLHandler.addTagValue("keyfilename", this.keyFilename));
/*  194 */     retval.append("      ").append(XMLHandler.addTagValue("keyfilepass", this.keyFilePass));
/*      */     
/*  196 */     retval.append("      ").append(XMLHandler.addTagValue("nr_limit_success", this.nr_limit_success));
/*  197 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*  198 */     retval.append("      ").append(XMLHandler.addTagValue("copyprevious", this.copyprevious));
/*  199 */     retval.append("      ").append(XMLHandler.addTagValue("ftps_connection_type", FTPSConnection.getConnectionTypeCode(this.FTPSConnectionType)));
/*      */     
/*  201 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_host", this.socksProxyHost));
/*  202 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_port", this.socksProxyPort));
/*  203 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_username", this.socksProxyUsername));
/*  204 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_password", Encr.encryptPasswordIfNotUsingVariables(getSocksProxyPassword())));
/*      */     
/*  206 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  213 */       super.loadXML(entrynode, databases, slaveServers);
/*      */       
/*  215 */       this.protocol = XMLHandler.getTagValue(entrynode, "protocol");
/*  216 */       this.port = XMLHandler.getTagValue(entrynode, "port");
/*  217 */       this.serverName = XMLHandler.getTagValue(entrynode, "servername");
/*  218 */       this.userName = XMLHandler.getTagValue(entrynode, "username");
/*  219 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/*  220 */       this.ftpDirectory = XMLHandler.getTagValue(entrynode, "ftpdirectory");
/*  221 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/*  222 */       this.timeout = Const.toInt(XMLHandler.getTagValue(entrynode, "timeout"), 10000);
/*  223 */       this.activeConnection = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "active"));
/*      */       
/*  225 */       this.useproxy = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "useproxy"));
/*  226 */       this.proxyHost = XMLHandler.getTagValue(entrynode, "proxy_host");
/*  227 */       this.proxyPort = XMLHandler.getTagValue(entrynode, "proxy_port");
/*  228 */       this.proxyUsername = XMLHandler.getTagValue(entrynode, "proxy_username");
/*  229 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "proxy_password"));
/*      */       
/*  231 */       this.publicpublickey = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "publicpublickey"));
/*  232 */       this.keyFilename = XMLHandler.getTagValue(entrynode, "keyfilename");
/*  233 */       this.keyFilePass = XMLHandler.getTagValue(entrynode, "keyfilepass");
/*      */       
/*  235 */       this.nr_limit_success = XMLHandler.getTagValue(entrynode, "nr_limit_success");
/*  236 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/*  237 */       this.copyprevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "copyprevious"));
/*  238 */       this.FTPSConnectionType = FTPSConnection.getConnectionTypeByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "ftps_connection_type"), ""));
/*  239 */       this.socksProxyHost = XMLHandler.getTagValue(entrynode, "socksproxy_host");
/*  240 */       this.socksProxyPort = XMLHandler.getTagValue(entrynode, "socksproxy_port");
/*  241 */       this.socksProxyUsername = XMLHandler.getTagValue(entrynode, "socksproxy_username");
/*  242 */       this.socksProxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "socksproxy_password"));
/*      */ 
/*      */     }
/*      */     catch (KettleXMLException xe)
/*      */     {
/*  247 */       throw new KettleXMLException("Unable to load job entry of type 'ftp' from XML node", xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  255 */       this.protocol = rep.getJobEntryAttributeString(id_jobentry, "protocol");
/*  256 */       this.port = rep.getJobEntryAttributeString(id_jobentry, "port");
/*  257 */       this.serverName = rep.getJobEntryAttributeString(id_jobentry, "servername");
/*  258 */       this.userName = rep.getJobEntryAttributeString(id_jobentry, "username");
/*  259 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/*  260 */       this.ftpDirectory = rep.getJobEntryAttributeString(id_jobentry, "ftpdirectory");
/*  261 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/*  262 */       this.timeout = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "timeout"));
/*  263 */       this.activeConnection = rep.getJobEntryAttributeBoolean(id_jobentry, "active");
/*      */       
/*  265 */       this.copyprevious = rep.getJobEntryAttributeBoolean(id_jobentry, "copyprevious");
/*      */       
/*      */ 
/*  268 */       this.useproxy = rep.getJobEntryAttributeBoolean(id_jobentry, "useproxy");
/*  269 */       this.proxyHost = rep.getJobEntryAttributeString(id_jobentry, "proxy_host");
/*  270 */       this.proxyPort = rep.getJobEntryAttributeString(id_jobentry, "proxy_port");
/*  271 */       this.proxyUsername = rep.getJobEntryAttributeString(id_jobentry, "proxy_username");
/*  272 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "proxy_password"));
/*      */       
/*  274 */       this.publicpublickey = rep.getJobEntryAttributeBoolean(id_jobentry, "publicpublickey");
/*  275 */       this.keyFilename = rep.getJobEntryAttributeString(id_jobentry, "keyfilename");
/*  276 */       this.keyFilePass = rep.getJobEntryAttributeString(id_jobentry, "keyfilepass");
/*      */       
/*  278 */       this.nr_limit_success = rep.getJobEntryAttributeString(id_jobentry, "nr_limit_success");
/*  279 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/*  280 */       this.FTPSConnectionType = FTPSConnection.getConnectionTypeByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "ftps_connection_type"), ""));
/*      */       
/*  282 */       this.socksProxyHost = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_host");
/*  283 */       this.socksProxyPort = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_port");
/*  284 */       this.socksProxyUsername = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_username");
/*  285 */       this.socksProxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "socksproxy_password"));
/*      */     }
/*      */     catch (KettleException dbe)
/*      */     {
/*  289 */       throw new KettleException("Unable to load job entry of type 'ftp' from the repository for id_jobentry=" + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  297 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "protocol", this.protocol);
/*  298 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "port", this.port);
/*  299 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "servername", this.serverName);
/*  300 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.userName);
/*  301 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/*  302 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ftpdirectory", this.ftpDirectory);
/*  303 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/*  304 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "timeout", this.timeout);
/*      */       
/*  306 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "active", this.activeConnection);
/*  307 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "copyprevious", this.copyprevious);
/*      */       
/*  309 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "useproxy", this.useproxy);
/*  310 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "publicpublickey", this.publicpublickey);
/*  311 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "keyfilename", this.keyFilename);
/*  312 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "keyfilepass", this.keyFilePass);
/*      */       
/*  314 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_host", this.proxyHost);
/*  315 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_port", this.proxyPort);
/*  316 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_username", this.proxyUsername);
/*  317 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword));
/*      */       
/*  319 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_limit_success", this.nr_limit_success);
/*  320 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*  321 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ftps_connection_type", FTPSConnection.getConnectionType(this.FTPSConnectionType));
/*      */       
/*  323 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_host", this.socksProxyHost);
/*  324 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_port", this.socksProxyPort);
/*  325 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_username", this.socksProxyUsername);
/*  326 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_password", Encr.encryptPasswordIfNotUsingVariables(this.socksProxyPassword));
/*      */ 
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  331 */       throw new KettleException("Unable to save job entry of type 'ftp' to the repository for id_job=" + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean getStatus() {
/*  336 */     boolean retval = false;
/*      */     
/*  338 */     if (((this.NrErrors == 0L) && (getSuccessCondition().equals(this.SUCCESS_IF_ALL_FILES_DOWNLOADED))) || ((this.NrfilesDeleted >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FILES_DOWNLOADED))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*      */ 
/*  342 */       retval = true;
/*      */     }
/*      */     
/*  345 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isCopyPrevious()
/*      */   {
/*  351 */     return this.copyprevious;
/*      */   }
/*      */   
/*      */   public void setCopyPrevious(boolean copyprevious)
/*      */   {
/*  356 */     this.copyprevious = copyprevious;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setUsePublicKey(boolean publickey)
/*      */   {
/*  363 */     this.publicpublickey = publickey;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isUsePublicKey()
/*      */   {
/*  371 */     return this.publicpublickey;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setKeyFilename(String keyfilename)
/*      */   {
/*  378 */     this.keyFilename = keyfilename;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getKeyFilename()
/*      */   {
/*  387 */     return this.keyFilename;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setKeyFilePass(String keyFilePass)
/*      */   {
/*  395 */     this.keyFilePass = keyFilePass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getKeyFilePass()
/*      */   {
/*  404 */     return this.keyFilePass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getFTPSConnectionType()
/*      */   {
/*  411 */     return this.FTPSConnectionType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFTPSConnectionType(int type)
/*      */   {
/*  420 */     this.FTPSConnectionType = type;
/*      */   }
/*      */   
/*      */   public void setLimitSuccess(String nr_limit_successin) {
/*  424 */     this.nr_limit_success = nr_limit_successin;
/*      */   }
/*      */   
/*      */   public String getLimitSuccess()
/*      */   {
/*  429 */     return this.nr_limit_success;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSuccessCondition(String success_condition)
/*      */   {
/*  435 */     this.success_condition = success_condition;
/*      */   }
/*      */   
/*      */   public String getSuccessCondition() {
/*  439 */     return this.success_condition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFtpDirectory()
/*      */   {
/*  447 */     return this.ftpDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFtpDirectory(String directory)
/*      */   {
/*  455 */     this.ftpDirectory = directory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPassword()
/*      */   {
/*  463 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/*  471 */     this.password = password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerName()
/*      */   {
/*  479 */     return this.serverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerName(String serverName)
/*      */   {
/*  487 */     this.serverName = serverName;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setProtocol(String protocol)
/*      */   {
/*  493 */     this.protocol = protocol;
/*      */   }
/*      */   
/*      */   public String getProtocol()
/*      */   {
/*  498 */     return this.protocol;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */   {
/*  506 */     return this.userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserName(String userName)
/*      */   {
/*  514 */     this.userName = userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWildcard()
/*      */   {
/*  522 */     return this.wildcard;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWildcard(String wildcard)
/*      */   {
/*  530 */     this.wildcard = wildcard;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimeout(int timeout)
/*      */   {
/*  539 */     this.timeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTimeout()
/*      */   {
/*  547 */     return this.timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyHost()
/*      */   {
/*  555 */     return this.proxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyHost(String proxyHost)
/*      */   {
/*  563 */     this.proxyHost = proxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isUseProxy()
/*      */   {
/*  569 */     return this.useproxy;
/*      */   }
/*      */   
/*      */   public void setUseProxy(boolean useproxy)
/*      */   {
/*  574 */     this.useproxy = useproxy;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyPassword()
/*      */   {
/*  583 */     return this.proxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPassword(String proxyPassword)
/*      */   {
/*  591 */     this.proxyPassword = proxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getPort()
/*      */   {
/*  598 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(String port)
/*      */   {
/*  606 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getProxyPort()
/*      */   {
/*  613 */     return this.proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(String proxyPort)
/*      */   {
/*  621 */     this.proxyPort = proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getProxyUsername()
/*      */   {
/*  628 */     return this.proxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProxyUsername(String proxyUsername)
/*      */   {
/*  635 */     this.proxyUsername = proxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Result execute(Result previousResult, int nr)
/*      */   {
/*  642 */     log4j.info(BaseMessages.getString(PKG, "JobEntryFTPDelete.Started", new String[] { this.serverName }));
/*  643 */     RowMetaAndData resultRow = null;
/*  644 */     Result result = previousResult;
/*  645 */     List<RowMetaAndData> rows = result.getRows();
/*      */     
/*  647 */     result.setResult(false);
/*  648 */     this.NrErrors = 0L;
/*  649 */     this.NrfilesDeleted = 0L;
/*  650 */     this.successConditionBroken = false;
/*  651 */     HashSet<String> list_previous_files = new HashSet();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  656 */     String realservername = environmentSubstitute(this.serverName);
/*  657 */     String realserverpassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password));
/*  658 */     String realFtpDirectory = environmentSubstitute(this.ftpDirectory);
/*      */     
/*  660 */     int realserverport = Const.toInt(environmentSubstitute(this.port), 0);
/*  661 */     String realUsername = environmentSubstitute(this.userName);
/*  662 */     String realPassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password));
/*  663 */     String realproxyhost = environmentSubstitute(this.proxyHost);
/*  664 */     String realproxyusername = environmentSubstitute(this.proxyUsername);
/*  665 */     String realproxypassword = environmentSubstitute(this.proxyPassword);
/*  666 */     int realproxyport = Const.toInt(environmentSubstitute(this.proxyPort), 0);
/*  667 */     String realkeyFilename = environmentSubstitute(this.keyFilename);
/*  668 */     String realkeyPass = environmentSubstitute(this.keyFilePass);
/*      */     
/*      */ 
/*  671 */     String sourceFolder = "";
/*      */     
/*  673 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.Start", new String[0]));
/*      */     }
/*  675 */     if ((this.copyprevious) && (rows.size() == 0))
/*      */     {
/*  677 */       if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.ArgsFromPreviousNothing", new String[0]));
/*  678 */       result.setResult(true);
/*  679 */       return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  686 */       String[] filelist = null;
/*  687 */       int fileCount; if (this.protocol.equals("FTP"))
/*      */       {
/*      */ 
/*  690 */         if (!Const.isEmpty(this.socksProxyHost)) {
/*  691 */           if (!Const.isEmpty(this.socksProxyPort)) {
/*  692 */             FTPClient.initSOCKS(environmentSubstitute(this.socksProxyPort), environmentSubstitute(this.socksProxyHost));
/*      */           }
/*      */           else {
/*  695 */             throw new FTPException(BaseMessages.getString(PKG, "JobEntryFTPDelete.SocksProxy.PortMissingException", new String[] { environmentSubstitute(this.socksProxyHost), getName() }));
/*      */           }
/*      */           
/*  698 */           if ((!Const.isEmpty(this.socksProxyUsername)) && (!Const.isEmpty(this.socksProxyPassword))) {
/*  699 */             FTPClient.initSOCKSAuthentication(environmentSubstitute(this.socksProxyUsername), environmentSubstitute(this.socksProxyPassword));
/*      */           }
/*  701 */           else if (((!Const.isEmpty(this.socksProxyUsername)) && (Const.isEmpty(this.socksProxyPassword))) || ((Const.isEmpty(this.socksProxyUsername)) && (!Const.isEmpty(this.socksProxyPassword))))
/*      */           {
/*      */ 
/*  704 */             throw new FTPException(BaseMessages.getString(PKG, "JobEntryFTPDelete.SocksProxy.IncompleteCredentials", new String[] { environmentSubstitute(this.socksProxyHost), getName() }));
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  709 */         FTPConnect(realservername, realUsername, realPassword, realserverport, realFtpDirectory, realproxyhost, realproxyusername, realproxypassword, realproxyport, this.timeout);
/*      */         
/*      */ 
/*      */ 
/*  713 */         filelist = this.ftpclient.dir();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  718 */         if (filelist.length == 1)
/*      */         {
/*  720 */           String translatedWildcard = environmentSubstitute(this.wildcard);
/*  721 */           if (!Const.isEmpty(translatedWildcard))
/*      */           {
/*  723 */             if (filelist[0].startsWith(translatedWildcard))
/*      */             {
/*  725 */               throw new FTPException(filelist[0]);
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */       }
/*  731 */       else if (this.protocol.equals("FTPS"))
/*      */       {
/*      */ 
/*  734 */         FTPSConnect(realservername, realUsername, realserverport, realPassword, realFtpDirectory, this.timeout);
/*      */         
/*  736 */         filelist = this.ftpsclient.getFileNames();
/*      */       }
/*  738 */       else if (this.protocol.equals("SFTP"))
/*      */       {
/*      */ 
/*  741 */         SFTPConnect(realservername, realUsername, realserverport, realPassword, realFtpDirectory);
/*      */         
/*      */ 
/*  744 */         filelist = this.sftpclient.dir();
/*      */       }
/*  746 */       else if (this.protocol.equals("SSH"))
/*      */       {
/*      */ 
/*  749 */         SSHConnect(realservername, realserverpassword, realserverport, realUsername, realPassword, realproxyhost, realproxyusername, realproxypassword, realproxyport, realkeyFilename, realkeyPass);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  754 */         sourceFolder = ".";
/*  755 */         if (realFtpDirectory != null) {
/*  756 */           sourceFolder = realFtpDirectory + "/";
/*      */         } else {
/*  758 */           sourceFolder = "./";
/*      */         }
/*      */         
/*  761 */         Vector<SFTPv3DirectoryEntry> vfilelist = this.sshclient.ls(sourceFolder);
/*  762 */         if (vfilelist != null)
/*      */         {
/*      */ 
/*      */ 
/*  766 */           fileCount = 0;
/*  767 */           Iterator<SFTPv3DirectoryEntry> iterator = vfilelist.iterator();
/*  768 */           while (iterator.hasNext())
/*      */           {
/*  770 */             SFTPv3DirectoryEntry dirEntry = (SFTPv3DirectoryEntry)iterator.next();
/*      */             
/*  772 */             if ((dirEntry != null) && (!dirEntry.filename.equals(".")) && (!dirEntry.filename.equals("..")) && (!isDirectory(this.sshclient, sourceFolder + dirEntry.filename)))
/*      */             {
/*      */ 
/*  775 */               fileCount++;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  780 */           filelist = new String[fileCount];
/*  781 */           iterator = vfilelist.iterator();
/*  782 */           int i = 0;
/*  783 */           while (iterator.hasNext())
/*      */           {
/*  785 */             SFTPv3DirectoryEntry dirEntry = (SFTPv3DirectoryEntry)iterator.next();
/*      */             
/*  787 */             if ((dirEntry != null) && (!dirEntry.filename.equals(".")) && (!dirEntry.filename.equals("..")) && (!isDirectory(this.sshclient, sourceFolder + dirEntry.filename)))
/*      */             {
/*      */ 
/*  790 */               filelist[i] = dirEntry.filename;
/*  791 */               i++;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  797 */       if (isDetailed()) logDetailed("JobEntryFTPDelete.FoundNFiles", new Object[] { String.valueOf(filelist.length) });
/*  798 */       int found = filelist == null ? 0 : filelist.length;
/*  799 */       if (found == 0)
/*      */       {
/*  801 */         result.setResult(true);
/*  802 */         return result;
/*      */       }
/*      */       
/*  805 */       Pattern pattern = null;
/*  806 */       if (this.copyprevious)
/*      */       {
/*      */ 
/*  809 */         for (int iteration = 0; iteration < rows.size(); iteration++)
/*      */         {
/*  811 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*      */           
/*      */ 
/*  814 */           String file_previous = resultRow.getString(0, null);
/*  815 */           if (!Const.isEmpty(file_previous))
/*      */           {
/*  817 */             list_previous_files.add(file_previous);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*  822 */       else if (!Const.isEmpty(this.wildcard))
/*      */       {
/*  824 */         String realWildcard = environmentSubstitute(this.wildcard);
/*  825 */         pattern = Pattern.compile(realWildcard);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  830 */       if (!getSuccessCondition().equals(this.SUCCESS_IF_ALL_FILES_DOWNLOADED)) {
/*  831 */         this.limitFiles = Const.toInt(environmentSubstitute(getLimitSuccess()), 10);
/*      */       }
/*      */       
/*  834 */       for (int i = 0; (i < filelist.length) && (!this.parentJob.isStopped()); i++)
/*      */       {
/*  836 */         if (this.successConditionBroken) {
/*  837 */           throw new Exception(BaseMessages.getString(PKG, "JobEntryFTPDelete.SuccesConditionBroken", new String[0]));
/*      */         }
/*  839 */         boolean getIt = false;
/*      */         
/*  841 */         if (isDebug()) { logDebug(BaseMessages.getString(PKG, "JobEntryFTPDelete.AnalysingFile", new String[] { filelist[i] }));
/*      */         }
/*      */         
/*      */         try
/*      */         {
/*  846 */           if (this.copyprevious)
/*      */           {
/*  848 */             if (list_previous_files.contains(filelist[i])) {
/*  849 */               getIt = true;
/*      */             }
/*      */           }
/*  852 */           else if (pattern != null)
/*      */           {
/*  854 */             Matcher matcher = pattern.matcher(filelist[i]);
/*  855 */             getIt = matcher.matches();
/*      */           }
/*      */           
/*      */ 
/*  859 */           if (getIt)
/*      */           {
/*      */ 
/*  862 */             if (this.protocol.equals("FTP"))
/*      */             {
/*  864 */               this.ftpclient.delete(filelist[i]);
/*      */             }
/*  866 */             if (this.protocol.equals("FTPS"))
/*      */             {
/*  868 */               System.out.println("---------------" + filelist[i]);
/*  869 */               this.ftpsclient.deleteFile(filelist[i]);
/*      */             }
/*  871 */             else if (this.protocol.equals("SFTP"))
/*      */             {
/*  873 */               this.sftpclient.delete(filelist[i]);
/*      */             }
/*  875 */             else if (this.protocol.equals("SSH"))
/*      */             {
/*  877 */               this.sshclient.rm(sourceFolder + filelist[i]);
/*      */             }
/*  879 */             if (isDetailed()) logDetailed("JobEntryFTPDelete.RemotefileDeleted", new Object[] { filelist[i] });
/*  880 */             updateDeletedFiles();
/*      */           }
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  885 */           updateErrors();
/*  886 */           logError(BaseMessages.getString(PKG, "JobFTP.UnexpectedError", new String[] { e.getMessage() }));
/*      */           
/*  888 */           if (this.successConditionBroken) {
/*  889 */             throw new Exception(BaseMessages.getString(PKG, "JobEntryFTPDelete.SuccesConditionBroken", new String[0]));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  895 */       updateErrors();
/*  896 */       logError(BaseMessages.getString(PKG, "JobEntryFTPDelete.ErrorGetting", new String[] { e.getMessage() }));
/*  897 */       logError(Const.getStackTracker(e));
/*      */     }
/*      */     finally
/*      */     {
/*  901 */       if ((this.ftpclient != null) && (this.ftpclient.connected()))
/*      */       {
/*      */         try
/*      */         {
/*  905 */           this.ftpclient.quit();
/*  906 */           this.ftpclient = null;
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  910 */           logError(BaseMessages.getString(PKG, "JobEntryFTPDelete.ErrorQuitting", new String[] { e.getMessage() }));
/*      */         }
/*      */       }
/*  913 */       if (this.ftpsclient != null)
/*      */       {
/*      */         try
/*      */         {
/*  917 */           this.ftpsclient.disconnect();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  921 */           logError(BaseMessages.getString(PKG, "JobEntryFTPDelete.ErrorQuitting", new String[] { e.getMessage() }));
/*      */         }
/*      */       }
/*  924 */       if (this.sftpclient != null)
/*      */       {
/*      */         try
/*      */         {
/*  928 */           this.sftpclient.disconnect();
/*  929 */           this.sftpclient = null;
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  933 */           logError(BaseMessages.getString(PKG, "JobEntryFTPDelete.ErrorQuitting", new String[] { e.getMessage() }));
/*      */         }
/*      */       }
/*  936 */       if (this.sshclient != null)
/*      */       {
/*      */         try
/*      */         {
/*  940 */           this.sshclient.close();
/*  941 */           this.sshclient = null;
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  945 */           logError(BaseMessages.getString(PKG, "JobEntryFTPDelete.ErrorQuitting", new String[] { e.getMessage() }));
/*      */         }
/*      */       }
/*      */       
/*  949 */       FTPClient.clearSOCKS();
/*      */     }
/*      */     
/*  952 */     result.setResult(!this.successConditionBroken);
/*  953 */     result.setNrFilesRetrieved(this.NrfilesDeleted);
/*  954 */     result.setNrErrors(this.NrErrors);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  959 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDirectory(SFTPv3Client sftpClient, String filename)
/*      */   {
/*      */     try
/*      */     {
/*  972 */       return sftpClient.stat(filename).isDirectory();
/*      */     }
/*      */     catch (Exception e) {}
/*  975 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void SSHConnect(String realservername, String realserverpassword, int realserverport, String realUsername, String realPassword, String realproxyhost, String realproxyusername, String realproxypassword, int realproxyport, String realkeyFilename, String realkeyPass)
/*      */     throws Exception
/*      */   {
/*  986 */     Connection conn = new Connection(realservername, realserverport);
/*      */     
/*      */ 
/*  989 */     if (this.useproxy)
/*      */     {
/*  991 */       conn.setProxyData(new HTTPProxyData(realproxyhost, realproxyport));
/*      */       
/*      */ 
/*      */ 
/*  995 */       if ((!Const.isEmpty(realproxyusername)) || (!Const.isEmpty(realproxypassword)))
/*      */       {
/*  997 */         conn.setProxyData(new HTTPProxyData(realproxyhost, realproxyport, realproxyusername, realproxypassword));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1002 */     if (this.timeout > 0)
/*      */     {
/*      */ 
/* 1005 */       conn.connect(null, 0, this.timeout * 1000);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1010 */       conn.connect();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1015 */     boolean isAuthenticated = false;
/* 1016 */     if (this.publicpublickey)
/*      */     {
/* 1018 */       isAuthenticated = conn.authenticateWithPublicKey(realUsername, new File(realkeyFilename), realkeyPass);
/*      */     }
/*      */     else {
/* 1021 */       isAuthenticated = conn.authenticateWithPassword(realUsername, realserverpassword);
/*      */     }
/*      */     
/* 1024 */     if (!isAuthenticated) { throw new Exception("Can not connect to ");
/*      */     }
/* 1026 */     this.sshclient = new SFTPv3Client(conn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void SFTPConnect(String realservername, String realusername, int realport, String realpassword, String realFTPDirectory)
/*      */     throws Exception
/*      */   {
/* 1036 */     this.sftpclient = new SFTPClient(InetAddress.getByName(realservername), realport, realusername);
/*      */     
/*      */ 
/*      */ 
/* 1040 */     this.sftpclient.login(realpassword);
/*      */     
/*      */ 
/* 1043 */     if (!Const.isEmpty(realFTPDirectory))
/*      */     {
/* 1045 */       this.sftpclient.chdir(realFTPDirectory);
/* 1046 */       if (isDetailed()) { logDetailed("Changed to directory [" + realFTPDirectory + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void FTPSConnect(String realservername, String realusername, int realport, String realpassword, String realFTPDirectory, int realtimeout)
/*      */     throws Exception
/*      */   {
/* 1054 */     this.ftpsclient = new FTPSConnection(getFTPSConnectionType(), realservername, realport, realusername, realpassword);
/*      */     
/*      */ 
/* 1057 */     if (!Const.isEmpty(this.proxyHost)) {
/* 1058 */       String realProxy_host = environmentSubstitute(this.proxyHost);
/* 1059 */       String realProxy_username = environmentSubstitute(this.proxyUsername);
/* 1060 */       String realProxy_password = environmentSubstitute(this.proxyPassword);
/*      */       
/* 1062 */       this.ftpsclient.setProxyHost(realProxy_host);
/* 1063 */       if (!Const.isEmpty(realProxy_username)) {
/* 1064 */         this.ftpsclient.setProxyUser(realProxy_username);
/*      */       }
/* 1066 */       if (!Const.isEmpty(realProxy_password)) {
/* 1067 */         this.ftpsclient.setProxyPassword(realProxy_password);
/*      */       }
/* 1069 */       if (isDetailed()) {
/* 1070 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.OpenedProxyConnectionOn", new String[] { realProxy_host }));
/*      */       }
/* 1072 */       int proxyport = Const.toInt(environmentSubstitute(this.proxyPort), 21);
/* 1073 */       if (proxyport != 0) {
/* 1074 */         this.ftpsclient.setProxyPort(proxyport);
/*      */       }
/*      */     }
/* 1077 */     else if (isDetailed()) {
/* 1078 */       logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.OpenedConnectionTo", new String[] { realservername }));
/*      */     }
/*      */     
/*      */ 
/* 1082 */     if (this.activeConnection)
/*      */     {
/* 1084 */       this.ftpsclient.setPassiveMode(false);
/* 1085 */       if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.SetActive", new String[0]));
/*      */     }
/*      */     else
/*      */     {
/* 1089 */       this.ftpsclient.setPassiveMode(true);
/* 1090 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.SetPassive", new String[0]));
/*      */       }
/*      */     }
/*      */     
/* 1094 */     this.ftpsclient.setTimeOut(realtimeout);
/* 1095 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.SetTimeout", new String[] { String.valueOf(realtimeout) }));
/*      */     }
/*      */     
/* 1098 */     this.ftpsclient.connect();
/*      */     
/*      */ 
/* 1101 */     if (!Const.isEmpty(realFTPDirectory))
/*      */     {
/* 1103 */       this.ftpsclient.changeDirectory(realFTPDirectory);
/* 1104 */       if (isDetailed()) { logDetailed("Changed to directory [" + realFTPDirectory + "]");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void FTPConnect(String realServername, String realusername, String realpassword, int realport, String realFtpDirectory, String realProxyhost, String realproxyusername, String realproxypassword, int realproxyport, int realtimeout)
/*      */     throws Exception
/*      */   {
/* 1115 */     this.ftpclient = new FTPClient();
/* 1116 */     this.ftpclient.setRemoteAddr(InetAddress.getByName(realServername));
/* 1117 */     if (realport != 0) { this.ftpclient.setRemotePort(realport);
/*      */     }
/* 1119 */     if (!Const.isEmpty(realProxyhost))
/*      */     {
/* 1121 */       this.ftpclient.setRemoteAddr(InetAddress.getByName(realProxyhost));
/* 1122 */       if (isDetailed()) {
/* 1123 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.OpenedProxyConnectionOn", new String[] { realProxyhost }));
/*      */       }
/*      */       
/* 1126 */       if (realproxyport != 0)
/*      */       {
/* 1128 */         this.ftpclient.setRemotePort(realproxyport);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1133 */       this.ftpclient.setRemoteAddr(InetAddress.getByName(realServername));
/*      */       
/* 1135 */       if (isDetailed()) {
/* 1136 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.OpenedConnectionTo", new String[] { realServername }));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1141 */     if (this.activeConnection)
/*      */     {
/* 1143 */       this.ftpclient.setConnectMode(FTPConnectMode.ACTIVE);
/* 1144 */       if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.SetActive", new String[0]));
/*      */     }
/*      */     else
/*      */     {
/* 1148 */       this.ftpclient.setConnectMode(FTPConnectMode.PASV);
/* 1149 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.SetPassive", new String[0]));
/*      */       }
/*      */     }
/*      */     
/* 1153 */     this.ftpclient.setTimeout(realtimeout);
/* 1154 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.SetTimeout", new String[] { String.valueOf(realtimeout) }));
/*      */     }
/*      */     
/* 1157 */     this.ftpclient.connect();
/*      */     
/* 1159 */     String realUsername = realusername + (!Const.isEmpty(realProxyhost) ? "@" + realServername : "") + (!Const.isEmpty(realproxyusername) ? " " + realproxyusername : "");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1164 */     String realPassword = realpassword + (!Const.isEmpty(realproxypassword) ? " " + realproxypassword : "");
/*      */     
/*      */ 
/*      */ 
/* 1168 */     this.ftpclient.login(realUsername, realPassword);
/*      */     
/* 1170 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.LoggedIn", new String[] { realUsername }));
/*      */     }
/*      */     
/* 1173 */     if (!Const.isEmpty(realFtpDirectory))
/*      */     {
/* 1175 */       this.ftpclient.chdir(realFtpDirectory);
/* 1176 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPDelete.ChangedDir", new String[] { realFtpDirectory }));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void updateErrors()
/*      */   {
/* 1184 */     this.NrErrors += 1L;
/* 1185 */     if (!getStatus())
/*      */     {
/*      */ 
/* 1188 */       this.successConditionBroken = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateDeletedFiles() {
/* 1193 */     this.NrfilesDeleted += 1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean evaluates()
/*      */   {
/* 1200 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActiveConnection()
/*      */   {
/* 1209 */     return this.activeConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setActiveConnection(boolean passive)
/*      */   {
/* 1217 */     this.activeConnection = passive;
/*      */   }
/*      */   
/*      */ 
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1223 */     JobEntryValidatorUtils.andValidator().validate(this, "serverName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1224 */     JobEntryValidatorUtils.andValidator().validate(this, "targetDirectory", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() }));
/*      */     
/* 1226 */     JobEntryValidatorUtils.andValidator().validate(this, "userName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1227 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */   }
/*      */   
/*      */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*      */   {
/* 1232 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 1233 */     if (!Const.isEmpty(this.serverName))
/*      */     {
/* 1235 */       String realServername = jobMeta.environmentSubstitute(this.serverName);
/* 1236 */       ResourceReference reference = new ResourceReference(this);
/* 1237 */       reference.getEntries().add(new ResourceEntry(realServername, ResourceEntry.ResourceType.SERVER));
/* 1238 */       references.add(reference);
/*      */     }
/* 1240 */     return references;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyHost()
/*      */   {
/* 1247 */     return this.socksProxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyPort()
/*      */   {
/* 1254 */     return this.socksProxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyUsername()
/*      */   {
/* 1261 */     return this.socksProxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getSocksProxyPassword()
/*      */   {
/* 1268 */     return this.socksProxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocksProxyHost(String socksProxyHost)
/*      */   {
/* 1275 */     this.socksProxyHost = socksProxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocksProxyPort(String socksProxyPort)
/*      */   {
/* 1282 */     this.socksProxyPort = socksProxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocksProxyUsername(String socksProxyUsername)
/*      */   {
/* 1289 */     this.socksProxyUsername = socksProxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSocksProxyPassword(String socksProxyPassword)
/*      */   {
/* 1296 */     this.socksProxyPassword = socksProxyPassword;
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftpdelete\JobEntryFTPDelete.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */