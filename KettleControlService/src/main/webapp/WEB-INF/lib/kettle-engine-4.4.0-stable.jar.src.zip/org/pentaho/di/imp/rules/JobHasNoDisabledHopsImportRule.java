/*    */ package org.pentaho.di.imp.rules;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.xml.XMLHandler;
/*    */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*    */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*    */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*    */ import org.pentaho.di.job.JobHopMeta;
/*    */ import org.pentaho.di.job.JobMeta;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobHasNoDisabledHopsImportRule
/*    */   extends BaseImportRule
/*    */   implements ImportRuleInterface
/*    */ {
/*    */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*    */   {
/* 46 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*    */     
/* 48 */     if (!isEnabled()) return feedback;
/* 49 */     if (!(subject instanceof JobMeta)) { return feedback;
/*    */     }
/* 51 */     JobMeta jobMeta = (JobMeta)subject;
/*    */     
/* 53 */     for (int i = 0; i < jobMeta.nrJobHops(); i++) {
/* 54 */       JobHopMeta hop = jobMeta.getJobHop(i);
/* 55 */       if (!hop.isEnabled()) {
/* 56 */         feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "There is a disabled hop in the job."));
/*    */       }
/*    */     }
/*    */     
/* 60 */     if (feedback.isEmpty()) {
/* 61 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "All hops are enabled in this job."));
/*    */     }
/*    */     
/* 64 */     return feedback;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getXML()
/*    */   {
/* 70 */     StringBuilder xml = new StringBuilder();
/* 71 */     xml.append(XMLHandler.openTag(XML_TAG));
/*    */     
/* 73 */     xml.append(super.getXML());
/*    */     
/* 75 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 76 */     return xml.toString();
/*    */   }
/*    */   
/*    */   public void loadXML(Node ruleNode) throws KettleException
/*    */   {
/* 81 */     super.loadXML(ruleNode);
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\JobHasNoDisabledHopsImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */