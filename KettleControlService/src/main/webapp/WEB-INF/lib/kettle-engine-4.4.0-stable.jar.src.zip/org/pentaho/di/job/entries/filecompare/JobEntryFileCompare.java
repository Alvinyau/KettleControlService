/*     */ package org.pentaho.di.job.entries.filecompare;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleFileException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFileCompare
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  74 */   private static Class<?> PKG = JobEntryFileCompare.class;
/*     */   
/*     */   private String filename1;
/*     */   private String filename2;
/*     */   private boolean addFilenameToResult;
/*     */   
/*     */   public JobEntryFileCompare(String n)
/*     */   {
/*  82 */     super(n, "");
/*  83 */     this.filename1 = null;
/*  84 */     this.filename2 = null;
/*  85 */     this.addFilenameToResult = false;
/*  86 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryFileCompare()
/*     */   {
/*  91 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  96 */     JobEntryFileCompare je = (JobEntryFileCompare)super.clone();
/*  97 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 102 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 104 */     retval.append(super.getXML());
/* 105 */     retval.append("      ").append(XMLHandler.addTagValue("filename1", this.filename1));
/* 106 */     retval.append("      ").append(XMLHandler.addTagValue("filename2", this.filename2));
/* 107 */     retval.append("      ").append(XMLHandler.addTagValue("add_filename_result", this.addFilenameToResult));
/* 108 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 116 */       super.loadXML(entrynode, databases, slaveServers);
/* 117 */       this.filename1 = XMLHandler.getTagValue(entrynode, "filename1");
/* 118 */       this.filename2 = XMLHandler.getTagValue(entrynode, "filename2");
/* 119 */       this.addFilenameToResult = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_filename_result"));
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 123 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0001_Unable_To_Load_From_Xml_Node", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 131 */       this.filename1 = rep.getJobEntryAttributeString(id_jobentry, "filename1");
/* 132 */       this.filename2 = rep.getJobEntryAttributeString(id_jobentry, "filename2");
/* 133 */       this.addFilenameToResult = rep.getJobEntryAttributeBoolean(id_jobentry, "add_filename_result");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 137 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0002_Unable_To_Load_Job_From_Repository", new Object[] { id_jobentry }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 145 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename1", this.filename1);
/* 146 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename2", this.filename2);
/* 147 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_filename_result", this.addFilenameToResult);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 151 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0003_Unable_To_Save_Job", new Object[] { id_job }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getRealFilename1()
/*     */   {
/* 157 */     return environmentSubstitute(getFilename1());
/*     */   }
/*     */   
/*     */   public String getRealFilename2()
/*     */   {
/* 162 */     return environmentSubstitute(getFilename2());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean equalFileContents(FileObject file1, FileObject file2)
/*     */     throws KettleFileException
/*     */   {
/* 178 */     DataInputStream in1 = null;
/* 179 */     DataInputStream in2 = null;
/*     */     try {
/* 181 */       in1 = new DataInputStream(new BufferedInputStream(KettleVFS.getInputStream(KettleVFS.getFilename(file1), this)));
/* 182 */       in2 = new DataInputStream(new BufferedInputStream(KettleVFS.getInputStream(KettleVFS.getFilename(file2), this)));
/*     */       
/*     */       boolean bool;
/* 185 */       while ((in1.available() != 0) && (in2.available() != 0))
/*     */       {
/* 187 */         char ch1 = (char)in1.readByte();
/* 188 */         char ch2 = (char)in2.readByte();
/* 189 */         if (ch1 != ch2)
/* 190 */           return false;
/*     */       }
/* 192 */       if (in1.available() != in2.available())
/*     */       {
/* 194 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 198 */       return true;
/*     */     }
/*     */     catch (IOException e) {
/* 201 */       throw new KettleFileException(e);
/*     */     } finally {
/* 203 */       if (in1 != null) {
/*     */         try {
/* 205 */           in1.close();
/*     */         }
/*     */         catch (IOException ignored) {}
/*     */       }
/*     */       
/* 210 */       if (in2 != null) {
/*     */         try {
/* 212 */           in2.close();
/*     */         }
/*     */         catch (IOException ignored) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 222 */     Result result = previousResult;
/* 223 */     result.setResult(false);
/*     */     
/* 225 */     String realFilename1 = getRealFilename1();
/* 226 */     String realFilename2 = getRealFilename2();
/*     */     
/* 228 */     FileObject file1 = null;
/* 229 */     FileObject file2 = null;
/*     */     try
/*     */     {
/* 232 */       if ((this.filename1 != null) && (this.filename2 != null))
/*     */       {
/* 234 */         file1 = KettleVFS.getFileObject(realFilename1, this);
/* 235 */         file2 = KettleVFS.getFileObject(realFilename2, this);
/*     */         
/* 237 */         if ((file1.exists()) && (file2.exists()))
/*     */         {
/* 239 */           if (equalFileContents(file1, file2))
/*     */           {
/* 241 */             result.setResult(true);
/*     */           }
/*     */           else
/*     */           {
/* 245 */             result.setResult(false);
/*     */           }
/*     */           
/*     */ 
/* 249 */           if ((this.addFilenameToResult) && (file1.getType() == FileType.FILE) && (file2.getType() == FileType.FILE))
/*     */           {
/* 251 */             ResultFile resultFile = new ResultFile(0, file1, this.parentJob.getJobname(), toString());
/* 252 */             resultFile.setComment(BaseMessages.getString(PKG, "JobWaitForFile.FilenameAdded", new String[0]));
/* 253 */             result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/* 254 */             resultFile = new ResultFile(0, file2, this.parentJob.getJobname(), toString());
/* 255 */             resultFile.setComment(BaseMessages.getString(PKG, "JobWaitForFile.FilenameAdded", new String[0]));
/* 256 */             result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 261 */           if (!file1.exists())
/* 262 */             logError(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0004_File1_Does_Not_Exist", new String[] { realFilename1 }));
/* 263 */           if (!file2.exists())
/* 264 */             logError(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0005_File2_Does_Not_Exist", new String[] { realFilename2 }));
/* 265 */           result.setResult(false);
/* 266 */           result.setNrErrors(1L);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 271 */         logError(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0006_Need_Two_Filenames", new String[0]));
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 276 */       result.setResult(false);
/* 277 */       result.setNrErrors(1L);
/* 278 */       logError(BaseMessages.getString(PKG, "JobEntryFileCompare.ERROR_0007_Comparing_Files", new String[] { realFilename2, realFilename2, e.getMessage() }));
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 284 */         if (file1 != null) {
/* 285 */           file1.close();
/* 286 */           file1 = null;
/*     */         }
/*     */         
/* 289 */         if (file2 != null) {
/* 290 */           file2.close();
/* 291 */           file2 = null;
/*     */         }
/*     */       }
/*     */       catch (IOException e) {}
/*     */     }
/*     */     
/*     */ 
/* 298 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 303 */     return true;
/*     */   }
/*     */   
/*     */   public void setFilename1(String filename)
/*     */   {
/* 308 */     this.filename1 = filename;
/*     */   }
/*     */   
/*     */   public String getFilename1()
/*     */   {
/* 313 */     return this.filename1;
/*     */   }
/*     */   
/*     */   public void setFilename2(String filename)
/*     */   {
/* 318 */     this.filename2 = filename;
/*     */   }
/*     */   
/*     */   public String getFilename2()
/*     */   {
/* 323 */     return this.filename2;
/*     */   }
/*     */   
/* 326 */   public boolean isAddFilenameToResult() { return this.addFilenameToResult; }
/*     */   
/*     */ 
/*     */ 
/* 330 */   public void setAddFilenameToResult(boolean addFilenameToResult) { this.addFilenameToResult = addFilenameToResult; }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 333 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 334 */     if ((!Const.isEmpty(this.filename1)) && (!Const.isEmpty(this.filename2))) {
/* 335 */       String realFilename1 = jobMeta.environmentSubstitute(this.filename1);
/* 336 */       String realFilename2 = jobMeta.environmentSubstitute(this.filename2);
/* 337 */       ResourceReference reference = new ResourceReference(this);
/* 338 */       reference.getEntries().add(new ResourceEntry(realFilename1, ResourceEntry.ResourceType.FILE));
/* 339 */       reference.getEntries().add(new ResourceEntry(realFilename2, ResourceEntry.ResourceType.FILE));
/* 340 */       references.add(reference);
/*     */     }
/* 342 */     return references;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {
/* 346 */     ValidatorContext ctx = new ValidatorContext();
/* 347 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 348 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 349 */     JobEntryValidatorUtils.andValidator().validate(this, "filename1", remarks, ctx);
/* 350 */     JobEntryValidatorUtils.andValidator().validate(this, "filename2", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\filecompare\JobEntryFileCompare.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */