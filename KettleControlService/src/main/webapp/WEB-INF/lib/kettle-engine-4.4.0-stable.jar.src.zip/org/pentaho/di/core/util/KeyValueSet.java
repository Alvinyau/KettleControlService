/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.collections.Closure;
/*     */ import org.apache.commons.collections.Predicate;
/*     */ import org.apache.commons.collections.functors.TruePredicate;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ import org.apache.commons.lang.builder.ToStringStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyValueSet
/*     */   implements Iterable<KeyValue<?>>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 925133158112717153L;
/*  50 */   private final Map<String, KeyValue<?>> entries = new TreeMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValueSet add(KeyValue<?>... keyValues)
/*     */   {
/*  60 */     for (KeyValue<?> keyValue : keyValues) {
/*  61 */       if (this.entries.containsKey(keyValue.getKey())) {
/*  62 */         throw new IllegalArgumentException("Key already added [key=" + keyValue.getKey() + "]");
/*     */       }
/*  64 */       this.entries.put(keyValue.getKey(), keyValue);
/*     */     }
/*  66 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<KeyValue<?>> iterator()
/*     */   {
/*  75 */     return keyValues().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue<?> get(String key)
/*     */   {
/*  84 */     if (key == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     return (KeyValue)this.entries.get(StringUtils.lowerCase(key));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<KeyValue<?>> get(Predicate filter)
/*     */     throws IllegalArgumentException
/*     */   {
/*  98 */     AddClosureArrayList<KeyValue<?>> result = new AddClosureArrayList();
/*  99 */     walk(result, filter);
/* 100 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue<?> getRequired(String key)
/*     */   {
/* 109 */     KeyValue<?> keyValue = get(key);
/* 110 */     if (keyValue == null) {
/* 111 */       throw new IllegalArgumentException("Entry not found [key=" + key + "]");
/*     */     }
/* 113 */     return keyValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<String> keys()
/*     */   {
/* 120 */     return new ArrayList(this.entries.keySet());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<KeyValue<?>> keyValues()
/*     */   {
/* 127 */     return new ArrayList(this.entries.values());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Object> values()
/*     */   {
/* 134 */     List<Object> result = new ArrayList();
/* 135 */     for (KeyValue<?> keyValue : this.entries.values()) {
/* 136 */       result.add(keyValue.getValue());
/*     */     }
/* 138 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Object> toMap()
/*     */   {
/* 145 */     Map<String, Object> map = new TreeMap();
/* 146 */     for (KeyValue<?> keyValue : this.entries.values()) {
/* 147 */       map.put(keyValue.getKey(), keyValue.getValue());
/*     */     }
/* 149 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void walk(Closure handler, Predicate filter)
/*     */     throws IllegalArgumentException
/*     */   {
/* 163 */     Assert.assertNotNull(handler, "Handler cannot be null");
/* 164 */     Assert.assertNotNull(filter, "Filter cannot be null");
/* 165 */     for (KeyValue<?> keyValue : this.entries.values()) {
/* 166 */       if (filter.evaluate(keyValue)) {
/* 167 */         handler.execute(keyValue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void walk(Closure handler)
/*     */     throws IllegalArgumentException
/*     */   {
/* 181 */     walk(handler, TruePredicate.INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue<?> remove(String key)
/*     */   {
/* 190 */     if (key == null) {
/* 191 */       return null;
/*     */     }
/* 193 */     return (KeyValue)this.entries.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(String key)
/*     */   {
/* 202 */     if (key == null) {
/* 203 */       return false;
/*     */     }
/* 205 */     return this.entries.containsKey(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 212 */     return this.entries.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 219 */     return this.entries.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValueSet clear()
/*     */   {
/* 228 */     this.entries.clear();
/* 229 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toMultiLineString()
/*     */   {
/* 236 */     ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE);
/* 237 */     for (KeyValue<?> keyValue : this.entries.values()) {
/* 238 */       builder.append(keyValue.getKey(), keyValue.getValue());
/*     */     }
/* 240 */     return builder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 250 */     ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
/* 251 */     builder.append("size", size());
/* 252 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\KeyValueSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */