/*    */ package org.pentaho.di.core.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.apache.commons.collections.Closure;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddClosureArrayList<T>
/*    */   extends ArrayList<T>
/*    */   implements Closure
/*    */ {
/*    */   private static final long serialVersionUID = 2395583665248110276L;
/*    */   
/*    */   public void execute(Object input)
/*    */   {
/* 49 */     add(input);
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\AddClosureArrayList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */