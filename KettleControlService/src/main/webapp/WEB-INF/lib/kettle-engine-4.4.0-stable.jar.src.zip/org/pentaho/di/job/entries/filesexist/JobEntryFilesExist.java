/*     */ package org.pentaho.di.job.entries.filesexist;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFilesExist
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  57 */   private static Class<?> PKG = JobEntryFilesExist.class;
/*     */   
/*     */   private String filename;
/*     */   
/*     */   public String[] arguments;
/*     */   
/*     */   public JobEntryFilesExist(String n)
/*     */   {
/*  65 */     super(n, "");
/*  66 */     this.filename = null;
/*  67 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryFilesExist()
/*     */   {
/*  72 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  77 */     JobEntryFilesExist je = (JobEntryFilesExist)super.clone();
/*  78 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  83 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  85 */     retval.append(super.getXML());
/*  86 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/*     */     
/*  88 */     retval.append("      <fields>").append(Const.CR);
/*  89 */     if (this.arguments != null) {
/*  90 */       for (int i = 0; i < this.arguments.length; i++) {
/*  91 */         retval.append("        <field>").append(Const.CR);
/*  92 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.arguments[i]));
/*  93 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/*  96 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/*  98 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 105 */       super.loadXML(entrynode, databases, slaveServers);
/* 106 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/*     */       
/* 108 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 111 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 112 */       this.arguments = new String[nrFields];
/*     */       
/*     */ 
/* 115 */       for (int i = 0; i < nrFields; i++) {
/* 116 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 118 */         this.arguments[i] = XMLHandler.getTagValue(fnode, "name");
/*     */       }
/*     */       
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 124 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryFilesExist.ERROR_0001_Cannot_Load_Job_Entry_From_Xml_Node", new String[] { xe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 132 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/*     */       
/*     */ 
/* 135 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "name");
/* 136 */       this.arguments = new String[argnr];
/*     */       
/*     */ 
/* 139 */       for (int a = 0; a < argnr; a++)
/*     */       {
/* 141 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "name");
/*     */       }
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 146 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryFilesExist.ERROR_0002_Cannot_Load_Job_From_Repository", new String[] { "" + id_jobentry, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 154 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/*     */       
/*     */ 
/* 157 */       if (this.arguments != null) {
/* 158 */         for (int i = 0; i < this.arguments.length; i++) {
/* 159 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "name", this.arguments[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 165 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryFilesExist.ERROR_0003_Cannot_Save_Job_Entry", new String[] { "" + id_job, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFilename(String filename)
/*     */   {
/* 171 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 176 */     return this.filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 183 */     Result result = previousResult;
/* 184 */     result.setResult(false);
/* 185 */     int missingfiles = 0;
/*     */     
/* 187 */     if (this.arguments != null)
/*     */     {
/* 189 */       for (int i = 0; (i < this.arguments.length) && (!this.parentJob.isStopped()); i++)
/*     */       {
/* 191 */         FileObject file = null;
/*     */         
/*     */         try
/*     */         {
/* 195 */           String realFilefoldername = environmentSubstitute(this.arguments[i]);
/* 196 */           file = KettleVFS.getFileObject(realFilefoldername, this);
/*     */           
/* 198 */           if ((file.exists()) && (file.isReadable()))
/*     */           {
/* 200 */             if (this.log.isDetailed()) {
/* 201 */               logDetailed(BaseMessages.getString(PKG, "JobEntryFilesExist.File_Exists", new String[] { realFilefoldername }));
/*     */             }
/*     */           }
/*     */           else {
/* 205 */             missingfiles++;
/* 206 */             result.setNrErrors(missingfiles);
/* 207 */             if (this.log.isDetailed()) {
/* 208 */               logDetailed(BaseMessages.getString(PKG, "JobEntryFilesExist.File_Does_Not_Exist", new String[] { realFilefoldername }));
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 214 */           missingfiles++;
/* 215 */           result.setNrErrors(missingfiles);
/* 216 */           logError(BaseMessages.getString(PKG, "JobEntryFilesExist.ERROR_0004_IO_Exception", new String[] { e.toString() }), e);
/*     */         }
/*     */         finally
/*     */         {
/* 220 */           if (file != null) try { file.close();file = null;
/*     */             }
/*     */             catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */     }
/* 226 */     if (missingfiles == 0) {
/* 227 */       result.setResult(true);
/*     */     }
/* 229 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 234 */     return true;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\filesexist\JobEntryFilesExist.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */