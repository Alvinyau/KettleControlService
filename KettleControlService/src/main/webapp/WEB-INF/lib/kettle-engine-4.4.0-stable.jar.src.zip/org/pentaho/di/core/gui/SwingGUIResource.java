/*     */ package org.pentaho.di.core.gui;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.logging.LogChannel;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.plugins.JobEntryPluginType;
/*     */ import org.pentaho.di.core.plugins.PluginInterface;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.plugins.StepPluginType;
/*     */ import org.pentaho.reporting.libraries.base.util.WaitingImageObserver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingGUIResource
/*     */ {
/*  44 */   private static LogChannelInterface log = new LogChannel("SwingGUIResource");
/*     */   private static SwingGUIResource instance;
/*     */   private Map<String, BufferedImage> stepImages;
/*     */   private Map<String, BufferedImage> entryImages;
/*     */   
/*     */   private SwingGUIResource()
/*     */     throws KettleException
/*     */   {
/*  52 */     this.stepImages = loadStepImages();
/*  53 */     this.entryImages = loadEntryImages();
/*     */   }
/*     */   
/*     */   public static SwingGUIResource getInstance() throws KettleException {
/*  57 */     if (instance == null) {
/*  58 */       instance = new SwingGUIResource();
/*     */     }
/*  60 */     return instance;
/*     */   }
/*     */   
/*     */   private Map<String, BufferedImage> loadStepImages() throws KettleException {
/*  64 */     Map<String, BufferedImage> map = new HashMap();
/*     */     
/*  66 */     for (PluginInterface plugin : PluginRegistry.getInstance().getPlugins(StepPluginType.class)) {
/*     */       try {
/*  68 */         BufferedImage image = getImageIcon(plugin);
/*  69 */         for (String id : plugin.getIds()) {
/*  70 */           map.put(id, image);
/*     */         }
/*     */       } catch (Exception e) {
/*  73 */         log.logError("Unable to load step icon image for plugin: " + plugin.getName() + " (id=" + plugin.getIds()[0], e);
/*     */         try {
/*  75 */           getImageIcon(plugin);
/*     */         }
/*     */         catch (Exception ex) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  82 */     return map;
/*     */   }
/*     */   
/*     */   private Map<String, BufferedImage> loadEntryImages() throws KettleException {
/*  86 */     Map<String, BufferedImage> map = new HashMap();
/*     */     
/*  88 */     for (PluginInterface plugin : PluginRegistry.getInstance().getPlugins(JobEntryPluginType.class)) {
/*     */       try {
/*  90 */         if (!"SPECIAL".equals(plugin.getIds()[0]))
/*     */         {
/*     */ 
/*     */ 
/*  94 */           String imageFile = plugin.getImageFile();
/*  95 */           if (imageFile == null) {
/*  96 */             throw new KettleException("No image file (icon) specified for plugin: " + plugin);
/*     */           }
/*     */           
/*  99 */           BufferedImage image = getImageIcon(plugin);
/* 100 */           if (image == null) {
/* 101 */             throw new KettleException("Unable to find image file: " + plugin.getImageFile() + " for plugin: " + plugin);
/*     */           }
/* 103 */           if (image.getHeight(null) < 0) {
/* 104 */             image = getImageIcon(plugin);
/* 105 */             if ((image == null) || (image.getHeight(null) < 0)) {
/* 106 */               throw new KettleException("Unable to load image file: " + plugin.getImageFile() + " for plugin: " + plugin);
/*     */             }
/*     */           }
/*     */           
/* 110 */           map.put(plugin.getIds()[0], image);
/*     */         }
/* 112 */       } catch (Exception e) { log.logError("Unable to load job entry icon image for plugin: " + plugin.getName() + " (id=" + plugin.getIds()[0], e);
/*     */       }
/*     */     }
/*     */     
/* 116 */     return map;
/*     */   }
/*     */   
/*     */   private BufferedImage getImageIcon(PluginInterface plugin) throws KettleException {
/*     */     try {
/* 121 */       PluginRegistry registry = PluginRegistry.getInstance();
/* 122 */       String filename = plugin.getImageFile();
/*     */       
/* 124 */       ClassLoader classLoader = registry.getClassLoader(plugin);
/*     */       
/*     */ 
/*     */ 
/* 128 */       InputStream inputStream = classLoader.getResourceAsStream(filename);
/* 129 */       if (inputStream == null) {
/* 130 */         inputStream = classLoader.getResourceAsStream("/" + classLoader);
/*     */       }
/*     */       
/*     */ 
/* 134 */       if (inputStream == null) {
/* 135 */         inputStream = registry.getClass().getResourceAsStream(plugin.getImageFile());
/*     */       }
/* 137 */       if (inputStream == null) {
/* 138 */         inputStream = registry.getClass().getResourceAsStream("/" + plugin.getImageFile());
/*     */       }
/*     */       
/*     */ 
/* 142 */       if (inputStream == null) {
/*     */         try {
/* 144 */           inputStream = new FileInputStream(plugin.getImageFile());
/*     */         }
/*     */         catch (FileNotFoundException e) {}
/*     */       }
/*     */       
/*     */ 
/* 150 */       if (inputStream == null) {
/* 151 */         throw new KettleException("Unable to find file: " + plugin.getImageFile() + " for plugin: " + plugin);
/*     */       }
/*     */       
/* 154 */       BufferedImage image = ImageIO.read(inputStream);
/* 155 */       inputStream.close();
/*     */       
/* 157 */       WaitingImageObserver wia = new WaitingImageObserver(image);
/* 158 */       wia.waitImageLoaded();
/*     */       
/* 160 */       return image;
/*     */     } catch (Throwable e) {
/* 162 */       throw new KettleException("Unable to load image from file : '" + plugin.getImageFile() + "' for plugin: " + plugin, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, BufferedImage> getEntryImages() {
/* 167 */     return this.entryImages;
/*     */   }
/*     */   
/*     */   public Map<String, BufferedImage> getStepImages() {
/* 171 */     return this.stepImages;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\SwingGUIResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */