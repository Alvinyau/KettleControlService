/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.row.RowMeta;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.repository.RepositoryAttributeInterface;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobLogTable
/*     */   extends BaseLogTable
/*     */   implements Cloneable, LogTableInterface
/*     */ {
/*  53 */   private static Class<?> PKG = JobLogTable.class;
/*     */   public static final String XML_TAG = "job-log-table";
/*     */   private String logInterval;
/*     */   private String logSizeLimit;
/*     */   
/*     */   public static enum ID {
/*  59 */     ID_JOB("ID_JOB"), 
/*  60 */     CHANNEL_ID("CHANNEL_ID"), 
/*  61 */     JOBNAME("JOBNAME"), 
/*  62 */     STATUS("STATUS"), 
/*  63 */     LINES_READ("LINES_READ"), 
/*  64 */     LINES_WRITTEN("LINES_WRITTEN"), 
/*  65 */     LINES_UPDATED("LINES_UPDATED"), 
/*  66 */     LINES_INPUT("LINES_INPUT"), 
/*  67 */     LINES_OUTPUT("LINES_OUTPUT"), 
/*  68 */     LINES_REJECTED("LINES_REJECTED"), 
/*  69 */     ERRORS("ERRORS"), 
/*  70 */     STARTDATE("STARTDATE"), 
/*  71 */     ENDDATE("ENDDATE"), 
/*  72 */     LOGDATE("LOGDATE"), 
/*  73 */     DEPDATE("DEPDATE"), 
/*  74 */     REPLAYDATE("REPLAYDATE"), 
/*  75 */     LOG_FIELD("LOG_FIELD");
/*     */     
/*     */     private String id;
/*     */     
/*  79 */     private ID(String id) { this.id = id; }
/*     */     
/*     */     public String toString()
/*     */     {
/*  83 */       return this.id;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JobLogTable(VariableSpace space, HasDatabasesInterface databasesInterface)
/*     */   {
/*  92 */     super(space, databasesInterface, null, null, null);
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/*  98 */       JobLogTable table = (JobLogTable)super.clone();
/*  99 */       table.fields = new ArrayList();
/* 100 */       for (LogTableField field : this.fields) {
/* 101 */         table.fields.add((LogTableField)field.clone());
/*     */       }
/* 103 */       return table;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 111 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 113 */     retval.append(XMLHandler.openTag("job-log-table"));
/* 114 */     retval.append(XMLHandler.addTagValue("connection", this.connectionName));
/* 115 */     retval.append(XMLHandler.addTagValue("schema", this.schemaName));
/* 116 */     retval.append(XMLHandler.addTagValue("table", this.tableName));
/* 117 */     retval.append(XMLHandler.addTagValue("size_limit_lines", this.logSizeLimit));
/* 118 */     retval.append(XMLHandler.addTagValue("interval", this.logInterval));
/* 119 */     retval.append(XMLHandler.addTagValue("timeout_days", this.timeoutInDays));
/* 120 */     retval.append(super.getFieldsXML());
/* 121 */     retval.append(XMLHandler.closeTag("job-log-table")).append(Const.CR);
/*     */     
/* 123 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node node, List<DatabaseMeta> databases) {
/* 127 */     this.connectionName = XMLHandler.getTagValue(node, "connection");
/* 128 */     this.schemaName = XMLHandler.getTagValue(node, "schema");
/* 129 */     this.tableName = XMLHandler.getTagValue(node, "table");
/* 130 */     this.logSizeLimit = XMLHandler.getTagValue(node, "size_limit_lines");
/* 131 */     this.logInterval = XMLHandler.getTagValue(node, "interval");
/* 132 */     this.timeoutInDays = XMLHandler.getTagValue(node, "timeout_days");
/*     */     
/* 134 */     super.loadFieldsXML(node);
/*     */   }
/*     */   
/*     */   public void saveToRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 138 */     super.saveToRepository(attributeInterface);
/*     */     
/*     */ 
/*     */ 
/* 142 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_INTERVAL, this.logInterval);
/* 143 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_SIZE_LIMIT, this.logSizeLimit);
/*     */   }
/*     */   
/*     */   public void loadFromRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 147 */     super.loadFromRepository(attributeInterface);
/*     */     
/* 149 */     this.logInterval = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_INTERVAL);
/* 150 */     this.logSizeLimit = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_SIZE_LIMIT);
/*     */   }
/*     */   
/*     */   public static JobLogTable getDefault(VariableSpace space, HasDatabasesInterface databasesInterface) {
/* 154 */     JobLogTable table = new JobLogTable(space, databasesInterface);
/*     */     
/* 156 */     table.fields.add(new LogTableField(ID.ID_JOB.id, true, false, "ID_JOB", BaseMessages.getString(PKG, "JobLogTable.FieldName.BatchID", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.BatchID", new String[0]), 5, 8));
/* 157 */     table.fields.add(new LogTableField(ID.CHANNEL_ID.id, true, false, "CHANNEL_ID", BaseMessages.getString(PKG, "JobLogTable.FieldName.ChannelID", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.ChannelID", new String[0]), 2, 255));
/* 158 */     table.fields.add(new LogTableField(ID.JOBNAME.id, true, false, "JOBNAME", BaseMessages.getString(PKG, "JobLogTable.FieldName.JobName", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.JobName", new String[0]), 2, 255));
/* 159 */     table.fields.add(new LogTableField(ID.STATUS.id, true, false, "STATUS", BaseMessages.getString(PKG, "JobLogTable.FieldName.Status", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.Status", new String[0]), 2, 15));
/* 160 */     table.fields.add(new LogTableField(ID.LINES_READ.id, true, false, "LINES_READ", BaseMessages.getString(PKG, "JobLogTable.FieldName.LinesRead", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LinesRead", new String[0]), 5, 18));
/* 161 */     table.fields.add(new LogTableField(ID.LINES_WRITTEN.id, true, false, "LINES_WRITTEN", BaseMessages.getString(PKG, "JobLogTable.FieldName.LinesWritten", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LinesWritten", new String[0]), 5, 18));
/* 162 */     table.fields.add(new LogTableField(ID.LINES_UPDATED.id, true, false, "LINES_UPDATED", BaseMessages.getString(PKG, "JobLogTable.FieldName.LinesUpdated", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LinesUpdated", new String[0]), 5, 18));
/* 163 */     table.fields.add(new LogTableField(ID.LINES_INPUT.id, true, false, "LINES_INPUT", BaseMessages.getString(PKG, "JobLogTable.FieldName.LinesInput", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LinesInput", new String[0]), 5, 18));
/* 164 */     table.fields.add(new LogTableField(ID.LINES_OUTPUT.id, true, false, "LINES_OUTPUT", BaseMessages.getString(PKG, "JobLogTable.FieldName.LinesOutput", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LinesOutput", new String[0]), 5, 18));
/* 165 */     table.fields.add(new LogTableField(ID.LINES_REJECTED.id, true, false, "LINES_REJECTED", BaseMessages.getString(PKG, "JobLogTable.FieldName.LinesRejected", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LinesRejected", new String[0]), 5, 18));
/* 166 */     table.fields.add(new LogTableField(ID.ERRORS.id, true, false, "ERRORS", BaseMessages.getString(PKG, "JobLogTable.FieldName.Errors", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.Errors", new String[0]), 5, 18));
/* 167 */     table.fields.add(new LogTableField(ID.STARTDATE.id, true, false, "STARTDATE", BaseMessages.getString(PKG, "JobLogTable.FieldName.StartDateRange", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.StartDateRange", new String[0]), 3, -1));
/* 168 */     table.fields.add(new LogTableField(ID.ENDDATE.id, true, false, "ENDDATE", BaseMessages.getString(PKG, "JobLogTable.FieldName.EndDateRange", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.EndDateRange", new String[0]), 3, -1));
/* 169 */     table.fields.add(new LogTableField(ID.LOGDATE.id, true, false, "LOGDATE", BaseMessages.getString(PKG, "JobLogTable.FieldName.LogDate", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LogDate", new String[0]), 3, -1));
/* 170 */     table.fields.add(new LogTableField(ID.DEPDATE.id, true, false, "DEPDATE", BaseMessages.getString(PKG, "JobLogTable.FieldName.DepDate", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.DepDate", new String[0]), 3, -1));
/* 171 */     table.fields.add(new LogTableField(ID.REPLAYDATE.id, true, false, "REPLAYDATE", BaseMessages.getString(PKG, "JobLogTable.FieldName.ReplayDate", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.ReplayDate", new String[0]), 3, -1));
/* 172 */     table.fields.add(new LogTableField(ID.LOG_FIELD.id, true, false, "LOG_FIELD", BaseMessages.getString(PKG, "JobLogTable.FieldName.LogField", new String[0]), BaseMessages.getString(PKG, "JobLogTable.FieldDescription.LogField", new String[0]), 2, 9999999));
/*     */     
/* 174 */     table.findField(ID.ID_JOB).setKey(true);
/* 175 */     table.findField(ID.LOGDATE).setLogDateField(true);
/* 176 */     table.findField(ID.LOG_FIELD).setLogField(true);
/* 177 */     table.findField(ID.CHANNEL_ID).setVisible(false);
/* 178 */     table.findField(ID.JOBNAME).setVisible(false);
/* 179 */     table.findField(ID.STATUS).setStatusField(true);
/* 180 */     table.findField(ID.ERRORS).setErrorsField(true);
/* 181 */     table.findField(ID.JOBNAME).setNameField(true);
/*     */     
/* 183 */     return table;
/*     */   }
/*     */   
/*     */   public LogTableField findField(ID id) {
/* 187 */     return super.findField(id.id);
/*     */   }
/*     */   
/*     */   public Object getSubject(ID id) {
/* 191 */     return super.getSubject(id.id);
/*     */   }
/*     */   
/*     */   public String getSubjectString(ID id) {
/* 195 */     return super.getSubjectString(id.id);
/*     */   }
/*     */   
/*     */   public void setBatchIdUsed(boolean use) {
/* 199 */     findField(ID.ID_JOB).setEnabled(use);
/*     */   }
/*     */   
/*     */   public boolean isBatchIdUsed() {
/* 203 */     return findField(ID.ID_JOB).isEnabled();
/*     */   }
/*     */   
/*     */   public void setLogFieldUsed(boolean use) {
/* 207 */     findField(ID.LOG_FIELD).setEnabled(use);
/*     */   }
/*     */   
/*     */   public boolean isLogFieldUsed() {
/* 211 */     return findField(ID.LOG_FIELD).isEnabled();
/*     */   }
/*     */   
/*     */   public String getStepnameRead() {
/* 215 */     return getSubjectString(ID.LINES_READ);
/*     */   }
/*     */   
/*     */   public String getStepnameWritten() {
/* 219 */     return getSubjectString(ID.LINES_WRITTEN);
/*     */   }
/*     */   
/*     */   public String getStepnameInput() {
/* 223 */     return getSubjectString(ID.LINES_INPUT);
/*     */   }
/*     */   
/*     */   public String getStepnameOutput() {
/* 227 */     return getSubjectString(ID.LINES_OUTPUT);
/*     */   }
/*     */   
/*     */   public String getStepnameUpdated() {
/* 231 */     return getSubjectString(ID.LINES_UPDATED);
/*     */   }
/*     */   
/*     */   public String getStepnameRejected() {
/* 235 */     return getSubjectString(ID.LINES_REJECTED);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogInterval(String logInterval)
/*     */   {
/* 245 */     this.logInterval = logInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLogInterval()
/*     */   {
/* 256 */     return this.logInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getLogSizeLimit()
/*     */   {
/* 263 */     return this.logSizeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogSizeLimit(String logSizeLimit)
/*     */   {
/* 270 */     this.logSizeLimit = logSizeLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowMetaAndData getLogRecord(LogStatus status, Object subject, Object parent)
/*     */   {
/* 279 */     if ((subject == null) || ((subject instanceof Job))) {
/* 280 */       Job job = (Job)subject;
/* 281 */       Result result = null;
/* 282 */       if (job != null) { result = job.getResult();
/*     */       }
/* 284 */       RowMetaAndData row = new RowMetaAndData();
/*     */       
/* 286 */       for (LogTableField field : this.fields) {
/* 287 */         if (field.isEnabled()) {
/* 288 */           Object value = null;
/* 289 */           if (job != null)
/*     */           {
/* 291 */             switch (ID.valueOf(field.getId())) {
/* 292 */             case ID_JOB:  value = new Long(job.getBatchId()); break;
/* 293 */             case CHANNEL_ID:  value = job.getLogChannelId(); break;
/* 294 */             case JOBNAME:  value = job.getJobname(); break;
/* 295 */             case STATUS:  value = status.getStatus(); break;
/* 296 */             case LINES_READ:  value = result == null ? null : new Long(result.getNrLinesRead()); break;
/* 297 */             case LINES_WRITTEN:  value = result == null ? null : new Long(result.getNrLinesWritten()); break;
/* 298 */             case LINES_INPUT:  value = result == null ? null : new Long(result.getNrLinesInput()); break;
/* 299 */             case LINES_OUTPUT:  value = result == null ? null : new Long(result.getNrLinesOutput()); break;
/* 300 */             case LINES_UPDATED:  value = result == null ? null : new Long(result.getNrLinesUpdated()); break;
/* 301 */             case LINES_REJECTED:  value = result == null ? null : new Long(result.getNrLinesRejected()); break;
/* 302 */             case ERRORS:  value = result == null ? null : new Long(result.getNrErrors()); break;
/* 303 */             case STARTDATE:  value = job.getStartDate(); break;
/* 304 */             case LOGDATE:  value = job.getLogDate(); break;
/* 305 */             case ENDDATE:  value = job.getEndDate(); break;
/* 306 */             case DEPDATE:  value = job.getDepDate(); break;
/* 307 */             case REPLAYDATE:  value = job.getCurrentDate(); break;
/*     */             case LOG_FIELD: 
/* 309 */               value = getLogBuffer(job, job.getLogChannelId(), status, this.logSizeLimit);
/*     */             }
/*     */             
/*     */           }
/*     */           
/* 314 */           row.addValue(field.getFieldName(), field.getDataType(), value);
/* 315 */           row.getRowMeta().getValueMeta(row.size() - 1).setLength(field.getLength());
/*     */         }
/*     */       }
/*     */       
/* 319 */       return row;
/*     */     }
/*     */     
/* 322 */     return null;
/*     */   }
/*     */   
/*     */   public String getLogTableCode()
/*     */   {
/* 327 */     return "JOB";
/*     */   }
/*     */   
/*     */   public String getLogTableType() {
/* 331 */     return BaseMessages.getString(PKG, "JobLogTable.Type.Description", new String[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionNameVariable() {
/* 335 */     return "KETTLE_JOB_LOG_DB";
/*     */   }
/*     */   
/*     */   public String getSchemaNameVariable() {
/* 339 */     return "KETTLE_JOB_LOG_SCHEMA";
/*     */   }
/*     */   
/*     */   public String getTableNameVariable() {
/* 343 */     return "KETTLE_JOB_LOG_TABLE";
/*     */   }
/*     */   
/*     */   public List<RowMetaInterface> getRecommendedIndexes() {
/* 347 */     List<RowMetaInterface> indexes = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/* 351 */     if (isBatchIdUsed()) {
/* 352 */       RowMetaInterface batchIndex = new RowMeta();
/* 353 */       LogTableField keyField = getKeyField();
/*     */       
/* 355 */       ValueMetaInterface keyMeta = new ValueMeta(keyField.getFieldName(), keyField.getDataType());
/* 356 */       keyMeta.setLength(keyField.getLength());
/* 357 */       batchIndex.addValueMeta(keyMeta);
/*     */       
/* 359 */       indexes.add(batchIndex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 364 */     RowMetaInterface lookupIndex = new RowMeta();
/* 365 */     LogTableField errorsField = findField(ID.ERRORS);
/* 366 */     if (errorsField != null) {
/* 367 */       ValueMetaInterface valueMeta = new ValueMeta(errorsField.getFieldName(), errorsField.getDataType());
/* 368 */       valueMeta.setLength(errorsField.getLength());
/* 369 */       lookupIndex.addValueMeta(valueMeta);
/*     */     }
/* 371 */     LogTableField statusField = findField(ID.STATUS);
/* 372 */     if (statusField != null) {
/* 373 */       ValueMetaInterface valueMeta = new ValueMeta(statusField.getFieldName(), statusField.getDataType());
/* 374 */       valueMeta.setLength(statusField.getLength());
/* 375 */       lookupIndex.addValueMeta(valueMeta);
/*     */     }
/* 377 */     LogTableField transNameField = findField(ID.JOBNAME);
/* 378 */     if (transNameField != null) {
/* 379 */       ValueMetaInterface valueMeta = new ValueMeta(transNameField.getFieldName(), transNameField.getDataType());
/* 380 */       valueMeta.setLength(transNameField.getLength());
/* 381 */       lookupIndex.addValueMeta(valueMeta);
/*     */     }
/*     */     
/* 384 */     indexes.add(lookupIndex);
/*     */     
/* 386 */     return indexes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\JobLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */