/*     */ package org.pentaho.di.core.reflection;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.core.Condition;
/*     */ import org.pentaho.di.core.database.DatabaseInterface;
/*     */ import org.pentaho.di.core.plugins.JobEntryPluginType;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.plugins.StepPluginType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringSearcher
/*     */ {
/*     */   private static final String LOCAL_PACKAGE = "org.pentaho.di";
/*  42 */   private static final String[] JAVA_PACKAGES = { "java.util" };
/*     */   
/*     */ 
/*     */   private static List<String> stepPluginPackages;
/*     */   
/*     */   private static List<String> jobEntryPluginPackages;
/*     */   
/*     */ 
/*     */   public static final void findMetaData(Object object, int level, List<StringSearchResult> stringList, Object parentObject, Object grandParentObject)
/*     */   {
/*  52 */     if (level > 5) { return;
/*     */     }
/*  54 */     PluginRegistry registry = PluginRegistry.getInstance();
/*     */     
/*  56 */     if (stepPluginPackages == null)
/*     */     {
/*  58 */       stepPluginPackages = registry.getPluginPackages(StepPluginType.class);
/*     */     }
/*  60 */     if (jobEntryPluginPackages == null)
/*     */     {
/*  62 */       jobEntryPluginPackages = registry.getPluginPackages(JobEntryPluginType.class);
/*     */     }
/*     */     
/*  65 */     Class<? extends Object> baseClass = object.getClass();
/*  66 */     Field[] fields = baseClass.getDeclaredFields();
/*  67 */     for (int i = 0; i < fields.length; i++)
/*     */     {
/*  69 */       Field field = fields[i];
/*     */       
/*  71 */       boolean processThisOne = true;
/*     */       
/*  73 */       if ((field.getModifiers() & 0x10) > 0) processThisOne = false;
/*  74 */       if ((field.getModifiers() & 0x8) > 0) { processThisOne = false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  80 */       boolean sanctionedPackage = false;
/*  81 */       if (field.toString().indexOf("org.pentaho.di") >= 0) sanctionedPackage = true;
/*  82 */       for (int x = 0; (x < JAVA_PACKAGES.length) && (!sanctionedPackage); x++)
/*     */       {
/*  84 */         if (field.toString().indexOf(JAVA_PACKAGES[x]) >= 0)
/*     */         {
/*  86 */           sanctionedPackage = true;
/*     */         }
/*     */       }
/*  89 */       for (int x = 0; (x < stepPluginPackages.size()) && (!sanctionedPackage); x++)
/*     */       {
/*  91 */         if (field.toString().indexOf((String)stepPluginPackages.get(x)) >= 0) sanctionedPackage = true;
/*     */       }
/*  93 */       for (int x = 0; (x < jobEntryPluginPackages.size()) && (!sanctionedPackage); x++)
/*     */       {
/*  95 */         if (field.toString().indexOf((String)jobEntryPluginPackages.get(x)) >= 0) sanctionedPackage = true;
/*     */       }
/*  97 */       if (!sanctionedPackage) { processThisOne = false;
/*     */       }
/*     */       
/*     */ 
/* 101 */       if (processThisOne)
/*     */       {
/*     */         try
/*     */         {
/* 105 */           Object obj = field.get(object);
/* 106 */           if (obj != null)
/*     */           {
/* 108 */             stringSearchInObject(obj, level, stringList, parentObject, grandParentObject, field);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (IllegalAccessException e)
/*     */         {
/*     */ 
/* 116 */           Method method = findMethod(baseClass, field.getName());
/* 117 */           if (method != null)
/*     */           {
/*     */ 
/*     */             try
/*     */             {
/*     */ 
/*     */ 
/* 124 */               Object string = method.invoke(object, (Object[])null);
/* 125 */               if (string != null)
/*     */               {
/* 127 */                 stringSearchInObject(string, level, stringList, parentObject, grandParentObject, field);
/*     */               }
/*     */             }
/*     */             catch (Exception ex) {}
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void stringSearchInObject(Object obj, int level, List<StringSearchResult> stringList, Object parentObject, Object grandParentObject, Field field)
/*     */   {
/* 141 */     if ((obj instanceof String))
/*     */     {
/*     */ 
/* 144 */       stringList.add(new StringSearchResult((String)obj, parentObject, grandParentObject, field.getName()));
/*     */ 
/*     */     }
/* 147 */     else if ((obj instanceof String[]))
/*     */     {
/* 149 */       String[] array = (String[])obj;
/* 150 */       for (int x = 0; x < array.length; x++)
/*     */       {
/* 152 */         if (array[x] != null)
/*     */         {
/* 154 */           stringList.add(new StringSearchResult(array[x], parentObject, grandParentObject, field.getName() + " #" + (x + 1)));
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 159 */     else if ((obj instanceof Boolean))
/*     */     {
/*     */ 
/* 162 */       stringList.add(new StringSearchResult(((Boolean)obj).toString(), parentObject, grandParentObject, field.getName() + " (Boolean)"));
/*     */ 
/*     */     }
/* 165 */     else if ((obj instanceof Condition))
/*     */     {
/* 167 */       stringList.add(new StringSearchResult(((Condition)obj).toString(), parentObject, grandParentObject, field.getName() + " (Condition)"));
/*     */ 
/*     */     }
/* 170 */     else if ((obj instanceof DatabaseInterface))
/*     */     {
/*     */ 
/*     */ 
/* 174 */       DatabaseInterface databaseInterface = (DatabaseInterface)obj;
/* 175 */       findMapMetaData(databaseInterface.getAttributes(), level + 1, stringList, parentObject, grandParentObject, field);
/* 176 */       findMetaData(obj, level + 1, stringList, parentObject, grandParentObject);
/*     */ 
/*     */     }
/* 179 */     else if ((obj instanceof Map))
/*     */     {
/* 181 */       findMapMetaData((Map)obj, level, stringList, parentObject, grandParentObject, field);
/*     */ 
/*     */     }
/* 184 */     else if ((obj instanceof Object[]))
/*     */     {
/* 186 */       for (int j = 0; j < ((Object[])obj).length; j++) findMetaData(((Object[])(Object[])obj)[j], level + 1, stringList, parentObject, grandParentObject);
/*     */     }
/*     */     else
/*     */     {
/* 190 */       findMetaData(obj, level + 1, stringList, parentObject, grandParentObject);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void findMapMetaData(Map<?, ?> map, int level, List<StringSearchResult> stringList, Object parentObject, Object grandParentObject, Field field)
/*     */   {
/* 196 */     for (Object key : map.keySet())
/*     */     {
/* 198 */       Object value = map.get(key);
/* 199 */       if (key != null)
/*     */       {
/* 201 */         stringList.add(new StringSearchResult(key.toString(), parentObject, grandParentObject, field.getName() + " (Map key)"));
/*     */       }
/* 203 */       if (value != null)
/*     */       {
/* 205 */         stringList.add(new StringSearchResult(value.toString(), parentObject, grandParentObject, field.getName() + " (Map value)"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static Method findMethod(Class<? extends Object> baseClass, String name)
/*     */   {
/* 213 */     Method[] methods = baseClass.getDeclaredMethods();
/* 214 */     Method method = null;
/*     */     
/*     */ 
/* 217 */     if (method == null)
/*     */     {
/* 219 */       String getter = constructGetter(name);
/* 220 */       method = searchGetter(getter, baseClass, methods);
/*     */     }
/*     */     
/*     */ 
/* 224 */     if (method == null)
/*     */     {
/* 226 */       String getter = constructIsGetter(name);
/* 227 */       method = searchGetter(getter, baseClass, methods);
/*     */     }
/*     */     
/*     */ 
/* 231 */     if (method == null)
/*     */     {
/* 233 */       String getter = name;
/* 234 */       method = searchGetter(getter, baseClass, methods);
/*     */     }
/*     */     
/* 237 */     return method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method searchGetter(String getter, Class<?> baseClass, Method[] methods)
/*     */   {
/* 245 */     Method method = null;
/*     */     int i;
/*     */     try {
/* 248 */       method = baseClass.getMethod(getter, new Class[0]);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/* 254 */       i = 0; } for (; i < methods.length; i++)
/*     */     {
/* 256 */       String methodName = methods[i].getName();
/* 257 */       if (methodName.equalsIgnoreCase(getter))
/*     */       {
/* 259 */         return methods[i];
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 265 */     return method;
/*     */   }
/*     */   
/*     */   public static final String constructGetter(String name)
/*     */   {
/* 270 */     StringBuffer buf = new StringBuffer();
/* 271 */     buf.append("get");
/* 272 */     buf.append(name.substring(0, 1).toUpperCase());
/* 273 */     buf.append(name.substring(1));
/*     */     
/* 275 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static final String constructIsGetter(String name)
/*     */   {
/* 280 */     StringBuffer buf = new StringBuffer();
/* 281 */     buf.append("is");
/* 282 */     buf.append(name.substring(0, 1).toUpperCase());
/* 283 */     buf.append(name.substring(1));
/*     */     
/* 285 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\reflection\StringSearcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */