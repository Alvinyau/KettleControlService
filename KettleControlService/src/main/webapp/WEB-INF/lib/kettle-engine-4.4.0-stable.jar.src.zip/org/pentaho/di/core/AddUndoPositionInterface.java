package org.pentaho.di.core;

import org.pentaho.di.core.gui.Point;
import org.pentaho.di.core.gui.UndoInterface;

public abstract interface AddUndoPositionInterface
{
  public abstract void addUndoPosition(UndoInterface paramUndoInterface, Object[] paramArrayOfObject, int[] paramArrayOfInt, Point[] paramArrayOfPoint1, Point[] paramArrayOfPoint2);
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\AddUndoPositionInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */