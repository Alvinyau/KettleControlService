/*    */ package org.pentaho.di.core.playlist;
/*    */ 
/*    */ import org.apache.commons.vfs.FileObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilePlayListAll
/*    */   implements FilePlayList
/*    */ {
/* 30 */   public static final FilePlayList INSTANCE = new FilePlayListAll();
/*    */   
/*    */   public boolean isProcessingNeeded(FileObject file, long lineNr, String filePart) {
/* 33 */     return true;
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\playlist\FilePlayListAll.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */