/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.prefs.Preferences;
/*     */ import org.apache.commons.collections.Closure;
/*     */ import org.apache.commons.collections.FunctorException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PluginPropertyHandler
/*     */ {
/*     */   public static abstract class AbstractHandler
/*     */     implements Closure
/*     */   {
/*     */     public final void execute(Object property)
/*     */       throws IllegalArgumentException, FunctorException
/*     */     {
/*  55 */       Assert.assertNotNull(property, "Plugin property cannot be null");
/*     */       try {
/*  57 */         handle((PluginProperty)property);
/*     */       } catch (KettleException e) {
/*  59 */         throw new FunctorException("EXCEPTION: " + this, e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected abstract void handle(PluginProperty paramPluginProperty)
/*     */       throws KettleException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Fail
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/*     */     public static final String MESSAGE = "Forced exception";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     public static final Fail INSTANCE = new Fail();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */       throws KettleException
/*     */     {
/*  98 */       throw new KettleException("Forced exception");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AppendXml
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/* 109 */     private final StringBuilder builder = new StringBuilder();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */     {
/* 118 */       property.appendXml(this.builder);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getXml()
/*     */     {
/* 125 */       return this.builder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LoadXml
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/*     */     private final Node node;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public LoadXml(Node node)
/*     */       throws IllegalArgumentException
/*     */     {
/* 148 */       Assert.assertNotNull(node, "Node cannot be null");
/* 149 */       this.node = node;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */     {
/* 159 */       property.loadXml(this.node);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SaveToRepository
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/*     */     private final Repository repository;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final ObjectId transformationId;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final ObjectId stepId;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public SaveToRepository(Repository repository, ObjectId transformationId, ObjectId stepId)
/*     */       throws IllegalArgumentException
/*     */     {
/* 191 */       Assert.assertNotNull(repository, "Repository cannot be null");
/* 192 */       this.repository = repository;
/* 193 */       this.transformationId = transformationId;
/* 194 */       this.stepId = stepId;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */       throws KettleException
/*     */     {
/* 204 */       property.saveToRepositoryStep(this.repository, this.transformationId, this.stepId);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ReadFromRepository
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/*     */     private final Repository repository;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final ObjectId stepId;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ReadFromRepository(Repository repository, ObjectId stepId)
/*     */       throws IllegalArgumentException
/*     */     {
/* 231 */       Assert.assertNotNull(repository, "Repository cannot be null");
/* 232 */       this.repository = repository;
/* 233 */       this.stepId = stepId;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */       throws KettleException
/*     */     {
/* 243 */       property.readFromRepositoryStep(this.repository, this.stepId);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SaveToPreferences
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/*     */     private final Preferences node;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public SaveToPreferences(Preferences node)
/*     */       throws IllegalArgumentException
/*     */     {
/* 266 */       Assert.assertNotNull(node, "Node cannot be null");
/* 267 */       this.node = node;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */     {
/* 277 */       property.saveToPreferences(this.node);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class ReadFromPreferences
/*     */     extends PluginPropertyHandler.AbstractHandler
/*     */   {
/*     */     private final Preferences node;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ReadFromPreferences(Preferences node)
/*     */       throws IllegalArgumentException
/*     */     {
/* 300 */       Assert.assertNotNull(node, "Node cannot be null");
/* 301 */       this.node = node;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void handle(PluginProperty property)
/*     */     {
/* 311 */       property.readFromPreferences(this.node);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertProperties(KeyValueSet properties)
/*     */     throws IllegalArgumentException
/*     */   {
/* 323 */     Assert.assertNotNull(properties, "Properties cannot be null");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toXml(KeyValueSet properties)
/*     */     throws IllegalArgumentException
/*     */   {
/* 334 */     assertProperties(properties);
/* 335 */     AppendXml handler = new AppendXml();
/* 336 */     properties.walk(handler);
/* 337 */     return handler.getXml();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void walk(KeyValueSet properties, Closure handler)
/*     */     throws KettleException, IllegalArgumentException
/*     */   {
/* 352 */     assertProperties(properties);
/*     */     try {
/* 354 */       properties.walk(handler);
/*     */     } catch (FunctorException e) {
/* 356 */       throw ((KettleException)e.getCause());
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\PluginPropertyHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */