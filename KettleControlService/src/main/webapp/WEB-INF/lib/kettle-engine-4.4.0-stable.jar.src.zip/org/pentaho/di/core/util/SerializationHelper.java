/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Counter;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializationHelper
/*     */ {
/*     */   private static final String INDENT_STRING = "    ";
/*     */   
/*     */   public static void read(Object object, Node node)
/*     */   {
/*  65 */     Field[] fields = object.getClass().getFields();
/*     */     
/*  67 */     for (Field field : fields)
/*     */     {
/*     */ 
/*  70 */       if ((!Modifier.isFinal(field.getModifiers())) && (!Modifier.isStatic(field.getModifiers())) && (!Modifier.isTransient(field.getModifiers())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  75 */         if (!field.isAccessible()) {
/*  76 */           field.setAccessible(true);
/*     */         }
/*     */         
/*     */ 
/*  80 */         if (field.getType().isArray()) {
/*     */           try
/*     */           {
/*  83 */             Node fieldNode = XMLHandler.getSubNode(node, field.getName());
/*  84 */             if (fieldNode == null) {
/*     */               continue;
/*     */             }
/*     */             
/*     */ 
/*  89 */             String fieldClassName = XMLHandler.getTagAttribute(fieldNode, "class");
/*  90 */             Class<?> clazz = null;
/*     */             
/*  92 */             if (fieldClassName.equals("boolean")) {
/*  93 */               clazz = Boolean.TYPE;
/*  94 */             } else if (fieldClassName.equals("int")) {
/*  95 */               clazz = Integer.TYPE;
/*  96 */             } else if (fieldClassName.equals("float")) {
/*  97 */               clazz = Float.TYPE;
/*  98 */             } else if (fieldClassName.equals("double")) {
/*  99 */               clazz = Double.TYPE;
/* 100 */             } else if (fieldClassName.equals("long")) {
/* 101 */               clazz = Long.TYPE;
/*     */             }
/*     */             else {
/* 104 */               clazz = Class.forName(fieldClassName);
/*     */             }
/*     */             
/* 107 */             NodeList childrenNodes = fieldNode.getChildNodes();
/*     */             
/*     */ 
/* 110 */             int arrayLength = 0;
/* 111 */             for (int i = 0; i < childrenNodes.getLength(); i++) {
/* 112 */               Node child = childrenNodes.item(i);
/*     */               
/* 114 */               if (child.getNodeType() != 3) {
/* 115 */                 arrayLength++;
/*     */               }
/*     */             }
/*     */             
/* 119 */             Object array = Array.newInstance(clazz, arrayLength);
/*     */             
/* 121 */             field.set(object, array);
/*     */             
/* 123 */             int arrayIndex = 0;
/* 124 */             for (int i = 0; i < childrenNodes.getLength(); i++) {
/* 125 */               Node child = childrenNodes.item(i);
/* 126 */               if (child.getNodeType() != 3)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 131 */                 if ((String.class.isAssignableFrom(clazz)) || (Number.class.isAssignableFrom(clazz))) {
/* 132 */                   Constructor<?> constructor = clazz.getConstructor(new Class[] { String.class });
/* 133 */                   Object instance = constructor.newInstance(new Object[] { XMLHandler.getTagAttribute(child, "value") });
/* 134 */                   Array.set(array, arrayIndex++, instance);
/* 135 */                 } else if ((Boolean.class.isAssignableFrom(clazz)) || (Boolean.TYPE.isAssignableFrom(clazz))) {
/* 136 */                   Object value = Boolean.valueOf(XMLHandler.getTagAttribute(child, "value"));
/* 137 */                   Array.set(array, arrayIndex++, value);
/* 138 */                 } else if ((Integer.class.isAssignableFrom(clazz)) || (Integer.TYPE.isAssignableFrom(clazz))) {
/* 139 */                   Object value = Integer.valueOf(XMLHandler.getTagAttribute(child, "value"));
/* 140 */                   Array.set(array, arrayIndex++, value);
/* 141 */                 } else if ((Float.class.isAssignableFrom(clazz)) || (Float.TYPE.isAssignableFrom(clazz))) {
/* 142 */                   Object value = Float.valueOf(XMLHandler.getTagAttribute(child, "value"));
/* 143 */                   Array.set(array, arrayIndex++, value);
/* 144 */                 } else if ((Double.class.isAssignableFrom(clazz)) || (Double.TYPE.isAssignableFrom(clazz))) {
/* 145 */                   Object value = Double.valueOf(XMLHandler.getTagAttribute(child, "value"));
/* 146 */                   Array.set(array, arrayIndex++, value);
/* 147 */                 } else if ((Long.class.isAssignableFrom(clazz)) || (Long.TYPE.isAssignableFrom(clazz))) {
/* 148 */                   Object value = Long.valueOf(XMLHandler.getTagAttribute(child, "value"));
/* 149 */                   Array.set(array, arrayIndex++, value);
/*     */                 }
/*     */                 else {
/* 152 */                   Object instance = clazz.newInstance();
/*     */                   
/* 154 */                   Array.set(array, arrayIndex++, instance);
/*     */                   
/* 156 */                   read(instance, child);
/*     */                 } }
/*     */             }
/*     */           } catch (Throwable t) {
/* 160 */             t.printStackTrace();
/*     */           }
/*     */         }
/* 163 */         if (List.class.isAssignableFrom(field.getType()))
/*     */         {
/*     */           try
/*     */           {
/* 167 */             Node fieldNode = XMLHandler.getSubNode(node, field.getName());
/* 168 */             if (fieldNode == null) {
/*     */               continue;
/*     */             }
/*     */             
/*     */ 
/* 173 */             String fieldClassName = XMLHandler.getTagAttribute(fieldNode, "class");
/* 174 */             Class<?> clazz = Class.forName(fieldClassName);
/*     */             
/*     */ 
/* 177 */             List<Object> list = new ArrayList();
/* 178 */             field.set(object, list);
/*     */             
/*     */ 
/* 181 */             NodeList childrenNodes = fieldNode.getChildNodes();
/* 182 */             for (int i = 0; i < childrenNodes.getLength(); i++) {
/* 183 */               Node child = childrenNodes.item(i);
/* 184 */               if (child.getNodeType() != 3)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 189 */                 if ((String.class.isAssignableFrom(clazz)) || (Number.class.isAssignableFrom(clazz)) || (Boolean.class.isAssignableFrom(clazz))) {
/* 190 */                   Constructor<?> constructor = clazz.getConstructor(new Class[] { String.class });
/* 191 */                   Object instance = constructor.newInstance(new Object[] { XMLHandler.getTagAttribute(child, "value") });
/* 192 */                   list.add(instance);
/*     */                 }
/*     */                 else {
/* 195 */                   Object instance = clazz.newInstance();
/*     */                   
/* 197 */                   list.add(instance);
/* 198 */                   read(instance, child);
/*     */                 } }
/*     */             }
/*     */           } catch (Throwable t) {
/* 202 */             t.printStackTrace();
/*     */           }
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 208 */           Object value = XMLHandler.getTagValue(node, field.getName());
/* 209 */           if (value != null)
/*     */           {
/*     */ 
/*     */ 
/* 213 */             if ((!field.getType().isPrimitive()) || (!"".equals(value)))
/*     */             {
/* 215 */               if ("".equals(value)) {
/* 216 */                 field.set(object, value);
/* 217 */               } else if (field.getType().isPrimitive())
/*     */               {
/* 219 */                 if (Double.TYPE.isAssignableFrom(field.getType())) {
/* 220 */                   field.set(object, Double.valueOf(Double.parseDouble(value.toString())));
/* 221 */                 } else if (Float.TYPE.isAssignableFrom(field.getType())) {
/* 222 */                   field.set(object, Float.valueOf(Float.parseFloat(value.toString())));
/* 223 */                 } else if (Long.TYPE.isAssignableFrom(field.getType())) {
/* 224 */                   field.set(object, Long.valueOf(Long.parseLong(value.toString())));
/* 225 */                 } else if (Integer.TYPE.isAssignableFrom(field.getType())) {
/* 226 */                   field.set(object, Integer.valueOf(Integer.parseInt(value.toString())));
/* 227 */                 } else if (Byte.TYPE.isAssignableFrom(field.getType())) {
/* 228 */                   field.set(object, value.toString().getBytes());
/* 229 */                 } else if (Boolean.TYPE.isAssignableFrom(field.getType())) {
/* 230 */                   field.set(object, Boolean.valueOf("true".equalsIgnoreCase(value.toString())));
/*     */                 }
/* 232 */               } else if ((String.class.isAssignableFrom(field.getType())) || (Number.class.isAssignableFrom(field.getType()))) {
/* 233 */                 Constructor<?> constructor = field.getType().getConstructor(new Class[] { String.class });
/* 234 */                 Object instance = constructor.newInstance(new Object[] { value });
/* 235 */                 field.set(object, instance);
/*     */               }
/*     */               else {
/* 238 */                 Node fieldNode = XMLHandler.getSubNode(node, field.getName());
/* 239 */                 if (fieldNode == null) {
/*     */                   continue;
/*     */                 }
/*     */                 
/*     */ 
/* 244 */                 String fieldClassName = XMLHandler.getTagAttribute(fieldNode, "class");
/* 245 */                 Class<?> clazz = Class.forName(fieldClassName);
/* 246 */                 Object instance = clazz.newInstance();
/* 247 */                 field.set(object, instance);
/* 248 */                 read(instance, fieldNode);
/*     */               } }
/*     */           }
/*     */         } catch (Throwable t) {
/* 252 */           t.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void write(Object object, int indentLevel, StringBuffer buffer)
/*     */   {
/* 269 */     if (object == null) {
/* 270 */       return;
/*     */     }
/*     */     
/*     */ 
/* 274 */     Field[] fields = object.getClass().getFields();
/* 275 */     for (Field field : fields)
/*     */     {
/*     */ 
/* 278 */       if ((!Modifier.isFinal(field.getModifiers())) && (!Modifier.isStatic(field.getModifiers())) && (!Modifier.isTransient(field.getModifiers())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 283 */         if (!field.isAccessible()) {
/* 284 */           field.setAccessible(true);
/*     */         }
/*     */         try
/*     */         {
/* 288 */           Object fieldValue = field.get(object);
/*     */           
/* 290 */           if ((fieldValue == null) || (!"".equals(fieldValue)))
/*     */           {
/*     */ 
/*     */ 
/* 294 */             if ((field.getType().isPrimitive()) || (String.class.isAssignableFrom(field.getType())) || (Number.class.isAssignableFrom(field.getType()))) {
/* 295 */               indent(buffer, indentLevel);
/* 296 */               buffer.append(XMLHandler.addTagValue(field.getName(), fieldValue.toString()));
/* 297 */             } else if (field.getType().isArray())
/*     */             {
/* 299 */               int length = Array.getLength(fieldValue);
/*     */               
/*     */ 
/* 302 */               indent(buffer, indentLevel);
/* 303 */               buffer.append("<" + field.getName() + " class=\"" + fieldValue.getClass().getComponentType().getName() + "\">").append(Const.CR);
/*     */               
/* 305 */               for (int i = 0; i < length; i++) {
/* 306 */                 Object childObject = Array.get(fieldValue, i);
/*     */                 
/* 308 */                 if ((String.class.isAssignableFrom(childObject.getClass())) || (Number.class.isAssignableFrom(childObject.getClass()))) {
/* 309 */                   indent(buffer, indentLevel + 1);
/* 310 */                   buffer.append("<").append(fieldValue.getClass().getComponentType().getSimpleName());
/* 311 */                   buffer.append(" value=\"" + childObject.toString() + "\"/>").append(Const.CR);
/* 312 */                 } else if ((Boolean.class.isAssignableFrom(childObject.getClass())) || (Boolean.TYPE.isAssignableFrom(childObject.getClass())))
/*     */                 {
/* 314 */                   indent(buffer, indentLevel + 1);
/* 315 */                   buffer.append("<").append(fieldValue.getClass().getComponentType().getSimpleName());
/* 316 */                   buffer.append(" value=\"" + childObject.toString() + "\"/>").append(Const.CR);
/*     */                 }
/*     */                 else {
/* 319 */                   indent(buffer, indentLevel + 1);
/* 320 */                   buffer.append("<" + fieldValue.getClass().getComponentType().getSimpleName() + ">").append(Const.CR);
/* 321 */                   write(childObject, indentLevel + 1, buffer);
/* 322 */                   indent(buffer, indentLevel + 1);
/* 323 */                   buffer.append("</" + fieldValue.getClass().getComponentType().getSimpleName() + ">").append(Const.CR);
/*     */                 }
/*     */               }
/*     */               
/* 327 */               buffer.append("    </" + field.getName() + ">").append(Const.CR);
/* 328 */             } else if (List.class.isAssignableFrom(field.getType()))
/*     */             {
/* 330 */               List<Object> list = (List)fieldValue;
/* 331 */               if (list.size() == 0) {
/*     */                 continue;
/*     */               }
/* 334 */               Class<?> listClass = list.get(0).getClass();
/*     */               
/*     */ 
/* 337 */               indent(buffer, indentLevel);
/* 338 */               buffer.append("<" + field.getName() + " class=\"" + listClass.getName() + "\">").append(Const.CR);
/*     */               
/* 340 */               for (Object childObject : list)
/*     */               {
/* 342 */                 if ((String.class.isAssignableFrom(childObject.getClass())) || (Number.class.isAssignableFrom(childObject.getClass()))) {
/* 343 */                   indent(buffer, indentLevel + 1);
/* 344 */                   buffer.append("<").append(listClass.getSimpleName());
/* 345 */                   buffer.append(" value=\"" + childObject.toString() + "\"/>").append(Const.CR);
/* 346 */                 } else if ((Boolean.class.isAssignableFrom(childObject.getClass())) || (Boolean.TYPE.isAssignableFrom(childObject.getClass())))
/*     */                 {
/* 348 */                   indent(buffer, indentLevel + 1);
/* 349 */                   buffer.append("<").append(listClass.getSimpleName());
/* 350 */                   buffer.append(" value=\"" + childObject.toString() + "\"/>").append(Const.CR);
/*     */                 }
/*     */                 else {
/* 353 */                   indent(buffer, indentLevel + 1);
/* 354 */                   buffer.append("<" + listClass.getSimpleName() + ">").append(Const.CR);
/* 355 */                   write(childObject, indentLevel + 1, buffer);
/* 356 */                   indent(buffer, indentLevel + 1);
/* 357 */                   buffer.append("</" + listClass.getSimpleName() + ">").append(Const.CR);
/*     */                 }
/*     */               }
/*     */               
/* 361 */               indent(buffer, indentLevel);
/* 362 */               buffer.append("</" + field.getName() + ">").append(Const.CR);
/*     */             }
/*     */             else
/*     */             {
/* 366 */               indent(buffer, indentLevel);
/* 367 */               buffer.append("<" + field.getName() + " class=\"" + fieldValue.getClass().getName() + "\">").append(Const.CR);
/* 368 */               write(fieldValue, indentLevel + 1, buffer);
/*     */               
/* 370 */               indent(buffer, indentLevel);
/* 371 */               buffer.append("</" + field.getName() + ">").append(Const.CR);
/*     */             } }
/*     */         } catch (Throwable t) {
/* 374 */           t.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void saveJobRep(Object object, Repository rep, ObjectId id_job, ObjectId id_job_entry)
/*     */     throws KettleException
/*     */   {
/* 392 */     StringBuffer sb = new StringBuffer(1024);
/* 393 */     write(object, 0, sb);
/* 394 */     rep.saveJobEntryAttribute(id_job, id_job_entry, "job-xml", sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void readJobRep(Object object, Repository rep, ObjectId id_step, List<DatabaseMeta> databases)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 409 */       String jobXML = rep.getJobEntryAttributeString(id_step, "job-xml");
/* 410 */       ByteArrayInputStream bais = new ByteArrayInputStream(jobXML.getBytes());
/* 411 */       Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(bais);
/* 412 */       read(object, doc.getDocumentElement());
/*     */     } catch (ParserConfigurationException ex) {
/* 414 */       throw new KettleException(ex.getMessage(), ex);
/*     */     } catch (SAXException ex) {
/* 416 */       throw new KettleException(ex.getMessage(), ex);
/*     */     } catch (IOException ex) {
/* 418 */       throw new KettleException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void saveStepRep(Object object, Repository rep, ObjectId id_transformation, ObjectId id_step)
/*     */     throws KettleException
/*     */   {
/* 434 */     StringBuffer sb = new StringBuffer(1024);
/* 435 */     write(object, 0, sb);
/* 436 */     rep.saveStepAttribute(id_transformation, id_step, "step-xml", sb.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void readStepRep(Object object, Repository rep, ObjectId id_step, List<DatabaseMeta> databases, Map<String, Counter> counters)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 452 */       String stepXML = rep.getStepAttributeString(id_step, "step-xml");
/* 453 */       ByteArrayInputStream bais = new ByteArrayInputStream(stepXML.getBytes());
/* 454 */       Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(bais);
/* 455 */       read(object, doc.getDocumentElement());
/*     */     } catch (ParserConfigurationException ex) {
/* 457 */       throw new KettleException(ex.getMessage(), ex);
/*     */     } catch (SAXException ex) {
/* 459 */       throw new KettleException(ex.getMessage(), ex);
/*     */     } catch (IOException ex) {
/* 461 */       throw new KettleException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void indent(StringBuffer sb, int indentLevel) {
/* 466 */     for (int i = 0; i < indentLevel; i++) {
/* 467 */       sb.append("    ");
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\SerializationHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */