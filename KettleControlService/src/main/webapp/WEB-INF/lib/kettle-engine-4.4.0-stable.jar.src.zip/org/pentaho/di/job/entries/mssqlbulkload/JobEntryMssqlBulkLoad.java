/*     */ package org.pentaho.di.job.entries.mssqlbulkload;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.provider.local.LocalFile;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.Database;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.database.MSSQLServerDatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleFileException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryMssqlBulkLoad
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  72 */   private static Class<?> PKG = JobEntryMssqlBulkLoad.class;
/*     */   
/*     */   private String schemaname;
/*     */   
/*     */   private String tablename;
/*     */   private String filename;
/*     */   private String datafiletype;
/*     */   private String fieldterminator;
/*     */   private String lineterminated;
/*     */   private String codepage;
/*     */   private String specificcodepage;
/*     */   private int startfile;
/*     */   private int endfile;
/*     */   private String orderby;
/*     */   private boolean addfiletoresult;
/*     */   private String formatfilename;
/*     */   private boolean firetriggers;
/*     */   private boolean checkconstraints;
/*     */   private boolean keepnulls;
/*     */   private boolean tablock;
/*     */   private String errorfilename;
/*     */   private boolean adddatetime;
/*     */   private String orderdirection;
/*     */   private int maxerrors;
/*     */   private int batchsize;
/*     */   private int rowsperbatch;
/*     */   private boolean keepidentity;
/*     */   private boolean truncate;
/*     */   private DatabaseMeta connection;
/*     */   
/*     */   public JobEntryMssqlBulkLoad(String n)
/*     */   {
/* 104 */     super(n, "");
/* 105 */     this.tablename = null;
/* 106 */     this.schemaname = null;
/* 107 */     this.filename = null;
/* 108 */     this.datafiletype = "char";
/* 109 */     this.fieldterminator = null;
/* 110 */     this.lineterminated = null;
/* 111 */     this.codepage = "OEM";
/* 112 */     this.specificcodepage = null;
/* 113 */     this.checkconstraints = false;
/* 114 */     this.keepnulls = false;
/* 115 */     this.tablock = false;
/* 116 */     this.startfile = 0;
/* 117 */     this.endfile = 0;
/* 118 */     this.orderby = null;
/*     */     
/* 120 */     this.errorfilename = null;
/* 121 */     this.adddatetime = false;
/* 122 */     this.orderdirection = "Asc";
/* 123 */     this.maxerrors = 0;
/* 124 */     this.batchsize = 0;
/* 125 */     this.rowsperbatch = 0;
/*     */     
/* 127 */     this.connection = null;
/* 128 */     this.addfiletoresult = false;
/* 129 */     this.formatfilename = null;
/* 130 */     this.firetriggers = false;
/* 131 */     this.keepidentity = false;
/* 132 */     this.truncate = false;
/* 133 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryMssqlBulkLoad()
/*     */   {
/* 138 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 143 */     JobEntryMssqlBulkLoad je = (JobEntryMssqlBulkLoad)super.clone();
/* 144 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 149 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/* 151 */     retval.append(super.getXML());
/* 152 */     retval.append("      ").append(XMLHandler.addTagValue("schemaname", this.schemaname));
/* 153 */     retval.append("      ").append(XMLHandler.addTagValue("tablename", this.tablename));
/* 154 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/*     */     
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("datafiletype", this.datafiletype));
/* 157 */     retval.append("      ").append(XMLHandler.addTagValue("fieldterminator", this.fieldterminator));
/* 158 */     retval.append("      ").append(XMLHandler.addTagValue("lineterminated", this.lineterminated));
/* 159 */     retval.append("      ").append(XMLHandler.addTagValue("codepage", this.codepage));
/* 160 */     retval.append("      ").append(XMLHandler.addTagValue("specificcodepage", this.specificcodepage));
/* 161 */     retval.append("      ").append(XMLHandler.addTagValue("formatfilename", this.formatfilename));
/* 162 */     retval.append("      ").append(XMLHandler.addTagValue("firetriggers", this.firetriggers));
/* 163 */     retval.append("      ").append(XMLHandler.addTagValue("checkconstraints", this.checkconstraints));
/* 164 */     retval.append("      ").append(XMLHandler.addTagValue("keepnulls", this.keepnulls));
/* 165 */     retval.append("      ").append(XMLHandler.addTagValue("keepidentity", this.keepidentity));
/* 166 */     retval.append("      ").append(XMLHandler.addTagValue("tablock", this.tablock));
/* 167 */     retval.append("      ").append(XMLHandler.addTagValue("startfile", this.startfile));
/* 168 */     retval.append("      ").append(XMLHandler.addTagValue("endfile", this.endfile));
/* 169 */     retval.append("      ").append(XMLHandler.addTagValue("orderby", this.orderby));
/* 170 */     retval.append("      ").append(XMLHandler.addTagValue("orderdirection", this.orderdirection));
/* 171 */     retval.append("      ").append(XMLHandler.addTagValue("maxerrors", this.maxerrors));
/* 172 */     retval.append("      ").append(XMLHandler.addTagValue("batchsize", this.batchsize));
/* 173 */     retval.append("      ").append(XMLHandler.addTagValue("rowsperbatch", this.rowsperbatch));
/* 174 */     retval.append("      ").append(XMLHandler.addTagValue("errorfilename", this.errorfilename));
/* 175 */     retval.append("      ").append(XMLHandler.addTagValue("adddatetime", this.adddatetime));
/* 176 */     retval.append("      ").append(XMLHandler.addTagValue("addfiletoresult", this.addfiletoresult));
/* 177 */     retval.append("      ").append(XMLHandler.addTagValue("truncate", this.truncate));
/*     */     
/* 179 */     retval.append("      ").append(XMLHandler.addTagValue("connection", this.connection == null ? null : this.connection.getName()));
/*     */     
/* 181 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 188 */       super.loadXML(entrynode, databases, slaveServers);
/* 189 */       this.schemaname = XMLHandler.getTagValue(entrynode, "schemaname");
/* 190 */       this.tablename = XMLHandler.getTagValue(entrynode, "tablename");
/* 191 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/* 192 */       this.datafiletype = XMLHandler.getTagValue(entrynode, "datafiletype");
/* 193 */       this.fieldterminator = XMLHandler.getTagValue(entrynode, "fieldterminator");
/*     */       
/* 195 */       this.lineterminated = XMLHandler.getTagValue(entrynode, "lineterminated");
/* 196 */       this.codepage = XMLHandler.getTagValue(entrynode, "codepage");
/* 197 */       this.specificcodepage = XMLHandler.getTagValue(entrynode, "specificcodepage");
/* 198 */       this.formatfilename = XMLHandler.getTagValue(entrynode, "formatfilename");
/*     */       
/* 200 */       this.firetriggers = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "firetriggers"));
/* 201 */       this.checkconstraints = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "checkconstraints"));
/* 202 */       this.keepnulls = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "keepnulls"));
/* 203 */       this.keepidentity = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "keepidentity"));
/*     */       
/* 205 */       this.tablock = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "tablock"));
/* 206 */       this.startfile = Const.toInt(XMLHandler.getTagValue(entrynode, "startfile"), 0);
/* 207 */       this.endfile = Const.toInt(XMLHandler.getTagValue(entrynode, "endfile"), 0);
/*     */       
/* 209 */       this.orderby = XMLHandler.getTagValue(entrynode, "orderby");
/* 210 */       this.orderdirection = XMLHandler.getTagValue(entrynode, "orderdirection");
/*     */       
/* 212 */       this.errorfilename = XMLHandler.getTagValue(entrynode, "errorfilename");
/*     */       
/* 214 */       this.maxerrors = Const.toInt(XMLHandler.getTagValue(entrynode, "maxerrors"), 0);
/* 215 */       this.batchsize = Const.toInt(XMLHandler.getTagValue(entrynode, "batchsize"), 0);
/* 216 */       this.rowsperbatch = Const.toInt(XMLHandler.getTagValue(entrynode, "rowsperbatch"), 0);
/* 217 */       this.adddatetime = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "adddatetime"));
/* 218 */       String dbname = XMLHandler.getTagValue(entrynode, "connection");
/* 219 */       this.addfiletoresult = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "addfiletoresult"));
/* 220 */       this.truncate = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "truncate"));
/*     */       
/* 222 */       this.connection = DatabaseMeta.findDatabase(databases, dbname);
/*     */ 
/*     */     }
/*     */     catch (KettleException e)
/*     */     {
/* 227 */       throw new KettleXMLException("Unable to load job entry of type 'MSsql bulk load' from XML node", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 236 */       this.schemaname = rep.getJobEntryAttributeString(id_jobentry, "schemaname");
/* 237 */       this.tablename = rep.getJobEntryAttributeString(id_jobentry, "tablename");
/* 238 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/*     */       
/* 240 */       this.datafiletype = rep.getJobEntryAttributeString(id_jobentry, "datafiletype");
/* 241 */       this.fieldterminator = rep.getJobEntryAttributeString(id_jobentry, "fieldterminator");
/*     */       
/* 243 */       this.lineterminated = rep.getJobEntryAttributeString(id_jobentry, "lineterminated");
/* 244 */       this.codepage = rep.getJobEntryAttributeString(id_jobentry, "codepage");
/* 245 */       this.specificcodepage = rep.getJobEntryAttributeString(id_jobentry, "specificcodepage");
/* 246 */       this.formatfilename = rep.getJobEntryAttributeString(id_jobentry, "formatfilename");
/* 247 */       this.firetriggers = rep.getJobEntryAttributeBoolean(id_jobentry, "firetriggers");
/* 248 */       this.checkconstraints = rep.getJobEntryAttributeBoolean(id_jobentry, "checkconstraints");
/* 249 */       this.keepnulls = rep.getJobEntryAttributeBoolean(id_jobentry, "keepnulls");
/* 250 */       this.keepidentity = rep.getJobEntryAttributeBoolean(id_jobentry, "keepidentity");
/*     */       
/* 252 */       this.tablock = rep.getJobEntryAttributeBoolean(id_jobentry, "tablock");
/*     */       
/* 254 */       this.startfile = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "startfile"));
/* 255 */       this.endfile = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "endfile"));
/*     */       
/* 257 */       this.orderby = rep.getJobEntryAttributeString(id_jobentry, "orderby");
/* 258 */       this.orderdirection = rep.getJobEntryAttributeString(id_jobentry, "orderdirection");
/*     */       
/* 260 */       this.errorfilename = rep.getJobEntryAttributeString(id_jobentry, "errorfilename");
/* 261 */       this.maxerrors = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "maxerrors"));
/* 262 */       this.batchsize = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "batchsize"));
/* 263 */       this.rowsperbatch = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "rowsperbatch"));
/* 264 */       this.adddatetime = rep.getJobEntryAttributeBoolean(id_jobentry, "adddatetime");
/*     */       
/* 266 */       this.addfiletoresult = rep.getJobEntryAttributeBoolean(id_jobentry, "addfiletoresult");
/* 267 */       this.truncate = rep.getJobEntryAttributeBoolean(id_jobentry, "truncate");
/*     */       
/* 269 */       this.connection = rep.loadDatabaseMetaFromJobEntryAttribute(id_jobentry, "connection", "id_database", databases);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 273 */       throw new KettleException("Unable to load job entry of type 'MSsql bulk load' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 281 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "schemaname", this.schemaname);
/* 282 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "tablename", this.tablename);
/* 283 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/* 284 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "datafiletype", this.datafiletype);
/* 285 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "fieldterminator", this.fieldterminator);
/* 286 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "lineterminated", this.lineterminated);
/* 287 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "codepage", this.codepage);
/* 288 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "specificcodepage", this.specificcodepage);
/* 289 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "formatfilename", this.formatfilename);
/* 290 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "firetriggers", this.firetriggers);
/* 291 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "checkconstraints", this.checkconstraints);
/* 292 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "keepnulls", this.keepnulls);
/* 293 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "keepidentity", this.keepidentity);
/* 294 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "tablock", this.tablock);
/* 295 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "startfile", this.startfile);
/* 296 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "endfile", this.endfile);
/* 297 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "orderby", this.orderby);
/* 298 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "orderdirection", this.orderdirection);
/* 299 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "errorfilename", this.errorfilename);
/* 300 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "maxerrors", this.maxerrors);
/* 301 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "batchsize", this.batchsize);
/* 302 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "rowsperbatch", this.rowsperbatch);
/* 303 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "adddatetime", this.adddatetime);
/* 304 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "addfiletoresult", this.addfiletoresult);
/* 305 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "truncate", this.truncate);
/*     */       
/* 307 */       rep.saveDatabaseMetaJobEntryAttribute(id_job, getObjectId(), "connection", "id_database", this.connection);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 311 */       throw new KettleException("Unable to load job entry of type 'MSsql Bulk Load' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTablename(String tablename)
/*     */   {
/* 317 */     this.tablename = tablename;
/*     */   }
/*     */   
/*     */   public void setSchemaname(String schemaname)
/*     */   {
/* 322 */     this.schemaname = schemaname;
/*     */   }
/*     */   
/*     */   public String getSchemaname()
/*     */   {
/* 327 */     return this.schemaname;
/*     */   }
/*     */   
/*     */   public String getTablename()
/*     */   {
/* 332 */     return this.tablename;
/*     */   }
/*     */   
/*     */   public void setMaxErrors(int maxerrors) {
/* 336 */     this.maxerrors = maxerrors;
/*     */   }
/*     */   
/*     */   public int getMaxErrors() {
/* 340 */     return this.maxerrors;
/*     */   }
/*     */   
/*     */   public int getBatchSize() {
/* 344 */     return this.batchsize;
/*     */   }
/*     */   
/*     */   public void setBatchSize(int batchsize) {
/* 348 */     this.batchsize = batchsize;
/*     */   }
/*     */   
/*     */   public int getRowsPerBatch() {
/* 352 */     return this.rowsperbatch;
/*     */   }
/*     */   
/*     */   public void setRowsPerBatch(int rowsperbatch) {
/* 356 */     this.rowsperbatch = rowsperbatch;
/*     */   }
/*     */   
/*     */   public void setDatabase(DatabaseMeta database) {
/* 360 */     this.connection = database;
/*     */   }
/*     */   
/*     */   public DatabaseMeta getDatabase()
/*     */   {
/* 365 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 370 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 375 */     return false;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 380 */     String TakeFirstNbrLines = "";
/* 381 */     String LineTerminatedby = "";
/* 382 */     String FieldTerminatedby = "";
/* 383 */     boolean useFieldSeparator = false;
/* 384 */     String UseCodepage = "";
/* 385 */     String ErrorfileName = "";
/*     */     
/* 387 */     Result result = previousResult;
/* 388 */     result.setResult(false);
/*     */     
/* 390 */     String vfsFilename = environmentSubstitute(this.filename);
/* 391 */     FileObject fileObject = null;
/*     */     
/* 393 */     if (!Const.isEmpty(vfsFilename))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 403 */         fileObject = KettleVFS.getFileObject(vfsFilename, this);
/* 404 */         if (!(fileObject instanceof LocalFile))
/*     */         {
/*     */ 
/* 407 */           throw new KettleException(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.OnlyLocalFileSupported", new String[] { vfsFilename }));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 412 */         String realFilename = KettleVFS.getFilename(fileObject);
/*     */         
/*     */ 
/*     */ 
/* 416 */         File file = new File(realFilename);
/* 417 */         if ((file.exists()) && (file.canRead()))
/*     */         {
/*     */ 
/* 420 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobMssqlBulkLoad.FileExists.Label", new String[] { realFilename }));
/*     */           }
/* 422 */           if (this.connection != null)
/*     */           {
/*     */ 
/* 425 */             Database db = new Database(this, this.connection);
/*     */             
/* 427 */             if (!(db.getDatabaseMeta().getDatabaseInterface() instanceof MSSQLServerDatabaseMeta))
/*     */             {
/* 429 */               logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.DbNotMSSQL", new String[] { this.connection.getDatabaseName() }));
/* 430 */               return result;
/*     */             }
/* 432 */             db.shareVariablesWith(this);
/*     */             try
/*     */             {
/* 435 */               db.connect();
/*     */               
/* 437 */               String realSchemaname = environmentSubstitute(this.schemaname);
/*     */               
/* 439 */               String realTablename = environmentSubstitute(this.tablename);
/*     */               
/* 441 */               if (db.checkTableExists(realTablename))
/*     */               {
/*     */ 
/* 444 */                 if (this.log.isDetailed()) {
/* 445 */                   logDetailed(BaseMessages.getString(PKG, "JobMssqlBulkLoad.TableExists.Label", new String[] { realTablename }));
/*     */                 }
/*     */                 
/* 448 */                 if (this.schemaname != null) { realTablename = realSchemaname + "." + realTablename;
/*     */                 }
/*     */                 
/* 451 */                 String Fieldterminator = getRealFieldTerminator();
/* 452 */                 if ((Const.isEmpty(Fieldterminator)) && ((this.datafiletype.equals("char")) || (this.datafiletype.equals("widechar"))))
/*     */                 {
/* 454 */                   logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.FieldTerminatorMissing", new String[0]));
/* 455 */                   return result;
/*     */                 }
/*     */                 
/*     */ 
/* 459 */                 if ((this.datafiletype.equals("char")) || (this.datafiletype.equals("widechar")))
/*     */                 {
/* 461 */                   useFieldSeparator = true;
/* 462 */                   FieldTerminatedby = "FIELDTERMINATOR='" + Fieldterminator + "'";
/*     */                 }
/*     */                 
/*     */ 
/* 466 */                 if (this.codepage.equals("Specific"))
/*     */                 {
/* 468 */                   String realCodePage = environmentSubstitute(this.codepage);
/* 469 */                   if (this.specificcodepage.length() < 0)
/*     */                   {
/* 471 */                     logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.SpecificCodePageMissing", new String[0]));
/* 472 */                     return result;
/*     */                   }
/*     */                   
/* 475 */                   UseCodepage = "CODEPAGE = '" + realCodePage + "'";
/*     */                 }
/*     */                 else {
/* 478 */                   UseCodepage = "CODEPAGE = '" + this.codepage + "'";
/*     */                 }
/*     */                 
/*     */ 
/* 482 */                 String realErrorFile = environmentSubstitute(this.errorfilename);
/* 483 */                 if (realErrorFile != null)
/*     */                 {
/* 485 */                   File errorfile = new File(realErrorFile);
/* 486 */                   if ((errorfile.exists()) && (!this.adddatetime))
/*     */                   {
/*     */ 
/* 489 */                     logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.ErrorFileExists", new String[0]));
/* 490 */                     return result;
/*     */                   }
/* 492 */                   if (this.adddatetime)
/*     */                   {
/*     */ 
/* 495 */                     SimpleDateFormat daf = new SimpleDateFormat();
/* 496 */                     Date now = new Date();
/* 497 */                     daf.applyPattern("yyyMMdd_HHmmss");
/* 498 */                     String d = daf.format(now);
/*     */                     
/* 500 */                     ErrorfileName = "ERRORFILE ='" + realErrorFile + "_" + d + "'";
/*     */                   } else {
/* 502 */                     ErrorfileName = "ERRORFILE ='" + realErrorFile + "'";
/*     */                   }
/*     */                 }
/*     */                 
/*     */ 
/* 507 */                 String Rowterminator = getRealLineterminated();
/* 508 */                 if (!Const.isEmpty(Rowterminator)) { LineTerminatedby = "ROWTERMINATOR='" + Rowterminator + "'";
/*     */                 }
/*     */                 
/* 511 */                 if (this.startfile > 0) { TakeFirstNbrLines = "FIRSTROW=" + this.startfile;
/*     */                 }
/*     */                 
/* 514 */                 if (this.endfile > 0) { TakeFirstNbrLines = "LASTROW=" + this.endfile;
/*     */                 }
/*     */                 
/* 517 */                 String SQLBULKLOAD = "";
/* 518 */                 if (this.truncate) { SQLBULKLOAD = "TRUNCATE TABLE " + realTablename + ";";
/*     */                 }
/*     */                 
/* 521 */                 SQLBULKLOAD = SQLBULKLOAD + "BULK INSERT " + realTablename + " FROM " + "'" + realFilename.replace('\\', '/') + "'";
/* 522 */                 SQLBULKLOAD = SQLBULKLOAD + " WITH (";
/* 523 */                 if (useFieldSeparator) {
/* 524 */                   SQLBULKLOAD = SQLBULKLOAD + FieldTerminatedby;
/*     */                 } else {
/* 526 */                   SQLBULKLOAD = SQLBULKLOAD + "DATAFILETYPE ='" + this.datafiletype + "'";
/*     */                 }
/* 528 */                 if (LineTerminatedby.length() > 0) SQLBULKLOAD = SQLBULKLOAD + "," + LineTerminatedby;
/* 529 */                 if (TakeFirstNbrLines.length() > 0) SQLBULKLOAD = SQLBULKLOAD + "," + TakeFirstNbrLines;
/* 530 */                 if (UseCodepage.length() > 0) SQLBULKLOAD = SQLBULKLOAD + "," + UseCodepage;
/* 531 */                 String realFormatFile = environmentSubstitute(this.formatfilename);
/* 532 */                 if (realFormatFile != null) SQLBULKLOAD = SQLBULKLOAD + ", FORMATFILE='" + realFormatFile + "'";
/* 533 */                 if (this.firetriggers) SQLBULKLOAD = SQLBULKLOAD + ",FIRE_TRIGGERS";
/* 534 */                 if (this.keepnulls) SQLBULKLOAD = SQLBULKLOAD + ",KEEPNULLS";
/* 535 */                 if (this.keepidentity) SQLBULKLOAD = SQLBULKLOAD + ",KEEPIDENTITY";
/* 536 */                 if (this.checkconstraints) SQLBULKLOAD = SQLBULKLOAD + ",CHECK_CONSTRAINTS";
/* 537 */                 if (this.tablock) SQLBULKLOAD = SQLBULKLOAD + ",TABLOCK";
/* 538 */                 if (this.orderby != null) SQLBULKLOAD = SQLBULKLOAD + ",ORDER ( " + this.orderby + " " + this.orderdirection + ")";
/* 539 */                 if (ErrorfileName.length() > 0) SQLBULKLOAD = SQLBULKLOAD + ", " + ErrorfileName;
/* 540 */                 if (this.maxerrors > 0) SQLBULKLOAD = SQLBULKLOAD + ", MAXERRORS=" + this.maxerrors;
/* 541 */                 if (this.batchsize > 0) SQLBULKLOAD = SQLBULKLOAD + ", BATCHSIZE=" + this.batchsize;
/* 542 */                 if (this.rowsperbatch > 0) { SQLBULKLOAD = SQLBULKLOAD + ", ROWS_PER_BATCH=" + this.rowsperbatch;
/*     */                 }
/* 544 */                 SQLBULKLOAD = SQLBULKLOAD + ")";
/*     */                 
/*     */ 
/*     */                 try
/*     */                 {
/* 549 */                   db.execStatements(SQLBULKLOAD);
/*     */                   
/*     */ 
/* 552 */                   db.disconnect();
/*     */                   
/* 554 */                   if (isAddFileToResult())
/*     */                   {
/*     */ 
/* 557 */                     ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(realFilename, this), this.parentJob.getJobname(), toString());
/* 558 */                     result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */                   }
/*     */                   
/* 561 */                   result.setResult(true);
/*     */                 }
/*     */                 catch (KettleDatabaseException je)
/*     */                 {
/* 565 */                   result.setNrErrors(1L);
/* 566 */                   logError("An error occurred executing this job entry : " + je.getMessage(), je);
/*     */                 }
/*     */                 catch (KettleFileException e)
/*     */                 {
/* 570 */                   logError("An error occurred executing this job entry : " + e.getMessage(), e);
/* 571 */                   result.setNrErrors(1L);
/*     */                 }
/*     */                 finally
/*     */                 {
/* 575 */                   if (db != null)
/*     */                   {
/* 577 */                     db.disconnect();
/* 578 */                     db = null;
/*     */                   }
/*     */                   
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 585 */                 db.disconnect();
/* 586 */                 result.setNrErrors(1L);
/* 587 */                 if (this.log.isDetailed()) {
/* 588 */                   logDetailed(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.TableNotExists", new String[] { realTablename }));
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (KettleDatabaseException dbe) {
/* 593 */               db.disconnect();
/* 594 */               result.setNrErrors(1L);
/* 595 */               logError("An error occurred executing this entry: " + dbe.getMessage());
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 601 */             result.setNrErrors(1L);
/* 602 */             logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Nodatabase.Label", new String[0]));
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 608 */           result.setNrErrors(1L);
/* 609 */           logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Error.FileNotExists", new String[] { realFilename }));
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 615 */         result.setNrErrors(1L);
/* 616 */         logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.UnexpectedError.Label", new String[0]), e);
/*     */       } finally {
/*     */         try {
/* 619 */           if (fileObject != null) fileObject.close();
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 626 */       result.setNrErrors(1L);
/* 627 */       logError(BaseMessages.getString(PKG, "JobMssqlBulkLoad.Nofilename.Label", new String[0]));
/*     */     }
/* 629 */     return result;
/*     */   }
/*     */   
/*     */   public DatabaseMeta[] getUsedDatabaseConnections()
/*     */   {
/* 634 */     return new DatabaseMeta[] { this.connection };
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFilename(String filename)
/*     */   {
/* 640 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 645 */     return this.filename;
/*     */   }
/*     */   
/*     */   public void setFieldTerminator(String fieldterminator)
/*     */   {
/* 650 */     this.fieldterminator = fieldterminator;
/*     */   }
/*     */   
/*     */   public void setLineterminated(String lineterminated)
/*     */   {
/* 655 */     this.lineterminated = lineterminated;
/*     */   }
/*     */   
/*     */   public void setCodePage(String codepage)
/*     */   {
/* 660 */     this.codepage = codepage;
/*     */   }
/*     */   
/*     */   public String getCodePage() {
/* 664 */     return this.codepage;
/*     */   }
/*     */   
/*     */   public void setSpecificCodePage(String specificcodepage) {
/* 668 */     this.specificcodepage = specificcodepage;
/*     */   }
/*     */   
/*     */   public String getSpecificCodePage() {
/* 672 */     return this.specificcodepage;
/*     */   }
/*     */   
/*     */   public void setFormatFilename(String formatfilename) {
/* 676 */     this.formatfilename = formatfilename;
/*     */   }
/*     */   
/*     */   public String getFormatFilename()
/*     */   {
/* 681 */     return this.formatfilename;
/*     */   }
/*     */   
/*     */   public String getFieldTerminator()
/*     */   {
/* 686 */     return this.fieldterminator;
/*     */   }
/*     */   
/*     */   public String getLineterminated()
/*     */   {
/* 691 */     return this.lineterminated;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getDataFileType()
/*     */   {
/* 697 */     return this.datafiletype;
/*     */   }
/*     */   
/*     */   public void setDataFileType(String datafiletype) {
/* 701 */     this.datafiletype = datafiletype;
/*     */   }
/*     */   
/*     */   public String getRealLineterminated() {
/* 705 */     return environmentSubstitute(getLineterminated());
/*     */   }
/*     */   
/*     */   public String getRealFieldTerminator()
/*     */   {
/* 710 */     return environmentSubstitute(getFieldTerminator());
/*     */   }
/*     */   
/*     */   public void setStartFile(int startfile)
/*     */   {
/* 715 */     this.startfile = startfile;
/*     */   }
/*     */   
/*     */   public int getStartFile()
/*     */   {
/* 720 */     return this.startfile;
/*     */   }
/*     */   
/*     */   public void setEndFile(int endfile) {
/* 724 */     this.endfile = endfile;
/*     */   }
/*     */   
/*     */   public int getEndFile() {
/* 728 */     return this.endfile;
/*     */   }
/*     */   
/*     */   public void setOrderBy(String orderby)
/*     */   {
/* 733 */     this.orderby = orderby;
/*     */   }
/*     */   
/*     */   public String getOrderBy()
/*     */   {
/* 738 */     return this.orderby;
/*     */   }
/*     */   
/*     */   public String getOrderDirection() {
/* 742 */     return this.orderdirection;
/*     */   }
/*     */   
/*     */   public void setOrderDirection(String orderdirection) {
/* 746 */     this.orderdirection = orderdirection;
/*     */   }
/*     */   
/*     */   public void setErrorFilename(String errorfilename) {
/* 750 */     this.errorfilename = errorfilename;
/*     */   }
/*     */   
/*     */   public String getErrorFilename()
/*     */   {
/* 755 */     return this.errorfilename;
/*     */   }
/*     */   
/*     */   public String getRealOrderBy()
/*     */   {
/* 760 */     return environmentSubstitute(getOrderBy());
/*     */   }
/*     */   
/*     */   public void setAddFileToResult(boolean addfiletoresultin)
/*     */   {
/* 765 */     this.addfiletoresult = addfiletoresultin;
/*     */   }
/*     */   
/*     */   public boolean isAddFileToResult()
/*     */   {
/* 770 */     return this.addfiletoresult;
/*     */   }
/*     */   
/*     */   public void setTruncate(boolean truncate)
/*     */   {
/* 775 */     this.truncate = truncate;
/*     */   }
/*     */   
/*     */   public boolean isTruncate()
/*     */   {
/* 780 */     return this.truncate;
/*     */   }
/*     */   
/*     */   public void setAddDatetime(boolean adddatetime) {
/* 784 */     this.adddatetime = adddatetime;
/*     */   }
/*     */   
/*     */   public boolean isAddDatetime()
/*     */   {
/* 789 */     return this.adddatetime;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFireTriggers(boolean firetriggers)
/*     */   {
/* 795 */     this.firetriggers = firetriggers;
/*     */   }
/*     */   
/*     */   public boolean isFireTriggers()
/*     */   {
/* 800 */     return this.firetriggers;
/*     */   }
/*     */   
/*     */   public void setCheckConstraints(boolean checkconstraints)
/*     */   {
/* 805 */     this.checkconstraints = checkconstraints;
/*     */   }
/*     */   
/*     */   public boolean isCheckConstraints() {
/* 809 */     return this.checkconstraints;
/*     */   }
/*     */   
/*     */   public void setKeepNulls(boolean keepnulls) {
/* 813 */     this.keepnulls = keepnulls;
/*     */   }
/*     */   
/*     */   public boolean isKeepNulls() {
/* 817 */     return this.keepnulls;
/*     */   }
/*     */   
/*     */   public void setKeepIdentity(boolean keepidentity) {
/* 821 */     this.keepidentity = keepidentity;
/*     */   }
/*     */   
/*     */   public boolean isKeepIdentity() {
/* 825 */     return this.keepidentity;
/*     */   }
/*     */   
/*     */   public void setTablock(boolean tablock) {
/* 829 */     this.tablock = tablock;
/*     */   }
/*     */   
/*     */   public boolean isTablock() {
/* 833 */     return this.tablock;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*     */   {
/* 838 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 839 */     ResourceReference reference = null;
/* 840 */     if (this.connection != null) {
/* 841 */       reference = new ResourceReference(this);
/* 842 */       references.add(reference);
/* 843 */       reference.getEntries().add(new ResourceEntry(this.connection.getHostname(), ResourceEntry.ResourceType.SERVER));
/* 844 */       reference.getEntries().add(new ResourceEntry(this.connection.getDatabaseName(), ResourceEntry.ResourceType.DATABASENAME));
/*     */     }
/* 846 */     if (this.filename != null) {
/* 847 */       String realFilename = getRealFilename();
/* 848 */       if (reference == null) {
/* 849 */         reference = new ResourceReference(this);
/* 850 */         references.add(reference);
/*     */       }
/* 852 */       reference.getEntries().add(new ResourceEntry(realFilename, ResourceEntry.ResourceType.FILE));
/*     */     }
/* 854 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 860 */     ValidatorContext ctx = new ValidatorContext();
/* 861 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 862 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 863 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */     
/* 865 */     JobEntryValidatorUtils.andValidator().validate(this, "tablename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\mssqlbulkload\JobEntryMssqlBulkLoad.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */