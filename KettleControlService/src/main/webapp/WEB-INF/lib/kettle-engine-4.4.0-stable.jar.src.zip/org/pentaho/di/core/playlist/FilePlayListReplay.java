/*     */ package org.pentaho.di.core.playlist;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.trans.step.errorhandling.AbstractFileErrorHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePlayListReplay
/*     */   implements FilePlayList
/*     */ {
/*     */   private final Date replayDate;
/*     */   private final String encoding;
/*     */   private final String lineNumberDirectory;
/*     */   private final String lineNumberExtension;
/*     */   private final String errorDirectory;
/*     */   private final String errorExtension;
/*     */   private FilePlayListReplayFile currentLineNumberFile;
/*     */   private FilePlayListReplayFile currentErrorFile;
/*     */   
/*     */   public FilePlayListReplay(Date replayDate, String lineNumberDirectory, String lineNumberExtension, String errorDirectory, String errorExtension, String encoding)
/*     */   {
/*  53 */     this.replayDate = replayDate;
/*  54 */     this.errorDirectory = errorDirectory;
/*  55 */     this.errorExtension = errorExtension;
/*  56 */     this.encoding = encoding;
/*  57 */     this.lineNumberDirectory = lineNumberDirectory;
/*  58 */     this.lineNumberExtension = lineNumberExtension;
/*     */   }
/*     */   
/*     */   private FileObject getCurrentProcessingFile()
/*     */   {
/*  63 */     FileObject result = null;
/*  64 */     if (this.currentLineNumberFile != null)
/*  65 */       result = this.currentLineNumberFile.getProcessingFile();
/*  66 */     return result;
/*     */   }
/*     */   
/*     */   private String getCurrentProcessingFilePart() {
/*  70 */     String result = null;
/*  71 */     if (this.currentLineNumberFile != null)
/*  72 */       result = this.currentLineNumberFile.getProcessingFilePart();
/*  73 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isProcessingNeeded(FileObject file, long lineNr, String filePart) throws KettleException
/*     */   {
/*  78 */     initializeCurrentIfNeeded(file, filePart);
/*  79 */     return (this.currentLineNumberFile.isProcessingNeeded(file, lineNr, filePart)) || (this.currentErrorFile.isProcessingNeeded(file, lineNr, filePart));
/*     */   }
/*     */   
/*     */   private void initializeCurrentIfNeeded(FileObject file, String filePart) throws KettleException
/*     */   {
/*  84 */     if ((!file.equals(getCurrentProcessingFile())) || (!filePart.equals(getCurrentProcessingFilePart()))) {
/*  85 */       initializeCurrent(file, filePart);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initializeCurrent(FileObject file, String filePart) throws KettleException {
/*     */     try {
/*  91 */       FileObject lineFile = AbstractFileErrorHandler.getReplayFilename(this.lineNumberDirectory, file.getName().getBaseName(), this.replayDate, this.lineNumberExtension, filePart);
/*     */       
/*     */ 
/*  94 */       if (lineFile.exists()) {
/*  95 */         this.currentLineNumberFile = new FilePlayListReplayLineNumberFile(lineFile, this.encoding, file, filePart);
/*     */       }
/*     */       else {
/*  98 */         this.currentLineNumberFile = new FilePlayListReplayFile(file, filePart);
/*     */       }
/* 100 */       FileObject errorFile = AbstractFileErrorHandler.getReplayFilename(this.errorDirectory, file.getName().getURI(), this.replayDate, this.errorExtension, "NO_PARTS");
/*     */       
/*     */ 
/* 103 */       if (errorFile.exists()) {
/* 104 */         this.currentErrorFile = new FilePlayListReplayErrorFile(errorFile, file);
/*     */       } else {
/* 106 */         this.currentErrorFile = new FilePlayListReplayFile(file, "NO_PARTS");
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 110 */       throw new KettleException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\playlist\FilePlayListReplay.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */