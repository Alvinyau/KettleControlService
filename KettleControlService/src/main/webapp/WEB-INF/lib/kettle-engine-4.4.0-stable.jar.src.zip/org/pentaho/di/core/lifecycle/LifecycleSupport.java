/*    */ package org.pentaho.di.core.lifecycle;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.pentaho.di.core.logging.LogChannel;
/*    */ import org.pentaho.di.core.logging.LogChannelInterface;
/*    */ import org.pentaho.di.core.plugins.LifecyclePluginType;
/*    */ import org.pentaho.di.core.plugins.PluginInterface;
/*    */ import org.pentaho.di.core.plugins.PluginRegistry;
/*    */ import org.pentaho.di.core.plugins.PluginTypeInterface;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LifecycleSupport
/*    */ {
/*    */   private Set<LifecycleListener> lifeListeners;
/*    */   
/*    */   public LifecycleSupport()
/*    */   {
/* 39 */     this.lifeListeners = loadPlugins(LifecyclePluginType.class, LifecycleListener.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static <T> Set<T> loadPlugins(Class<? extends PluginTypeInterface> pluginType, Class<T> mainPluginClass)
/*    */   {
/* 50 */     Set<T> pluginInstances = new HashSet();
/* 51 */     PluginRegistry registry = PluginRegistry.getInstance();
/* 52 */     List<PluginInterface> plugins = registry.getPlugins(pluginType);
/* 53 */     for (PluginInterface plugin : plugins) {
/*    */       try {
/* 55 */         pluginInstances.add(registry.loadClass(plugin, mainPluginClass));
/*    */       } catch (Throwable e) {
/* 57 */         LogChannel.GENERAL.logError("Unexpected error loading class for plugin " + plugin.getName(), e);
/*    */       }
/*    */     }
/* 60 */     return pluginInstances;
/*    */   }
/*    */   
/*    */   public void onStart(LifeEventHandler handler) throws LifecycleException {
/* 64 */     for (LifecycleListener listener : this.lifeListeners)
/* 65 */       listener.onStart(handler);
/*    */   }
/*    */   
/*    */   public void onExit(LifeEventHandler handler) throws LifecycleException {
/* 69 */     for (LifecycleListener listener : this.lifeListeners) {
/* 70 */       listener.onExit(handler);
/*    */     }
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\lifecycle\LifecycleSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */