/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.pentaho.di.core.Const;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetaGenerator
/*     */ {
/*  30 */   public static final TypeFieldDefinition[] FIELDS = { new TypeFieldDefinition(4, "UsingLines"), new TypeFieldDefinition(5, "MaxNumberOfSuggestions"), new TypeFieldDefinition(2, "NameField"), new TypeFieldDefinition(2, "OrganizationField"), new TypeFieldDefinition(2, "DepartmentField"), new TypeFieldDefinition(2, "PostBoxField"), new TypeFieldDefinition(2, "SubPremiseField"), new TypeFieldDefinition(2, "PremiseField"), new TypeFieldDefinition(2, "HouseNumberField"), new TypeFieldDefinition(2, "HouseNumberAdditionField"), new TypeFieldDefinition(2, "DependentThoroughfareField"), new TypeFieldDefinition(2, "ThoroughfareField"), new TypeFieldDefinition(2, "DependentLocalityField"), new TypeFieldDefinition(2, "LocalityField"), new TypeFieldDefinition(2, "PostTownField"), new TypeFieldDefinition(2, "DeliveryServiceQualifierField"), new TypeFieldDefinition(2, "PostalCodeField"), new TypeFieldDefinition(2, "SubAdministrativeAreaField"), new TypeFieldDefinition(2, "AdministrativeAreaField"), new TypeFieldDefinition(2, "CountryNameField"), new TypeFieldDefinition(2, "CountryCodeField") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TypeFieldDefinition[] fields;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MetaGenerator(TypeFieldDefinition[] fields)
/*     */   {
/*  59 */     this.fields = fields;
/*     */   }
/*     */   
/*     */   public String generateCode()
/*     */   {
/*  64 */     StringBuilder code = new StringBuilder(5000);
/*     */     
/*     */ 
/*     */ 
/*  68 */     for (TypeFieldDefinition field : this.fields) {
/*  69 */       code.append("  private " + field.getTypeDescription() + " " + field.getMemberName() + ";").append(Const.CR);
/*     */     }
/*  71 */     code.append(Const.CR);
/*     */     
/*     */ 
/*     */ 
/*  75 */     code.append("  public String getXML() throws KettleException {").append(Const.CR);
/*  76 */     code.append("    StringBuilder xml = new StringBuilder(100);").append(Const.CR);
/*  77 */     for (TypeFieldDefinition field : this.fields) {
/*  78 */       code.append("    xml.append(XMLHandler.addTagValue(\"" + field.getFieldName() + "\", " + field.getMemberName() + "));").append(Const.CR);
/*     */     }
/*  80 */     code.append("    return xml.toString();").append(Const.CR);
/*  81 */     code.append("  }").append(Const.CR);
/*  82 */     code.append(Const.CR);
/*     */     
/*     */ 
/*     */ 
/*  86 */     code.append("  public void loadXML(Node stepnode, List<DatabaseMeta> databases, Map<String, Counter> counters) throws KettleXMLException {").append(Const.CR);
/*  87 */     for (TypeFieldDefinition field : this.fields) {
/*  88 */       switch (field.getType()) {
/*     */       case 2: 
/*  90 */         code.append("    " + field.getMemberName() + " = XMLHandler.getTagValue(stepnode, \"" + field.getFieldName() + "\");").append(Const.CR);
/*  91 */         break;
/*     */       case 4: 
/*  93 */         code.append("    " + field.getMemberName() + " = \"Y\".equalsIgnoreCase(XMLHandler.getTagValue(stepnode, \"" + field.getFieldName() + "\"));").append(Const.CR);
/*  94 */         break;
/*     */       case 5: 
/*  96 */         code.append("    " + field.getMemberName() + " = Const.toInt(XMLHandler.getTagValue(stepnode, \"" + field.getFieldName() + "\"), -1);").append(Const.CR);
/*     */       }
/*     */       
/*     */     }
/* 100 */     code.append("  }").append(Const.CR);
/* 101 */     code.append(Const.CR);
/*     */     
/*     */ 
/*     */ 
/* 105 */     code.append("  public void saveRep(Repository rep, ObjectId id_transformation, ObjectId id_step) throws KettleException {").append(Const.CR);
/* 106 */     for (TypeFieldDefinition field : this.fields) {
/* 107 */       code.append("    rep.saveStepAttribute(id_transformation, id_step, \"" + field.getFieldName() + "\", " + field.getMemberName() + ");").append(Const.CR);
/*     */     }
/* 109 */     code.append("  }").append(Const.CR);
/* 110 */     code.append(Const.CR);
/*     */     
/*     */ 
/*     */ 
/* 114 */     code.append("  public void readRep(Repository rep, ObjectId id_step, List<DatabaseMeta> databases, Map<String, Counter> counters) throws KettleException {").append(Const.CR);
/* 115 */     for (TypeFieldDefinition field : this.fields) {
/* 116 */       switch (field.getType()) {
/*     */       case 2: 
/* 118 */         code.append("    " + field.getMemberName() + " = rep.getStepAttributeString(id_step, \"" + field.getFieldName() + "\");").append(Const.CR);
/* 119 */         break;
/*     */       case 4: 
/* 121 */         code.append("    " + field.getMemberName() + " = rep.getStepAttributeBoolean(id_step, \"" + field.getFieldName() + "\");").append(Const.CR);
/* 122 */         break;
/*     */       case 5: 
/* 124 */         code.append("    " + field.getMemberName() + " = (int) rep.getStepAttributeInteger(id_step, \"" + field.getFieldName() + "\");").append(Const.CR);
/*     */       }
/*     */       
/*     */     }
/* 128 */     code.append("  }").append(Const.CR);
/* 129 */     code.append(Const.CR);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 134 */     for (TypeFieldDefinition field : this.fields)
/*     */     {
/*     */       String getPrefix;
/*     */       String setPrefix;
/* 138 */       switch (field.getType()) {
/* 139 */       case 4:  getPrefix = "is";setPrefix = "set"; break;
/* 140 */       default:  getPrefix = "get";setPrefix = "set";
/*     */       }
/*     */       
/* 143 */       code.append("  public " + field.getTypeDescription() + " " + getPrefix + field.getFieldName() + "() {").append(Const.CR);
/* 144 */       code.append("    return " + field.getMemberName() + ";").append(Const.CR);
/* 145 */       code.append("  }").append(Const.CR);
/* 146 */       code.append(Const.CR);
/*     */       
/* 148 */       code.append("  public void " + setPrefix + field.getFieldName() + "(" + field.getTypeDescription() + " " + field.getMemberName() + ") {").append(Const.CR);
/* 149 */       code.append("    this." + field.getMemberName() + " = " + field.getMemberName() + ";").append(Const.CR);
/* 150 */       code.append("  }").append(Const.CR);
/* 151 */       code.append(Const.CR);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */     for (TypeFieldDefinition field : this.fields) {
/* 162 */       code.append("  " + field.getMemberName() + "Item = new TableItem(wInputFields.table, SWT.NONE);").append(Const.CR);
/* 163 */       code.append("  " + field.getMemberName() + "Item.setText(1, BaseMessages.getString(PKG, \"PIQAddressDialog." + field.getFieldName() + ".Description\"));").append(Const.CR);
/* 164 */       code.append("  " + field.getMemberName() + "Item.setText(2, Const.NVL(input.get" + field.getFieldName() + "(), \"\"));").append(Const.CR);
/*     */     }
/*     */     
/* 167 */     for (TypeFieldDefinition field : this.fields) {
/* 168 */       code.append("PIQAddressDialog." + field.getFieldName() + ".Description = " + field.getFieldName()).append(" DESCRIPTION TODO").append(Const.CR);
/*     */     }
/*     */     
/* 171 */     return code.toString();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 175 */     MetaGenerator generator = new MetaGenerator(FIELDS);
/* 176 */     System.out.println(generator.generateCode());
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\MetaGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */