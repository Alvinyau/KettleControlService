/*     */ package org.pentaho.di.job.entries.getpop;
/*     */ 
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailConnectionMeta
/*     */ {
/*  37 */   private static Class<?> PKG = JobEntryGetPOP.class;
/*     */   
/*     */   public static final String FOLDER_SEPARATOR = "/";
/*     */   
/*     */   public static final int PROTOCOL_POP3 = 0;
/*     */   
/*     */   public static final int PROTOCOL_IMAP = 1;
/*     */   
/*     */   public static final String INBOX_FOLDER = "INBOX";
/*     */   public static final String PROTOCOL_STRING_IMAP = "IMAP";
/*     */   public static final String PROTOCOL_STRING_POP3 = "POP3";
/*  48 */   public static final String[] protocolCodes = { "POP3", "IMAP" };
/*     */   
/*     */   public static final int DEFAULT_IMAP_PORT = 110;
/*     */   
/*     */   public static final int DEFAULT_POP3_PORT = 110;
/*     */   public static final int DEFAULT_SSL_POP3_PORT = 995;
/*     */   public static final int DEFAULT_SSL_IMAP_PORT = 993;
/*  55 */   public static final String[] actionTypeDesc = { BaseMessages.getString(PKG, "JobGetPOP.ActionType.GetMessages.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.ActionType.MoveMessages.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.ActionType.DeleteMessages.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */   public static final String[] actionTypeCode = { "get", "move", "delete" };
/*     */   
/*     */ 
/*     */   public static final int ACTION_TYPE_GET = 0;
/*     */   
/*     */   public static final int ACTION_TYPE_MOVE = 1;
/*     */   
/*     */   public static final int ACTION_TYPE_DELETE = 2;
/*     */   
/*  70 */   public static final String[] conditionDateDesc = { BaseMessages.getString(PKG, "JobGetPOP.ConditionIgnore.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.ConditionEqual.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.ConditionSmaller.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.ConditionGreater.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.ConditionBetween.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   public static final String[] conditionDateCode = { "ignore", "equal", "smaller", "greater", "between" };
/*     */   
/*     */ 
/*     */   public static final int CONDITION_DATE_IGNORE = 0;
/*     */   
/*     */   public static final int CONDITION_DATE_EQUAL = 1;
/*     */   
/*     */   public static final int CONDITION_DATE_SMALLER = 2;
/*     */   
/*     */   public static final int CONDITION_DATE_GREATER = 3;
/*     */   
/*     */   public static final int CONDITION_DATE_BETWEEN = 4;
/*     */   
/*  91 */   public static final String[] valueIMAPListDesc = { BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetAll.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetNew.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetOld.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetRead.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetUnread.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetFlagged.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetUnFlagged.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetDraft.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetNotDraft.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetAnswered.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.IMAPListGetNotAnswered.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   public static final String[] valueIMAPListCode = { "imaplistall", "imaplistnew", "imaplistold", "imaplistread", "imaplistunread", "imaplistflagged", "imaplistnotflagged", "imaplistdraft", "imaplistnotdraft", "imaplistanswered", "imaplistnotanswered" };
/*     */   
/*     */ 
/*     */   public static final int VALUE_IMAP_LIST_ALL = 0;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_NEW = 1;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_OLD = 2;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_READ = 3;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_UNREAD = 4;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_FLAGGED = 5;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_NOT_FLAGGED = 6;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_DRAFT = 7;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_NOT_DRAFT = 8;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_ANWERED = 9;
/*     */   
/*     */   public static final int VALUE_IMAP_LIST_NOT_ANSWERED = 10;
/*     */   
/* 130 */   public static final String[] afterGetIMAPDesc = { BaseMessages.getString(PKG, "JobGetPOP.afterGetIMAP.Nothing.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.afterGetIMAP.Delete.Label", new String[0]), BaseMessages.getString(PKG, "JobGetPOP.afterGetIMAP.MoveTo.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   public static final String[] afterGetIMAPCode = { "nothing", "delete", "move" };
/*     */   
/*     */ 
/*     */   public static final int AFTER_GET_IMAP_NOTHING = 0;
/*     */   
/*     */ 
/*     */   public static final int AFTER_GET_IMAP_DELETE = 1;
/*     */   
/*     */ 
/*     */   public static final int AFTER_GET_IMAP_MOVE = 2;
/*     */   
/*     */ 
/*     */   public static String getValueImapListCode(int i)
/*     */   {
/* 150 */     if ((i < 0) || (i >= valueIMAPListCode.length))
/* 151 */       return valueIMAPListCode[0];
/* 152 */     return valueIMAPListCode[i];
/*     */   }
/*     */   
/*     */   public static int getConditionByCode(String tt) {
/* 156 */     if (tt == null) {
/* 157 */       return 0;
/*     */     }
/* 159 */     for (int i = 0; i < conditionDateCode.length; i++) {
/* 160 */       if (conditionDateCode[i].equalsIgnoreCase(tt))
/* 161 */         return i;
/*     */     }
/* 163 */     return 0;
/*     */   }
/*     */   
/* 166 */   public static int getActionTypeByCode(String tt) { if (tt == null) {
/* 167 */       return 0;
/*     */     }
/* 169 */     for (int i = 0; i < actionTypeCode.length; i++) {
/* 170 */       if (actionTypeCode[i].equalsIgnoreCase(tt))
/* 171 */         return i;
/*     */     }
/* 173 */     return 0;
/*     */   }
/*     */   
/* 176 */   public static int getAfterGetIMAPByCode(String tt) { if (tt == null) {
/* 177 */       return 0;
/*     */     }
/* 179 */     for (int i = 0; i < afterGetIMAPCode.length; i++) {
/* 180 */       if (afterGetIMAPCode[i].equalsIgnoreCase(tt))
/* 181 */         return i;
/*     */     }
/* 183 */     return 0;
/*     */   }
/*     */   
/* 186 */   public static int getValueImapListByCode(String tt) { if (tt == null) {
/* 187 */       return 0;
/*     */     }
/* 189 */     for (int i = 0; i < valueIMAPListCode.length; i++) {
/* 190 */       if (valueIMAPListCode[i].equalsIgnoreCase(tt))
/* 191 */         return i;
/*     */     }
/* 193 */     return 0;
/*     */   }
/*     */   
/* 196 */   public static int getValueListImapListByCode(String tt) { if (tt == null) {
/* 197 */       return 0;
/*     */     }
/* 199 */     for (int i = 0; i < valueIMAPListCode.length; i++) {
/* 200 */       if (valueIMAPListCode[i].equalsIgnoreCase(tt))
/* 201 */         return i;
/*     */     }
/* 203 */     return 0;
/*     */   }
/*     */   
/* 206 */   public static String getActionTypeCode(int i) { if ((i < 0) || (i >= actionTypeCode.length))
/* 207 */       return actionTypeCode[0];
/* 208 */     return actionTypeCode[i];
/*     */   }
/*     */   
/* 211 */   public static String getAfterGetIMAPCode(int i) { if ((i < 0) || (i >= afterGetIMAPCode.length))
/* 212 */       return afterGetIMAPCode[0];
/* 213 */     return afterGetIMAPCode[i];
/*     */   }
/*     */   
/* 216 */   public static String getConditionDateCode(int i) { if ((i < 0) || (i >= conditionDateCode.length))
/* 217 */       return conditionDateCode[0];
/* 218 */     return conditionDateCode[i];
/*     */   }
/*     */   
/* 221 */   public static int getValueImapListByDesc(String tt) { if (tt == null) {
/* 222 */       return 0;
/*     */     }
/* 224 */     for (int i = 0; i < valueIMAPListDesc.length; i++) {
/* 225 */       if (valueIMAPListDesc[i].equalsIgnoreCase(tt)) {
/* 226 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 230 */     return getValueImapListByCode(tt);
/*     */   }
/*     */   
/* 233 */   public static String getConditionDateDesc(int i) { if ((i < 0) || (i >= conditionDateDesc.length))
/* 234 */       return conditionDateDesc[0];
/* 235 */     return conditionDateDesc[i];
/*     */   }
/*     */   
/* 238 */   public static String getActionTypeDesc(int i) { if ((i < 0) || (i >= actionTypeDesc.length))
/* 239 */       return actionTypeDesc[0];
/* 240 */     return actionTypeDesc[i];
/*     */   }
/*     */   
/* 243 */   public static String getAfterGetIMAPDesc(int i) { if ((i < 0) || (i >= afterGetIMAPDesc.length))
/* 244 */       return afterGetIMAPDesc[0];
/* 245 */     return afterGetIMAPDesc[i];
/*     */   }
/*     */   
/* 248 */   public static String getValueImapListDesc(int i) { if ((i < 0) || (i >= valueIMAPListDesc.length))
/* 249 */       return valueIMAPListDesc[0];
/* 250 */     return valueIMAPListDesc[i];
/*     */   }
/*     */   
/* 253 */   public static int getConditionDateByDesc(String tt) { if (tt == null) {
/* 254 */       return 0;
/*     */     }
/* 256 */     for (int i = 0; i < conditionDateDesc.length; i++) {
/* 257 */       if (conditionDateDesc[i].equalsIgnoreCase(tt)) {
/* 258 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 262 */     return getConditionDateByCode(tt);
/*     */   }
/*     */   
/* 265 */   public static int getActionTypeByDesc(String tt) { if (tt == null) {
/* 266 */       return 0;
/*     */     }
/* 268 */     for (int i = 0; i < actionTypeDesc.length; i++) {
/* 269 */       if (actionTypeDesc[i].equalsIgnoreCase(tt)) {
/* 270 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 274 */     return getActionTypeByCode(tt);
/*     */   }
/*     */   
/*     */   public static int getAfterGetIMAPByDesc(String tt) {
/* 278 */     if (tt == null) {
/* 279 */       return 0;
/*     */     }
/* 281 */     for (int i = 0; i < afterGetIMAPDesc.length; i++) {
/* 282 */       if (afterGetIMAPDesc[i].equalsIgnoreCase(tt)) {
/* 283 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 287 */     return getAfterGetIMAPByCode(tt);
/*     */   }
/*     */   
/* 290 */   public static int getConditionDateByCode(String tt) { if (tt == null) {
/* 291 */       return 0;
/*     */     }
/* 293 */     for (int i = 0; i < conditionDateCode.length; i++) {
/* 294 */       if (conditionDateCode[i].equalsIgnoreCase(tt))
/* 295 */         return i;
/*     */     }
/* 297 */     return 0;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\getpop\MailConnectionMeta.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */