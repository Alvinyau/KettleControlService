/*     */ package org.pentaho.di.job.entries.createfolder;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entries.createfile.JobEntryCreateFile;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryCreateFolder
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*     */   private String foldername;
/*     */   private boolean failOfFolderExists;
/*     */   
/*     */   public JobEntryCreateFolder(String n)
/*     */   {
/*  71 */     super(n, "");
/*  72 */     this.foldername = null;
/*  73 */     this.failOfFolderExists = true;
/*  74 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryCreateFolder()
/*     */   {
/*  79 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  84 */     JobEntryCreateFolder je = (JobEntryCreateFolder)super.clone();
/*  85 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  90 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/*  92 */     retval.append(super.getXML());
/*  93 */     retval.append("      ").append(XMLHandler.addTagValue("foldername", this.foldername));
/*  94 */     retval.append("      ").append(XMLHandler.addTagValue("fail_of_folder_exists", this.failOfFolderExists));
/*     */     
/*  96 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       super.loadXML(entrynode, databases, slaveServers);
/* 104 */       this.foldername = XMLHandler.getTagValue(entrynode, "foldername");
/* 105 */       this.failOfFolderExists = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "fail_of_folder_exists"));
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 109 */       throw new KettleXMLException("Unable to load job entry of type 'create folder' from XML node", xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       this.foldername = rep.getJobEntryAttributeString(id_jobentry, "foldername");
/* 118 */       this.failOfFolderExists = rep.getJobEntryAttributeBoolean(id_jobentry, "fail_of_folder_exists");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 122 */       throw new KettleException("Unable to load job entry of type 'create Folder' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 130 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "foldername", this.foldername);
/* 131 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "fail_of_folder_exists", this.failOfFolderExists);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 135 */       throw new KettleException("Unable to save job entry of type 'create Folder' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFoldername(String foldername)
/*     */   {
/* 141 */     this.foldername = foldername;
/*     */   }
/*     */   
/*     */   public String getFoldername()
/*     */   {
/* 146 */     return this.foldername;
/*     */   }
/*     */   
/*     */   public String getRealFoldername()
/*     */   {
/* 151 */     return environmentSubstitute(getFoldername());
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 156 */     Result result = previousResult;
/* 157 */     result.setResult(false);
/*     */     
/*     */ 
/* 160 */     if (this.foldername != null)
/*     */     {
/* 162 */       String realFoldername = getRealFoldername();
/* 163 */       FileObject folderObject = null;
/*     */       try {
/* 165 */         folderObject = KettleVFS.getFileObject(realFoldername, this);
/*     */         
/* 167 */         if (folderObject.exists())
/*     */         {
/* 169 */           boolean isFolder = false;
/*     */           
/*     */ 
/* 172 */           if (folderObject.getType() == FileType.FOLDER) { isFolder = true;
/*     */           }
/* 174 */           if (isFailOfFolderExists())
/*     */           {
/*     */ 
/* 177 */             result.setResult(false);
/* 178 */             if (isFolder) {
/* 179 */               logError("Folder [" + realFoldername + "] exists, failing.");
/*     */             } else {
/* 181 */               logError("File [" + realFoldername + "] exists, failing.");
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 186 */             result.setResult(true);
/* 187 */             if (this.log.isDetailed()) {
/* 188 */               logDetailed("Folder [" + realFoldername + "] already exists, not recreating.");
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 196 */           folderObject.createFolder();
/* 197 */           if (this.log.isDetailed())
/* 198 */             logDetailed("Folder [" + realFoldername + "] created!");
/* 199 */           result.setResult(true);
/*     */         }
/*     */       } catch (Exception e) {
/* 202 */         logError("Could not create Folder [" + realFoldername + "]", e);
/* 203 */         result.setResult(false);
/* 204 */         result.setNrErrors(1L);
/*     */       }
/*     */       finally {
/* 207 */         if (folderObject != null) {
/*     */           try
/*     */           {
/* 210 */             folderObject.close();
/* 211 */             folderObject = null;
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 219 */       logError("No Foldername is defined.");
/*     */     }
/*     */     
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 227 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isFailOfFolderExists()
/*     */   {
/* 233 */     return this.failOfFolderExists;
/*     */   }
/*     */   
/*     */   public void setFailOfFolderExists(boolean failIfFolderExists) {
/* 237 */     this.failOfFolderExists = failIfFolderExists;
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 242 */     List<CheckResultInterface> remarks = new ArrayList();
/* 243 */     new JobEntryCreateFile().check(remarks, null);
/* 244 */     System.out.printf("Remarks: %s\n", new Object[] { remarks });
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 249 */     ValidatorContext ctx = new ValidatorContext();
/* 250 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 251 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileDoesNotExistValidator() });
/* 252 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\createfolder\JobEntryCreateFolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */