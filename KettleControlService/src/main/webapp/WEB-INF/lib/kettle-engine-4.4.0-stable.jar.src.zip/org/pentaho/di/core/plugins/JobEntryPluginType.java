/*     */ package org.pentaho.di.core.plugins;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.annotations.JobEntry;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannel;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PluginTypeCategoriesOrder(getNaturalCategoriesOrder={"BaseStep.Category.Input", "JobCategory.Category.General", "JobCategory.Category.Mail", "JobCategory.Category.FileManagement", "JobCategory.Category.Conditions", "JobCategory.Category.Scripting", "JobCategory.Category.BulkLoading", "JobCategory.Category.BigData", "JobCategory.Category.DataQuality", "JobCategory.Category.XML", "JobCategory.Category.Utility", "JobCategory.Category.Repository", "JobCategory.Category.FileTransfer", "JobCategory.Category.FileEncryption", "JobCategory.Category.Palo", "JobCategory.Category.Experimental"}, i18nPackageClass=JobMeta.class)
/*     */ @PluginMainClassType(JobEntryInterface.class)
/*     */ @PluginAnnotationType(JobEntry.class)
/*     */ public class JobEntryPluginType
/*     */   extends BasePluginType
/*     */   implements PluginTypeInterface
/*     */ {
/*  72 */   private static Class<?> PKG = JobMeta.class;
/*     */   
/*  74 */   public static final String GENERAL_CATEGORY = BaseMessages.getString(PKG, "JobCategory.Category.General", new String[0]);
/*     */   private static JobEntryPluginType pluginType;
/*     */   
/*     */   private JobEntryPluginType()
/*     */   {
/*  79 */     super(JobEntry.class, "JOBENTRY", "Job entry");
/*  80 */     populateFolders("jobentries");
/*     */   }
/*     */   
/*     */   public static JobEntryPluginType getInstance() {
/*  84 */     if (pluginType == null) {
/*  85 */       pluginType = new JobEntryPluginType();
/*     */     }
/*  87 */     return pluginType;
/*     */   }
/*     */   
/*     */ 
/*     */   public void searchPlugins()
/*     */     throws KettlePluginException
/*     */   {
/*  94 */     registerNatives();
/*  95 */     registerAnnotations();
/*  96 */     registerPluginJars();
/*  97 */     registerXmlPlugins();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerNatives()
/*     */     throws KettlePluginException
/*     */   {
/* 106 */     String kettleJobEntriesXmlFile = "kettle-job-entries.xml";
/* 107 */     String alternative = System.getProperty("KETTLE_CORE_JOBENTRIES_FILE", null);
/* 108 */     if (!Const.isEmpty(alternative)) {
/* 109 */       kettleJobEntriesXmlFile = alternative;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 115 */       InputStream inputStream = getClass().getResourceAsStream(kettleJobEntriesXmlFile);
/* 116 */       if (inputStream == null) {
/* 117 */         inputStream = getClass().getResourceAsStream("/" + kettleJobEntriesXmlFile);
/*     */       }
/*     */       
/* 120 */       if ((inputStream == null) && (!Const.isEmpty(alternative))) {
/*     */         try {
/* 122 */           inputStream = new FileInputStream(kettleJobEntriesXmlFile);
/*     */         } catch (Exception e) {
/* 124 */           throw new KettlePluginException("Unable to load native job entries plugins '" + kettleJobEntriesXmlFile + "'", e);
/*     */         }
/*     */       }
/* 127 */       if (inputStream == null) {
/* 128 */         throw new KettlePluginException("Unable to find native step definition file: kettle-job-entries.xml");
/*     */       }
/* 130 */       Document document = XMLHandler.loadXMLFile(inputStream, null, true, false);
/*     */       
/*     */ 
/*     */ 
/* 134 */       Node entriesNode = XMLHandler.getSubNode(document, "job-entries");
/* 135 */       List<Node> entryNodes = XMLHandler.getNodes(entriesNode, "job-entry");
/* 136 */       for (Node entryNode : entryNodes) {
/* 137 */         registerPluginFromXmlResource(entryNode, null, getClass(), true, null);
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException e) {
/* 141 */       throw new KettlePluginException("Unable to read the kettle job entries XML config file: " + kettleJobEntriesXmlFile, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void registerAnnotations()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */ 
/*     */   protected void registerXmlPlugins()
/*     */     throws KettlePluginException
/*     */   {
/* 155 */     for (PluginFolderInterface folder : this.pluginFolders)
/*     */     {
/* 157 */       if (folder.isPluginXmlFolder()) {
/* 158 */         List<FileObject> pluginXmlFiles = findPluginXmlFiles(folder.getFolder());
/* 159 */         for (FileObject file : pluginXmlFiles) {
/*     */           try
/*     */           {
/* 162 */             Document document = XMLHandler.loadXMLFile(file);
/* 163 */             Node pluginNode = XMLHandler.getSubNode(document, "plugin");
/*     */             
/* 165 */             registerPluginFromXmlResource(pluginNode, KettleVFS.getFilename(file.getParent()), getClass(), false, file.getParent().getURL());
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 169 */             this.log.logError("Error found while reading job entry plugin.xml file: " + file.getName().toString(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String extractCategory(Annotation annotation)
/*     */   {
/* 178 */     return ((JobEntry)annotation).categoryDescription();
/*     */   }
/*     */   
/*     */   protected String extractDesc(Annotation annotation)
/*     */   {
/* 183 */     return ((JobEntry)annotation).description();
/*     */   }
/*     */   
/*     */   protected String extractID(Annotation annotation)
/*     */   {
/* 188 */     return ((JobEntry)annotation).id();
/*     */   }
/*     */   
/*     */   protected String extractName(Annotation annotation)
/*     */   {
/* 193 */     return ((JobEntry)annotation).name();
/*     */   }
/*     */   
/*     */   protected String extractImageFile(Annotation annotation)
/*     */   {
/* 198 */     return ((JobEntry)annotation).image();
/*     */   }
/*     */   
/*     */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*     */   {
/* 203 */     return false;
/*     */   }
/*     */   
/*     */   protected String extractI18nPackageName(Annotation annotation)
/*     */   {
/* 208 */     return ((JobEntry)annotation).i18nPackageName();
/*     */   }
/*     */   
/*     */   protected void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation) {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\JobEntryPluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */