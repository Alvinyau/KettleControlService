package org.pentaho.di.core;

public abstract interface TableManager
{
  public abstract void setTableName(String paramString);
  
  public abstract boolean flush();
  
  public abstract boolean dropTable();
  
  public abstract void setRowLimit(long paramLong);
  
  public abstract boolean truncateTable();
  
  public abstract boolean adjustSchema();
  
  public abstract String getMessage();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\TableManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */