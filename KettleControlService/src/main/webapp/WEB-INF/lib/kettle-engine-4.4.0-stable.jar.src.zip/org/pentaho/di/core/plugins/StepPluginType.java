/*     */ package org.pentaho.di.core.plugins;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.annotations.Step;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannel;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.trans.step.StepInterface;
/*     */ import org.pentaho.di.trans.step.StepMetaInterface;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PluginTypeCategoriesOrder(getNaturalCategoriesOrder={"BaseStep.Category.Input", "BaseStep.Category.Output", "BaseStep.Category.Transform", "BaseStep.Category.Utility", "BaseStep.Category.Flow", "BaseStep.Category.Scripting", "BaseStep.Category.Lookup", "BaseStep.Category.Joins", "BaseStep.Category.DataWarehouse", "BaseStep.Category.Validation", "BaseStep.Category.Statistics", "BaseStep.Category.BigData", "BaseStep.Category.Agile", "BaseStep.Category.DataQuality", "BaseStep.Category.Cryptography", "BaseStep.Category.Palo", "BaseStep.Category.OpenERP", "BaseStep.Category.Job", "BaseStep.Category.Mapping", "BaseStep.Category.Bulk", "BaseStep.Category.Inline", "BaseStep.Category.Experimental", "BaseStep.Category.Deprecated"}, i18nPackageClass=StepInterface.class)
/*     */ @PluginMainClassType(StepMetaInterface.class)
/*     */ @PluginAnnotationType(Step.class)
/*     */ public class StepPluginType
/*     */   extends BasePluginType
/*     */   implements PluginTypeInterface
/*     */ {
/*     */   private static StepPluginType stepPluginType;
/*     */   
/*     */   private StepPluginType()
/*     */   {
/*  81 */     super(Step.class, "STEP", "Step");
/*  82 */     populateFolders("steps");
/*     */   }
/*     */   
/*     */   public static StepPluginType getInstance() {
/*  86 */     if (stepPluginType == null) {
/*  87 */       stepPluginType = new StepPluginType();
/*     */     }
/*  89 */     return stepPluginType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerNatives()
/*     */     throws KettlePluginException
/*     */   {
/*  98 */     String kettleStepsXmlFile = "kettle-steps.xml";
/*  99 */     String alternative = System.getProperty("KETTLE_CORE_STEPS_FILE", null);
/* 100 */     if (!Const.isEmpty(alternative)) {
/* 101 */       kettleStepsXmlFile = alternative;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 107 */       InputStream inputStream = getClass().getResourceAsStream(kettleStepsXmlFile);
/* 108 */       if (inputStream == null) {
/* 109 */         inputStream = getClass().getResourceAsStream("/" + kettleStepsXmlFile);
/*     */       }
/*     */       
/* 112 */       if ((inputStream == null) && (!Const.isEmpty(alternative))) {
/*     */         try {
/* 114 */           inputStream = new FileInputStream(kettleStepsXmlFile);
/*     */         } catch (Exception e) {
/* 116 */           throw new KettlePluginException("Unable to load native step plugins '" + kettleStepsXmlFile + "'", e);
/*     */         }
/*     */       }
/* 119 */       if (inputStream == null) {
/* 120 */         throw new KettlePluginException("Unable to find native step definition file: kettle-steps.xml");
/*     */       }
/* 122 */       Document document = XMLHandler.loadXMLFile(inputStream, null, true, false);
/*     */       
/*     */ 
/*     */ 
/* 126 */       Node stepsNode = XMLHandler.getSubNode(document, "steps");
/* 127 */       List<Node> stepNodes = XMLHandler.getNodes(stepsNode, "step");
/* 128 */       for (Node stepNode : stepNodes) {
/* 129 */         registerPluginFromXmlResource(stepNode, null, getClass(), true, null);
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException e) {
/* 133 */       throw new KettlePluginException("Unable to read the kettle steps XML config file: " + kettleStepsXmlFile, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerXmlPlugins() throws KettlePluginException {
/* 138 */     for (PluginFolderInterface folder : this.pluginFolders)
/*     */     {
/* 140 */       if (folder.isPluginXmlFolder()) {
/* 141 */         List<FileObject> pluginXmlFiles = findPluginXmlFiles(folder.getFolder());
/* 142 */         for (FileObject file : pluginXmlFiles) {
/*     */           try
/*     */           {
/* 145 */             Document document = XMLHandler.loadXMLFile(file);
/* 146 */             Node pluginNode = XMLHandler.getSubNode(document, "plugin");
/* 147 */             if (pluginNode != null) {
/* 148 */               registerPluginFromXmlResource(pluginNode, KettleVFS.getFilename(file.getParent()), getClass(), false, file.getParent().getURL());
/*     */             }
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 153 */             this.log.logError("Error found while reading step plugin.xml file: " + file.getName().toString(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected String extractCategory(Annotation annotation)
/*     */   {
/* 162 */     return ((Step)annotation).categoryDescription();
/*     */   }
/*     */   
/*     */   protected String extractDesc(Annotation annotation)
/*     */   {
/* 167 */     return ((Step)annotation).description();
/*     */   }
/*     */   
/*     */   protected String extractID(Annotation annotation)
/*     */   {
/* 172 */     return ((Step)annotation).id();
/*     */   }
/*     */   
/*     */   protected String extractName(Annotation annotation)
/*     */   {
/* 177 */     return ((Step)annotation).name();
/*     */   }
/*     */   
/*     */   protected String extractImageFile(Annotation annotation)
/*     */   {
/* 182 */     return ((Step)annotation).image();
/*     */   }
/*     */   
/*     */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*     */   {
/* 187 */     return ((Step)annotation).isSeparateClassLoaderNeeded();
/*     */   }
/*     */   
/*     */   protected String extractI18nPackageName(Annotation annotation)
/*     */   {
/* 192 */     return ((Step)annotation).i18nPackageName();
/*     */   }
/*     */   
/*     */   protected void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation) {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\StepPluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */