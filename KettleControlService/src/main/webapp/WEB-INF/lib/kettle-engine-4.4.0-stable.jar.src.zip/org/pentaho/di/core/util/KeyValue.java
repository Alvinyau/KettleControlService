/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyValue<T>
/*     */   implements Serializable
/*     */ {
/*  43 */   public static final List<String> DEFAULT_TRUE_VALUES = Arrays.asList(new String[] { "j", "y", "on", "true" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String VALID_KEY_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789_-";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final long serialVersionUID = -6847244072467344205L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String key;
/*     */   
/*     */ 
/*     */ 
/*     */   private T value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(String key, T value)
/*     */     throws IllegalArgumentException
/*     */   {
/*  70 */     String keyToSet = StringUtils.lowerCase(key);
/*  71 */     assertKey(keyToSet);
/*  72 */     this.key = keyToSet;
/*  73 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  85 */     this(key, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void assertKey(String lowerKey)
/*     */     throws IllegalArgumentException
/*     */   {
/*  95 */     Assert.assertNotEmpty(lowerKey, "Key cannot be null or empty");
/*  96 */     if (!StringUtils.containsOnly(lowerKey, "abcdefghijklmnopqrstuvwxyz0123456789_-")) {
/*  97 */       throw new IllegalArgumentException("Key contains invalid characters [validKeyCharacters=abcdefghijklmnopqrstuvwxyz0123456789_-]");
/*     */     }
/*     */     
/* 100 */     if (lowerKey.charAt(0) == '-') {
/* 101 */       throw new IllegalArgumentException("Key must not start with '-'");
/*     */     }
/* 103 */     if (lowerKey.endsWith("-")) {
/* 104 */       throw new IllegalArgumentException("Key must not end with '-'");
/*     */     }
/* 106 */     if ("_".equals(lowerKey)) {
/* 107 */       throw new IllegalArgumentException("Key must not be  '_'");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getKey()
/*     */   {
/* 115 */     return this.key;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public T getValue()
/*     */   {
/* 122 */     return (T)this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(T value)
/*     */   {
/* 130 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue<T> value(T newValue)
/*     */   {
/* 139 */     this.value = newValue;
/* 140 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public T value()
/*     */   {
/* 147 */     return (T)this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean booleanValue(String... trueValues)
/*     */   {
/* 156 */     return booleanValue(Arrays.asList(trueValues));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean booleanValue(List<String> trueValues)
/*     */   {
/* 165 */     return booleanValue(trueValues, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean booleanValue(List<String> trueValues, boolean ignoreCase)
/*     */   {
/* 176 */     if (this.value == null) {
/* 177 */       return null;
/*     */     }
/* 179 */     if ((this.value instanceof Boolean)) {
/* 180 */       return (Boolean)this.value;
/*     */     }
/* 182 */     String stringValue = stringValue();
/* 183 */     if (ignoreCase) {
/* 184 */       return Boolean.valueOf(trueValues.contains(StringUtils.lowerCase(stringValue)));
/*     */     }
/* 186 */     return Boolean.valueOf(trueValues.contains(stringValue));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean booleanValue()
/*     */   {
/* 195 */     return booleanValue(DEFAULT_TRUE_VALUES, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean booleanValue(Boolean defaultValue)
/*     */   {
/* 204 */     Boolean returnValue = booleanValue();
/* 205 */     if (returnValue == null) {
/* 206 */       return defaultValue;
/*     */     }
/* 208 */     return returnValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String stringValue()
/*     */   {
/* 215 */     if (this.value == null) {
/* 216 */       return null;
/*     */     }
/* 218 */     if ((this.value instanceof String)) {
/* 219 */       return (String)this.value;
/*     */     }
/* 221 */     return String.valueOf(this.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String stringValue(String defaultValue)
/*     */   {
/* 230 */     String returnValue = stringValue();
/* 231 */     if (returnValue == null) {
/* 232 */       return defaultValue;
/*     */     }
/* 234 */     return returnValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String stringValueDefaultIfBlank(String defaultValue)
/*     */   {
/* 243 */     String returnValue = stringValue();
/* 244 */     if (StringUtils.isBlank(returnValue)) {
/* 245 */       return defaultValue;
/*     */     }
/* 247 */     return returnValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer integerValue()
/*     */     throws NumberFormatException
/*     */   {
/* 256 */     if (this.value == null) {
/* 257 */       return null;
/*     */     }
/* 259 */     if ((this.value instanceof Integer)) {
/* 260 */       return (Integer)this.value;
/*     */     }
/* 262 */     return Integer.valueOf(String.valueOf(this.value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer integerValue(Integer defaultValue)
/*     */   {
/* 271 */     if (this.value == null) {
/* 272 */       return defaultValue;
/*     */     }
/*     */     try {
/* 275 */       return integerValue();
/*     */     } catch (NumberFormatException e) {}
/* 277 */     return defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Long longValue()
/*     */     throws NumberFormatException
/*     */   {
/* 287 */     if (this.value == null) {
/* 288 */       return null;
/*     */     }
/* 290 */     if ((this.value instanceof Long)) {
/* 291 */       return (Long)this.value;
/*     */     }
/* 293 */     return Long.valueOf(String.valueOf(this.value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Long longValue(Long defaultValue)
/*     */   {
/* 302 */     if (this.value == null) {
/* 303 */       return defaultValue;
/*     */     }
/*     */     try {
/* 306 */       return longValue();
/*     */     } catch (NumberFormatException e) {}
/* 308 */     return defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Double doubleValue()
/*     */     throws NumberFormatException
/*     */   {
/* 318 */     if (this.value == null) {
/* 319 */       return null;
/*     */     }
/* 321 */     if ((this.value instanceof Double)) {
/* 322 */       return (Double)this.value;
/*     */     }
/* 324 */     return Double.valueOf(String.valueOf(this.value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Double doubleValue(Double defaultValue)
/*     */   {
/* 333 */     if (this.value == null) {
/* 334 */       return defaultValue;
/*     */     }
/*     */     try {
/* 337 */       return doubleValue();
/*     */     } catch (NumberFormatException e) {}
/* 339 */     return defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Float floatValue()
/*     */     throws NumberFormatException
/*     */   {
/* 349 */     if (this.value == null) {
/* 350 */       return null;
/*     */     }
/* 352 */     if ((this.value instanceof Float)) {
/* 353 */       return (Float)this.value;
/*     */     }
/* 355 */     return Float.valueOf(String.valueOf(this.value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Float floatValue(Float defaultValue)
/*     */   {
/* 364 */     if (this.value == null) {
/* 365 */       return defaultValue;
/*     */     }
/*     */     try {
/* 368 */       return floatValue();
/*     */     } catch (NumberFormatException e) {}
/* 370 */     return defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 381 */     StringBuilder builder = new StringBuilder();
/* 382 */     builder.append(KeyValue.class.getSimpleName());
/* 383 */     builder.append('(');
/* 384 */     builder.append(this.key);
/* 385 */     if (this.value == null) {
/* 386 */       builder.append("<null>)");
/*     */     } else {
/* 388 */       builder.append("=[");
/* 389 */       builder.append(this.value);
/* 390 */       builder.append("])");
/*     */     }
/* 392 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\KeyValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */