/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.RepositoryAttributeInterface;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseLogTable
/*     */ {
/*     */   public static final String XML_TAG = "field";
/*  40 */   public static String PROP_LOG_TABLE_CONNECTION_NAME = "_LOG_TABLE_CONNECTION_NAME";
/*  41 */   public static String PROP_LOG_TABLE_SCHEMA_NAME = "_LOG_TABLE_SCHEMA_NAME";
/*  42 */   public static String PROP_LOG_TABLE_TABLE_NAME = "_LOG_TABLE_TABLE_NAME";
/*     */   
/*  44 */   public static String PROP_LOG_TABLE_FIELD_ID = "_LOG_TABLE_FIELD_ID";
/*  45 */   public static String PROP_LOG_TABLE_FIELD_NAME = "_LOG_TABLE_FIELD_NAME";
/*  46 */   public static String PROP_LOG_TABLE_FIELD_ENABLED = "_LOG_TABLE_FIELD_ENABLED";
/*  47 */   public static String PROP_LOG_TABLE_FIELD_SUBJECT = "_LOG_TABLE_FIELD_SUBJECT";
/*     */   
/*  49 */   public static String PROP_LOG_TABLE_INTERVAL = "LOG_TABLE_INTERVAL";
/*  50 */   public static String PROP_LOG_TABLE_SIZE_LIMIT = "LOG_TABLE_SIZE_LIMIT";
/*  51 */   public static String PROP_LOG_TABLE_TIMEOUT_DAYS = "_LOG_TABLE_TIMEOUT_IN_DAYS";
/*     */   
/*     */   protected VariableSpace space;
/*     */   
/*     */   protected HasDatabasesInterface databasesInterface;
/*     */   
/*     */   protected String connectionName;
/*     */   protected String schemaName;
/*     */   protected String tableName;
/*     */   protected String timeoutInDays;
/*     */   protected List<LogTableField> fields;
/*     */   
/*     */   public BaseLogTable(VariableSpace space, HasDatabasesInterface databasesInterface, String connectionName, String schemaName, String tableName)
/*     */   {
/*  65 */     this.space = space;
/*  66 */     this.databasesInterface = databasesInterface;
/*  67 */     this.connectionName = connectionName;
/*  68 */     this.schemaName = schemaName;
/*  69 */     this.tableName = tableName;
/*  70 */     this.fields = new ArrayList();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  74 */     if (isDefined()) {
/*  75 */       return getDatabaseMeta().getName() + "-" + getActualTableName();
/*     */     }
/*  77 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToRepository(RepositoryAttributeInterface attributeInterface)
/*     */     throws KettleException
/*     */   {
/*  87 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_CONNECTION_NAME, getConnectionName());
/*  88 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_SCHEMA_NAME, getSchemaName());
/*  89 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_TABLE_NAME, getTableName());
/*  90 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_TIMEOUT_DAYS, getTimeoutInDays());
/*     */     
/*     */ 
/*     */ 
/*  94 */     for (int i = 0; i < getFields().size(); i++) {
/*  95 */       LogTableField field = (LogTableField)getFields().get(i);
/*  96 */       attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_FIELD_ID + i, field.getId());
/*  97 */       attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_FIELD_NAME + i, field.getFieldName());
/*  98 */       attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_FIELD_ENABLED + i, field.isEnabled());
/*     */       
/* 100 */       if (field.isSubjectAllowed()) {
/* 101 */         attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_FIELD_SUBJECT + i, field.getSubject() == null ? null : field.getSubject().toString());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadFromRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 107 */     String connectionNameFromRepository = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_CONNECTION_NAME);
/* 108 */     if (connectionNameFromRepository != null) {
/* 109 */       this.connectionName = connectionNameFromRepository;
/*     */     }
/* 111 */     String schemaNameFromRepository = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_SCHEMA_NAME);
/* 112 */     if (schemaNameFromRepository != null) {
/* 113 */       this.schemaName = schemaNameFromRepository;
/*     */     }
/* 115 */     String tableNameFromRepository = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_TABLE_NAME);
/* 116 */     if (tableNameFromRepository != null) {
/* 117 */       this.tableName = tableNameFromRepository;
/*     */     }
/* 119 */     this.timeoutInDays = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_TIMEOUT_DAYS);
/* 120 */     for (int i = 0; i < getFields().size(); i++) {
/* 121 */       String id = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_FIELD_ID + i);
/*     */       
/*     */ 
/*     */ 
/* 125 */       if (id != null) {
/* 126 */         LogTableField field = findField(id);
/* 127 */         field.setFieldName(attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_FIELD_NAME + i));
/* 128 */         field.setEnabled(attributeInterface.getAttributeBoolean(getLogTableCode() + PROP_LOG_TABLE_FIELD_ENABLED + i));
/* 129 */         if (field.isSubjectAllowed()) {
/* 130 */           field.setSubject(attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_FIELD_SUBJECT + i));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   abstract String getLogTableCode();
/*     */   
/*     */ 
/*     */   abstract String getConnectionNameVariable();
/*     */   
/*     */ 
/*     */   abstract String getSchemaNameVariable();
/*     */   
/*     */ 
/*     */   abstract String getTableNameVariable();
/*     */   
/*     */   public DatabaseMeta getDatabaseMeta()
/*     */   {
/* 150 */     String name = getActualConnectionName();
/* 151 */     if (name == null) { return null;
/*     */     }
/* 153 */     return this.databasesInterface.findDatabase(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getActualConnectionName()
/*     */   {
/* 160 */     String name = this.space.environmentSubstitute(this.connectionName);
/* 161 */     if (Const.isEmpty(name)) {
/* 162 */       name = this.space.getVariable(getConnectionNameVariable());
/*     */     }
/* 164 */     if (Const.isEmpty(name)) {
/* 165 */       return null;
/*     */     }
/* 167 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getActualSchemaName()
/*     */   {
/* 174 */     if (!Const.isEmpty(this.schemaName)) { return this.space.environmentSubstitute(this.schemaName);
/*     */     }
/* 176 */     String name = this.space.getVariable(getSchemaNameVariable());
/* 177 */     if (Const.isEmpty(name)) {
/* 178 */       return null;
/*     */     }
/* 180 */     return name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 188 */     this.schemaName = schemaName;
/*     */   }
/*     */   
/*     */   public String getSchemaName() {
/* 192 */     return this.schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getActualTableName()
/*     */   {
/* 199 */     if (!Const.isEmpty(this.tableName)) { return this.space.environmentSubstitute(this.tableName);
/*     */     }
/* 201 */     String name = this.space.getVariable(getTableNameVariable());
/* 202 */     if (Const.isEmpty(name)) {
/* 203 */       return null;
/*     */     }
/* 205 */     return name;
/*     */   }
/*     */   
/*     */   public String getTableName()
/*     */   {
/* 210 */     return this.tableName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTableName(String tableName)
/*     */   {
/* 218 */     this.tableName = tableName;
/*     */   }
/*     */   
/*     */   public String getQuotedSchemaTableCombination() {
/* 222 */     return getDatabaseMeta().getQuotedSchemaTableCombination(getActualSchemaName(), getActualTableName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<LogTableField> getFields()
/*     */   {
/* 229 */     return this.fields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFields(List<LogTableField> fields)
/*     */   {
/* 236 */     this.fields = fields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LogTableField findField(String id)
/*     */   {
/* 246 */     for (LogTableField field : this.fields) {
/* 247 */       if (field.getId().equals(id)) {
/* 248 */         return field;
/*     */       }
/*     */     }
/* 251 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getSubject(String id)
/*     */   {
/* 260 */     LogTableField field = findField(id);
/* 261 */     if (field == null) return null;
/* 262 */     return field.getSubject();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubjectString(String id)
/*     */   {
/* 271 */     LogTableField field = findField(id);
/* 272 */     if (field == null) return null;
/* 273 */     if (field.getSubject() == null) return null;
/* 274 */     return field.getSubject().toString();
/*     */   }
/*     */   
/*     */   public boolean containsKeyField() {
/* 278 */     for (LogTableField field : this.fields) {
/* 279 */       if (field.isKey()) return true;
/*     */     }
/* 281 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LogTableField getLogDateField()
/*     */   {
/* 288 */     for (LogTableField field : this.fields) {
/* 289 */       if (field.isLogDateField()) {
/* 290 */         return field;
/*     */       }
/*     */     }
/* 293 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LogTableField getKeyField()
/*     */   {
/* 300 */     for (LogTableField field : this.fields) {
/* 301 */       if (field.isKey()) {
/* 302 */         return field;
/*     */       }
/*     */     }
/* 305 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LogTableField getLogField()
/*     */   {
/* 312 */     for (LogTableField field : this.fields) {
/* 313 */       if (field.isLogField()) {
/* 314 */         return field;
/*     */       }
/*     */     }
/* 317 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LogTableField getStatusField()
/*     */   {
/* 324 */     for (LogTableField field : this.fields) {
/* 325 */       if (field.isStatusField()) {
/* 326 */         return field;
/*     */       }
/*     */     }
/* 329 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LogTableField getErrorsField()
/*     */   {
/* 336 */     for (LogTableField field : this.fields) {
/* 337 */       if (field.isErrorsField()) {
/* 338 */         return field;
/*     */       }
/*     */     }
/* 341 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LogTableField getNameField()
/*     */   {
/* 348 */     for (LogTableField field : this.fields) {
/* 349 */       if (field.isNameField()) {
/* 350 */         return field;
/*     */       }
/*     */     }
/* 353 */     return null;
/*     */   }
/*     */   
/*     */   protected String getFieldsXML() {
/* 357 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 359 */     for (LogTableField field : this.fields) {
/* 360 */       retval.append(XMLHandler.openTag("field"));
/*     */       
/* 362 */       retval.append(XMLHandler.addTagValue("id", field.getId(), false, new String[0]));
/* 363 */       retval.append(XMLHandler.addTagValue("enabled", field.isEnabled(), false));
/* 364 */       retval.append(XMLHandler.addTagValue("name", field.getFieldName(), false, new String[0]));
/* 365 */       if (field.isSubjectAllowed()) {
/* 366 */         retval.append(XMLHandler.addTagValue("subject", field.getSubject() == null ? null : field.getSubject().toString(), false, new String[0]));
/*     */       }
/*     */       
/* 369 */       retval.append(XMLHandler.closeTag("field"));
/*     */     }
/*     */     
/*     */ 
/* 373 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadFieldsXML(Node node) {
/* 377 */     int nr = XMLHandler.countNodes(node, "field");
/* 378 */     for (int i = 0; i < nr; i++) {
/* 379 */       Node fieldNode = XMLHandler.getSubNodeByNr(node, "field", i);
/* 380 */       String id = XMLHandler.getTagValue(fieldNode, "id");
/* 381 */       LogTableField field = findField(id);
/* 382 */       if ((field == null) && (i < this.fields.size())) {
/* 383 */         field = (LogTableField)this.fields.get(i);
/*     */       }
/* 385 */       if (field != null) {
/* 386 */         field.setFieldName(XMLHandler.getTagValue(fieldNode, "name"));
/* 387 */         field.setEnabled("Y".equalsIgnoreCase(XMLHandler.getTagValue(fieldNode, "enabled")));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isDefined() {
/* 393 */     return (getDatabaseMeta() != null) && (!Const.isEmpty(getActualTableName()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTimeoutInDays()
/*     */   {
/* 400 */     return this.timeoutInDays;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTimeoutInDays(String timeoutInDays)
/*     */   {
/* 407 */     this.timeoutInDays = timeoutInDays;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConnectionName()
/*     */   {
/* 414 */     return this.connectionName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setConnectionName(String connectionName)
/*     */   {
/* 421 */     this.connectionName = connectionName;
/*     */   }
/*     */   
/*     */   protected String getLogBuffer(VariableSpace space, String logChannelId, LogStatus status, String limit)
/*     */   {
/* 426 */     StringBuffer buffer = CentralLogStore.getAppender().getBuffer(logChannelId, true);
/*     */     
/* 428 */     if (Const.isEmpty(limit)) {
/* 429 */       String defaultLimit = space.getVariable("KETTLE_LOG_SIZE_LIMIT", null);
/* 430 */       if (!Const.isEmpty(defaultLimit)) {
/* 431 */         limit = defaultLimit;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 437 */     int nrLines = Const.isEmpty(limit) ? -1 : Const.toInt(space.environmentSubstitute(limit), -1);
/*     */     
/* 439 */     if (nrLines > 0) {
/* 440 */       int start = buffer.length() - 1;
/* 441 */       for (int i = 0; (i < nrLines) && (start > 0); i++) {
/* 442 */         start = buffer.lastIndexOf(Const.CR, start - 1);
/*     */       }
/* 444 */       if (start > 0) {
/* 445 */         buffer.delete(0, start + Const.CR.length());
/*     */       }
/*     */     }
/*     */     
/* 449 */     return new StringBuilder().append(Const.CR).append(status.getStatus().toUpperCase()).append(Const.CR).toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 455 */     if ((obj == null) || (!(obj instanceof BaseLogTable))) return false;
/* 456 */     BaseLogTable blt = (BaseLogTable)obj;
/*     */     
/*     */ 
/* 459 */     String cName = getActualConnectionName();
/* 460 */     String sName = getActualSchemaName();
/* 461 */     String tName = getActualTableName();
/*     */     
/* 463 */     return (cName == null ? blt.getActualConnectionName() == null : cName.equals(blt.getActualConnectionName())) && (sName == null ? blt.getActualSchemaName() == null : sName.equals(blt.getActualSchemaName())) && (tName == null ? blt.getActualTableName() == null : tName.equals(blt.getActualTableName()));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\BaseLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */