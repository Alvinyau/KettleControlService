/*     */ package org.pentaho.di.job.entries.mysqlbulkload;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.provider.local.LocalFile;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.Database;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleFileException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryMysqlBulkLoad
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  69 */   private static Class<?> PKG = JobEntryMysqlBulkLoad.class;
/*     */   
/*     */   private String schemaname;
/*     */   
/*     */   private String tablename;
/*     */   private String filename;
/*     */   private String separator;
/*     */   private String enclosed;
/*     */   private String escaped;
/*     */   private String linestarted;
/*     */   private String lineterminated;
/*     */   private String ignorelines;
/*     */   private boolean replacedata;
/*     */   private String listattribut;
/*     */   private boolean localinfile;
/*     */   public int prorityvalue;
/*     */   private boolean addfiletoresult;
/*     */   private DatabaseMeta connection;
/*     */   
/*     */   public JobEntryMysqlBulkLoad(String n)
/*     */   {
/*  90 */     super(n, "");
/*  91 */     this.tablename = null;
/*  92 */     this.schemaname = null;
/*  93 */     this.filename = null;
/*  94 */     this.separator = null;
/*  95 */     this.enclosed = null;
/*  96 */     this.escaped = null;
/*  97 */     this.lineterminated = null;
/*  98 */     this.linestarted = null;
/*  99 */     this.replacedata = true;
/* 100 */     this.ignorelines = "0";
/* 101 */     this.listattribut = null;
/* 102 */     this.localinfile = true;
/* 103 */     this.connection = null;
/* 104 */     this.addfiletoresult = false;
/* 105 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryMysqlBulkLoad()
/*     */   {
/* 110 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 115 */     JobEntryMysqlBulkLoad je = (JobEntryMysqlBulkLoad)super.clone();
/* 116 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 121 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/* 123 */     retval.append(super.getXML());
/* 124 */     retval.append("      ").append(XMLHandler.addTagValue("schemaname", this.schemaname));
/* 125 */     retval.append("      ").append(XMLHandler.addTagValue("tablename", this.tablename));
/* 126 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/* 127 */     retval.append("      ").append(XMLHandler.addTagValue("separator", this.separator));
/* 128 */     retval.append("      ").append(XMLHandler.addTagValue("enclosed", this.enclosed));
/* 129 */     retval.append("      ").append(XMLHandler.addTagValue("escaped", this.escaped));
/* 130 */     retval.append("      ").append(XMLHandler.addTagValue("linestarted", this.linestarted));
/* 131 */     retval.append("      ").append(XMLHandler.addTagValue("lineterminated", this.lineterminated));
/*     */     
/* 133 */     retval.append("      ").append(XMLHandler.addTagValue("replacedata", this.replacedata));
/* 134 */     retval.append("      ").append(XMLHandler.addTagValue("ignorelines", this.ignorelines));
/* 135 */     retval.append("      ").append(XMLHandler.addTagValue("listattribut", this.listattribut));
/*     */     
/* 137 */     retval.append("      ").append(XMLHandler.addTagValue("localinfile", this.localinfile));
/*     */     
/* 139 */     retval.append("      ").append(XMLHandler.addTagValue("prorityvalue", this.prorityvalue));
/*     */     
/* 141 */     retval.append("      ").append(XMLHandler.addTagValue("addfiletoresult", this.addfiletoresult));
/*     */     
/* 143 */     retval.append("      ").append(XMLHandler.addTagValue("connection", this.connection == null ? null : this.connection.getName()));
/*     */     
/* 145 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 152 */       super.loadXML(entrynode, databases, slaveServers);
/* 153 */       this.schemaname = XMLHandler.getTagValue(entrynode, "schemaname");
/* 154 */       this.tablename = XMLHandler.getTagValue(entrynode, "tablename");
/* 155 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/* 156 */       this.separator = XMLHandler.getTagValue(entrynode, "separator");
/* 157 */       this.enclosed = XMLHandler.getTagValue(entrynode, "enclosed");
/* 158 */       this.escaped = XMLHandler.getTagValue(entrynode, "escaped");
/*     */       
/* 160 */       this.linestarted = XMLHandler.getTagValue(entrynode, "linestarted");
/* 161 */       this.lineterminated = XMLHandler.getTagValue(entrynode, "lineterminated");
/* 162 */       this.replacedata = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "replacedata"));
/* 163 */       this.ignorelines = XMLHandler.getTagValue(entrynode, "ignorelines");
/* 164 */       this.listattribut = XMLHandler.getTagValue(entrynode, "listattribut");
/* 165 */       this.localinfile = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "localinfile"));
/* 166 */       this.prorityvalue = Const.toInt(XMLHandler.getTagValue(entrynode, "prorityvalue"), -1);
/* 167 */       String dbname = XMLHandler.getTagValue(entrynode, "connection");
/* 168 */       this.addfiletoresult = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "addfiletoresult"));
/* 169 */       this.connection = DatabaseMeta.findDatabase(databases, dbname);
/*     */     }
/*     */     catch (KettleException e)
/*     */     {
/* 173 */       throw new KettleXMLException("Unable to load job entry of type 'Mysql bulk load' from XML node", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 182 */       this.schemaname = rep.getJobEntryAttributeString(id_jobentry, "schemaname");
/* 183 */       this.tablename = rep.getJobEntryAttributeString(id_jobentry, "tablename");
/* 184 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/* 185 */       this.separator = rep.getJobEntryAttributeString(id_jobentry, "separator");
/* 186 */       this.enclosed = rep.getJobEntryAttributeString(id_jobentry, "enclosed");
/* 187 */       this.escaped = rep.getJobEntryAttributeString(id_jobentry, "escaped");
/* 188 */       this.linestarted = rep.getJobEntryAttributeString(id_jobentry, "linestarted");
/* 189 */       this.lineterminated = rep.getJobEntryAttributeString(id_jobentry, "lineterminated");
/* 190 */       this.replacedata = rep.getJobEntryAttributeBoolean(id_jobentry, "replacedata");
/* 191 */       this.ignorelines = rep.getJobEntryAttributeString(id_jobentry, "ignorelines");
/* 192 */       this.listattribut = rep.getJobEntryAttributeString(id_jobentry, "listattribut");
/* 193 */       this.localinfile = rep.getJobEntryAttributeBoolean(id_jobentry, "localinfile");
/* 194 */       this.prorityvalue = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "prorityvalue"));
/* 195 */       this.addfiletoresult = rep.getJobEntryAttributeBoolean(id_jobentry, "addfiletoresult");
/*     */       
/* 197 */       this.connection = rep.loadDatabaseMetaFromJobEntryAttribute(id_jobentry, "connection", "id_database", databases);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 201 */       throw new KettleException("Unable to load job entry of type 'Mysql bulk load' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 209 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "schemaname", this.schemaname);
/* 210 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "tablename", this.tablename);
/* 211 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/* 212 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "separator", this.separator);
/* 213 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "enclosed", this.enclosed);
/* 214 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "escaped", this.escaped);
/* 215 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "linestarted", this.linestarted);
/* 216 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "lineterminated", this.lineterminated);
/* 217 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "replacedata", this.replacedata);
/* 218 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ignorelines", this.ignorelines);
/* 219 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "listattribut", this.listattribut);
/* 220 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "localinfile", this.localinfile);
/* 221 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "prorityvalue", this.prorityvalue);
/* 222 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "addfiletoresult", this.addfiletoresult);
/*     */       
/* 224 */       rep.saveDatabaseMetaJobEntryAttribute(id_job, getObjectId(), "connection", "id_database", this.connection);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 228 */       throw new KettleException("Unable to load job entry of type 'Mysql Bulk Load' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTablename(String tablename)
/*     */   {
/* 234 */     this.tablename = tablename;
/*     */   }
/*     */   
/*     */   public void setSchemaname(String schemaname)
/*     */   {
/* 239 */     this.schemaname = schemaname;
/*     */   }
/*     */   
/*     */   public String getSchemaname()
/*     */   {
/* 244 */     return this.schemaname;
/*     */   }
/*     */   
/*     */   public String getTablename()
/*     */   {
/* 249 */     return this.tablename;
/*     */   }
/*     */   
/*     */   public void setDatabase(DatabaseMeta database)
/*     */   {
/* 254 */     this.connection = database;
/*     */   }
/*     */   
/*     */   public DatabaseMeta getDatabase()
/*     */   {
/* 259 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 264 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 269 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 275 */     String IgnoreNbrLignes = "";
/* 276 */     String ListOfColumn = "";
/* 277 */     String LocalExec = "";
/* 278 */     String PriorityText = "";
/* 279 */     String LineTerminatedby = "";
/* 280 */     String FieldTerminatedby = "";
/*     */     
/* 282 */     Result result = previousResult;
/* 283 */     result.setResult(false);
/*     */     
/* 285 */     String vfsFilename = environmentSubstitute(this.filename);
/*     */     
/*     */ 
/* 288 */     if (!Const.isEmpty(vfsFilename))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 299 */         FileObject fileObject = KettleVFS.getFileObject(vfsFilename, this);
/* 300 */         if (!(fileObject instanceof LocalFile))
/*     */         {
/*     */ 
/* 303 */           throw new KettleException("Only local files are supported at this time, file [" + vfsFilename + "] is not a local file.");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 308 */         String realFilename = KettleVFS.getFilename(fileObject);
/*     */         
/*     */ 
/*     */ 
/* 312 */         File file = new File(realFilename);
/* 313 */         if (((file.exists()) && (file.canRead())) || (!isLocalInfile()))
/*     */         {
/*     */ 
/* 316 */           if (this.log.isDetailed()) {
/* 317 */             logDetailed("File [" + realFilename + "] exists.");
/*     */           }
/* 319 */           if (this.connection != null)
/*     */           {
/*     */ 
/* 322 */             Database db = new Database(this, this.connection);
/* 323 */             db.shareVariablesWith(this);
/*     */             try
/*     */             {
/* 326 */               db.connect();
/*     */               
/* 328 */               String realSchemaname = environmentSubstitute(this.schemaname);
/*     */               
/* 330 */               String realTablename = environmentSubstitute(this.tablename);
/*     */               
/* 332 */               if (db.checkTableExists(realTablename))
/*     */               {
/*     */ 
/* 335 */                 if (this.log.isDetailed()) {
/* 336 */                   logDetailed("Table [" + realTablename + "] exists.");
/*     */                 }
/*     */                 
/* 339 */                 if (this.schemaname != null)
/*     */                 {
/* 341 */                   realTablename = realSchemaname + "." + realTablename;
/*     */                 }
/*     */                 String ReplaceIgnore;
/*     */                 String ReplaceIgnore;
/* 345 */                 if (isReplacedata())
/*     */                 {
/* 347 */                   ReplaceIgnore = "REPLACE";
/*     */                 }
/*     */                 else
/*     */                 {
/* 351 */                   ReplaceIgnore = "IGNORE";
/*     */                 }
/*     */                 
/*     */ 
/* 355 */                 if (Const.toInt(getRealIgnorelines(), 0) > 0)
/*     */                 {
/* 357 */                   IgnoreNbrLignes = "IGNORE " + getRealIgnorelines() + " LINES";
/*     */                 }
/*     */                 
/*     */ 
/* 361 */                 if (getRealListattribut() != null)
/*     */                 {
/* 363 */                   ListOfColumn = "(" + MysqlString(getRealListattribut()) + ")";
/*     */                 }
/*     */                 
/*     */ 
/*     */ 
/* 368 */                 if (isLocalInfile())
/*     */                 {
/* 370 */                   LocalExec = "LOCAL";
/*     */                 }
/*     */                 
/*     */ 
/* 374 */                 if (this.prorityvalue == 1)
/*     */                 {
/*     */ 
/* 377 */                   PriorityText = "LOW_PRIORITY";
/*     */                 }
/* 379 */                 else if (this.prorityvalue == 2)
/*     */                 {
/*     */ 
/* 382 */                   PriorityText = "CONCURRENT";
/*     */                 }
/*     */                 
/*     */ 
/* 386 */                 if ((getRealSeparator() != null) || (getRealEnclosed() != null) || (getRealEscaped() != null))
/*     */                 {
/* 388 */                   FieldTerminatedby = "FIELDS ";
/*     */                   
/* 390 */                   if (getRealSeparator() != null)
/*     */                   {
/* 392 */                     FieldTerminatedby = FieldTerminatedby + "TERMINATED BY '" + Const.replace(getRealSeparator(), "'", "''") + "'";
/*     */                   }
/* 394 */                   if (getRealEnclosed() != null)
/*     */                   {
/* 396 */                     FieldTerminatedby = FieldTerminatedby + " ENCLOSED BY '" + Const.replace(getRealEnclosed(), "'", "''") + "'";
/*     */                   }
/*     */                   
/* 399 */                   if (getRealEscaped() != null)
/*     */                   {
/*     */ 
/* 402 */                     FieldTerminatedby = FieldTerminatedby + " ESCAPED BY '" + Const.replace(getRealEscaped(), "'", "''") + "'";
/*     */                   }
/*     */                 }
/*     */                 
/*     */ 
/*     */ 
/* 408 */                 if ((getRealLinestarted() != null) || (getRealLineterminated() != null))
/*     */                 {
/* 410 */                   LineTerminatedby = "LINES ";
/*     */                   
/*     */ 
/* 413 */                   if (getRealLinestarted() != null)
/*     */                   {
/* 415 */                     LineTerminatedby = LineTerminatedby + "STARTING BY '" + Const.replace(getRealLinestarted(), "'", "''") + "'";
/*     */                   }
/*     */                   
/*     */ 
/* 419 */                   if (getRealLineterminated() != null)
/*     */                   {
/* 421 */                     LineTerminatedby = LineTerminatedby + " TERMINATED BY '" + Const.replace(getRealLineterminated(), "'", "''") + "'";
/*     */                   }
/*     */                 }
/*     */                 
/* 425 */                 String SQLBULKLOAD = "LOAD DATA " + PriorityText + " " + LocalExec + " INFILE '" + realFilename.replace('\\', '/') + "' " + ReplaceIgnore + " INTO TABLE " + realTablename + " " + FieldTerminatedby + " " + LineTerminatedby + " " + IgnoreNbrLignes + " " + ListOfColumn + ";";
/*     */                 
/*     */ 
/*     */ 
/*     */                 try
/*     */                 {
/* 431 */                   db.execStatements(SQLBULKLOAD);
/*     */                   
/*     */ 
/* 434 */                   db.disconnect();
/*     */                   
/* 436 */                   if (isAddFileToResult())
/*     */                   {
/*     */ 
/* 439 */                     ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(realFilename, this), this.parentJob.getJobname(), toString());
/* 440 */                     result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */                   }
/*     */                   
/* 443 */                   result.setResult(true);
/*     */                 }
/*     */                 catch (KettleDatabaseException je)
/*     */                 {
/* 447 */                   db.disconnect();
/* 448 */                   result.setNrErrors(1L);
/* 449 */                   logError("An error occurred executing this job entry : " + je.getMessage());
/*     */                 }
/*     */                 catch (KettleFileException e)
/*     */                 {
/* 453 */                   logError("An error occurred executing this job entry : " + e.getMessage());
/* 454 */                   result.setNrErrors(1L);
/*     */                 }
/*     */                 
/*     */               }
/*     */               else
/*     */               {
/* 460 */                 db.disconnect();
/* 461 */                 result.setNrErrors(1L);
/* 462 */                 if (this.log.isDetailed()) {
/* 463 */                   logDetailed("Table [" + realTablename + "] doesn't exist!");
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (KettleDatabaseException dbe) {
/* 468 */               db.disconnect();
/* 469 */               result.setNrErrors(1L);
/* 470 */               logError("An error occurred executing this entry: " + dbe.getMessage());
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 476 */             result.setNrErrors(1L);
/* 477 */             logError(BaseMessages.getString(PKG, "JobMysqlBulkLoad.Nodatabase.Label", new String[0]));
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 483 */           result.setNrErrors(1L);
/* 484 */           logError("File [" + realFilename + "] doesn't exist!");
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 490 */         result.setNrErrors(1L);
/* 491 */         logError(BaseMessages.getString(PKG, "JobMysqlBulkLoad.UnexpectedError.Label", new String[0]), e);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 497 */       result.setNrErrors(1L);
/* 498 */       logError(BaseMessages.getString(PKG, "JobMysqlBulkLoad.Nofilename.Label", new String[0]));
/*     */     }
/* 500 */     return result;
/*     */   }
/*     */   
/*     */   public DatabaseMeta[] getUsedDatabaseConnections()
/*     */   {
/* 505 */     return new DatabaseMeta[] { this.connection };
/*     */   }
/*     */   
/*     */   public boolean isReplacedata()
/*     */   {
/* 510 */     return this.replacedata;
/*     */   }
/*     */   
/*     */   public void setReplacedata(boolean replacedata)
/*     */   {
/* 515 */     this.replacedata = replacedata;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLocalInfile(boolean localinfile)
/*     */   {
/* 521 */     this.localinfile = localinfile;
/*     */   }
/*     */   
/*     */   public boolean isLocalInfile()
/*     */   {
/* 526 */     return this.localinfile;
/*     */   }
/*     */   
/*     */   public void setFilename(String filename)
/*     */   {
/* 531 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 536 */     return this.filename;
/*     */   }
/*     */   
/*     */   public void setSeparator(String separator)
/*     */   {
/* 541 */     this.separator = separator;
/*     */   }
/*     */   
/*     */   public void setLineterminated(String lineterminated)
/*     */   {
/* 546 */     this.lineterminated = lineterminated;
/*     */   }
/*     */   
/*     */   public void setLinestarted(String linestarted)
/*     */   {
/* 551 */     this.linestarted = linestarted;
/*     */   }
/*     */   
/*     */   public String getEnclosed()
/*     */   {
/* 556 */     return this.enclosed;
/*     */   }
/*     */   
/*     */   public String getRealEnclosed() {
/* 560 */     return environmentSubstitute(getEnclosed());
/*     */   }
/*     */   
/*     */   public void setEnclosed(String enclosed)
/*     */   {
/* 565 */     this.enclosed = enclosed;
/*     */   }
/*     */   
/*     */   public String getEscaped()
/*     */   {
/* 570 */     return this.escaped;
/*     */   }
/*     */   
/*     */   public String getRealEscaped()
/*     */   {
/* 575 */     return environmentSubstitute(getEscaped());
/*     */   }
/*     */   
/*     */   public void setEscaped(String escaped)
/*     */   {
/* 580 */     this.escaped = escaped;
/*     */   }
/*     */   
/*     */   public String getSeparator()
/*     */   {
/* 585 */     return this.separator;
/*     */   }
/*     */   
/*     */   public String getLineterminated()
/*     */   {
/* 590 */     return this.lineterminated;
/*     */   }
/*     */   
/*     */   public String getLinestarted()
/*     */   {
/* 595 */     return this.linestarted;
/*     */   }
/*     */   
/*     */   public String getRealLinestarted()
/*     */   {
/* 600 */     return environmentSubstitute(getLinestarted());
/*     */   }
/*     */   
/*     */   public String getRealLineterminated()
/*     */   {
/* 605 */     return environmentSubstitute(getLineterminated());
/*     */   }
/*     */   
/*     */   public String getRealSeparator()
/*     */   {
/* 610 */     return environmentSubstitute(getSeparator());
/*     */   }
/*     */   
/*     */   public void setIgnorelines(String ignorelines)
/*     */   {
/* 615 */     this.ignorelines = ignorelines;
/*     */   }
/*     */   
/*     */   public String getIgnorelines()
/*     */   {
/* 620 */     return this.ignorelines;
/*     */   }
/*     */   
/*     */   public String getRealIgnorelines()
/*     */   {
/* 625 */     return environmentSubstitute(getIgnorelines());
/*     */   }
/*     */   
/*     */   public void setListattribut(String listattribut)
/*     */   {
/* 630 */     this.listattribut = listattribut;
/*     */   }
/*     */   
/*     */   public String getListattribut()
/*     */   {
/* 635 */     return this.listattribut;
/*     */   }
/*     */   
/*     */   public String getRealListattribut()
/*     */   {
/* 640 */     return environmentSubstitute(getListattribut());
/*     */   }
/*     */   
/*     */   public void setAddFileToResult(boolean addfiletoresultin)
/*     */   {
/* 645 */     this.addfiletoresult = addfiletoresultin;
/*     */   }
/*     */   
/*     */   public boolean isAddFileToResult()
/*     */   {
/* 650 */     return this.addfiletoresult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String MysqlString(String listcolumns)
/*     */   {
/* 658 */     String returnString = "";
/* 659 */     String[] split = listcolumns.split(",");
/*     */     
/* 661 */     for (int i = 0; i < split.length; i++)
/*     */     {
/* 663 */       if (returnString.equals("")) {
/* 664 */         returnString = "`" + Const.trim(split[i]) + "`";
/*     */       } else {
/* 666 */         returnString = returnString + ", `" + Const.trim(split[i]) + "`";
/*     */       }
/*     */     }
/* 669 */     return returnString;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 673 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 674 */     ResourceReference reference = null;
/* 675 */     if (this.connection != null) {
/* 676 */       reference = new ResourceReference(this);
/* 677 */       references.add(reference);
/* 678 */       reference.getEntries().add(new ResourceEntry(this.connection.getHostname(), ResourceEntry.ResourceType.SERVER));
/* 679 */       reference.getEntries().add(new ResourceEntry(this.connection.getDatabaseName(), ResourceEntry.ResourceType.DATABASENAME));
/*     */     }
/* 681 */     if (this.filename != null) {
/* 682 */       String realFilename = getRealFilename();
/* 683 */       if (reference == null) {
/* 684 */         reference = new ResourceReference(this);
/* 685 */         references.add(reference);
/*     */       }
/* 687 */       reference.getEntries().add(new ResourceEntry(realFilename, ResourceEntry.ResourceType.FILE));
/*     */     }
/* 689 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 695 */     ValidatorContext ctx = new ValidatorContext();
/* 696 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 697 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 698 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */     
/* 700 */     JobEntryValidatorUtils.andValidator().validate(this, "tablename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\mysqlbulkload\JobEntryMysqlBulkLoad.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */