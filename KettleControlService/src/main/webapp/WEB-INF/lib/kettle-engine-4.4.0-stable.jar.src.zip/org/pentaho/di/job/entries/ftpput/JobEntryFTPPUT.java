/*     */ package org.pentaho.di.job.entries.ftpput;
/*     */ 
/*     */ import com.enterprisedt.net.ftp.FTPClient;
/*     */ import com.enterprisedt.net.ftp.FTPConnectMode;
/*     */ import com.enterprisedt.net.ftp.FTPException;
/*     */ import com.enterprisedt.net.ftp.FTPFileFactory;
/*     */ import com.enterprisedt.net.ftp.FTPFileParser;
/*     */ import com.enterprisedt.net.ftp.FTPTransferType;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.encryption.Encr;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entries.ftp.MVSFileParser;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFTPPUT
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  79 */   private static Class<?> PKG = JobEntryFTPPUT.class;
/*     */   
/*     */   private String serverName;
/*     */   
/*     */   private String serverPort;
/*     */   
/*     */   private String userName;
/*     */   
/*     */   private String password;
/*     */   
/*     */   private String remoteDirectory;
/*     */   
/*     */   private String localDirectory;
/*     */   
/*     */   private String wildcard;
/*     */   
/*     */   private boolean binaryMode;
/*     */   
/*     */   private int timeout;
/*     */   private boolean remove;
/*     */   private boolean onlyPuttingNewFiles;
/*     */   private boolean activeConnection;
/*     */   private String controlEncoding;
/*     */   private String proxyHost;
/*     */   private String proxyPort;
/*     */   private String proxyUsername;
/*     */   private String proxyPassword;
/*     */   private String socksProxyHost;
/*     */   private String socksProxyPort;
/*     */   private String socksProxyUsername;
/*     */   private String socksProxyPassword;
/* 110 */   private static String LEGACY_CONTROL_ENCODING = "US-ASCII";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 115 */   private static String DEFAULT_CONTROL_ENCODING = "ISO-8859-1";
/*     */   
/*     */   public JobEntryFTPPUT(String n)
/*     */   {
/* 119 */     super(n, "");
/* 120 */     this.serverName = null;
/* 121 */     this.serverPort = "21";
/* 122 */     this.socksProxyPort = "1080";
/* 123 */     this.remoteDirectory = null;
/* 124 */     this.localDirectory = null;
/* 125 */     setID(-1L);
/* 126 */     setControlEncoding(DEFAULT_CONTROL_ENCODING);
/*     */   }
/*     */   
/*     */   public JobEntryFTPPUT()
/*     */   {
/* 131 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 136 */     JobEntryFTPPUT je = (JobEntryFTPPUT)super.clone();
/* 137 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 142 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/* 144 */     retval.append(super.getXML());
/*     */     
/* 146 */     retval.append("      ").append(XMLHandler.addTagValue("servername", this.serverName));
/* 147 */     retval.append("      ").append(XMLHandler.addTagValue("serverport", this.serverPort));
/* 148 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.userName));
/* 149 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(getPassword())));
/* 150 */     retval.append("      ").append(XMLHandler.addTagValue("remoteDirectory", this.remoteDirectory));
/* 151 */     retval.append("      ").append(XMLHandler.addTagValue("localDirectory", this.localDirectory));
/* 152 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/* 153 */     retval.append("      ").append(XMLHandler.addTagValue("binary", this.binaryMode));
/* 154 */     retval.append("      ").append(XMLHandler.addTagValue("timeout", this.timeout));
/* 155 */     retval.append("      ").append(XMLHandler.addTagValue("remove", this.remove));
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("only_new", this.onlyPuttingNewFiles));
/* 157 */     retval.append("      ").append(XMLHandler.addTagValue("active", this.activeConnection));
/* 158 */     retval.append("      ").append(XMLHandler.addTagValue("control_encoding", this.controlEncoding));
/*     */     
/* 160 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_host", this.proxyHost));
/* 161 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_port", this.proxyPort));
/* 162 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_username", this.proxyUsername));
/* 163 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword)));
/* 164 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_host", this.socksProxyHost));
/* 165 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_port", this.socksProxyPort));
/* 166 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_username", this.socksProxyUsername));
/* 167 */     retval.append("      ").append(XMLHandler.addTagValue("socksproxy_password", Encr.encryptPasswordIfNotUsingVariables(this.socksProxyPassword)));
/*     */     
/*     */ 
/* 170 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 177 */       super.loadXML(entrynode, databases, slaveServers);
/* 178 */       this.serverName = XMLHandler.getTagValue(entrynode, "servername");
/* 179 */       this.serverPort = XMLHandler.getTagValue(entrynode, "serverport");
/* 180 */       this.userName = XMLHandler.getTagValue(entrynode, "username");
/* 181 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/* 182 */       this.remoteDirectory = XMLHandler.getTagValue(entrynode, "remoteDirectory");
/* 183 */       this.localDirectory = XMLHandler.getTagValue(entrynode, "localDirectory");
/* 184 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/* 185 */       this.binaryMode = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "binary"));
/* 186 */       this.timeout = Const.toInt(XMLHandler.getTagValue(entrynode, "timeout"), 10000);
/* 187 */       this.remove = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "remove"));
/* 188 */       this.onlyPuttingNewFiles = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "only_new"));
/* 189 */       this.activeConnection = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "active"));
/* 190 */       this.controlEncoding = XMLHandler.getTagValue(entrynode, "control_encoding");
/*     */       
/* 192 */       this.proxyHost = XMLHandler.getTagValue(entrynode, "proxy_host");
/* 193 */       this.proxyPort = XMLHandler.getTagValue(entrynode, "proxy_port");
/* 194 */       this.proxyUsername = XMLHandler.getTagValue(entrynode, "proxy_username");
/* 195 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "proxy_password"));
/* 196 */       this.socksProxyHost = XMLHandler.getTagValue(entrynode, "socksproxy_host");
/* 197 */       this.socksProxyPort = XMLHandler.getTagValue(entrynode, "socksproxy_port");
/* 198 */       this.socksProxyUsername = XMLHandler.getTagValue(entrynode, "socksproxy_username");
/* 199 */       this.socksProxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "socksproxy_password"));
/*     */       
/* 201 */       if (this.controlEncoding == null)
/*     */       {
/*     */ 
/*     */ 
/* 205 */         this.controlEncoding = LEGACY_CONTROL_ENCODING;
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 210 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobFTPPUT.Log.UnableToLoadFromXml", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 218 */       this.serverName = rep.getJobEntryAttributeString(id_jobentry, "servername");
/* 219 */       int intServerPort = (int)rep.getJobEntryAttributeInteger(id_jobentry, "serverport");
/* 220 */       this.serverPort = rep.getJobEntryAttributeString(id_jobentry, "serverport");
/* 221 */       if ((intServerPort > 0) && (Const.isEmpty(this.serverPort))) { this.serverPort = Integer.toString(intServerPort);
/*     */       }
/* 223 */       this.userName = rep.getJobEntryAttributeString(id_jobentry, "username");
/* 224 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/* 225 */       this.remoteDirectory = rep.getJobEntryAttributeString(id_jobentry, "remoteDirectory");
/* 226 */       this.localDirectory = rep.getJobEntryAttributeString(id_jobentry, "localDirectory");
/* 227 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/* 228 */       this.binaryMode = rep.getJobEntryAttributeBoolean(id_jobentry, "binary");
/* 229 */       this.timeout = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "timeout"));
/* 230 */       this.remove = rep.getJobEntryAttributeBoolean(id_jobentry, "remove");
/* 231 */       this.onlyPuttingNewFiles = rep.getJobEntryAttributeBoolean(id_jobentry, "only_new");
/* 232 */       this.activeConnection = rep.getJobEntryAttributeBoolean(id_jobentry, "active");
/* 233 */       this.controlEncoding = rep.getJobEntryAttributeString(id_jobentry, "control_encoding");
/* 234 */       if (this.controlEncoding == null)
/*     */       {
/*     */ 
/*     */ 
/* 238 */         this.controlEncoding = LEGACY_CONTROL_ENCODING;
/*     */       }
/*     */       
/* 241 */       this.proxyHost = rep.getJobEntryAttributeString(id_jobentry, "proxy_host");
/* 242 */       this.proxyPort = rep.getJobEntryAttributeString(id_jobentry, "proxy_port");
/* 243 */       this.proxyUsername = rep.getJobEntryAttributeString(id_jobentry, "proxy_username");
/* 244 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "proxy_password"));
/* 245 */       this.socksProxyHost = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_host");
/* 246 */       this.socksProxyPort = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_port");
/* 247 */       this.socksProxyUsername = rep.getJobEntryAttributeString(id_jobentry, "socksproxy_username");
/* 248 */       this.socksProxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "socksproxy_password"));
/*     */ 
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 253 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPPUT.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 261 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "servername", this.serverName);
/* 262 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "serverport", this.serverPort);
/* 263 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.userName);
/* 264 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/* 265 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remoteDirectory", this.remoteDirectory);
/* 266 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "localDirectory", this.localDirectory);
/* 267 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/* 268 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "binary", this.binaryMode);
/* 269 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "timeout", this.timeout);
/* 270 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remove", this.remove);
/* 271 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "only_new", this.onlyPuttingNewFiles);
/* 272 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "active", this.activeConnection);
/* 273 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "control_encoding", this.controlEncoding);
/*     */       
/* 275 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_host", this.proxyHost);
/* 276 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_port", this.proxyPort);
/* 277 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_username", this.proxyUsername);
/* 278 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword));
/* 279 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_host", this.socksProxyHost);
/* 280 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_port", this.socksProxyPort);
/* 281 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_username", this.socksProxyUsername);
/* 282 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "socksproxy_password", Encr.encryptPasswordIfNotUsingVariables(this.socksProxyPassword));
/*     */ 
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 287 */       throw new KettleException(BaseMessages.getString(PKG, "JobFTPPUT.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBinaryMode()
/*     */   {
/* 296 */     return this.binaryMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBinaryMode(boolean binaryMode)
/*     */   {
/* 304 */     this.binaryMode = binaryMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 311 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 319 */     return this.timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isOnlyPuttingNewFiles()
/*     */   {
/* 326 */     return this.onlyPuttingNewFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnlyPuttingNewFiles(boolean onlyPuttingNewFiles)
/*     */   {
/* 334 */     this.onlyPuttingNewFiles = onlyPuttingNewFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getControlEncoding()
/*     */   {
/* 344 */     return this.controlEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setControlEncoding(String encoding)
/*     */   {
/* 356 */     this.controlEncoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRemoteDirectory()
/*     */   {
/* 363 */     return this.remoteDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteDirectory(String directory)
/*     */   {
/* 371 */     this.remoteDirectory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 379 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 387 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getServerName()
/*     */   {
/* 395 */     return this.serverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServerName(String serverName)
/*     */   {
/* 403 */     this.serverName = serverName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUserName()
/*     */   {
/* 411 */     return this.userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserName(String userName)
/*     */   {
/* 419 */     this.userName = userName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getWildcard()
/*     */   {
/* 427 */     return this.wildcard;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWildcard(String wildcard)
/*     */   {
/* 435 */     this.wildcard = wildcard;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocalDirectory()
/*     */   {
/* 443 */     return this.localDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocalDirectory(String directory)
/*     */   {
/* 451 */     this.localDirectory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemove(boolean remove)
/*     */   {
/* 459 */     this.remove = remove;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRemove()
/*     */   {
/* 467 */     return this.remove;
/*     */   }
/*     */   
/*     */   public String getServerPort() {
/* 471 */     return this.serverPort;
/*     */   }
/*     */   
/*     */   public void setServerPort(String serverPort) {
/* 475 */     this.serverPort = serverPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActiveConnection()
/*     */   {
/* 483 */     return this.activeConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActiveConnection(boolean activeConnection)
/*     */   {
/* 491 */     this.activeConnection = activeConnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxyHost()
/*     */   {
/* 499 */     return this.proxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyHost(String proxyHost)
/*     */   {
/* 507 */     this.proxyHost = proxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxyPassword()
/*     */   {
/* 515 */     return this.proxyPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyPassword(String proxyPassword)
/*     */   {
/* 523 */     this.proxyPassword = proxyPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProxyPort()
/*     */   {
/* 531 */     return this.proxyPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyPort(String proxyPort)
/*     */   {
/* 539 */     this.proxyPort = proxyPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getProxyUsername()
/*     */   {
/* 546 */     return this.proxyUsername;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSocksProxyHost(String socksProxyHost)
/*     */   {
/* 553 */     this.socksProxyHost = socksProxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocksProxyPort(String socksProxyPort)
/*     */   {
/* 561 */     this.socksProxyPort = socksProxyPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocksProxyUsername(String socksProxyUsername)
/*     */   {
/* 569 */     this.socksProxyUsername = socksProxyUsername;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocksProxyPassword(String socksProxyPassword)
/*     */   {
/* 577 */     this.socksProxyPassword = socksProxyPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSocksProxyHost()
/*     */   {
/* 584 */     return this.socksProxyHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSocksProxyPort()
/*     */   {
/* 591 */     return this.socksProxyPort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSocksProxyUsername()
/*     */   {
/* 598 */     return this.socksProxyUsername;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSocksProxyPassword()
/*     */   {
/* 605 */     return this.socksProxyPassword;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProxyUsername(String proxyUsername)
/*     */   {
/* 612 */     this.proxyUsername = proxyUsername;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 617 */     Result result = previousResult;
/* 618 */     result.setResult(false);
/* 619 */     long filesput = 0L;
/*     */     
/* 621 */     if (this.log.isDetailed()) {
/* 622 */       logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.Starting", new String[0]));
/*     */     }
/*     */     
/* 625 */     String realServerName = environmentSubstitute(this.serverName);
/* 626 */     String realServerPort = environmentSubstitute(this.serverPort);
/* 627 */     String realUsername = environmentSubstitute(this.userName);
/* 628 */     String realPassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password));
/* 629 */     String realRemoteDirectory = environmentSubstitute(this.remoteDirectory);
/* 630 */     String realWildcard = environmentSubstitute(this.wildcard);
/* 631 */     String realLocalDirectory = environmentSubstitute(this.localDirectory);
/*     */     
/*     */ 
/* 634 */     FTPClient ftpclient = null;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 639 */       ftpclient = new PDIFTPClient(this.log);
/* 640 */       ftpclient.setRemoteAddr(InetAddress.getByName(realServerName));
/* 641 */       if (!Const.isEmpty(realServerPort))
/*     */       {
/* 643 */         ftpclient.setRemotePort(Const.toInt(realServerPort, 21));
/*     */       }
/*     */       
/* 646 */       if (!Const.isEmpty(this.proxyHost))
/*     */       {
/* 648 */         String realProxy_host = environmentSubstitute(this.proxyHost);
/* 649 */         ftpclient.setRemoteAddr(InetAddress.getByName(realProxy_host));
/* 650 */         if (this.log.isDetailed()) {
/* 651 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTPPUT.OpenedProxyConnectionOn", new String[] { realProxy_host }));
/*     */         }
/*     */         
/* 654 */         int port = Const.toInt(environmentSubstitute(this.proxyPort), 21);
/* 655 */         if (port != 0)
/*     */         {
/* 657 */           ftpclient.setRemotePort(port);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 662 */         ftpclient.setRemoteAddr(InetAddress.getByName(realServerName));
/*     */         
/* 664 */         if (this.log.isDetailed()) {
/* 665 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTPPUT.OpenConnection", new String[] { realServerName }));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 670 */       if (this.activeConnection)
/*     */       {
/* 672 */         ftpclient.setConnectMode(FTPConnectMode.ACTIVE);
/* 673 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.SetActiveConnection", new String[0]));
/*     */       }
/*     */       else
/*     */       {
/* 677 */         ftpclient.setConnectMode(FTPConnectMode.PASV);
/* 678 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.SetPassiveConnection", new String[0]));
/*     */         }
/*     */       }
/*     */       
/* 682 */       if (this.timeout > 0)
/*     */       {
/* 684 */         ftpclient.setTimeout(this.timeout);
/* 685 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.SetTimeout", new String[] { "" + this.timeout }));
/*     */         }
/*     */       }
/* 688 */       ftpclient.setControlEncoding(this.controlEncoding);
/* 689 */       if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.SetEncoding", new String[] { this.controlEncoding }));
/*     */       }
/*     */       
/* 692 */       if (!Const.isEmpty(this.socksProxyHost))
/*     */       {
/*     */ 
/* 695 */         if (!Const.isEmpty(this.socksProxyPort))
/*     */         {
/* 697 */           FTPClient.initSOCKS(environmentSubstitute(this.socksProxyPort), environmentSubstitute(this.socksProxyHost));
/*     */         }
/*     */         else
/*     */         {
/* 701 */           throw new FTPException(BaseMessages.getString(PKG, "JobFTPPUT.SocksProxy.PortMissingException", new String[] { environmentSubstitute(this.socksProxyHost) }));
/*     */         }
/*     */         
/* 704 */         if (((!Const.isEmpty(this.socksProxyUsername)) && (Const.isEmpty(this.socksProxyPassword))) || ((Const.isEmpty(this.socksProxyUsername)) && (!Const.isEmpty(this.socksProxyPassword))))
/*     */         {
/*     */ 
/* 707 */           throw new FTPException(BaseMessages.getString(PKG, "JobFTPPUT.SocksProxy.IncompleteCredentials", new String[] { environmentSubstitute(this.socksProxyHost), getName() }));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 712 */       ftpclient.connect();
/* 713 */       ftpclient.login(realUsername, realPassword);
/*     */       
/*     */ 
/* 716 */       if (this.binaryMode)
/*     */       {
/* 718 */         ftpclient.setType(FTPTransferType.BINARY);
/* 719 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.BinaryMode", new String[0]));
/*     */         }
/*     */       }
/*     */       
/* 723 */       if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.Logged", new String[] { realUsername }));
/*     */       }
/*     */       
/* 726 */       hookInOtherParsers(ftpclient);
/*     */       
/*     */ 
/* 729 */       if (!Const.isEmpty(realRemoteDirectory))
/*     */       {
/* 731 */         ftpclient.chdir(realRemoteDirectory);
/* 732 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.ChangedDirectory", new String[] { realRemoteDirectory }));
/*     */         }
/*     */       }
/*     */       
/* 736 */       int x = 0;
/*     */       
/*     */ 
/*     */ 
/* 740 */       ArrayList<String> myFileList = new ArrayList();
/*     */       
/*     */ 
/* 743 */       File localFiles = new File(realLocalDirectory);
/* 744 */       File[] children = localFiles.listFiles();
/* 745 */       for (int i = 0; i < children.length; i++)
/*     */       {
/* 747 */         if (!children[i].isDirectory())
/*     */         {
/* 749 */           myFileList.add(children[i].getName());
/* 750 */           x += 1;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 758 */       String[] filelist = new String[myFileList.size()];
/* 759 */       myFileList.toArray(filelist);
/*     */       
/*     */ 
/* 762 */       if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.FoundFileLocalDirectory", new String[] { "" + filelist.length, realLocalDirectory }));
/*     */       }
/* 764 */       Pattern pattern = null;
/* 765 */       if (!Const.isEmpty(realWildcard))
/*     */       {
/* 767 */         pattern = Pattern.compile(realWildcard);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 773 */       for (int i = 0; (i < filelist.length) && (!this.parentJob.isStopped()); i++)
/*     */       {
/* 775 */         boolean getIt = true;
/*     */         
/*     */ 
/* 778 */         if (pattern != null)
/*     */         {
/* 780 */           Matcher matcher = pattern.matcher(filelist[i]);
/* 781 */           getIt = matcher.matches();
/*     */         }
/*     */         
/* 784 */         if (getIt)
/*     */         {
/*     */ 
/*     */ 
/* 788 */           boolean fileExist = false;
/*     */           try
/*     */           {
/* 791 */             fileExist = ftpclient.exists(filelist[i]);
/*     */           }
/*     */           catch (Exception e) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 798 */           if (this.log.isDebug())
/*     */           {
/* 800 */             if (fileExist) {
/* 801 */               logDebug(BaseMessages.getString(PKG, "JobFTPPUT.Log.FileExists", new String[] { filelist[i] }));
/*     */             } else {
/* 803 */               logDebug(BaseMessages.getString(PKG, "JobFTPPUT.Log.FileDoesNotExists", new String[] { filelist[i] }));
/*     */             }
/*     */           }
/* 806 */           if ((!fileExist) || ((!this.onlyPuttingNewFiles) && (fileExist)))
/*     */           {
/* 808 */             if (this.log.isDebug()) { logDebug(BaseMessages.getString(PKG, "JobFTPPUT.Log.PuttingFileToRemoteDirectory", new String[] { filelist[i], realRemoteDirectory }));
/*     */             }
/* 810 */             String localFilename = realLocalDirectory + Const.FILE_SEPARATOR + filelist[i];
/* 811 */             ftpclient.put(localFilename, filelist[i]);
/*     */             
/* 813 */             filesput += 1L;
/*     */             
/*     */ 
/* 816 */             if (this.remove)
/*     */             {
/* 818 */               new File(localFilename).delete();
/* 819 */               if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobFTPPUT.Log.DeletedFile", new String[] { localFilename }));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 825 */       result.setResult(true);
/* 826 */       if (this.log.isDetailed()) logDebug(BaseMessages.getString(PKG, "JobFTPPUT.Log.WeHavePut", new String[] { "" + filesput }));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 830 */       result.setNrErrors(1L);
/* 831 */       logError(BaseMessages.getString(PKG, "JobFTPPUT.Log.ErrorPuttingFiles", new String[] { e.getMessage() }));
/* 832 */       logError(Const.getStackTracker(e));
/*     */     }
/*     */     finally {
/* 835 */       if ((ftpclient != null) && (ftpclient.connected()))
/*     */       {
/*     */         try
/*     */         {
/* 839 */           ftpclient.quit();
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 843 */           logError(BaseMessages.getString(PKG, "JobFTPPUT.Log.ErrorQuitingFTP", new String[] { e.getMessage() }));
/*     */         }
/*     */       }
/*     */       
/* 847 */       FTPClient.clearSOCKS();
/*     */     }
/*     */     
/* 850 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 855 */   public boolean evaluates() { return true; }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 858 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 859 */     if (!Const.isEmpty(this.serverName)) {
/* 860 */       String realServerName = jobMeta.environmentSubstitute(this.serverName);
/* 861 */       ResourceReference reference = new ResourceReference(this);
/* 862 */       reference.getEntries().add(new ResourceEntry(realServerName, ResourceEntry.ResourceType.SERVER));
/* 863 */       references.add(reference);
/*     */     }
/* 865 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 871 */     JobEntryValidatorUtils.andValidator().validate(this, "serverName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 872 */     JobEntryValidatorUtils.andValidator().validate(this, "localDirectory", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() }));
/*     */     
/* 874 */     JobEntryValidatorUtils.andValidator().validate(this, "userName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 875 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/* 876 */     JobEntryValidatorUtils.andValidator().validate(this, "serverPort", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void hookInOtherParsers(FTPClient ftpClient)
/*     */     throws FTPException, IOException
/*     */   {
/* 887 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Hooking.Parsers", new String[0]));
/* 888 */     String system = ftpClient.system();
/* 889 */     MVSFileParser parser = new MVSFileParser();
/* 890 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Created.MVS.Parser", new String[0]));
/* 891 */     FTPFileFactory factory = new FTPFileFactory(system);
/* 892 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Created.Factory", new String[0]));
/* 893 */     factory.addParser(parser);
/* 894 */     ftpClient.setFTPFileFactory(factory);
/* 895 */     if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Get.Variable.Space", new String[0]));
/* 896 */     VariableSpace vs = getVariables();
/* 897 */     if (vs != null) {
/* 898 */       if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Getting.Other.Parsers", new String[0]));
/* 899 */       String otherParserNames = vs.getVariable("ftp.file.parser.class.names");
/* 900 */       if (otherParserNames != null) {
/* 901 */         if (this.log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Creating.Parsers", new String[0]));
/* 902 */         String[] parserClasses = otherParserNames.split("|");
/* 903 */         String cName = null;
/* 904 */         Class<?> clazz = null;
/* 905 */         Object parserInstance = null;
/* 906 */         for (int i = 0; i < parserClasses.length; i++) {
/* 907 */           cName = parserClasses[i].trim();
/* 908 */           if (cName.length() > 0) {
/*     */             try {
/* 910 */               clazz = Class.forName(cName);
/* 911 */               parserInstance = clazz.newInstance();
/* 912 */               if ((parserInstance instanceof FTPFileParser)) {
/* 913 */                 if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTP.DEBUG.Created.Other.Parser", new String[] { cName }));
/* 914 */                 factory.addParser((FTPFileParser)parserInstance);
/*     */               }
/*     */             } catch (Exception ignored) {
/* 917 */               if (this.log.isDebug()) {
/* 918 */                 ignored.printStackTrace();
/* 919 */                 logError(BaseMessages.getString(PKG, "JobEntryFTP.ERROR.Creating.Parser", new String[] { cName }));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftpput\JobEntryFTPPUT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */