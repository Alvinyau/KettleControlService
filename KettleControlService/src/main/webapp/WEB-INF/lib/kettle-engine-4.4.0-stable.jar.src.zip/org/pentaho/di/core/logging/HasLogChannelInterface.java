package org.pentaho.di.core.logging;

public abstract interface HasLogChannelInterface
{
  public abstract LogChannelInterface getLogChannel();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\HasLogChannelInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */