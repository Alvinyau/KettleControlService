/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.prefs.Preferences;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringPluginProperty
/*     */   extends KeyValue<String>
/*     */   implements PluginProperty
/*     */ {
/*     */   private static final long serialVersionUID = -2990345692552430357L;
/*     */   
/*     */   public StringPluginProperty(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  54 */     super(key, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate()
/*     */   {
/*  65 */     return StringUtils.isNotBlank((String)getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendXml(StringBuilder builder)
/*     */   {
/*  76 */     builder.append(XMLHandler.addTagValue(getKey(), (String)getValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadXml(Node node)
/*     */   {
/*  85 */     String value = XMLHandler.getTagValue(node, getKey());
/*  86 */     setValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromRepositoryStep(Repository repository, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/*  96 */     String value = repository.getStepAttributeString(stepId, getKey());
/*  97 */     setValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToPreferences(Preferences node)
/*     */   {
/* 106 */     node.put(getKey(), (String)getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromPreferences(Preferences node)
/*     */   {
/* 115 */     setValue(node.get(getKey(), (String)getValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToRepositoryStep(Repository repository, ObjectId transformationId, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/* 126 */     repository.saveStepAttribute(transformationId, stepId, getKey(), (String)getValue());
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\StringPluginProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */