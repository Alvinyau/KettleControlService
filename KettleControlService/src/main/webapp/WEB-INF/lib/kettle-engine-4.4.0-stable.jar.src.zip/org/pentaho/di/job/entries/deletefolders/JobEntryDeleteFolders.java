/*     */ package org.pentaho.di.job.entries.deletefolders;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileSelector;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDeleteFolders
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  68 */   private static Class<?> PKG = JobEntryDeleteFolders.class;
/*     */   
/*     */   public boolean argFromPrevious;
/*     */   
/*     */   public String[] arguments;
/*     */   
/*     */   private String success_condition;
/*  75 */   public String SUCCESS_IF_AT_LEAST_X_FOLDERS_DELETED = "success_when_at_least";
/*  76 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*  77 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*     */   
/*     */ 
/*     */   private String limit_folders;
/*     */   
/*  82 */   int NrErrors = 0;
/*  83 */   int NrSuccess = 0;
/*  84 */   boolean successConditionBroken = false;
/*  85 */   boolean successConditionBrokenExit = false;
/*  86 */   int limitFolders = 0;
/*     */   
/*     */   public JobEntryDeleteFolders(String n)
/*     */   {
/*  90 */     super(n, "");
/*  91 */     this.argFromPrevious = false;
/*  92 */     this.arguments = null;
/*     */     
/*  94 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/*  95 */     this.limit_folders = "10";
/*  96 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryDeleteFolders() {
/* 100 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 104 */     JobEntryDeleteFolders je = (JobEntryDeleteFolders)super.clone();
/* 105 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML() {
/* 109 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 111 */     retval.append(super.getXML());
/* 112 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.argFromPrevious));
/* 113 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/* 114 */     retval.append("      ").append(XMLHandler.addTagValue("limit_folders", this.limit_folders));
/*     */     
/* 116 */     retval.append("      <fields>").append(Const.CR);
/* 117 */     if (this.arguments != null) {
/* 118 */       for (int i = 0; i < this.arguments.length; i++) {
/* 119 */         retval.append("        <field>").append(Const.CR);
/* 120 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.arguments[i]));
/* 121 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 124 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/* 126 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException {
/*     */     try {
/* 131 */       super.loadXML(entrynode, databases, slaveServers);
/* 132 */       this.argFromPrevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/* 133 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/* 134 */       this.limit_folders = XMLHandler.getTagValue(entrynode, "limit_folders");
/*     */       
/* 136 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 139 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 140 */       this.arguments = new String[nrFields];
/*     */       
/*     */ 
/* 143 */       for (int i = 0; i < nrFields; i++) {
/* 144 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 146 */         this.arguments[i] = XMLHandler.getTagValue(fnode, "name");
/*     */       }
/*     */     } catch (KettleXMLException xe) {
/* 149 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDeleteFolders.UnableToLoadFromXml", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException {
/*     */     try {
/* 155 */       this.argFromPrevious = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/* 156 */       this.limit_folders = rep.getJobEntryAttributeString(id_jobentry, "limit_folders");
/* 157 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/*     */       
/*     */ 
/* 160 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "name");
/* 161 */       this.arguments = new String[argnr];
/*     */       
/*     */ 
/* 164 */       for (int a = 0; a < argnr; a++) {
/* 165 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "name");
/*     */       }
/*     */     } catch (KettleException dbe) {
/* 168 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDeleteFolders.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException {
/*     */     try {
/* 174 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.argFromPrevious);
/* 175 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "limit_folders", this.limit_folders);
/* 176 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*     */       
/*     */ 
/* 179 */       if (this.arguments != null) {
/* 180 */         for (int i = 0; i < this.arguments.length; i++) {
/* 181 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "name", this.arguments[i]);
/*     */         }
/*     */       }
/*     */     } catch (KettleDatabaseException dbe) {
/* 185 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDeleteFolders.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public Result execute(Result result, int nr) throws KettleException
/*     */   {
/* 191 */     List<RowMetaAndData> rows = result.getRows();
/* 192 */     RowMetaAndData resultRow = null;
/*     */     
/* 194 */     result.setNrErrors(1L);
/* 195 */     result.setResult(false);
/*     */     
/* 197 */     this.NrErrors = 0;
/* 198 */     this.NrSuccess = 0;
/* 199 */     this.successConditionBroken = false;
/* 200 */     this.successConditionBrokenExit = false;
/* 201 */     this.limitFolders = Const.toInt(environmentSubstitute(getLimitFolders()), 10);
/*     */     
/*     */ 
/* 204 */     if ((this.argFromPrevious) && 
/* 205 */       (this.log.isDetailed())) {
/* 206 */       logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFolders.FoundPreviousRows", new String[] { String.valueOf(rows != null ? rows.size() : 0) }));
/*     */     }
/*     */     
/* 209 */     if ((this.argFromPrevious) && (rows != null)) {
/* 210 */       for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++) {
/* 211 */         if (this.successConditionBroken) {
/* 212 */           logError(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/* 213 */           result.setNrErrors(this.NrErrors);
/* 214 */           result.setNrLinesDeleted(this.NrSuccess);
/* 215 */           return result;
/*     */         }
/* 217 */         resultRow = (RowMetaAndData)rows.get(iteration);
/* 218 */         String args_previous = resultRow.getString(0, null);
/* 219 */         if (!Const.isEmpty(args_previous)) {
/* 220 */           if (deleteFolder(args_previous)) {
/* 221 */             updateSuccess();
/*     */           } else {
/* 223 */             updateErrors();
/*     */           }
/*     */         }
/*     */         else {
/* 227 */           logError(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Error.EmptyLine", new String[0]));
/*     */         }
/*     */       }
/* 230 */     } else if (this.arguments != null) {
/* 231 */       for (int i = 0; (i < this.arguments.length) && (!this.parentJob.isStopped()); i++) {
/* 232 */         if (this.successConditionBroken)
/*     */         {
/* 234 */           logError(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/* 235 */           result.setNrErrors(this.NrErrors);
/* 236 */           result.setNrLinesDeleted(this.NrSuccess);
/* 237 */           return result;
/*     */         }
/* 239 */         String realfilename = environmentSubstitute(this.arguments[i]);
/* 240 */         if (!Const.isEmpty(realfilename))
/*     */         {
/* 242 */           if (deleteFolder(realfilename)) {
/* 243 */             updateSuccess();
/*     */           } else {
/* 245 */             updateErrors();
/*     */           }
/*     */         }
/*     */         else {
/* 249 */           logError(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Error.EmptyLine", new String[0]));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 254 */     if (this.log.isDetailed()) {
/* 255 */       logDetailed("=======================================");
/* 256 */       logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Log.Info.NrError", new String[] { "" + this.NrErrors }));
/* 257 */       logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Log.Info.NrDeletedFolders", new String[] { "" + this.NrSuccess }));
/* 258 */       logDetailed("=======================================");
/*     */     }
/*     */     
/* 261 */     result.setNrErrors(this.NrErrors);
/* 262 */     result.setNrLinesDeleted(this.NrSuccess);
/* 263 */     if (getSuccessStatus()) { result.setResult(true);
/*     */     }
/* 265 */     return result;
/*     */   }
/*     */   
/*     */   private void updateErrors() {
/* 269 */     this.NrErrors += 1;
/* 270 */     if (checkIfSuccessConditionBroken())
/*     */     {
/* 272 */       this.successConditionBroken = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkIfSuccessConditionBroken() {
/* 277 */     boolean retval = false;
/* 278 */     if (((this.NrErrors > 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFolders) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/* 280 */       retval = true;
/*     */     }
/* 282 */     return retval;
/*     */   }
/*     */   
/*     */   private void updateSuccess() {
/* 286 */     this.NrSuccess += 1;
/*     */   }
/*     */   
/*     */   private boolean getSuccessStatus() {
/* 290 */     boolean retval = false;
/*     */     
/* 292 */     if (((this.NrErrors == 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrSuccess >= this.limitFolders) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FOLDERS_DELETED))) || ((this.NrErrors <= this.limitFolders) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/*     */ 
/* 295 */       retval = true;
/*     */     }
/*     */     
/* 298 */     return retval;
/*     */   }
/*     */   
/* 301 */   private boolean deleteFolder(String foldername) { boolean rcode = false;
/* 302 */     FileObject filefolder = null;
/*     */     try
/*     */     {
/* 305 */       filefolder = KettleVFS.getFileObject(foldername, this);
/*     */       
/* 307 */       if (filefolder.exists())
/*     */       {
/* 309 */         if (filefolder.getType() == FileType.FOLDER)
/*     */         {
/* 311 */           if (this.log.isDetailed()) {
/* 312 */             logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFolders.ProcessingFolder", new String[] { foldername }));
/*     */           }
/* 314 */           int Nr = filefolder.delete(new TextFileSelector(null));
/*     */           
/* 316 */           if (this.log.isDetailed())
/* 317 */             logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFolders.TotalDeleted", new String[] { foldername, String.valueOf(Nr) }));
/* 318 */           rcode = true;
/*     */         }
/*     */         else {
/* 321 */           logError(BaseMessages.getString(PKG, "JobEntryDeleteFolders.Error.NotFolder", new String[0]));
/*     */         }
/*     */       }
/*     */       else {
/* 325 */         if (this.log.isBasic()) logBasic(BaseMessages.getString(PKG, "JobEntryDeleteFolders.FolderAlreadyDeleted", new String[] { foldername }));
/* 326 */         rcode = true;
/*     */       }
/*     */     } catch (Exception e) {
/* 329 */       logError(BaseMessages.getString(PKG, "JobEntryDeleteFolders.CouldNotDelete", new String[] { foldername, e.getMessage() }), e);
/*     */     } finally {
/* 331 */       if (filefolder != null) {
/*     */         try {
/* 333 */           filefolder.close();
/* 334 */           filefolder = null;
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */     }
/*     */     
/* 340 */     return rcode;
/*     */   }
/*     */   
/*     */   private class TextFileSelector implements FileSelector {
/*     */     private TextFileSelector() {}
/*     */     
/*     */     public boolean includeFile(FileSelectInfo info) {
/* 347 */       return true;
/*     */     }
/*     */     
/*     */     public boolean traverseDescendents(FileSelectInfo info) {
/* 351 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setPrevious(boolean argFromPrevious)
/*     */   {
/* 357 */     this.argFromPrevious = argFromPrevious;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 363 */     return true;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {
/* 367 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */     
/* 369 */     if (!res) {
/* 370 */       return;
/*     */     }
/*     */     
/* 373 */     ValidatorContext ctx = new ValidatorContext();
/* 374 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 375 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*     */     
/* 377 */     for (int i = 0; i < this.arguments.length; i++) {
/* 378 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 383 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 384 */     if (this.arguments != null) {
/* 385 */       ResourceReference reference = null;
/* 386 */       for (int i = 0; i < this.arguments.length; i++) {
/* 387 */         String filename = jobMeta.environmentSubstitute(this.arguments[i]);
/* 388 */         if (reference == null) {
/* 389 */           reference = new ResourceReference(this);
/* 390 */           references.add(reference);
/*     */         }
/* 392 */         reference.getEntries().add(new ResourceEntry(filename, ResourceEntry.ResourceType.FILE));
/*     */       }
/*     */     }
/* 395 */     return references;
/*     */   }
/*     */   
/*     */   public boolean isArgFromPrevious()
/*     */   {
/* 400 */     return this.argFromPrevious;
/*     */   }
/*     */   
/*     */   public String[] getArguments()
/*     */   {
/* 405 */     return this.arguments;
/*     */   }
/*     */   
/*     */   public void setSuccessCondition(String success_condition)
/*     */   {
/* 410 */     this.success_condition = success_condition;
/*     */   }
/*     */   
/*     */   public String getSuccessCondition() {
/* 414 */     return this.success_condition;
/*     */   }
/*     */   
/*     */   public void setLimitFolders(String limit_folders) {
/* 418 */     this.limit_folders = limit_folders;
/*     */   }
/*     */   
/*     */   public String getLimitFolders()
/*     */   {
/* 423 */     return this.limit_folders;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\deletefolders\JobEntryDeleteFolders.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */