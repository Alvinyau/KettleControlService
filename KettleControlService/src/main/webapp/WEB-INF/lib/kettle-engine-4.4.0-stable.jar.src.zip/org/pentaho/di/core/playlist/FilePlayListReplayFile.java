/*    */ package org.pentaho.di.core.playlist;
/*    */ 
/*    */ import org.apache.commons.vfs.FileObject;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilePlayListReplayFile
/*    */   implements FilePlayList
/*    */ {
/*    */   private FileObject processingFile;
/*    */   private String processingFilePart;
/*    */   
/*    */   public FilePlayListReplayFile(FileObject processingFile, String processingFilePart)
/*    */   {
/* 33 */     this.processingFile = processingFile;
/* 34 */     this.processingFilePart = processingFilePart;
/*    */   }
/*    */   
/*    */   FileObject getProcessingFile() {
/* 38 */     return this.processingFile;
/*    */   }
/*    */   
/*    */   String getProcessingFilePart() {
/* 42 */     return this.processingFilePart;
/*    */   }
/*    */   
/*    */   public boolean isProcessingNeeded(FileObject file, long lineNr, String filePart) throws KettleException
/*    */   {
/* 47 */     return false;
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\playlist\FilePlayListReplayFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */