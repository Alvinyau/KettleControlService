/*    */ package org.pentaho.di.core.util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import org.pentaho.di.core.Const;
/*    */ import org.pentaho.di.core.logging.LogChannelInterface;
/*    */ import org.pentaho.di.core.logging.LogLevel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurableStreamLogger
/*    */   implements Runnable
/*    */ {
/*    */   private InputStream is;
/*    */   private String type;
/*    */   private LogLevel logLevel;
/*    */   private LogChannelInterface log;
/*    */   
/*    */   public ConfigurableStreamLogger(LogChannelInterface logChannel, InputStream in, LogLevel logLevel, String type)
/*    */   {
/* 55 */     this.log = logChannel;
/* 56 */     this.is = in;
/* 57 */     this.type = type;
/* 58 */     this.logLevel = logLevel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 67 */       InputStreamReader isr = new InputStreamReader(this.is);
/* 68 */       BufferedReader br = new BufferedReader(isr);
/* 69 */       String line = null;
/* 70 */       while ((line = br.readLine()) != null)
/*    */       {
/* 72 */         switch (this.logLevel) {
/* 73 */         case MINIMAL:  this.log.logMinimal(this.type, new Object[] { line }); break;
/* 74 */         case BASIC:  this.log.logBasic(this.type, new Object[] { line }); break;
/* 75 */         case DETAILED:  this.log.logDetailed(this.type, new Object[] { line }); break;
/* 76 */         case DEBUG:  this.log.logDebug(this.type, new Object[] { line }); break;
/* 77 */         case ROWLEVEL:  this.log.logRowlevel(this.type, new Object[] { line }); break;
/* 78 */         case ERROR:  this.log.logError(this.type, new Object[] { line });
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (IOException ioe)
/*    */     {
/* 84 */       if (this.log.isError()) {
/* 85 */         this.log.logError(this.type, new Object[] { Const.getStackTracker(ioe) });
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\ConfigurableStreamLogger.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */