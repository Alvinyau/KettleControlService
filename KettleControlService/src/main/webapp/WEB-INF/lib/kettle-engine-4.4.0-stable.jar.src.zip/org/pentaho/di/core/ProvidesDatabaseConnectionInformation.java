package org.pentaho.di.core;

import org.pentaho.di.core.database.DatabaseMeta;

public abstract interface ProvidesDatabaseConnectionInformation
{
  public abstract DatabaseMeta getDatabaseMeta();
  
  public abstract String getTableName();
  
  public abstract String getSchemaName();
  
  public abstract String getMissingDatabaseConnectionInformationMessage();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\ProvidesDatabaseConnectionInformation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */