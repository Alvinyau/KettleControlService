/*    */ package org.pentaho.di.core;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.exception.KettlePluginException;
/*    */ import org.pentaho.di.core.xml.XMLHandler;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KettleVariablesList
/*    */ {
/*    */   private static KettleVariablesList kettleVariablesList;
/*    */   private Map<String, String> descriptionMap;
/*    */   private Map<String, String> defaultValueMap;
/*    */   
/*    */   public static KettleVariablesList getInstance()
/*    */   {
/* 40 */     if (kettleVariablesList == null) {
/* 41 */       kettleVariablesList = new KettleVariablesList();
/*    */     }
/* 43 */     return kettleVariablesList;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static void init()
/*    */     throws KettleException
/*    */   {
/* 51 */     KettleVariablesList variablesList = getInstance();
/*    */     
/* 53 */     InputStream inputStream = variablesList.getClass().getResourceAsStream("kettle-variables.xml");
/* 54 */     if (inputStream == null) {
/* 55 */       inputStream = variablesList.getClass().getResourceAsStream("/kettle-variables.xml");
/*    */     }
/* 57 */     if (inputStream == null) {
/* 58 */       throw new KettlePluginException("Unable to find standard kettle variables definition file: kettle-variables.xml");
/*    */     }
/*    */     try
/*    */     {
/* 62 */       Document doc = XMLHandler.loadXMLFile(inputStream, null, false, false);
/* 63 */       Node varsNode = XMLHandler.getSubNode(doc, "kettle-variables");
/* 64 */       int nrVars = XMLHandler.countNodes(varsNode, "kettle-variable");
/* 65 */       for (int i = 0; i < nrVars; i++) {
/* 66 */         Node varNode = XMLHandler.getSubNodeByNr(varsNode, "kettle-variable", i);
/* 67 */         String description = XMLHandler.getTagValue(varNode, "description");
/* 68 */         String variable = XMLHandler.getTagValue(varNode, "variable");
/* 69 */         String defaultValue = XMLHandler.getTagValue(varNode, "default-value");
/*    */         
/* 71 */         variablesList.getDescriptionMap().put(variable, description);
/* 72 */         variablesList.getDefaultValueMap().put(variable, defaultValue);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 76 */       throw new KettleException("Unable to read file 'kettle-variables.xml'", e);
/*    */     }
/*    */   }
/*    */   
/*    */   private KettleVariablesList() {
/* 81 */     this.descriptionMap = new HashMap();
/* 82 */     this.defaultValueMap = new HashMap();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Map<String, String> getDescriptionMap()
/*    */   {
/* 89 */     return this.descriptionMap;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Map<String, String> getDefaultValueMap()
/*    */   {
/* 96 */     return this.defaultValueMap;
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\KettleVariablesList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */