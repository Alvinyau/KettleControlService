package org.pentaho.di.imp.rule;

import java.util.List;
import org.pentaho.di.core.exception.KettleException;
import org.w3c.dom.Node;

public abstract interface ImportRuleInterface
  extends Cloneable
{
  public abstract String getId();
  
  public abstract void setId(String paramString);
  
  public abstract List<ImportValidationFeedback> verifyRule(Object paramObject);
  
  public abstract boolean isEnabled();
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract boolean isUnique();
  
  public abstract void loadXML(Node paramNode)
    throws KettleException;
  
  public abstract String getXML();
  
  public abstract String getCompositeClassName();
  
  public abstract ImportRuleInterface clone();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rule\ImportRuleInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */