/*     */ package org.pentaho.di.imp.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*     */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*     */ import org.pentaho.di.trans.TransMeta;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformationHasDescriptionImportRule
/*     */   extends BaseImportRule
/*     */   implements ImportRuleInterface
/*     */ {
/*     */   private int minLength;
/*     */   
/*     */   public TransformationHasDescriptionImportRule()
/*     */   {
/*  43 */     this.minLength = 20;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  48 */     if (this.minLength > 0) {
/*  49 */       return super.toString() + " The minimum length is " + this.minLength;
/*     */     }
/*  51 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*     */   {
/*  58 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*     */     
/*  60 */     if (!isEnabled()) return feedback;
/*  61 */     if (!(subject instanceof TransMeta)) { return feedback;
/*     */     }
/*  63 */     TransMeta transMeta = (TransMeta)subject;
/*  64 */     String description = transMeta.getDescription();
/*     */     
/*  66 */     if ((Const.isEmpty(description)) || ((this.minLength > 0) && (description.length() < this.minLength))) {
/*  67 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "A description is not present or is too short."));
/*     */     } else {
/*  69 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "A description is present"));
/*     */     }
/*     */     
/*  72 */     return feedback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMinLength()
/*     */   {
/*  79 */     return this.minLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMinLength(int minLength)
/*     */   {
/*  86 */     this.minLength = minLength;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getXML()
/*     */   {
/*  92 */     StringBuilder xml = new StringBuilder();
/*  93 */     xml.append(XMLHandler.openTag(XML_TAG));
/*     */     
/*  95 */     xml.append(super.getXML());
/*     */     
/*  97 */     xml.append(XMLHandler.addTagValue("min_length", this.minLength));
/*     */     
/*  99 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 100 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node ruleNode) throws KettleException
/*     */   {
/* 105 */     super.loadXML(ruleNode);
/*     */     
/* 107 */     this.minLength = Const.toInt(XMLHandler.getTagValue(ruleNode, "min_length"), 0);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\TransformationHasDescriptionImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */