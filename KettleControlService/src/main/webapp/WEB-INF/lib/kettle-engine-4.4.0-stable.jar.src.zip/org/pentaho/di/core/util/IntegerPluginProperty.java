/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.prefs.Preferences;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerPluginProperty
/*     */   extends KeyValue<Integer>
/*     */   implements PluginProperty
/*     */ {
/*     */   private static final long serialVersionUID = -2990345692552430357L;
/*     */   
/*     */   public IntegerPluginProperty(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  53 */     super(key, DEFAULT_INTEGER_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate()
/*     */   {
/*  62 */     Integer value = (Integer)getValue();
/*  63 */     return (value != null) && (value.intValue() != 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendXml(StringBuilder builder)
/*     */   {
/*  72 */     builder.append(XMLHandler.addTagValue(getKey(), ((Integer)getValue()).intValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadXml(Node node)
/*     */   {
/*  81 */     Integer value = Integer.valueOf(Integer.parseInt(XMLHandler.getTagValue(node, getKey())));
/*  82 */     setValue(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromRepositoryStep(Repository repository, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/*  92 */     Long longValue = Long.valueOf(repository.getStepAttributeInteger(stepId, getKey()));
/*  93 */     setValue(Integer.valueOf(longValue.intValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToPreferences(Preferences node)
/*     */   {
/* 102 */     node.putInt(getKey(), ((Integer)getValue()).intValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromPreferences(Preferences node)
/*     */   {
/* 111 */     setValue(Integer.valueOf(node.getInt(getKey(), ((Integer)getValue()).intValue())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToRepositoryStep(Repository repository, ObjectId transformationId, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/* 122 */     repository.saveStepAttribute(transformationId, stepId, getKey(), ((Integer)getValue()).intValue());
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\IntegerPluginProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */