/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.repository.RepositoryAttributeInterface;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.pentaho.di.trans.performance.StepPerformanceSnapShot;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PerformanceLogTable
/*     */   extends BaseLogTable
/*     */   implements Cloneable, LogTableInterface
/*     */ {
/*  50 */   private static Class<?> PKG = PerformanceLogTable.class;
/*     */   public static final String XML_TAG = "perf-log-table";
/*     */   private String logInterval;
/*     */   
/*     */   public static enum ID
/*     */   {
/*  56 */     ID_BATCH("ID_BATCH"), 
/*  57 */     SEQ_NR("SEQ_NR"), 
/*  58 */     LOGDATE("LOGDATE"), 
/*  59 */     TRANSNAME("TRANSNAME"), 
/*  60 */     STEPNAME("STEPNAME"), 
/*  61 */     STEP_COPY("STEP_COPY"), 
/*  62 */     LINES_READ("LINES_READ"), 
/*  63 */     LINES_WRITTEN("LINES_WRITTEN"), 
/*  64 */     LINES_UPDATED("LINES_UPDATED"), 
/*  65 */     LINES_INPUT("LINES_INPUT"), 
/*  66 */     LINES_OUTPUT("LINES_OUTPUT"), 
/*  67 */     LINES_REJECTED("LINES_REJECTED"), 
/*  68 */     ERRORS("ERRORS"), 
/*  69 */     INPUT_BUFFER_ROWS("INPUT_BUFFER_ROWS"), 
/*  70 */     OUTPUT_BUFFER_ROWS("OUTPUT_BUFFER_ROWS");
/*     */     
/*     */     private String id;
/*     */     
/*     */     private ID(String id) {
/*  75 */       this.id = id;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  79 */       return this.id;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private PerformanceLogTable(VariableSpace space, HasDatabasesInterface databasesInterface)
/*     */   {
/*  86 */     super(space, databasesInterface, null, null, null);
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/*  92 */       PerformanceLogTable table = (PerformanceLogTable)super.clone();
/*  93 */       table.fields = new ArrayList();
/*  94 */       for (LogTableField field : this.fields) {
/*  95 */         table.fields.add((LogTableField)field.clone());
/*     */       }
/*  97 */       return table;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/* 100 */     return null;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 105 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 107 */     retval.append(XMLHandler.openTag("perf-log-table"));
/* 108 */     retval.append(XMLHandler.addTagValue("connection", this.connectionName));
/* 109 */     retval.append(XMLHandler.addTagValue("schema", this.schemaName));
/* 110 */     retval.append(XMLHandler.addTagValue("table", this.tableName));
/* 111 */     retval.append(XMLHandler.addTagValue("interval", this.logInterval));
/* 112 */     retval.append(XMLHandler.addTagValue("timeout_days", this.timeoutInDays));
/* 113 */     retval.append(super.getFieldsXML());
/* 114 */     retval.append(XMLHandler.closeTag("perf-log-table")).append(Const.CR);
/*     */     
/* 116 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node node, List<DatabaseMeta> databases) {
/* 120 */     this.connectionName = XMLHandler.getTagValue(node, "connection");
/* 121 */     this.schemaName = XMLHandler.getTagValue(node, "schema");
/* 122 */     this.tableName = XMLHandler.getTagValue(node, "table");
/* 123 */     this.logInterval = XMLHandler.getTagValue(node, "interval");
/* 124 */     this.timeoutInDays = XMLHandler.getTagValue(node, "timeout_days");
/*     */     
/* 126 */     super.loadFieldsXML(node);
/*     */   }
/*     */   
/*     */   public void saveToRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 130 */     super.saveToRepository(attributeInterface);
/*     */     
/*     */ 
/*     */ 
/* 134 */     attributeInterface.setAttribute(getLogTableCode() + PROP_LOG_TABLE_INTERVAL, this.logInterval);
/*     */   }
/*     */   
/*     */   public void loadFromRepository(RepositoryAttributeInterface attributeInterface) throws KettleException {
/* 138 */     super.loadFromRepository(attributeInterface);
/*     */     
/* 140 */     this.logInterval = attributeInterface.getAttributeString(getLogTableCode() + PROP_LOG_TABLE_INTERVAL);
/*     */   }
/*     */   
/*     */   public static PerformanceLogTable getDefault(VariableSpace space, HasDatabasesInterface databasesInterface)
/*     */   {
/* 145 */     PerformanceLogTable table = new PerformanceLogTable(space, databasesInterface);
/*     */     
/* 147 */     table.fields.add(new LogTableField(ID.ID_BATCH.id, true, false, "ID_BATCH", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.BatchID", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.BatchID", new String[0]), 5, 8));
/* 148 */     table.fields.add(new LogTableField(ID.SEQ_NR.id, true, false, "SEQ_NR", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.SeqNr", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.SeqNr", new String[0]), 5, 8));
/* 149 */     table.fields.add(new LogTableField(ID.LOGDATE.id, true, false, "LOGDATE", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LogDate", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LogDate", new String[0]), 3, -1));
/* 150 */     table.fields.add(new LogTableField(ID.TRANSNAME.id, true, false, "TRANSNAME", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.TransName", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.TransName", new String[0]), 2, 255));
/* 151 */     table.fields.add(new LogTableField(ID.STEPNAME.id, true, false, "STEPNAME", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.StepName", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.StepName", new String[0]), 2, 255));
/* 152 */     table.fields.add(new LogTableField(ID.STEP_COPY.id, true, false, "STEP_COPY", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.StepCopy", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.StepCopy", new String[0]), 5, 8));
/* 153 */     table.fields.add(new LogTableField(ID.LINES_READ.id, true, false, "LINES_READ", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LinesRead", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LinesRead", new String[0]), 5, 18));
/* 154 */     table.fields.add(new LogTableField(ID.LINES_WRITTEN.id, true, false, "LINES_WRITTEN", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LinesWritten", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LinesWritten", new String[0]), 5, 18));
/* 155 */     table.fields.add(new LogTableField(ID.LINES_UPDATED.id, true, false, "LINES_UPDATED", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LinesUpdated", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LinesUpdated", new String[0]), 5, 18));
/* 156 */     table.fields.add(new LogTableField(ID.LINES_INPUT.id, true, false, "LINES_INPUT", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LinesInput", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LinesInput", new String[0]), 5, 18));
/* 157 */     table.fields.add(new LogTableField(ID.LINES_OUTPUT.id, true, false, "LINES_OUTPUT", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LinesOutput", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LinesOutput", new String[0]), 5, 18));
/* 158 */     table.fields.add(new LogTableField(ID.LINES_REJECTED.id, true, false, "LINES_REJECTED", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.LinesRejected", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.LinesRejected", new String[0]), 5, 18));
/* 159 */     table.fields.add(new LogTableField(ID.ERRORS.id, true, false, "ERRORS", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.Errors", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.Errors", new String[0]), 5, 18));
/* 160 */     table.fields.add(new LogTableField(ID.INPUT_BUFFER_ROWS.id, true, false, "INPUT_BUFFER_ROWS", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.InputBufferRows", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.InputBufferRows", new String[0]), 5, 18));
/* 161 */     table.fields.add(new LogTableField(ID.OUTPUT_BUFFER_ROWS.id, true, false, "OUTPUT_BUFFER_ROWS", BaseMessages.getString(PKG, "PerformanceLogTable.FieldName.OutputBufferRows", new String[0]), BaseMessages.getString(PKG, "PerformanceLogTable.FieldDescription.OutputBufferRows", new String[0]), 5, 18));
/*     */     
/* 163 */     table.findField(ID.ID_BATCH.id).setKey(true);
/* 164 */     table.findField(ID.LOGDATE.id).setLogDateField(true);
/* 165 */     table.findField(ID.TRANSNAME.id).setNameField(true);
/*     */     
/* 167 */     return table;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogInterval(String logInterval)
/*     */   {
/* 177 */     this.logInterval = logInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLogInterval()
/*     */   {
/* 188 */     return this.logInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowMetaAndData getLogRecord(LogStatus status, Object subject, Object parent)
/*     */   {
/* 197 */     if ((subject == null) || ((subject instanceof StepPerformanceSnapShot))) {
/* 198 */       StepPerformanceSnapShot snapShot = (StepPerformanceSnapShot)subject;
/*     */       
/* 200 */       RowMetaAndData row = new RowMetaAndData();
/*     */       
/* 202 */       for (LogTableField field : this.fields) {
/* 203 */         if (field.isEnabled()) {
/* 204 */           Object value = null;
/* 205 */           if (subject != null) {
/* 206 */             switch (ID.valueOf(field.getId())) {
/*     */             case ID_BATCH: 
/* 208 */               value = new Long(snapShot.getBatchId()); break;
/* 209 */             case SEQ_NR:  value = new Long(snapShot.getSeqNr()); break;
/* 210 */             case LOGDATE:  value = snapShot.getDate(); break;
/* 211 */             case TRANSNAME:  value = snapShot.getTransName(); break;
/* 212 */             case STEPNAME:  value = snapShot.getStepName(); break;
/* 213 */             case STEP_COPY:  value = new Long(snapShot.getStepCopy()); break;
/* 214 */             case LINES_READ:  value = new Long(snapShot.getLinesRead()); break;
/* 215 */             case LINES_WRITTEN:  value = new Long(snapShot.getLinesWritten()); break;
/* 216 */             case LINES_INPUT:  value = new Long(snapShot.getLinesInput()); break;
/* 217 */             case LINES_OUTPUT:  value = new Long(snapShot.getLinesOutput()); break;
/* 218 */             case LINES_UPDATED:  value = new Long(snapShot.getLinesUpdated()); break;
/* 219 */             case LINES_REJECTED:  value = new Long(snapShot.getLinesRejected()); break;
/* 220 */             case ERRORS:  value = new Long(snapShot.getErrors()); break;
/* 221 */             case INPUT_BUFFER_ROWS:  value = new Long(snapShot.getInputBufferSize()); break;
/* 222 */             case OUTPUT_BUFFER_ROWS:  value = new Long(snapShot.getOutputBufferSize());
/*     */             }
/*     */             
/*     */           }
/* 226 */           row.addValue(field.getFieldName(), field.getDataType(), value);
/* 227 */           row.getRowMeta().getValueMeta(row.size() - 1).setLength(field.getLength());
/*     */         }
/*     */       }
/*     */       
/* 231 */       return row;
/*     */     }
/*     */     
/* 234 */     return null;
/*     */   }
/*     */   
/*     */   public String getLogTableCode()
/*     */   {
/* 239 */     return "PERFORMANCE";
/*     */   }
/*     */   
/*     */   public String getLogTableType() {
/* 243 */     return BaseMessages.getString(PKG, "PerformanceLogTable.Type.Description", new String[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionNameVariable() {
/* 247 */     return "KETTLE_TRANS_PERFORMANCE_LOG_DB";
/*     */   }
/*     */   
/*     */   public String getSchemaNameVariable() {
/* 251 */     return "KETTLE_TRANS_PERFORMANCE_LOG_SCHEMA";
/*     */   }
/*     */   
/*     */   public String getTableNameVariable() {
/* 255 */     return "KETTLE_TRANS_PERFORMANCE_LOG_TABLE";
/*     */   }
/*     */   
/*     */   public List<RowMetaInterface> getRecommendedIndexes() {
/* 259 */     List<RowMetaInterface> indexes = new ArrayList();
/* 260 */     return indexes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\PerformanceLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */