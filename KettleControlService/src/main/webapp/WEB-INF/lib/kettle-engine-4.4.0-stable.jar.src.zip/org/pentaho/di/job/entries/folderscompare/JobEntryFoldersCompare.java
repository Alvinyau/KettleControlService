/*     */ package org.pentaho.di.job.entries.folderscompare;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileContent;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileSelector;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleFileException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFoldersCompare
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  78 */   private static Class<?> PKG = JobEntryFoldersCompare.class;
/*     */   
/*     */   private String filename1;
/*     */   
/*     */   private String filename2;
/*     */   private String wildcard;
/*     */   private String compareonly;
/*     */   private boolean includesubfolders;
/*     */   private boolean comparefilecontent;
/*     */   private boolean comparefilesize;
/*     */   
/*     */   public JobEntryFoldersCompare(String n)
/*     */   {
/*  91 */     super(n, "");
/*  92 */     this.includesubfolders = false;
/*  93 */     this.comparefilesize = false;
/*  94 */     this.comparefilecontent = false;
/*  95 */     this.compareonly = "all";
/*  96 */     this.wildcard = null;
/*  97 */     this.filename1 = null;
/*  98 */     this.filename2 = null;
/*  99 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public void setCompareOnly(String comparevalue)
/*     */   {
/* 104 */     this.compareonly = comparevalue;
/*     */   }
/*     */   
/*     */   public String getCompareOnly() {
/* 108 */     return this.compareonly;
/*     */   }
/*     */   
/*     */   public JobEntryFoldersCompare() {
/* 112 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 117 */     JobEntryFoldersCompare je = (JobEntryFoldersCompare)super.clone();
/* 118 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 123 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 125 */     retval.append(super.getXML());
/* 126 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.includesubfolders));
/* 127 */     retval.append("      ").append(XMLHandler.addTagValue("compare_filecontent", this.comparefilecontent));
/* 128 */     retval.append("      ").append(XMLHandler.addTagValue("compare_filesize", this.comparefilesize));
/*     */     
/*     */ 
/* 131 */     retval.append("      ").append(XMLHandler.addTagValue("compareonly", this.compareonly));
/* 132 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/* 133 */     retval.append("      ").append(XMLHandler.addTagValue("filename1", this.filename1));
/* 134 */     retval.append("      ").append(XMLHandler.addTagValue("filename2", this.filename2));
/*     */     
/* 136 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       super.loadXML(entrynode, databases, slaveServers);
/* 145 */       this.includesubfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/* 146 */       this.comparefilecontent = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "compare_filecontent"));
/* 147 */       this.comparefilesize = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "compare_filesize"));
/*     */       
/*     */ 
/* 150 */       this.compareonly = XMLHandler.getTagValue(entrynode, "compareonly");
/* 151 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/* 152 */       this.filename1 = XMLHandler.getTagValue(entrynode, "filename1");
/* 153 */       this.filename2 = XMLHandler.getTagValue(entrynode, "filename2");
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 157 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobFoldersCompare.Meta.UnableLoadXML", new String[] { xe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 165 */       this.includesubfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/* 166 */       this.comparefilecontent = rep.getJobEntryAttributeBoolean(id_jobentry, "compare_filecontent");
/* 167 */       this.comparefilesize = rep.getJobEntryAttributeBoolean(id_jobentry, "compare_filesize");
/*     */       
/* 169 */       this.compareonly = rep.getJobEntryAttributeString(id_jobentry, "compareonly");
/* 170 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/* 171 */       this.filename1 = rep.getJobEntryAttributeString(id_jobentry, "filename1");
/* 172 */       this.filename2 = rep.getJobEntryAttributeString(id_jobentry, "filename2");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 176 */       throw new KettleException(BaseMessages.getString(PKG, "JobFoldersCompare.Meta.UnableLoadRep", new String[] { "" + id_jobentry, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 184 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.includesubfolders);
/* 185 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "compare_filecontent", this.comparefilecontent);
/* 186 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "compare_filesize", this.comparefilesize);
/*     */       
/* 188 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "compareonly", this.compareonly);
/* 189 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/* 190 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename1", this.filename1);
/* 191 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename2", this.filename2);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 195 */       throw new KettleException(BaseMessages.getString(PKG, "JobFoldersCompare.Meta.UnableSaveRep", new String[] { "" + id_job, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setIncludeSubfolders(boolean includeSubfolders)
/*     */   {
/* 201 */     this.includesubfolders = includeSubfolders;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubfolders()
/*     */   {
/* 206 */     return this.includesubfolders;
/*     */   }
/*     */   
/*     */   public void setCompareFileContent(boolean comparefilecontent)
/*     */   {
/* 211 */     this.comparefilecontent = comparefilecontent;
/*     */   }
/*     */   
/*     */   public boolean isCompareFileContent()
/*     */   {
/* 216 */     return this.comparefilecontent;
/*     */   }
/*     */   
/*     */   public void setCompareFileSize(boolean comparefilesize)
/*     */   {
/* 221 */     this.comparefilesize = comparefilesize;
/*     */   }
/*     */   
/*     */   public boolean isCompareFileSize()
/*     */   {
/* 226 */     return this.comparefilesize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRealWildcard()
/*     */   {
/* 234 */     return environmentSubstitute(getWildcard());
/*     */   }
/*     */   
/*     */   public String getRealFilename1() {
/* 238 */     return environmentSubstitute(getFilename1());
/*     */   }
/*     */   
/*     */   public String getRealFilename2()
/*     */   {
/* 243 */     return environmentSubstitute(getFilename2());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean equalFileContents(FileObject file1, FileObject file2)
/*     */     throws KettleFileException
/*     */   {
/* 259 */     DataInputStream in1 = null;
/* 260 */     DataInputStream in2 = null;
/*     */     
/*     */     try
/*     */     {
/* 264 */       in1 = new DataInputStream(new BufferedInputStream(KettleVFS.getInputStream(KettleVFS.getFilename(file1), this)));
/* 265 */       in2 = new DataInputStream(new BufferedInputStream(KettleVFS.getInputStream(KettleVFS.getFilename(file2), this)));
/*     */       
/*     */       boolean bool;
/* 268 */       while ((in1.available() != 0) && (in2.available() != 0))
/*     */       {
/* 270 */         char ch1 = (char)in1.readByte();
/* 271 */         char ch2 = (char)in2.readByte();
/* 272 */         if (ch1 != ch2)
/* 273 */           return false;
/*     */       }
/* 275 */       if (in1.available() != in2.available())
/*     */       {
/* 277 */         return false;
/*     */       }
/*     */       
/*     */ 
/* 281 */       return true;
/*     */     }
/*     */     catch (IOException e) {
/* 284 */       throw new KettleFileException(e);
/*     */     } finally {
/* 286 */       if (in1 != null) {
/*     */         try {
/* 288 */           in1.close();
/*     */         }
/*     */         catch (IOException ignored) {}
/*     */       }
/*     */       
/* 293 */       if (in2 != null) {
/*     */         try {
/* 295 */           in2.close();
/*     */         }
/*     */         catch (Exception ignored) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 305 */     Result result = previousResult;
/* 306 */     result.setResult(false);
/* 307 */     boolean ok = true;
/*     */     
/* 309 */     String realFilename1 = getRealFilename1();
/* 310 */     String realFilename2 = getRealFilename2();
/*     */     
/* 312 */     FileObject folder1 = null;
/* 313 */     FileObject folder2 = null;
/* 314 */     FileObject filefolder1 = null;
/* 315 */     FileObject filefolder2 = null;
/*     */     
/*     */     try
/*     */     {
/* 319 */       if ((this.filename1 != null) && (this.filename2 != null))
/*     */       {
/*     */ 
/* 322 */         folder1 = KettleVFS.getFileObject(realFilename1, this);
/* 323 */         folder2 = KettleVFS.getFileObject(realFilename2, this);
/*     */         
/* 325 */         if ((folder1.exists()) && (folder2.exists()))
/*     */         {
/* 327 */           if (!folder1.getType().equals(folder2.getType()))
/*     */           {
/*     */ 
/* 330 */             logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.CanNotCompareFilesFolders", new String[0]));
/*     */             
/* 332 */             if (folder1.getType() == FileType.FILE) {
/* 333 */               logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFile", new String[] { realFilename1 }));
/* 334 */             } else if (folder1.getType() == FileType.FOLDER) {
/* 335 */               logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFolder", new String[] { realFilename1 }));
/*     */             } else {
/* 337 */               logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsUnknownFileType", new String[] { realFilename1 }));
/*     */             }
/* 339 */             if (folder2.getType() == FileType.FILE) {
/* 340 */               logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFile", new String[] { realFilename2 }));
/* 341 */             } else if (folder2.getType() == FileType.FOLDER) {
/* 342 */               logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFolder", new String[] { realFilename2 }));
/*     */             } else {
/* 344 */               logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsUnknownFileType", new String[] { realFilename2 }));
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 349 */           else if (folder1.getType() == FileType.FILE)
/*     */           {
/*     */ 
/* 352 */             if (equalFileContents(folder1, folder2)) {
/* 353 */               result.setResult(true);
/*     */             } else {
/* 355 */               result.setResult(false);
/*     */             }
/* 357 */           } else if (folder1.getType() == FileType.FOLDER)
/*     */           {
/*     */ 
/*     */ 
/* 361 */             FileObject[] list1 = folder1.findFiles(new TextFileSelector(folder1.toString()));
/* 362 */             FileObject[] list2 = folder2.findFiles(new TextFileSelector(folder2.toString()));
/*     */             
/* 364 */             int lenList1 = list1.length;
/* 365 */             int lenList2 = list2.length;
/*     */             
/* 367 */             if (this.log.isDetailed())
/*     */             {
/* 369 */               logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FolderContains", new String[] { realFilename1, "" + lenList1 }));
/* 370 */               logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FolderContains", new String[] { realFilename2, "" + lenList2 }));
/*     */             }
/* 372 */             if (lenList1 == lenList2)
/*     */             {
/*     */ 
/* 375 */               HashMap<String, String> collection1 = new HashMap();
/* 376 */               HashMap<String, String> collection2 = new HashMap();
/*     */               
/*     */ 
/* 379 */               for (int i = 0; i < list1.length; i++)
/*     */               {
/*     */ 
/* 382 */                 collection1.put(list1[i].getName().getBaseName(), list1[i].toString());
/*     */               }
/*     */               
/*     */ 
/* 386 */               for (int i = 0; i < list2.length; i++)
/*     */               {
/*     */ 
/* 389 */                 collection2.put(list2[i].getName().getBaseName(), list2[i].toString());
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */               Set<Map.Entry<String, String>> entrees = collection1.entrySet();
/* 397 */               Iterator<Map.Entry<String, String>> iterateur = entrees.iterator();
/*     */               
/* 399 */               while (iterateur.hasNext())
/*     */               {
/* 401 */                 Map.Entry<String, String> entree = (Map.Entry)iterateur.next();
/* 402 */                 if (!collection2.containsKey(entree.getKey()))
/*     */                 {
/* 404 */                   ok = false;
/* 405 */                   if (this.log.isDetailed()) {
/* 406 */                     logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FileCanNotBeFoundIn", new String[] { ((String)entree.getKey()).toString(), realFilename2 }));
/*     */                   }
/*     */                 }
/*     */                 else {
/* 410 */                   if (this.log.isDebug()) { logDebug(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FileIsFoundIn", new String[] { ((String)entree.getKey()).toString(), realFilename2 }));
/*     */                   }
/* 412 */                   filefolder1 = KettleVFS.getFileObject(((String)entree.getValue()).toString(), this);
/* 413 */                   filefolder2 = KettleVFS.getFileObject(((String)collection2.get(entree.getKey())).toString(), this);
/*     */                   
/* 415 */                   if (!filefolder2.getType().equals(filefolder1.getType()))
/*     */                   {
/*     */ 
/* 418 */                     ok = false;
/* 419 */                     if (this.log.isDetailed()) {
/* 420 */                       logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FilesNotSameType", new String[] { filefolder1.toString(), filefolder2.toString() }));
/*     */                     }
/* 422 */                     if (filefolder1.getType() == FileType.FILE) {
/* 423 */                       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFile", new String[] { filefolder1.toString() }));
/* 424 */                     } else if (filefolder1.getType() == FileType.FOLDER) {
/* 425 */                       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFolder", new String[] { filefolder1.toString() }));
/*     */                     } else {
/* 427 */                       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsUnknownFileType", new String[] { filefolder1.toString() }));
/*     */                     }
/* 429 */                     if (filefolder2.getType() == FileType.FILE) {
/* 430 */                       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFile", new String[] { filefolder2.toString() }));
/* 431 */                     } else if (filefolder2.getType() == FileType.FOLDER) {
/* 432 */                       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsAFolder", new String[] { filefolder2.toString() }));
/*     */                     } else {
/* 434 */                       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.IsUnknownFileType", new String[] { filefolder2.toString() }));
/*     */ 
/*     */                     }
/*     */                     
/*     */ 
/*     */ 
/*     */                   }
/* 441 */                   else if (filefolder2.getType() == FileType.FILE)
/*     */                   {
/*     */ 
/* 444 */                     if (this.comparefilesize)
/*     */                     {
/* 446 */                       long filefolder1_size = filefolder1.getContent().getSize();
/* 447 */                       long filefolder2_size = filefolder2.getContent().getSize();
/* 448 */                       if (filefolder1_size != filefolder2_size)
/*     */                       {
/* 450 */                         ok = false;
/* 451 */                         if (this.log.isDetailed())
/*     */                         {
/* 453 */                           logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FilesNotSameSize", new String[] { filefolder1.toString(), filefolder2.toString() }));
/* 454 */                           logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.SizeFileIs", new String[] { filefolder1.toString(), "" + filefolder1_size }));
/* 455 */                           logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.SizeFileIs", new String[] { filefolder2.toString(), "" + filefolder2_size }));
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                     
/* 460 */                     if (ok)
/*     */                     {
/*     */ 
/* 463 */                       if (this.comparefilecontent)
/*     */                       {
/* 465 */                         if (!equalFileContents(filefolder1, filefolder2))
/*     */                         {
/* 467 */                           ok = false;
/* 468 */                           if (this.log.isDetailed()) {
/* 469 */                             logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FilesNotSameContent", new String[] { filefolder1.toString(), filefolder2.toString() }));
/*     */                           }
/*     */                         }
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 481 */               result.setResult(ok);
/*     */ 
/*     */ 
/*     */ 
/*     */             }
/* 486 */             else if (this.log.isDetailed()) {
/* 487 */               logDetailed(BaseMessages.getString(PKG, "JobFoldersCompare.Log.FoldersDifferentFiles", new String[] { realFilename1.toString(), realFilename2.toString() }));
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 502 */           if (!folder1.exists())
/* 503 */             logError(BaseMessages.getString(PKG, "JobFileCompare.Log.FileNotExist", new String[] { realFilename1 }));
/* 504 */           if (!folder2.exists())
/* 505 */             logError(BaseMessages.getString(PKG, "JobFileCompare.Log.FileNotExist", new String[] { realFilename2 }));
/* 506 */           result.setResult(false);
/* 507 */           result.setNrErrors(1L);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 512 */         logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.Need2Files", new String[0]));
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 517 */       result.setResult(false);
/* 518 */       result.setNrErrors(1L);
/* 519 */       logError(BaseMessages.getString(PKG, "JobFoldersCompare.Log.ErrorComparing", new String[] { realFilename2, realFilename2, e.getMessage() }));
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 525 */         if (folder1 != null) {
/* 526 */           folder1.close();
/* 527 */           folder1 = null;
/*     */         }
/* 529 */         if (folder2 != null) {
/* 530 */           folder2.close();
/* 531 */           folder2 = null;
/*     */         }
/* 533 */         if (filefolder1 != null) {
/* 534 */           filefolder1.close();
/* 535 */           filefolder1 = null;
/*     */         }
/* 537 */         if (filefolder2 != null) {
/* 538 */           filefolder2.close();
/* 539 */           filefolder2 = null;
/*     */         }
/*     */       }
/*     */       catch (IOException e) {}
/*     */     }
/*     */     
/*     */ 
/* 546 */     return result;
/*     */   }
/*     */   
/*     */   private class TextFileSelector implements FileSelector {
/* 550 */     String source_folder = null;
/*     */     
/*     */     public TextFileSelector(String sourcefolderin) {
/* 553 */       if (!Const.isEmpty(sourcefolderin)) { this.source_folder = sourcefolderin;
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean includeFile(FileSelectInfo info)
/*     */     {
/* 559 */       boolean returncode = false;
/*     */       try
/*     */       {
/* 562 */         if (!info.getFile().toString().equals(this.source_folder))
/*     */         {
/*     */ 
/* 565 */           String short_filename = info.getFile().getName().getBaseName();
/*     */           
/* 567 */           if (info.getFile().getParent().equals(info.getBaseFolder()))
/*     */           {
/*     */ 
/* 570 */             if (((info.getFile().getType() == FileType.FILE) && (JobEntryFoldersCompare.this.compareonly.equals("only_files"))) || ((info.getFile().getType() == FileType.FOLDER) && (JobEntryFoldersCompare.this.compareonly.equals("only_folders"))) || ((JobEntryFoldersCompare.this.GetFileWildcard(short_filename)) && (JobEntryFoldersCompare.this.compareonly.equals("specify"))) || (JobEntryFoldersCompare.this.compareonly.equals("all")))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 575 */               returncode = true;
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 580 */           else if (JobEntryFoldersCompare.this.includesubfolders)
/*     */           {
/* 582 */             if (((info.getFile().getType() == FileType.FILE) && (JobEntryFoldersCompare.this.compareonly.equals("only_files"))) || ((info.getFile().getType() == FileType.FOLDER) && (JobEntryFoldersCompare.this.compareonly.equals("only_folders"))) || ((JobEntryFoldersCompare.this.GetFileWildcard(short_filename)) && (JobEntryFoldersCompare.this.compareonly.equals("specify"))) || (JobEntryFoldersCompare.this.compareonly.equals("all")))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 587 */               returncode = true;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 598 */         JobEntryFoldersCompare.this.logError("Error while finding files ... in [" + info.getFile().toString() + "]. Exception :" + e.getMessage());
/* 599 */         returncode = false;
/*     */       }
/* 601 */       return returncode;
/*     */     }
/*     */     
/*     */     public boolean traverseDescendents(FileSelectInfo info)
/*     */     {
/* 606 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile)
/*     */   {
/* 617 */     Pattern pattern = null;
/* 618 */     boolean getIt = true;
/*     */     
/* 620 */     if (!Const.isEmpty(this.wildcard))
/*     */     {
/* 622 */       pattern = Pattern.compile(this.wildcard);
/*     */       
/* 624 */       if (pattern != null)
/*     */       {
/* 626 */         Matcher matcher = pattern.matcher(selectedfile);
/* 627 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 631 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 638 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setWildcard(String wildcard)
/*     */   {
/* 644 */     this.wildcard = wildcard;
/*     */   }
/*     */   
/*     */   public String getWildcard() {
/* 648 */     return this.wildcard;
/*     */   }
/*     */   
/*     */   public void setFilename1(String filename) {
/* 652 */     this.filename1 = filename;
/*     */   }
/*     */   
/*     */   public String getFilename1()
/*     */   {
/* 657 */     return this.filename1;
/*     */   }
/*     */   
/*     */   public void setFilename2(String filename)
/*     */   {
/* 662 */     this.filename2 = filename;
/*     */   }
/*     */   
/*     */   public String getFilename2()
/*     */   {
/* 667 */     return this.filename2;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 672 */     ValidatorContext ctx = new ValidatorContext();
/* 673 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 674 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 675 */     JobEntryValidatorUtils.andValidator().validate(this, "filename1", remarks, ctx);
/* 676 */     JobEntryValidatorUtils.andValidator().validate(this, "filename2", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\folderscompare\JobEntryFoldersCompare.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */