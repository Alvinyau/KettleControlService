/*     */ package org.pentaho.di.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LastUsedFile
/*     */ {
/*     */   public static final String FILE_TYPE_TRANSFORMATION = "Trans";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String FILE_TYPE_JOB = "Job";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String FILE_TYPE_SCHEMA = "Schema";
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int OPENED_ITEM_TYPE_MASK_NONE = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int OPENED_ITEM_TYPE_MASK_GRAPH = 1;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int OPENED_ITEM_TYPE_MASK_LOG = 2;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final int OPENED_ITEM_TYPE_MASK_HISTORY = 4;
/*     */   
/*     */ 
/*     */   private String fileType;
/*     */   
/*     */ 
/*     */   private String filename;
/*     */   
/*     */ 
/*     */   private String directory;
/*     */   
/*     */ 
/*     */   private boolean sourceRepository;
/*     */   
/*     */ 
/*     */   private String repositoryName;
/*     */   
/*     */ 
/*     */   private boolean opened;
/*     */   
/*     */ 
/*     */   private int openItemTypes;
/*     */   
/*     */ 
/*     */ 
/*     */   public LastUsedFile(String fileType, String filename, String directory, boolean sourceRepository, String repositoryName, boolean opened, int openItemTypes)
/*     */   {
/*  59 */     this.fileType = fileType;
/*  60 */     this.filename = filename;
/*  61 */     this.directory = directory;
/*  62 */     this.sourceRepository = sourceRepository;
/*  63 */     this.repositoryName = repositoryName;
/*  64 */     this.opened = opened;
/*  65 */     this.openItemTypes = openItemTypes;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  70 */     String string = "";
/*     */     
/*  72 */     if ((this.sourceRepository) && (!Const.isEmpty(this.directory)) && (!Const.isEmpty(this.repositoryName)))
/*     */     {
/*  74 */       string = string + "[" + this.repositoryName + "] ";
/*     */       
/*  76 */       if (this.directory.endsWith("/"))
/*     */       {
/*  78 */         string = string + ": " + this.directory + this.filename;
/*     */       }
/*     */       else
/*     */       {
/*  82 */         string = string + ": /" + this.filename;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  87 */       string = string + this.filename;
/*     */     }
/*     */     
/*  90 */     return string;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  95 */     return (getFileType() + toString()).hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 100 */     LastUsedFile file = (LastUsedFile)obj;
/* 101 */     return (getFileType().equals(file.getFileType())) && (toString().equals(file.toString()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDirectory()
/*     */   {
/* 109 */     return this.directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectory(String directory)
/*     */   {
/* 117 */     this.directory = directory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilename()
/*     */   {
/* 125 */     return this.filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilename(String filename)
/*     */   {
/* 133 */     this.filename = filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRepositoryName()
/*     */   {
/* 141 */     return this.repositoryName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRepositoryName(String repositoryName)
/*     */   {
/* 149 */     this.repositoryName = repositoryName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSourceRepository()
/*     */   {
/* 157 */     return this.sourceRepository;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceRepository(boolean sourceRepository)
/*     */   {
/* 165 */     this.sourceRepository = sourceRepository;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileType()
/*     */   {
/* 173 */     return this.fileType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileType(String fileType)
/*     */   {
/* 181 */     this.fileType = fileType;
/*     */   }
/*     */   
/*     */   public boolean isTransformation()
/*     */   {
/* 186 */     return "Trans".equalsIgnoreCase(this.fileType);
/*     */   }
/*     */   
/*     */   public boolean isJob()
/*     */   {
/* 191 */     return "Job".equalsIgnoreCase(this.fileType);
/*     */   }
/*     */   
/*     */   public boolean isSchema()
/*     */   {
/* 196 */     return "Schema".equalsIgnoreCase(this.fileType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isOpened()
/*     */   {
/* 203 */     return this.opened;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOpened(boolean opened)
/*     */   {
/* 210 */     this.opened = opened;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getOpenItemTypes()
/*     */   {
/* 217 */     return this.openItemTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOpenItemTypes(int openItemTypes)
/*     */   {
/* 224 */     this.openItemTypes = openItemTypes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\LastUsedFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */