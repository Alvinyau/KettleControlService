/*     */ package org.pentaho.di.job.entries.dtdvalidator;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDTDValidator
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*     */   private String xmlfilename;
/*     */   private String dtdfilename;
/*     */   private boolean dtdintern;
/*     */   
/*     */   public JobEntryDTDValidator(String n)
/*     */   {
/*  71 */     super(n, "");
/*  72 */     this.xmlfilename = null;
/*  73 */     this.dtdfilename = null;
/*  74 */     this.dtdintern = false;
/*     */     
/*  76 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryDTDValidator()
/*     */   {
/*  81 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  86 */     JobEntryDTDValidator je = (JobEntryDTDValidator)super.clone();
/*  87 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  92 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/*  94 */     retval.append(super.getXML());
/*  95 */     retval.append("      ").append(XMLHandler.addTagValue("xmlfilename", this.xmlfilename));
/*  96 */     retval.append("      ").append(XMLHandler.addTagValue("dtdfilename", this.dtdfilename));
/*  97 */     retval.append("      ").append(XMLHandler.addTagValue("dtdintern", this.dtdintern));
/*     */     
/*     */ 
/* 100 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       super.loadXML(entrynode, databases, slaveServers);
/* 109 */       this.xmlfilename = XMLHandler.getTagValue(entrynode, "xmlfilename");
/* 110 */       this.dtdfilename = XMLHandler.getTagValue(entrynode, "dtdfilename");
/* 111 */       this.dtdintern = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "dtdintern"));
/*     */ 
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/*     */ 
/* 117 */       throw new KettleXMLException("Unable to load job entry of type 'DTDvalidator' from XML node", xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 125 */       this.xmlfilename = rep.getJobEntryAttributeString(id_jobentry, "xmlfilename");
/* 126 */       this.dtdfilename = rep.getJobEntryAttributeString(id_jobentry, "dtdfilename");
/* 127 */       this.dtdintern = rep.getJobEntryAttributeBoolean(id_jobentry, "dtdintern");
/*     */ 
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 132 */       throw new KettleException("Unable to load job entry of type 'DTDvalidator' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 140 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "xmlfilename", this.xmlfilename);
/* 141 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "DTDfilename", this.dtdfilename);
/* 142 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "dtdintern", this.dtdintern);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 146 */       throw new KettleException("Unable to save job entry of type 'DTDvalidator' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getRealxmlfilename()
/*     */   {
/* 152 */     return environmentSubstitute(this.xmlfilename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRealDTDfilename()
/*     */   {
/* 159 */     return environmentSubstitute(this.dtdfilename);
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 164 */     Result result = previousResult;
/* 165 */     result.setResult(true);
/*     */     
/* 167 */     String realxmlfilename = getRealxmlfilename();
/* 168 */     String realDTDfilename = getRealDTDfilename();
/*     */     
/*     */ 
/* 171 */     DTDValidator validator = new DTDValidator(this.log);
/*     */     
/* 173 */     validator.setXMLFilename(realxmlfilename);
/* 174 */     if (this.dtdintern)
/*     */     {
/* 176 */       validator.setInternDTD(true);
/*     */     }
/*     */     else
/*     */     {
/* 180 */       validator.setDTDFilename(realDTDfilename);
/*     */     }
/*     */     
/* 183 */     boolean status = validator.validate();
/* 184 */     if (!status)
/*     */     {
/* 186 */       this.log.logError(validator.getErrorMessage());
/* 187 */       result.setResult(false);
/* 188 */       result.setNrErrors(validator.getNrErrors());
/* 189 */       result.setLogText(validator.getErrorMessage());
/*     */     }
/*     */     
/*     */ 
/* 193 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 198 */     return true;
/*     */   }
/*     */   
/*     */   public void setxmlFilename(String filename)
/*     */   {
/* 203 */     this.xmlfilename = filename;
/*     */   }
/*     */   
/*     */   public String getxmlFilename()
/*     */   {
/* 208 */     return this.xmlfilename;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setdtdFilename(String filename)
/*     */   {
/* 214 */     this.dtdfilename = filename;
/*     */   }
/*     */   
/*     */   public String getdtdFilename()
/*     */   {
/* 219 */     return this.dtdfilename;
/*     */   }
/*     */   
/*     */   public boolean getDTDIntern()
/*     */   {
/* 224 */     return this.dtdintern;
/*     */   }
/*     */   
/*     */   public void setDTDIntern(boolean dtdinternin)
/*     */   {
/* 229 */     this.dtdintern = dtdinternin;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 233 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 234 */     if ((!Const.isEmpty(this.dtdfilename)) && (!Const.isEmpty(this.xmlfilename))) {
/* 235 */       String realXmlFileName = jobMeta.environmentSubstitute(this.xmlfilename);
/* 236 */       String realXsdFileName = jobMeta.environmentSubstitute(this.dtdfilename);
/* 237 */       ResourceReference reference = new ResourceReference(this);
/* 238 */       reference.getEntries().add(new ResourceEntry(realXmlFileName, ResourceEntry.ResourceType.FILE));
/* 239 */       reference.getEntries().add(new ResourceEntry(realXsdFileName, ResourceEntry.ResourceType.FILE));
/* 240 */       references.add(reference);
/*     */     }
/* 242 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 248 */     ValidatorContext ctx = new ValidatorContext();
/* 249 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 250 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 251 */     JobEntryValidatorUtils.andValidator().validate(this, "dtdfilename", remarks, ctx);
/* 252 */     JobEntryValidatorUtils.andValidator().validate(this, "xmlFilename", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\dtdvalidator\JobEntryDTDValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */