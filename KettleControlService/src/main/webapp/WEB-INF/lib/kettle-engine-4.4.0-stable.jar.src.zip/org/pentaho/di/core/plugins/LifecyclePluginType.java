/*     */ package org.pentaho.di.core.plugins;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.core.annotations.LifecyclePlugin;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.gui.GUIOption;
/*     */ import org.pentaho.di.core.lifecycle.LifecycleListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PluginMainClassType(LifecycleListener.class)
/*     */ @PluginExtraClassTypes(classTypes={GUIOption.class})
/*     */ @PluginAnnotationType(LifecyclePlugin.class)
/*     */ public class LifecyclePluginType
/*     */   extends BasePluginType
/*     */   implements PluginTypeInterface
/*     */ {
/*     */   private static LifecyclePluginType pluginType;
/*     */   
/*     */   private LifecyclePluginType()
/*     */   {
/*  49 */     super(LifecyclePlugin.class, "LIFECYCLE LISTENERS", "Lifecycle listener plugin type");
/*  50 */     populateFolders("repositories");
/*     */   }
/*     */   
/*     */   public static LifecyclePluginType getInstance() {
/*  54 */     if (pluginType == null) {
/*  55 */       pluginType = new LifecyclePluginType();
/*     */     }
/*  57 */     return pluginType;
/*     */   }
/*     */   
/*     */ 
/*     */   public void searchPlugins()
/*     */     throws KettlePluginException
/*     */   {
/*  64 */     registerNatives();
/*  65 */     registerAnnotations();
/*  66 */     registerPluginJars();
/*  67 */     registerXmlPlugins();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void registerNatives()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected void registerAnnotations()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   protected void registerXmlPlugins()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */ 
/*     */   protected String extractCategory(Annotation annotation)
/*     */   {
/*  91 */     return "";
/*     */   }
/*     */   
/*     */   protected String extractDesc(Annotation annotation)
/*     */   {
/*  96 */     return "";
/*     */   }
/*     */   
/*     */   protected String extractID(Annotation annotation)
/*     */   {
/* 101 */     return ((LifecyclePlugin)annotation).id();
/*     */   }
/*     */   
/*     */   protected String extractName(Annotation annotation)
/*     */   {
/* 106 */     return ((LifecyclePlugin)annotation).name();
/*     */   }
/*     */   
/*     */   protected String extractImageFile(Annotation annotation)
/*     */   {
/* 111 */     return null;
/*     */   }
/*     */   
/*     */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*     */   {
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   protected String extractI18nPackageName(Annotation annotation)
/*     */   {
/* 121 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation)
/*     */   {
/* 133 */     classMap.put(GUIOption.class, clazz.getName());
/* 134 */     classMap.put(LifecycleListener.class, clazz.getName());
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\LifecyclePluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */