package org.pentaho.di.core.gui;

import org.pentaho.di.core.undo.TransAction;

public abstract interface UndoInterface
{
  public abstract void addUndo(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, int[] paramArrayOfInt, Point[] paramArrayOfPoint1, Point[] paramArrayOfPoint2, int paramInt, boolean paramBoolean);
  
  public abstract int getMaxUndo();
  
  public abstract void setMaxUndo(int paramInt);
  
  public abstract TransAction previousUndo();
  
  public abstract TransAction viewThisUndo();
  
  public abstract TransAction viewPreviousUndo();
  
  public abstract TransAction nextUndo();
  
  public abstract TransAction viewNextUndo();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\UndoInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */