/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PluginPropertyFactory
/*     */ {
/*     */   private final KeyValueSet properties;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PluginPropertyFactory(KeyValueSet properties)
/*     */     throws IllegalArgumentException
/*     */   {
/*  43 */     Assert.assertNotNull(properties, "Properties cannot be null");
/*  44 */     this.properties = properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public KeyValueSet getProperties()
/*     */   {
/*  51 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringPluginProperty createString(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  62 */     StringPluginProperty property = new StringPluginProperty(key);
/*  63 */     this.properties.add(new KeyValue[] { property });
/*  64 */     return property;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IntegerPluginProperty createInteger(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  75 */     IntegerPluginProperty property = new IntegerPluginProperty(key);
/*  76 */     this.properties.add(new KeyValue[] { property });
/*  77 */     return property;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BooleanPluginProperty createBoolean(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  88 */     BooleanPluginProperty property = new BooleanPluginProperty(key);
/*  89 */     this.properties.add(new KeyValue[] { property });
/*  90 */     return property;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StringListPluginProperty createStringList(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/* 101 */     StringListPluginProperty property = new StringListPluginProperty(key);
/* 102 */     this.properties.add(new KeyValue[] { property });
/* 103 */     return property;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\PluginPropertyFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */