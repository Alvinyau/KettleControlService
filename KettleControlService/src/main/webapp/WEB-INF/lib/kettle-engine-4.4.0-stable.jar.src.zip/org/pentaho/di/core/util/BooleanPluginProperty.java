/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.prefs.Preferences;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanPluginProperty
/*     */   extends KeyValue<Boolean>
/*     */   implements PluginProperty
/*     */ {
/*     */   private static final long serialVersionUID = -2990345692552430357L;
/*     */   
/*     */   public BooleanPluginProperty(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/*  53 */     super(key, DEFAULT_BOOLEAN_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate()
/*     */   {
/*  62 */     return Boolean.TRUE.equals(getValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendXml(StringBuilder builder)
/*     */   {
/*  71 */     builder.append(XMLHandler.addTagValue(getKey(), ((Boolean)getValue()).booleanValue()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadXml(Node node)
/*     */   {
/*  80 */     String stringValue = XMLHandler.getTagValue(node, getKey());
/*  81 */     setValue(Boolean.valueOf("Y".equalsIgnoreCase(stringValue)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromRepositoryStep(Repository repository, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/*  91 */     boolean value = repository.getStepAttributeBoolean(stepId, getKey());
/*  92 */     setValue(Boolean.valueOf(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToPreferences(Preferences node)
/*     */   {
/* 101 */     node.putBoolean(getKey(), ((Boolean)getValue()).booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromPreferences(Preferences node)
/*     */   {
/* 110 */     setValue(Boolean.valueOf(node.getBoolean(getKey(), ((Boolean)getValue()).booleanValue())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveToRepositoryStep(Repository repository, ObjectId transformationId, ObjectId stepId)
/*     */     throws KettleException
/*     */   {
/* 121 */     repository.saveStepAttribute(transformationId, stepId, getKey(), ((Boolean)getValue()).booleanValue());
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\BooleanPluginProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */