/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.repository.RepositoryDirectoryInterface;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelLogTable
/*     */   extends BaseLogTable
/*     */   implements Cloneable, LogTableInterface
/*     */ {
/*  48 */   private static Class<?> PKG = ChannelLogTable.class;
/*     */   
/*     */   public static final String XML_TAG = "channel-log-table";
/*     */   
/*     */   public static enum ID
/*     */   {
/*  54 */     ID_BATCH("ID_BATCH"), 
/*  55 */     CHANNEL_ID("CHANNEL_ID"), 
/*  56 */     LOG_DATE("LOG_DATE"), 
/*  57 */     LOGGING_OBJECT_TYPE("LOGGING_OBJECT_TYPE"), 
/*  58 */     OBJECT_NAME("OBJECT_NAME"), 
/*  59 */     OBJECT_COPY("OBJECT_COPY"), 
/*  60 */     REPOSITORY_DIRECTORY("REPOSITORY_DIRECTORY"), 
/*  61 */     FILENAME("FILENAME"), 
/*  62 */     OBJECT_ID("OBJECT_ID"), 
/*  63 */     OBJECT_REVISION("OBJECT_REVISION"), 
/*  64 */     PARENT_CHANNEL_ID("PARENT_CHANNEL_ID"), 
/*  65 */     ROOT_CHANNEL_ID("ROOT_CHANNEL_ID");
/*     */     
/*     */     private String id;
/*     */     
/*     */     private ID(String id) {
/*  70 */       this.id = id;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  74 */       return this.id;
/*     */     }
/*     */   }
/*     */   
/*     */   private ChannelLogTable(VariableSpace space, HasDatabasesInterface databasesInterface) {
/*  79 */     super(space, databasesInterface, null, null, null);
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/*  85 */       ChannelLogTable table = (ChannelLogTable)super.clone();
/*  86 */       table.fields = new ArrayList();
/*  87 */       for (LogTableField field : this.fields) {
/*  88 */         table.fields.add((LogTableField)field.clone());
/*     */       }
/*  90 */       return table;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  98 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 100 */     retval.append(XMLHandler.openTag("channel-log-table"));
/* 101 */     retval.append(XMLHandler.addTagValue("connection", this.connectionName));
/* 102 */     retval.append(XMLHandler.addTagValue("schema", this.schemaName));
/* 103 */     retval.append(XMLHandler.addTagValue("table", this.tableName));
/* 104 */     retval.append(XMLHandler.addTagValue("timeout_days", this.timeoutInDays));
/* 105 */     retval.append(super.getFieldsXML());
/* 106 */     retval.append(XMLHandler.closeTag("channel-log-table")).append(Const.CR);
/*     */     
/* 108 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node node, List<DatabaseMeta> databases) {
/* 112 */     this.connectionName = XMLHandler.getTagValue(node, "connection");
/* 113 */     this.schemaName = XMLHandler.getTagValue(node, "schema");
/* 114 */     this.tableName = XMLHandler.getTagValue(node, "table");
/* 115 */     this.timeoutInDays = XMLHandler.getTagValue(node, "timeout_days");
/*     */     
/* 117 */     super.loadFieldsXML(node);
/*     */   }
/*     */   
/*     */   public static ChannelLogTable getDefault(VariableSpace space, HasDatabasesInterface databasesInterface) {
/* 121 */     ChannelLogTable table = new ChannelLogTable(space, databasesInterface);
/*     */     
/* 123 */     table.fields.add(new LogTableField(ID.ID_BATCH.id, true, false, "ID_BATCH", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.IdBatch", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.IdBatch", new String[0]), 5, 8));
/* 124 */     table.fields.add(new LogTableField(ID.CHANNEL_ID.id, true, false, "CHANNEL_ID", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ChannelId", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ChannelId", new String[0]), 2, 255));
/* 125 */     table.fields.add(new LogTableField(ID.LOG_DATE.id, true, false, "LOG_DATE", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.LogDate", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.LogDate", new String[0]), 3, -1));
/* 126 */     table.fields.add(new LogTableField(ID.LOGGING_OBJECT_TYPE.id, true, false, "LOGGING_OBJECT_TYPE", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ObjectType", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ObjectType", new String[0]), 2, 255));
/* 127 */     table.fields.add(new LogTableField(ID.OBJECT_NAME.id, true, false, "OBJECT_NAME", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ObjectName", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ObjectName", new String[0]), 2, 255));
/* 128 */     table.fields.add(new LogTableField(ID.OBJECT_COPY.id, true, false, "OBJECT_COPY", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ObjectCopy", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ObjectCopy", new String[0]), 2, 255));
/* 129 */     table.fields.add(new LogTableField(ID.REPOSITORY_DIRECTORY.id, true, false, "REPOSITORY_DIRECTORY", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.RepositoryDirectory", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.RepositoryDirectory", new String[0]), 2, 255));
/* 130 */     table.fields.add(new LogTableField(ID.FILENAME.id, true, false, "FILENAME", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.Filename", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.Filename", new String[0]), 2, 255));
/* 131 */     table.fields.add(new LogTableField(ID.OBJECT_ID.id, true, false, "OBJECT_ID", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ObjectId", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ObjectId", new String[0]), 2, 255));
/* 132 */     table.fields.add(new LogTableField(ID.OBJECT_REVISION.id, true, false, "OBJECT_REVISION", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ObjectRevision", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ObjectRevision", new String[0]), 2, 255));
/* 133 */     table.fields.add(new LogTableField(ID.PARENT_CHANNEL_ID.id, true, false, "PARENT_CHANNEL_ID", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.ParentChannelId", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.ParentChannelId", new String[0]), 2, 255));
/* 134 */     table.fields.add(new LogTableField(ID.ROOT_CHANNEL_ID.id, true, false, "ROOT_CHANNEL_ID", BaseMessages.getString(PKG, "ChannelLogTable.FieldName.RootChannelId", new String[0]), BaseMessages.getString(PKG, "ChannelLogTable.FieldDescription.RootChannelId", new String[0]), 2, 255));
/*     */     
/* 136 */     table.findField(ID.LOG_DATE.id).setLogDateField(true);
/* 137 */     table.findField(ID.ID_BATCH.id).setKey(true);
/*     */     
/* 139 */     return table;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowMetaAndData getLogRecord(LogStatus status, Object subject, Object parent)
/*     */   {
/* 148 */     if ((subject == null) || ((subject instanceof LoggingHierarchy)))
/*     */     {
/* 150 */       LoggingHierarchy loggingHierarchy = (LoggingHierarchy)subject;
/* 151 */       LoggingObjectInterface loggingObject = null;
/* 152 */       if (subject != null) { loggingObject = loggingHierarchy.getLoggingObject();
/*     */       }
/* 154 */       RowMetaAndData row = new RowMetaAndData();
/*     */       
/* 156 */       for (LogTableField field : this.fields) {
/* 157 */         if (field.isEnabled()) {
/* 158 */           Object value = null;
/* 159 */           if (subject != null) {
/* 160 */             switch (ID.valueOf(field.getId())) {
/*     */             case ID_BATCH: 
/* 162 */               value = new Long(loggingHierarchy.getBatchId()); break;
/* 163 */             case CHANNEL_ID:  value = loggingObject.getLogChannelId(); break;
/* 164 */             case LOG_DATE:  value = new Date(); break;
/* 165 */             case LOGGING_OBJECT_TYPE:  value = loggingObject.getObjectType().toString(); break;
/* 166 */             case OBJECT_NAME:  value = loggingObject.getObjectName(); break;
/* 167 */             case OBJECT_COPY:  value = loggingObject.getObjectCopy(); break;
/* 168 */             case REPOSITORY_DIRECTORY:  value = loggingObject.getRepositoryDirectory() == null ? null : loggingObject.getRepositoryDirectory().getPath(); break;
/* 169 */             case FILENAME:  value = loggingObject.getFilename(); break;
/* 170 */             case OBJECT_ID:  value = loggingObject.getObjectId() == null ? null : loggingObject.getObjectId().toString(); break;
/* 171 */             case OBJECT_REVISION:  value = loggingObject.getObjectRevision() == null ? null : loggingObject.getObjectRevision().toString(); break;
/* 172 */             case PARENT_CHANNEL_ID:  value = loggingObject.getParent() == null ? null : loggingObject.getParent().getLogChannelId(); break;
/* 173 */             case ROOT_CHANNEL_ID:  value = loggingHierarchy.getRootChannelId();
/*     */             }
/*     */             
/*     */           }
/*     */           
/* 178 */           row.addValue(field.getFieldName(), field.getDataType(), value);
/* 179 */           row.getRowMeta().getValueMeta(row.size() - 1).setLength(field.getLength());
/*     */         }
/*     */       }
/*     */       
/* 183 */       return row;
/*     */     }
/*     */     
/* 186 */     return null;
/*     */   }
/*     */   
/*     */   public String getLogTableCode()
/*     */   {
/* 191 */     return "CHANNEL";
/*     */   }
/*     */   
/*     */   public String getLogTableType() {
/* 195 */     return BaseMessages.getString(PKG, "ChannelLogTable.Type.Description", new String[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionNameVariable() {
/* 199 */     return "KETTLE_CHANNEL_LOG_DB";
/*     */   }
/*     */   
/*     */   public String getSchemaNameVariable() {
/* 203 */     return "KETTLE_CHANNEL_LOG_SCHEMA";
/*     */   }
/*     */   
/*     */   public String getTableNameVariable() {
/* 207 */     return "KETTLE_CHANNEL_LOG_TABLE";
/*     */   }
/*     */   
/*     */   public List<RowMetaInterface> getRecommendedIndexes() {
/* 211 */     List<RowMetaInterface> indexes = new ArrayList();
/* 212 */     return indexes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\ChannelLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */