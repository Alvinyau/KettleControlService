/*     */ package org.pentaho.di.imp.rule;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportValidationFeedback
/*     */ {
/*     */   private ImportRuleInterface importRule;
/*     */   private ImportValidationResultType resultType;
/*     */   private String comment;
/*     */   
/*     */   public ImportValidationFeedback(ImportRuleInterface importRule, ImportValidationResultType resultType, String comment)
/*     */   {
/*  38 */     this.importRule = importRule;
/*  39 */     this.resultType = resultType;
/*  40 */     this.comment = comment;
/*     */   }
/*     */   
/*     */   public static List<ImportValidationFeedback> getErrors(List<ImportValidationFeedback> feedback) {
/*  44 */     List<ImportValidationFeedback> errors = new ArrayList();
/*     */     
/*  46 */     for (ImportValidationFeedback error : feedback) {
/*  47 */       if (error.isError()) {
/*  48 */         errors.add(error);
/*     */       }
/*     */     }
/*     */     
/*  52 */     return errors;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  57 */     StringBuilder string = new StringBuilder();
/*     */     
/*  59 */     string.append(this.resultType.name()).append(" : ");
/*  60 */     string.append(this.comment).append(" - ");
/*  61 */     string.append(this.importRule.toString());
/*     */     
/*  63 */     return string.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ImportValidationResultType getResultType()
/*     */   {
/*  70 */     return this.resultType;
/*     */   }
/*     */   
/*     */   public boolean isError() {
/*  74 */     return this.resultType == ImportValidationResultType.ERROR;
/*     */   }
/*     */   
/*     */   public boolean isApproval() {
/*  78 */     return this.resultType == ImportValidationResultType.APPROVAL;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResultType(ImportValidationResultType resultType)
/*     */   {
/*  86 */     this.resultType = resultType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getComment()
/*     */   {
/*  93 */     return this.comment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComment(String comment)
/*     */   {
/* 101 */     this.comment = comment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ImportRuleInterface getImportRule()
/*     */   {
/* 108 */     return this.importRule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setImportRule(ImportRuleInterface importRule)
/*     */   {
/* 115 */     this.importRule = importRule;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rule\ImportValidationFeedback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */