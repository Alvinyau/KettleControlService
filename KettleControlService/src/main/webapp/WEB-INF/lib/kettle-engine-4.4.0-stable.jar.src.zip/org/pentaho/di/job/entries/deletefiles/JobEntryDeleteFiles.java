/*     */ package org.pentaho.di.job.entries.deletefiles;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileSelector;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDeleteFiles
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  72 */   private static Class<?> PKG = JobEntryDeleteFiles.class;
/*     */   
/*     */   public boolean argFromPrevious;
/*     */   
/*     */   public boolean includeSubfolders;
/*     */   
/*     */   public String[] arguments;
/*     */   public String[] filemasks;
/*     */   
/*     */   public JobEntryDeleteFiles(String n)
/*     */   {
/*  83 */     super(n, "");
/*  84 */     this.argFromPrevious = false;
/*  85 */     this.arguments = null;
/*     */     
/*  87 */     this.includeSubfolders = false;
/*  88 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryDeleteFiles() {
/*  92 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  96 */     JobEntryDeleteFiles je = (JobEntryDeleteFiles)super.clone();
/*  97 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML() {
/* 101 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 103 */     retval.append(super.getXML());
/* 104 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.argFromPrevious));
/* 105 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.includeSubfolders));
/*     */     
/* 107 */     retval.append("      <fields>").append(Const.CR);
/* 108 */     if (this.arguments != null) {
/* 109 */       for (int i = 0; i < this.arguments.length; i++) {
/* 110 */         retval.append("        <field>").append(Const.CR);
/* 111 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.arguments[i]));
/* 112 */         retval.append("          ").append(XMLHandler.addTagValue("filemask", this.filemasks[i]));
/* 113 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 116 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/* 118 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException {
/*     */     try {
/* 123 */       super.loadXML(entrynode, databases, slaveServers);
/* 124 */       this.argFromPrevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/* 125 */       this.includeSubfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/*     */       
/* 127 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 130 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 131 */       this.arguments = new String[nrFields];
/* 132 */       this.filemasks = new String[nrFields];
/*     */       
/*     */ 
/* 135 */       for (int i = 0; i < nrFields; i++) {
/* 136 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 138 */         this.arguments[i] = XMLHandler.getTagValue(fnode, "name");
/* 139 */         this.filemasks[i] = XMLHandler.getTagValue(fnode, "filemask");
/*     */       }
/*     */     } catch (KettleXMLException xe) {
/* 142 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDeleteFiles.UnableToLoadFromXml", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException {
/*     */     try {
/* 148 */       this.argFromPrevious = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/* 149 */       this.includeSubfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*     */       
/*     */ 
/* 152 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "name");
/* 153 */       this.arguments = new String[argnr];
/* 154 */       this.filemasks = new String[argnr];
/*     */       
/*     */ 
/* 157 */       for (int a = 0; a < argnr; a++) {
/* 158 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "name");
/* 159 */         this.filemasks[a] = rep.getJobEntryAttributeString(id_jobentry, a, "filemask");
/*     */       }
/*     */     } catch (KettleException dbe) {
/* 162 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDeleteFiles.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException {
/*     */     try {
/* 168 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.argFromPrevious);
/* 169 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.includeSubfolders);
/*     */       
/*     */ 
/* 172 */       if (this.arguments != null) {
/* 173 */         for (int i = 0; i < this.arguments.length; i++) {
/* 174 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "name", this.arguments[i]);
/* 175 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "filemask", this.filemasks[i]);
/*     */         }
/*     */       }
/*     */     } catch (KettleDatabaseException dbe) {
/* 179 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDeleteFiles.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public Result execute(Result result, int nr) throws KettleException
/*     */   {
/* 185 */     List<RowMetaAndData> rows = result.getRows();
/* 186 */     RowMetaAndData resultRow = null;
/*     */     
/* 188 */     int NrErrFiles = 0;
/*     */     
/* 190 */     result.setResult(false);
/* 191 */     result.setNrErrors(1L);
/*     */     
/*     */ 
/* 194 */     if ((this.argFromPrevious) && 
/* 195 */       (this.log.isDetailed())) {
/* 196 */       logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFiles.FoundPreviousRows", new String[] { String.valueOf(rows != null ? rows.size() : 0) }));
/*     */     }
/*     */     
/* 199 */     if ((this.argFromPrevious) && (rows != null))
/*     */     {
/* 201 */       for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++) {
/* 202 */         resultRow = (RowMetaAndData)rows.get(iteration);
/*     */         
/* 204 */         String args_previous = resultRow.getString(0, null);
/* 205 */         String fmasks_previous = resultRow.getString(1, null);
/*     */         
/*     */ 
/* 208 */         if (this.log.isDetailed()) {
/* 209 */           logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFiles.ProcessingRow", new String[] { args_previous, fmasks_previous }));
/*     */         }
/* 211 */         if (!ProcessFile(args_previous, fmasks_previous, this.parentJob)) {
/* 212 */           NrErrFiles++;
/*     */         }
/*     */       }
/* 215 */     } else if (this.arguments != null)
/*     */     {
/* 217 */       for (int i = 0; (i < this.arguments.length) && (!this.parentJob.isStopped()); i++)
/*     */       {
/*     */ 
/* 220 */         if (this.log.isDetailed())
/* 221 */           logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFiles.ProcessingArg", new String[] { this.arguments[i], this.filemasks[i] }));
/* 222 */         if (!ProcessFile(this.arguments[i], this.filemasks[i], this.parentJob)) {
/* 223 */           NrErrFiles++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 229 */     if (NrErrFiles == 0)
/*     */     {
/* 231 */       result.setResult(true);
/* 232 */       result.setNrErrors(0L);
/*     */     }
/*     */     else {
/* 235 */       result.setNrErrors(NrErrFiles);
/* 236 */       result.setResult(false);
/*     */     }
/*     */     
/*     */ 
/* 240 */     return result;
/*     */   }
/*     */   
/*     */   private boolean ProcessFile(String filename, String wildcard, Job parentJob) {
/* 244 */     boolean rcode = false;
/* 245 */     FileObject filefolder = null;
/* 246 */     String realFilefoldername = environmentSubstitute(filename);
/* 247 */     String realwildcard = environmentSubstitute(wildcard);
/*     */     try
/*     */     {
/* 250 */       filefolder = KettleVFS.getFileObject(realFilefoldername, this);
/*     */       
/* 252 */       if (filefolder.exists())
/*     */       {
/* 254 */         if (filefolder.getType() == FileType.FOLDER)
/*     */         {
/*     */ 
/* 257 */           if (this.log.isDetailed()) {
/* 258 */             logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFiles.ProcessingFolder", new String[] { realFilefoldername }));
/*     */           }
/*     */           
/* 261 */           int Nr = filefolder.delete(new TextFileSelector(filefolder.toString(), realwildcard, parentJob));
/*     */           
/* 263 */           if (this.log.isDetailed())
/* 264 */             logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFiles.TotalDeleted", new String[] { String.valueOf(Nr) }));
/* 265 */           rcode = true;
/*     */         }
/*     */         else {
/* 268 */           if (this.log.isDetailed())
/* 269 */             logDetailed(BaseMessages.getString(PKG, "JobEntryDeleteFiles.ProcessingFile", new String[] { realFilefoldername }));
/* 270 */           boolean deleted = filefolder.delete();
/* 271 */           if (!deleted) {
/* 272 */             logError(BaseMessages.getString(PKG, "JobEntryDeleteFiles.CouldNotDeleteFile", new String[] { realFilefoldername }));
/*     */           } else {
/* 274 */             if (this.log.isBasic()) logBasic(BaseMessages.getString(PKG, "JobEntryDeleteFiles.FileDeleted", new String[] { filename }));
/* 275 */             rcode = true;
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 280 */         if (this.log.isBasic()) logBasic(BaseMessages.getString(PKG, "JobEntryDeleteFiles.FileAlreadyDeleted", new String[] { realFilefoldername }));
/* 281 */         rcode = true;
/*     */       }
/*     */     } catch (Exception e) {
/* 284 */       logError(BaseMessages.getString(PKG, "JobEntryDeleteFiles.CouldNotProcess", new String[] { realFilefoldername, e.getMessage() }), e);
/*     */     } finally {
/* 286 */       if (filefolder != null) {
/*     */         try {
/* 288 */           filefolder.close();
/* 289 */           filefolder = null;
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 296 */     return rcode;
/*     */   }
/*     */   
/*     */   private class TextFileSelector implements FileSelector
/*     */   {
/*     */     Job parentjob;
/* 302 */     String source_folder = null; String file_wildcard = null;
/*     */     
/*     */ 
/*     */ 
/*     */     public TextFileSelector(String sourcefolderin, String filewildcard, Job parentJob)
/*     */     {
/* 308 */       if (!Const.isEmpty(sourcefolderin))
/*     */       {
/* 310 */         this.source_folder = sourcefolderin;
/*     */       }
/*     */       
/* 313 */       if (!Const.isEmpty(filewildcard))
/*     */       {
/* 315 */         this.file_wildcard = filewildcard;
/*     */       }
/* 317 */       this.parentjob = parentJob;
/*     */     }
/*     */     
/*     */     public boolean includeFile(FileSelectInfo info)
/*     */     {
/* 322 */       boolean returncode = false;
/* 323 */       FileObject file_name = null;
/*     */       
/*     */       try
/*     */       {
/* 327 */         if ((!info.getFile().toString().equals(this.source_folder)) && (!this.parentjob.isStopped()))
/*     */         {
/*     */ 
/*     */ 
/* 331 */           String short_filename = info.getFile().getName().getBaseName();
/*     */           
/* 333 */           if (!info.getFile().getParent().equals(info.getBaseFolder()))
/*     */           {
/*     */ 
/*     */ 
/* 337 */             if ((JobEntryDeleteFiles.this.includeSubfolders) && (info.getFile().getType() == FileType.FILE) && (JobEntryDeleteFiles.this.GetFileWildcard(short_filename, this.file_wildcard)))
/*     */             {
/* 339 */               if (JobEntryDeleteFiles.this.log.isDetailed()) {
/* 340 */                 JobEntryDeleteFiles.this.logDetailed(BaseMessages.getString(JobEntryDeleteFiles.PKG, "JobEntryDeleteFiles.DeletingFile", new String[] { info.getFile().toString() }));
/*     */               }
/* 342 */               returncode = true;
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */           }
/* 350 */           else if ((info.getFile().getType() == FileType.FILE) && (JobEntryDeleteFiles.this.GetFileWildcard(short_filename, this.file_wildcard)))
/*     */           {
/* 352 */             if (JobEntryDeleteFiles.this.log.isDetailed()) {
/* 353 */               JobEntryDeleteFiles.this.logDetailed(BaseMessages.getString(JobEntryDeleteFiles.PKG, "JobEntryDeleteFiles.DeletingFile", new String[] { info.getFile().toString() }));
/*     */             }
/* 355 */             returncode = true;
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/* 368 */         JobEntryDeleteFiles.this.log.logError(BaseMessages.getString(JobEntryDeleteFiles.PKG, "JobDeleteFiles.Error.Exception.DeleteProcessError", new String[0]), new Object[] { BaseMessages.getString(JobEntryDeleteFiles.PKG, "JobDeleteFiles.Error.Exception.DeleteProcess", new String[] { info.getFile().toString(), e.getMessage() }) });
/*     */         
/*     */ 
/* 371 */         returncode = false;
/*     */       }
/*     */       finally
/*     */       {
/* 375 */         if (file_name != null)
/*     */         {
/*     */           try
/*     */           {
/* 379 */             file_name.close();
/* 380 */             file_name = null;
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 390 */       return returncode;
/*     */     }
/*     */     
/*     */     public boolean traverseDescendents(FileSelectInfo info)
/*     */     {
/* 395 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*     */   {
/* 407 */     Pattern pattern = null;
/* 408 */     boolean getIt = true;
/*     */     
/* 410 */     if (!Const.isEmpty(wildcard))
/*     */     {
/* 412 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 414 */       if (pattern != null)
/*     */       {
/* 416 */         Matcher matcher = pattern.matcher(selectedfile);
/* 417 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 421 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIncludeSubfolders(boolean includeSubfolders)
/*     */   {
/* 427 */     this.includeSubfolders = includeSubfolders;
/*     */   }
/*     */   
/* 430 */   public void setPrevious(boolean argFromPrevious) { this.argFromPrevious = argFromPrevious; }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 436 */     return true;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {
/* 440 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */     
/* 442 */     if (!res) {
/* 443 */       return;
/*     */     }
/*     */     
/* 446 */     ValidatorContext ctx = new ValidatorContext();
/* 447 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 448 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*     */     
/* 450 */     for (int i = 0; i < this.arguments.length; i++) {
/* 451 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 456 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 457 */     if (this.arguments != null) {
/* 458 */       ResourceReference reference = null;
/* 459 */       for (int i = 0; i < this.arguments.length; i++) {
/* 460 */         String filename = jobMeta.environmentSubstitute(this.arguments[i]);
/* 461 */         if (reference == null) {
/* 462 */           reference = new ResourceReference(this);
/* 463 */           references.add(reference);
/*     */         }
/* 465 */         reference.getEntries().add(new ResourceEntry(filename, ResourceEntry.ResourceType.FILE));
/*     */       }
/*     */     }
/* 468 */     return references;
/*     */   }
/*     */   
/*     */   public boolean isArgFromPrevious()
/*     */   {
/* 473 */     return this.argFromPrevious;
/*     */   }
/*     */   
/*     */   public String[] getArguments()
/*     */   {
/* 478 */     return this.arguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getFilemasks()
/*     */   {
/* 485 */     return this.filemasks;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubfolders()
/*     */   {
/* 490 */     return this.includeSubfolders;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\deletefiles\JobEntryDeleteFiles.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */