/*     */ package org.pentaho.di.imp;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.KettleEnvironment;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.logging.LogChannel;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.logging.LogWriter;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.plugins.RepositoryPluginType;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.pan.CommandLineOption;
/*     */ import org.pentaho.di.repository.RepositoriesMeta;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.repository.RepositoryDirectoryInterface;
/*     */ import org.pentaho.di.repository.RepositoryImportFeedbackInterface;
/*     */ import org.pentaho.di.repository.RepositoryImporter;
/*     */ import org.pentaho.di.repository.RepositoryMeta;
/*     */ import org.pentaho.di.trans.TransMeta;
/*     */ import org.pentaho.di.version.BuildVersion;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Import
/*     */ {
/*  57 */   private static Class<?> PKG = Import.class;
/*     */   public static final String STRING_IMPORT = "Import";
/*     */   
/*     */   public static void main(String[] a) throws KettleException
/*     */   {
/*  62 */     KettleEnvironment.init();
/*     */     
/*  64 */     List<String> args = new ArrayList();
/*  65 */     for (int i = 0; i < a.length; i++)
/*  66 */       if (a[i].length() > 0)
/*  67 */         args.add(a[i]);
/*     */     StringBuffer optionRepname;
/*     */     StringBuffer optionUsername;
/*     */     StringBuffer optionPassword;
/*     */     StringBuffer optionDirname;
/*     */     StringBuffer optionLimitDir;
/*  73 */     StringBuffer optionFilename; StringBuffer optionFileDir; StringBuffer optionRules; StringBuffer optionNoRules; StringBuffer optionComment; StringBuffer optionReplace; StringBuffer optionContinueOnError; StringBuffer optionVersion; CommandLineOption[] options = { new CommandLineOption("rep", BaseMessages.getString(PKG, "Import.CmdLine.RepName", new String[0]), optionRepname = new StringBuffer()), new CommandLineOption("user", BaseMessages.getString(PKG, "Import.CmdLine.RepUsername", new String[0]), optionUsername = new StringBuffer()), new CommandLineOption("pass", BaseMessages.getString(PKG, "Import.CmdLine.RepPassword", new String[0]), optionPassword = new StringBuffer()), new CommandLineOption("dir", BaseMessages.getString(PKG, "Import.CmdLine.RepDir", new String[0]), optionDirname = new StringBuffer()), new CommandLineOption("limitdir", BaseMessages.getString(PKG, "Import.CmdLine.LimitDir", new String[0]), optionLimitDir = new StringBuffer()), new CommandLineOption("file", BaseMessages.getString(PKG, "Import.CmdLine.File", new String[0]), optionFilename = new StringBuffer()), new CommandLineOption("filedir", BaseMessages.getString(PKG, "Import.CmdLine.FileDir", new String[0]), optionFileDir = new StringBuffer()), new CommandLineOption("rules", BaseMessages.getString(PKG, "Import.CmdLine.RulesFile", new String[0]), optionRules = new StringBuffer()), new CommandLineOption("norules", BaseMessages.getString(PKG, "Import.CmdLine.NoRules", new String[0]), optionNoRules = new StringBuffer(), true, false), new CommandLineOption("comment", BaseMessages.getString(PKG, "Import.CmdLine.Comment", new String[0]), optionComment = new StringBuffer(), true, false), new CommandLineOption("replace", BaseMessages.getString(PKG, "Import.CmdLine.Replace", new String[0]), optionReplace = new StringBuffer(), true, false), new CommandLineOption("coe", BaseMessages.getString(PKG, "Import.CmdLine.ContinueOnError", new String[0]), optionContinueOnError = new StringBuffer(), true, false), new CommandLineOption("version", BaseMessages.getString(PKG, "Import.CmdLine.Version", new String[0]), optionVersion = new StringBuffer(), true, false), new CommandLineOption("", BaseMessages.getString(PKG, "Import.CmdLine.ExtraFiles", new String[0]), new StringBuffer(), false, true, true) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     if (args.size() == 0) {
/*  94 */       CommandLineOption.printUsage(options);
/*  95 */       exitJVM(9);
/*     */     }
/*     */     
/*  98 */     final LogChannelInterface log = new LogChannel("Import");
/*     */     
/* 100 */     CommandLineOption.parseArguments(args, options, log);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */     List<String> filenames = new ArrayList(args);
/* 107 */     if (!Const.isEmpty(optionFilename)) {
/* 108 */       filenames.add(optionFilename.toString());
/*     */     }
/*     */     
/* 111 */     String kettleRepname = Const.getEnvironmentVariable("KETTLE_REPOSITORY", null);
/* 112 */     String kettleUsername = Const.getEnvironmentVariable("KETTLE_USER", null);
/* 113 */     String kettlePassword = Const.getEnvironmentVariable("KETTLE_PASSWORD", null);
/*     */     
/* 115 */     if (!Const.isEmpty(kettleRepname))
/* 116 */       optionRepname = new StringBuffer(kettleRepname);
/* 117 */     if (!Const.isEmpty(kettleUsername))
/* 118 */       optionUsername = new StringBuffer(kettleUsername);
/* 119 */     if (!Const.isEmpty(kettlePassword)) {
/* 120 */       optionPassword = new StringBuffer(kettlePassword);
/*     */     }
/* 122 */     if (!Const.isEmpty(optionVersion)) {
/* 123 */       BuildVersion buildVersion = BuildVersion.getInstance();
/* 124 */       log.logBasic(BaseMessages.getString(PKG, "Import.Log.KettleVersion", new String[] { buildVersion.getVersion(), buildVersion.getRevision(), buildVersion.getBuildDate() }));
/* 125 */       if (a.length == 1) {
/* 126 */         exitJVM(6);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 131 */     if (Const.isEmpty(optionRepname)) {
/* 132 */       log.logError(BaseMessages.getString(PKG, "Import.Error.NoRepProvided", new String[0]));
/* 133 */       exitJVM(1);
/*     */     }
/*     */     
/* 136 */     if (Const.isEmpty(filenames)) {
/* 137 */       log.logError(BaseMessages.getString(PKG, "Import.Error.NoExportFileProvided", new String[0]));
/* 138 */       exitJVM(1);
/*     */     }
/*     */     
/* 141 */     if (Const.isEmpty(optionDirname)) {
/* 142 */       log.logError(BaseMessages.getString(PKG, "Import.Error.NoRepositoryDirectoryProvided", new String[0]));
/* 143 */       exitJVM(1);
/*     */     }
/*     */     
/* 146 */     if ((Const.isEmpty(optionRules)) && (Const.isEmpty(optionNoRules)) && (!"Y".equalsIgnoreCase(optionNoRules.toString()))) {
/* 147 */       log.logError(BaseMessages.getString(PKG, "Import.Error.NoRulesFileProvided", new String[0]));
/* 148 */       exitJVM(1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     ImportRules importRules = new ImportRules();
/* 155 */     String rulesFile = optionRules.toString();
/*     */     
/* 157 */     if (!Const.isEmpty(rulesFile)) {
/*     */       try {
/* 159 */         Document document = XMLHandler.loadXMLFile(rulesFile);
/* 160 */         Node rulesNode = XMLHandler.getSubNode(document, "rules");
/* 161 */         importRules.loadXML(rulesNode);
/* 162 */         log.logMinimal(BaseMessages.getString(PKG, "Import.Log.RulesLoaded", new String[] { rulesFile, "" + importRules.getRules().size() }));
/* 163 */         for (ImportRuleInterface rule : importRules.getRules()) {
/* 164 */           log.logBasic(" - " + rule.toString());
/*     */         }
/*     */       } catch (KettleException e) {
/* 167 */         log.logError(BaseMessages.getString(PKG, "Import.Log.ExceptionLoadingRules", new String[] { rulesFile }), e);
/* 168 */         exitJVM(7);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 174 */     List<String> limitDirs = new ArrayList();
/* 175 */     if (!Const.isEmpty(optionLimitDir)) {
/* 176 */       String[] directories = optionLimitDir.toString().split(",");
/* 177 */       for (String directory : directories) {
/* 178 */         limitDirs.add(directory);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 184 */     RepositoriesMeta repsinfo = new RepositoriesMeta();
/*     */     try {
/* 186 */       repsinfo.readData();
/*     */     } catch (Exception e) {
/* 188 */       log.logError(BaseMessages.getString(PKG, "Import.Error.UnableToLoadRepositoryInformation", new String[0]), e);
/* 189 */       exitJVM(1);
/*     */     }
/*     */     
/* 192 */     RepositoryMeta repositoryMeta = repsinfo.findRepository(optionRepname.toString());
/* 193 */     if (repositoryMeta == null) {
/* 194 */       log.logError(BaseMessages.getString(PKG, "Import.Error.RepositoryCouldNotBeFound", new String[] { optionRepname.toString() }));
/* 195 */       exitJVM(1);
/*     */     }
/*     */     
/* 198 */     if (Const.isEmpty(optionRepname)) {
/* 199 */       log.logError(BaseMessages.getString(PKG, "Import.Error.NoRepProvided", new String[0]));
/* 200 */       exitJVM(1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 205 */     Repository repository = null;
/*     */     try {
/* 207 */       repository = (Repository)PluginRegistry.getInstance().loadClass(RepositoryPluginType.class, repositoryMeta, Repository.class);
/* 208 */       repository.init(repositoryMeta);
/*     */     } catch (Exception e) {
/* 210 */       log.logError(BaseMessages.getString(PKG, "Import.Error.UnableToLoadOrInitializeRepository", new String[0]));
/* 211 */       exitJVM(1);
/*     */     }
/*     */     try {
/* 214 */       repository.connect(optionUsername != null ? optionUsername.toString() : null, optionPassword != null ? optionPassword.toString() : null);
/*     */     }
/*     */     catch (KettleException ke) {
/* 217 */       log.logError(ke.getMessage());
/* 218 */       exitJVM(1);
/*     */     }
/*     */     catch (Exception e) {
/* 221 */       log.logError(BaseMessages.getString(PKG, "Import.Error.UnableToConnectToRepository", new String[0]));
/* 222 */       exitJVM(1);
/*     */     }
/*     */     
/* 225 */     boolean replace = Const.isEmpty(optionReplace) ? false : ValueMeta.convertStringToBoolean(optionReplace.toString()).booleanValue();
/* 226 */     final boolean continueOnError = Const.isEmpty(optionContinueOnError) ? false : ValueMeta.convertStringToBoolean(optionContinueOnError.toString()).booleanValue();
/*     */     
/*     */ 
/*     */ 
/* 230 */     log.logMinimal(BaseMessages.getString(PKG, "Import.Log.Starting", new String[0]));
/*     */     
/*     */ 
/*     */ 
/* 234 */     SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
/* 235 */     Calendar cal = Calendar.getInstance();
/* 236 */     Date start = cal.getTime();
/* 237 */     int returnCode = 0;
/*     */     try
/*     */     {
/* 240 */       RepositoryDirectoryInterface tree = repository.loadRepositoryDirectoryTree();
/*     */       
/* 242 */       RepositoryDirectoryInterface targetDirectory = tree.findDirectory(optionDirname.toString());
/* 243 */       if (targetDirectory == null) {
/* 244 */         log.logError(BaseMessages.getString(PKG, "Import.Error.UnableToFindTargetDirectoryInRepository", new String[] { optionDirname.toString() }));
/* 245 */         exitJVM(1);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 250 */       RepositoryImporter importer = new RepositoryImporter(repository, importRules, limitDirs);
/* 251 */       RepositoryImportFeedbackInterface feedbackInterface = new RepositoryImportFeedbackInterface()
/*     */       {
/*     */         public void updateDisplay() {}
/*     */         
/*     */ 
/*     */ 
/*     */         public boolean transOverwritePrompt(TransMeta transMeta)
/*     */         {
/* 259 */           return this.val$replace;
/*     */         }
/*     */         
/*     */         public void showError(String title, String message, Exception e)
/*     */         {
/* 264 */           log.logError(title + " : " + message, e);
/*     */         }
/*     */         
/*     */         public void setLabel(String labelText)
/*     */         {
/* 269 */           log.logBasic(labelText);
/*     */         }
/*     */         
/*     */         public boolean jobOverwritePrompt(JobMeta jobMeta)
/*     */         {
/* 274 */           return this.val$replace;
/*     */         }
/*     */         
/*     */         public boolean askContinueOnErrorQuestion(String title, String message)
/*     */         {
/* 279 */           return continueOnError;
/*     */         }
/*     */         
/*     */         public void addLog(String line)
/*     */         {
/* 284 */           log.logBasic(line);
/*     */         }
/*     */         
/*     */         public boolean isAskingOverwriteConfirmation()
/*     */         {
/* 289 */           return false;
/*     */ 
/*     */         }
/*     */         
/*     */ 
/* 294 */       };
/* 295 */       importer.importAll(feedbackInterface, optionFileDir.toString(), (String[])filenames.toArray(new String[filenames.size()]), targetDirectory, replace, continueOnError, optionComment.toString());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 301 */       List<Exception> exceptions = importer.getExceptions();
/* 302 */       if ((exceptions != null) && (!exceptions.isEmpty())) {
/* 303 */         log.logError(BaseMessages.getString(PKG, "Import.Error.UnexpectedErrorDuringImport", new String[0]), (Throwable)exceptions.get(0));
/* 304 */         returnCode = 2;
/*     */       }
/*     */     } catch (Exception e) {
/* 307 */       log.logError(BaseMessages.getString(PKG, "Import.Error.UnexpectedErrorDuringImport", new String[0]), e);
/* 308 */       exitJVM(2);
/*     */     }
/* 310 */     log.logMinimal(BaseMessages.getString(PKG, "Import.Log.Finished", new String[0]));
/*     */     
/* 312 */     cal = Calendar.getInstance();
/* 313 */     Date stop = cal.getTime();
/* 314 */     String begin = df.format(start).toString();
/* 315 */     String end = df.format(stop).toString();
/*     */     
/* 317 */     log.logMinimal(BaseMessages.getString(PKG, "Import.Log.StartStop", new String[] { begin, end }));
/*     */     
/* 319 */     long seconds = (stop.getTime() - start.getTime()) / 1000L;
/* 320 */     if (seconds <= 60L) {
/* 321 */       log.logMinimal(BaseMessages.getString(PKG, "Import.Log.ProcessEndAfter", new String[] { String.valueOf(seconds) }));
/* 322 */     } else if (seconds <= 3600L) {
/* 323 */       int min = (int)(seconds / 60L);
/* 324 */       int rem = (int)(seconds % 60L);
/* 325 */       log.logMinimal(BaseMessages.getString(PKG, "Import.Log.ProcessEndAfterLong", new String[] { String.valueOf(min), String.valueOf(rem), String.valueOf(seconds) }));
/* 326 */     } else if (seconds <= 86400L)
/*     */     {
/* 328 */       int hour = (int)(seconds / 3600L);
/* 329 */       int rem = (int)(seconds % 3600L);
/* 330 */       int min = rem / 60;
/* 331 */       rem %= 60;
/* 332 */       log.logMinimal(BaseMessages.getString(PKG, "Import.Log.ProcessEndAfterLonger", new String[] { String.valueOf(hour), String.valueOf(min), String.valueOf(rem), String.valueOf(seconds) }));
/*     */     }
/*     */     else {
/* 335 */       int days = (int)(seconds / 86400L);
/* 336 */       int rem = (int)(seconds % 86400L);
/* 337 */       int hour = rem / 3600;
/* 338 */       rem %= 3600;
/* 339 */       int min = rem / 60;
/* 340 */       rem %= 60;
/* 341 */       log.logMinimal(BaseMessages.getString(PKG, "Import.Log.ProcessEndAfterLongest", new String[] { String.valueOf(days), String.valueOf(hour), String.valueOf(min), String.valueOf(rem), String.valueOf(seconds) }));
/*     */     }
/*     */     
/* 344 */     exitJVM(returnCode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static int parseIntArgument(CommandLineOption option, int def)
/*     */     throws KettleException
/*     */   {
/* 361 */     if (!Const.isEmpty(option.getArgument())) {
/*     */       try {
/* 363 */         return Integer.parseInt(option.getArgument().toString());
/*     */       } catch (NumberFormatException ex) {
/* 365 */         throw new KettleException(BaseMessages.getString(PKG, "Import.Error.InvalidNumberArgument", new Object[] { option.getOption(), option.getArgument() }));
/*     */       }
/*     */     }
/* 368 */     return def;
/*     */   }
/*     */   
/*     */ 
/*     */   private static final void exitJVM(int status)
/*     */   {
/* 374 */     LogWriter.getInstance().close();
/*     */     
/* 376 */     System.exit(status);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\Import.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */