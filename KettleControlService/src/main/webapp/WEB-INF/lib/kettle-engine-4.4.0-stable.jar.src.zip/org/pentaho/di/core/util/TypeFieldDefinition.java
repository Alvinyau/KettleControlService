/*    */ package org.pentaho.di.core.util;
/*    */ 
/*    */ import org.pentaho.di.core.row.ValueMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeFieldDefinition
/*    */ {
/*    */   private int type;
/*    */   private String fieldName;
/*    */   
/*    */   public TypeFieldDefinition(int type, String fieldName)
/*    */   {
/* 36 */     this.type = type;
/* 37 */     this.fieldName = fieldName;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getType()
/*    */   {
/* 43 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setType(int type)
/*    */   {
/* 49 */     this.type = type;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getFieldName()
/*    */   {
/* 55 */     return this.fieldName;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setFieldName(String fieldName)
/*    */   {
/* 61 */     this.fieldName = fieldName;
/*    */   }
/*    */   
/*    */   public String getTypeDescription() {
/* 65 */     switch (this.type) {
/* 66 */     case 4:  return "boolean";
/* 67 */     case 5:  return "int"; }
/* 68 */     return ValueMeta.getTypeDesc(this.type);
/*    */   }
/*    */   
/*    */   public String getMemberName()
/*    */   {
/* 73 */     return this.fieldName.substring(0, 1).toLowerCase() + this.fieldName.substring(1);
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\TypeFieldDefinition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */