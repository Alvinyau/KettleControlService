/*    */ package org.pentaho.di.core.util;
/*    */ 
/*    */ import java.util.prefs.Preferences;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.repository.ObjectId;
/*    */ import org.pentaho.di.repository.Repository;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface PluginProperty
/*    */ {
/*    */   public static final String DEFAULT_STRING_VALUE = "";
/* 46 */   public static final Boolean DEFAULT_BOOLEAN_VALUE = Boolean.FALSE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 51 */   public static final Integer DEFAULT_INTEGER_VALUE = Integer.valueOf(0);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 56 */   public static final Double DEFAULT_DOUBLE_VALUE = Double.valueOf(0.0D);
/*    */   public static final String BOOLEAN_STRING_TRUE = "Y";
/*    */   
/*    */   public abstract boolean evaluate();
/*    */   
/*    */   public abstract void saveToPreferences(Preferences paramPreferences);
/*    */   
/*    */   public abstract void readFromPreferences(Preferences paramPreferences);
/*    */   
/*    */   public abstract void appendXml(StringBuilder paramStringBuilder);
/*    */   
/*    */   public abstract void loadXml(Node paramNode);
/*    */   
/*    */   public abstract void saveToRepositoryStep(Repository paramRepository, ObjectId paramObjectId1, ObjectId paramObjectId2)
/*    */     throws KettleException;
/*    */   
/*    */   public abstract void readFromRepositoryStep(Repository paramRepository, ObjectId paramObjectId)
/*    */     throws KettleException;
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\PluginProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */