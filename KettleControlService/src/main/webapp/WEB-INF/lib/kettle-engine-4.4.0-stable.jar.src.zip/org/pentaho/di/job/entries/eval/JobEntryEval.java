/*     */ package org.pentaho.di.job.entries.eval;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryEval
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  60 */   private static Class<?> PKG = JobEntryEval.class;
/*     */   private String script;
/*     */   
/*     */   public JobEntryEval(String n, String scr)
/*     */   {
/*  65 */     super(n, "");
/*  66 */     this.script = scr;
/*  67 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryEval() {
/*  71 */     this("", "");
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  75 */     JobEntryEval je = (JobEntryEval)super.clone();
/*  76 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML() {
/*  80 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  82 */     retval.append(super.getXML());
/*  83 */     retval.append("      ").append(XMLHandler.addTagValue("script", this.script));
/*     */     
/*  85 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException {
/*     */     try {
/*  90 */       super.loadXML(entrynode, databases, slaveServers);
/*  91 */       this.script = XMLHandler.getTagValue(entrynode, "script");
/*     */     } catch (Exception e) {
/*  93 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryEval.UnableToLoadFromXml", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException {
/*     */     try {
/*  99 */       this.script = rep.getJobEntryAttributeString(id_jobentry, "script");
/*     */     } catch (KettleDatabaseException dbe) {
/* 101 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryEval.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 110 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "script", this.script);
/*     */     } catch (KettleDatabaseException dbe) {
/* 112 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryEval.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setScript(String s)
/*     */   {
/* 118 */     this.script = s;
/*     */   }
/*     */   
/*     */   public String getScript() {
/* 122 */     return this.script;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean evaluate(Result result, org.pentaho.di.job.Job parentJob, Result prev_result)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 36	org/mozilla/javascript/ContextFactory:getGlobal	()Lorg/mozilla/javascript/ContextFactory;
/*     */     //   3: invokevirtual 37	org/mozilla/javascript/ContextFactory:enterContext	()Lorg/mozilla/javascript/Context;
/*     */     //   6: astore 4
/*     */     //   8: aload 4
/*     */     //   10: aconst_null
/*     */     //   11: invokevirtual 38	org/mozilla/javascript/Context:initStandardObjects	(Lorg/mozilla/javascript/ScriptableObject;)Lorg/mozilla/javascript/Scriptable;
/*     */     //   14: astore 5
/*     */     //   16: new 39	java/lang/Long
/*     */     //   19: dup
/*     */     //   20: aload_1
/*     */     //   21: invokevirtual 40	org/pentaho/di/core/Result:getNrErrors	()J
/*     */     //   24: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   27: astore 6
/*     */     //   29: new 39	java/lang/Long
/*     */     //   32: dup
/*     */     //   33: aload_1
/*     */     //   34: invokevirtual 42	org/pentaho/di/core/Result:getNrLinesInput	()J
/*     */     //   37: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   40: astore 7
/*     */     //   42: new 39	java/lang/Long
/*     */     //   45: dup
/*     */     //   46: aload_1
/*     */     //   47: invokevirtual 43	org/pentaho/di/core/Result:getNrLinesOutput	()J
/*     */     //   50: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   53: astore 8
/*     */     //   55: new 39	java/lang/Long
/*     */     //   58: dup
/*     */     //   59: aload_1
/*     */     //   60: invokevirtual 44	org/pentaho/di/core/Result:getNrLinesUpdated	()J
/*     */     //   63: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   66: astore 9
/*     */     //   68: new 39	java/lang/Long
/*     */     //   71: dup
/*     */     //   72: aload_1
/*     */     //   73: invokevirtual 45	org/pentaho/di/core/Result:getNrLinesRejected	()J
/*     */     //   76: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   79: astore 10
/*     */     //   81: new 39	java/lang/Long
/*     */     //   84: dup
/*     */     //   85: aload_1
/*     */     //   86: invokevirtual 46	org/pentaho/di/core/Result:getNrLinesRead	()J
/*     */     //   89: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   92: astore 11
/*     */     //   94: new 39	java/lang/Long
/*     */     //   97: dup
/*     */     //   98: aload_1
/*     */     //   99: invokevirtual 47	org/pentaho/di/core/Result:getNrLinesWritten	()J
/*     */     //   102: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   105: astore 12
/*     */     //   107: new 39	java/lang/Long
/*     */     //   110: dup
/*     */     //   111: aload_1
/*     */     //   112: invokevirtual 48	org/pentaho/di/core/Result:getExitStatus	()I
/*     */     //   115: i2l
/*     */     //   116: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   119: astore 13
/*     */     //   121: new 39	java/lang/Long
/*     */     //   124: dup
/*     */     //   125: aload_1
/*     */     //   126: invokevirtual 49	org/pentaho/di/core/Result:getNrFilesRetrieved	()J
/*     */     //   129: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   132: astore 14
/*     */     //   134: new 39	java/lang/Long
/*     */     //   137: dup
/*     */     //   138: aload_1
/*     */     //   139: invokevirtual 50	org/pentaho/di/core/Result:getEntryNr	()J
/*     */     //   142: invokespecial 41	java/lang/Long:<init>	(J)V
/*     */     //   145: astore 15
/*     */     //   147: aload 5
/*     */     //   149: ldc 51
/*     */     //   151: aload 5
/*     */     //   153: aload 6
/*     */     //   155: invokeinterface 52 4 0
/*     */     //   160: aload 5
/*     */     //   162: ldc 53
/*     */     //   164: aload 5
/*     */     //   166: aload 7
/*     */     //   168: invokeinterface 52 4 0
/*     */     //   173: aload 5
/*     */     //   175: ldc 54
/*     */     //   177: aload 5
/*     */     //   179: aload 8
/*     */     //   181: invokeinterface 52 4 0
/*     */     //   186: aload 5
/*     */     //   188: ldc 55
/*     */     //   190: aload 5
/*     */     //   192: aload 9
/*     */     //   194: invokeinterface 52 4 0
/*     */     //   199: aload 5
/*     */     //   201: ldc 56
/*     */     //   203: aload 5
/*     */     //   205: aload 10
/*     */     //   207: invokeinterface 52 4 0
/*     */     //   212: aload 5
/*     */     //   214: ldc 57
/*     */     //   216: aload 5
/*     */     //   218: aload 11
/*     */     //   220: invokeinterface 52 4 0
/*     */     //   225: aload 5
/*     */     //   227: ldc 58
/*     */     //   229: aload 5
/*     */     //   231: aload 12
/*     */     //   233: invokeinterface 52 4 0
/*     */     //   238: aload 5
/*     */     //   240: ldc 59
/*     */     //   242: aload 5
/*     */     //   244: aload 14
/*     */     //   246: invokeinterface 52 4 0
/*     */     //   251: aload 5
/*     */     //   253: ldc 60
/*     */     //   255: aload 5
/*     */     //   257: aload 13
/*     */     //   259: invokeinterface 52 4 0
/*     */     //   264: aload 5
/*     */     //   266: ldc 61
/*     */     //   268: aload 5
/*     */     //   270: aload 15
/*     */     //   272: invokeinterface 52 4 0
/*     */     //   277: aload 5
/*     */     //   279: ldc 62
/*     */     //   281: aload 5
/*     */     //   283: invokestatic 63	org/pentaho/di/core/Const:isWindows	()Z
/*     */     //   286: invokestatic 64	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
/*     */     //   289: invokeinterface 52 4 0
/*     */     //   294: aconst_null
/*     */     //   295: astore 16
/*     */     //   297: aload_1
/*     */     //   298: invokevirtual 65	org/pentaho/di/core/Result:getRows	()Ljava/util/List;
/*     */     //   301: ifnull +14 -> 315
/*     */     //   304: aload_1
/*     */     //   305: invokevirtual 65	org/pentaho/di/core/Result:getRows	()Ljava/util/List;
/*     */     //   308: invokeinterface 66 1 0
/*     */     //   313: astore 16
/*     */     //   315: aload 5
/*     */     //   317: ldc 67
/*     */     //   319: aload 5
/*     */     //   321: aload 16
/*     */     //   323: invokeinterface 52 4 0
/*     */     //   328: aload 5
/*     */     //   330: ldc 68
/*     */     //   332: aload 5
/*     */     //   334: aload_2
/*     */     //   335: invokeinterface 52 4 0
/*     */     //   340: aload 5
/*     */     //   342: ldc 69
/*     */     //   344: aload 5
/*     */     //   346: aload_3
/*     */     //   347: invokeinterface 52 4 0
/*     */     //   352: aload 4
/*     */     //   354: aload 5
/*     */     //   356: aload_0
/*     */     //   357: getfield 3	org/pentaho/di/job/entries/eval/JobEntryEval:script	Ljava/lang/String;
/*     */     //   360: ldc 70
/*     */     //   362: iconst_1
/*     */     //   363: aconst_null
/*     */     //   364: invokevirtual 71	org/mozilla/javascript/Context:evaluateString	(Lorg/mozilla/javascript/Scriptable;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   367: astore 17
/*     */     //   369: aload 17
/*     */     //   371: invokestatic 72	org/mozilla/javascript/Context:toBoolean	(Ljava/lang/Object;)Z
/*     */     //   374: istore 18
/*     */     //   376: aload_1
/*     */     //   377: lconst_0
/*     */     //   378: invokevirtual 73	org/pentaho/di/core/Result:setNrErrors	(J)V
/*     */     //   381: iload 18
/*     */     //   383: istore 19
/*     */     //   385: jsr +94 -> 479
/*     */     //   388: iload 19
/*     */     //   390: ireturn
/*     */     //   391: astore 17
/*     */     //   393: aload_1
/*     */     //   394: lconst_1
/*     */     //   395: invokevirtual 73	org/pentaho/di/core/Result:setNrErrors	(J)V
/*     */     //   398: aload_0
/*     */     //   399: getstatic 22	org/pentaho/di/job/entries/eval/JobEntryEval:PKG	Ljava/lang/Class;
/*     */     //   402: ldc 74
/*     */     //   404: iconst_1
/*     */     //   405: anewarray 24	java/lang/String
/*     */     //   408: dup
/*     */     //   409: iconst_0
/*     */     //   410: aload 17
/*     */     //   412: invokevirtual 75	java/lang/Exception:toString	()Ljava/lang/String;
/*     */     //   415: aastore
/*     */     //   416: invokestatic 25	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*     */     //   419: invokevirtual 76	org/pentaho/di/job/entries/eval/JobEntryEval:logError	(Ljava/lang/String;)V
/*     */     //   422: iconst_0
/*     */     //   423: istore 18
/*     */     //   425: jsr +54 -> 479
/*     */     //   428: iload 18
/*     */     //   430: ireturn
/*     */     //   431: astore 6
/*     */     //   433: aload_1
/*     */     //   434: lconst_1
/*     */     //   435: invokevirtual 73	org/pentaho/di/core/Result:setNrErrors	(J)V
/*     */     //   438: aload_0
/*     */     //   439: getstatic 22	org/pentaho/di/job/entries/eval/JobEntryEval:PKG	Ljava/lang/Class;
/*     */     //   442: ldc 77
/*     */     //   444: iconst_1
/*     */     //   445: anewarray 24	java/lang/String
/*     */     //   448: dup
/*     */     //   449: iconst_0
/*     */     //   450: aload 6
/*     */     //   452: invokevirtual 75	java/lang/Exception:toString	()Ljava/lang/String;
/*     */     //   455: aastore
/*     */     //   456: invokestatic 25	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*     */     //   459: invokevirtual 76	org/pentaho/di/job/entries/eval/JobEntryEval:logError	(Ljava/lang/String;)V
/*     */     //   462: iconst_0
/*     */     //   463: istore 7
/*     */     //   465: jsr +14 -> 479
/*     */     //   468: iload 7
/*     */     //   470: ireturn
/*     */     //   471: astore 20
/*     */     //   473: jsr +6 -> 479
/*     */     //   476: aload 20
/*     */     //   478: athrow
/*     */     //   479: astore 21
/*     */     //   481: invokestatic 78	org/mozilla/javascript/Context:exit	()V
/*     */     //   484: ret 21
/*     */     // Line number table:
/*     */     //   Java source line #136	-> byte code offset #0
/*     */     //   Java source line #139	-> byte code offset #8
/*     */     //   Java source line #141	-> byte code offset #16
/*     */     //   Java source line #142	-> byte code offset #29
/*     */     //   Java source line #143	-> byte code offset #42
/*     */     //   Java source line #144	-> byte code offset #55
/*     */     //   Java source line #145	-> byte code offset #68
/*     */     //   Java source line #146	-> byte code offset #81
/*     */     //   Java source line #147	-> byte code offset #94
/*     */     //   Java source line #148	-> byte code offset #107
/*     */     //   Java source line #149	-> byte code offset #121
/*     */     //   Java source line #150	-> byte code offset #134
/*     */     //   Java source line #152	-> byte code offset #147
/*     */     //   Java source line #153	-> byte code offset #160
/*     */     //   Java source line #154	-> byte code offset #173
/*     */     //   Java source line #155	-> byte code offset #186
/*     */     //   Java source line #156	-> byte code offset #199
/*     */     //   Java source line #157	-> byte code offset #212
/*     */     //   Java source line #158	-> byte code offset #225
/*     */     //   Java source line #159	-> byte code offset #238
/*     */     //   Java source line #160	-> byte code offset #251
/*     */     //   Java source line #161	-> byte code offset #264
/*     */     //   Java source line #162	-> byte code offset #277
/*     */     //   Java source line #164	-> byte code offset #294
/*     */     //   Java source line #165	-> byte code offset #297
/*     */     //   Java source line #166	-> byte code offset #304
/*     */     //   Java source line #169	-> byte code offset #315
/*     */     //   Java source line #170	-> byte code offset #328
/*     */     //   Java source line #171	-> byte code offset #340
/*     */     //   Java source line #174	-> byte code offset #352
/*     */     //   Java source line #175	-> byte code offset #369
/*     */     //   Java source line #177	-> byte code offset #376
/*     */     //   Java source line #179	-> byte code offset #381
/*     */     //   Java source line #180	-> byte code offset #391
/*     */     //   Java source line #181	-> byte code offset #393
/*     */     //   Java source line #182	-> byte code offset #398
/*     */     //   Java source line #183	-> byte code offset #422
/*     */     //   Java source line #185	-> byte code offset #431
/*     */     //   Java source line #186	-> byte code offset #433
/*     */     //   Java source line #187	-> byte code offset #438
/*     */     //   Java source line #188	-> byte code offset #462
/*     */     //   Java source line #190	-> byte code offset #471
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	486	0	this	JobEntryEval
/*     */     //   0	486	1	result	Result
/*     */     //   0	486	2	parentJob	org.pentaho.di.job.Job
/*     */     //   0	486	3	prev_result	Result
/*     */     //   6	347	4	cx	org.mozilla.javascript.Context
/*     */     //   14	341	5	scope	org.mozilla.javascript.Scriptable
/*     */     //   27	127	6	errors	Long
/*     */     //   431	20	6	e	Exception
/*     */     //   40	429	7	lines_input	Long
/*     */     //   53	127	8	lines_output	Long
/*     */     //   66	127	9	lines_updated	Long
/*     */     //   79	127	10	lines_rejected	Long
/*     */     //   92	127	11	lines_read	Long
/*     */     //   105	127	12	lines_written	Long
/*     */     //   119	139	13	exit_status	Long
/*     */     //   132	113	14	files_retrieved	Long
/*     */     //   145	126	15	nr	Long
/*     */     //   295	27	16	array	Object[]
/*     */     //   367	3	17	res	Object
/*     */     //   391	20	17	e	Exception
/*     */     //   374	55	18	retval	boolean
/*     */     //   471	6	20	localObject1	Object
/*     */     //   479	1	21	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   352	385	391	java/lang/Exception
/*     */     //   8	388	431	java/lang/Exception
/*     */     //   391	428	431	java/lang/Exception
/*     */     //   8	388	471	finally
/*     */     //   391	428	471	finally
/*     */     //   431	468	471	finally
/*     */     //   471	476	471	finally
/*     */   }
/*     */   
/*     */   public Result execute(Result prev_result, int nr)
/*     */   {
/* 201 */     prev_result.setResult(evaluate(prev_result, this.parentJob, prev_result));
/*     */     
/* 203 */     return prev_result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean resetErrorsBeforeExecution()
/*     */   {
/* 209 */     return false;
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 213 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional() {
/* 217 */     return false;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 222 */     JobEntryValidatorUtils.andValidator().validate(this, "script", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\eval\JobEntryEval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */