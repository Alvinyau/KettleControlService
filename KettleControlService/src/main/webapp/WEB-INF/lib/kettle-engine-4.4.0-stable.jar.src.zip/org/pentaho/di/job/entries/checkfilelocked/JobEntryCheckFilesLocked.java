/*     */ package org.pentaho.di.job.entries.checkfilelocked;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileSelector;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryCheckFilesLocked
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  70 */   private static Class<?> PKG = JobEntryCheckFilesLocked.class;
/*     */   
/*     */   public boolean argFromPrevious;
/*     */   
/*     */   public boolean includeSubfolders;
/*     */   
/*     */   public String[] arguments;
/*     */   
/*     */   public String[] filemasks;
/*     */   private boolean oneFileLocked;
/*     */   
/*     */   public JobEntryCheckFilesLocked(String n)
/*     */   {
/*  83 */     super(n, "");
/*  84 */     this.argFromPrevious = false;
/*  85 */     this.arguments = null;
/*     */     
/*  87 */     this.includeSubfolders = false;
/*  88 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryCheckFilesLocked()
/*     */   {
/*  93 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  97 */     JobEntryCheckFilesLocked je = (JobEntryCheckFilesLocked)super.clone();
/*  98 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML() {
/* 102 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 104 */     retval.append(super.getXML());
/* 105 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.argFromPrevious));
/* 106 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.includeSubfolders));
/*     */     
/* 108 */     retval.append("      <fields>").append(Const.CR);
/* 109 */     if (this.arguments != null) {
/* 110 */       for (int i = 0; i < this.arguments.length; i++) {
/* 111 */         retval.append("        <field>").append(Const.CR);
/* 112 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.arguments[i]));
/* 113 */         retval.append("          ").append(XMLHandler.addTagValue("filemask", this.filemasks[i]));
/* 114 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 117 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/* 119 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 126 */       super.loadXML(entrynode, databases, slaveServers);
/* 127 */       this.argFromPrevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/* 128 */       this.includeSubfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/*     */       
/* 130 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 133 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 134 */       this.arguments = new String[nrFields];
/* 135 */       this.filemasks = new String[nrFields];
/*     */       
/*     */ 
/* 138 */       for (int i = 0; i < nrFields; i++) {
/* 139 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 141 */         this.arguments[i] = XMLHandler.getTagValue(fnode, "name");
/* 142 */         this.filemasks[i] = XMLHandler.getTagValue(fnode, "filemask");
/*     */       }
/*     */     } catch (KettleXMLException xe) {
/* 145 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.UnableToLoadFromXml", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 153 */       this.argFromPrevious = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/* 154 */       this.includeSubfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*     */       
/*     */ 
/* 157 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "name");
/* 158 */       this.arguments = new String[argnr];
/* 159 */       this.filemasks = new String[argnr];
/*     */       
/*     */ 
/* 162 */       for (int a = 0; a < argnr; a++) {
/* 163 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "name");
/* 164 */         this.filemasks[a] = rep.getJobEntryAttributeString(id_jobentry, a, "filemask");
/*     */       }
/*     */     } catch (KettleException dbe) {
/* 167 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.UnableToLoadFromRepo", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try {
/* 174 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.argFromPrevious);
/* 175 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.includeSubfolders);
/*     */       
/*     */ 
/* 178 */       if (this.arguments != null) {
/* 179 */         for (int i = 0; i < this.arguments.length; i++) {
/* 180 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "name", this.arguments[i]);
/* 181 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "filemask", this.filemasks[i]);
/*     */         }
/*     */       }
/*     */     } catch (KettleDatabaseException dbe) {
/* 185 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.UnableToSaveToRepo", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 192 */     Result result = previousResult;
/* 193 */     List<RowMetaAndData> rows = result.getRows();
/* 194 */     RowMetaAndData resultRow = null;
/*     */     
/* 196 */     this.oneFileLocked = false;
/* 197 */     result.setResult(true);
/*     */     try
/*     */     {
/* 200 */       if ((this.argFromPrevious) && 
/* 201 */         (isDetailed())) {
/* 202 */         logDetailed(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.FoundPreviousRows", new String[] { String.valueOf(rows != null ? rows.size() : 0) }));
/*     */       }
/*     */       
/* 205 */       if ((this.argFromPrevious) && (rows != null))
/*     */       {
/* 207 */         for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++) {
/* 208 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*     */           
/*     */ 
/* 211 */           String filefolder_previous = resultRow.getString(0, "");
/* 212 */           String fmasks_previous = resultRow.getString(1, "");
/*     */           
/*     */ 
/* 215 */           if (isDetailed()) {
/* 216 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.ProcessingRow", new String[] { filefolder_previous, fmasks_previous }));
/*     */           }
/* 218 */           ProcessFile(filefolder_previous, fmasks_previous);
/*     */         }
/* 220 */       } else if (this.arguments != null)
/*     */       {
/* 222 */         for (int i = 0; (i < this.arguments.length) && (!this.parentJob.isStopped()); i++)
/*     */         {
/* 224 */           if (isDetailed()) {
/* 225 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.ProcessingArg", new String[] { this.arguments[i], this.filemasks[i] }));
/*     */           }
/* 227 */           ProcessFile(this.arguments[i], this.filemasks[i]);
/*     */         }
/*     */       }
/*     */       
/* 231 */       if (this.oneFileLocked) {
/* 232 */         result.setResult(false);
/* 233 */         result.setNrErrors(1L);
/*     */       }
/*     */     } catch (Exception e) {
/* 236 */       logError(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.ErrorRunningJobEntry", new Object[] { e }));
/*     */     }
/*     */     
/* 239 */     return result;
/*     */   }
/*     */   
/*     */   private void ProcessFile(String filename, String wildcard)
/*     */   {
/* 244 */     FileObject filefolder = null;
/* 245 */     String realFilefoldername = environmentSubstitute(filename);
/* 246 */     String realwilcard = environmentSubstitute(wildcard);
/*     */     try
/*     */     {
/* 249 */       filefolder = KettleVFS.getFileObject(realFilefoldername);
/* 250 */       FileObject[] files = { filefolder };
/* 251 */       if (filefolder.exists())
/*     */       {
/* 253 */         if (filefolder.getType() == FileType.FOLDER)
/*     */         {
/* 255 */           if (isDetailed()) {
/* 256 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.ProcessingFolder", new String[] { realFilefoldername }));
/*     */           }
/* 258 */           files = filefolder.findFiles(new TextFileSelector(filefolder.toString(), realwilcard));
/*     */           
/* 260 */           if (isDetailed()) {
/* 261 */             logDetailed(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.TotalFilesToCheck", new String[] { String.valueOf(files.length) }));
/*     */           }
/*     */         }
/* 264 */         else if (isDetailed()) {
/* 265 */           logDetailed(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.ProcessingFile", new String[] { realFilefoldername }));
/*     */         }
/*     */         
/* 268 */         checkFilesLocked(files);
/*     */       }
/*     */       else {
/* 271 */         logBasic(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.FileNotExist", new String[] { realFilefoldername }));
/*     */       }
/*     */     } catch (Exception e) {
/* 274 */       logError(BaseMessages.getString(PKG, "JobEntryCheckFilesLocked.CouldNotProcess", new String[] { realFilefoldername, e.getMessage() }));
/*     */     } finally {
/* 276 */       if (filefolder != null) {
/*     */         try {
/* 278 */           filefolder.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkFilesLocked(FileObject[] files) throws KettleException {
/* 286 */     for (int i = 0; (i < files.length) && (!this.oneFileLocked); i++) {
/* 287 */       FileObject file = files[i];
/* 288 */       String filename = KettleVFS.getFilename(file);
/* 289 */       LockFile locked = new LockFile(filename);
/* 290 */       if (locked.isLocked()) {
/* 291 */         this.oneFileLocked = true;
/* 292 */         logError(BaseMessages.getString(PKG, "JobCheckFilesLocked.Log.FileLocked", new String[] { filename }));
/*     */       }
/* 294 */       else if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobCheckFilesLocked.Log.FileNotLocked", new String[] { filename }));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class TextFileSelector implements FileSelector
/*     */   {
/* 301 */     String source_folder = null; String file_wildcard = null;
/*     */     
/*     */ 
/*     */     public TextFileSelector(String sourcefolderin, String filewildcard)
/*     */     {
/* 306 */       if (!Const.isEmpty(sourcefolderin))
/*     */       {
/* 308 */         this.source_folder = sourcefolderin;
/*     */       }
/*     */       
/* 311 */       if (!Const.isEmpty(filewildcard))
/*     */       {
/* 313 */         this.file_wildcard = filewildcard;
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean includeFile(FileSelectInfo info)
/*     */     {
/* 319 */       boolean returncode = false;
/* 320 */       FileObject file_name = null;
/*     */       
/*     */       try
/*     */       {
/* 324 */         if (!info.getFile().toString().equals(this.source_folder))
/*     */         {
/*     */ 
/*     */ 
/* 328 */           String short_filename = info.getFile().getName().getBaseName();
/*     */           
/* 330 */           if (!info.getFile().getParent().equals(info.getBaseFolder()))
/*     */           {
/*     */ 
/*     */ 
/* 334 */             if ((JobEntryCheckFilesLocked.this.includeSubfolders) && (info.getFile().getType() == FileType.FILE) && (JobEntryCheckFilesLocked.this.GetFileWildcard(short_filename, this.file_wildcard)))
/*     */             {
/* 336 */               if (JobEntryCheckFilesLocked.this.isDetailed()) {
/* 337 */                 JobEntryCheckFilesLocked.this.logDetailed(BaseMessages.getString(JobEntryCheckFilesLocked.PKG, "JobEntryCheckFilesLocked.CheckingFile", new String[] { info.getFile().toString() }));
/*     */               }
/* 339 */               returncode = true;
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */           }
/* 347 */           else if ((info.getFile().getType() == FileType.FILE) && (JobEntryCheckFilesLocked.this.GetFileWildcard(short_filename, this.file_wildcard)))
/*     */           {
/* 349 */             if (JobEntryCheckFilesLocked.this.isDetailed()) {
/* 350 */               JobEntryCheckFilesLocked.this.logDetailed(BaseMessages.getString(JobEntryCheckFilesLocked.PKG, "JobEntryCheckFilesLocked.CheckingFile", new String[] { info.getFile().toString() }));
/*     */             }
/* 352 */             returncode = true;
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 361 */         JobEntryCheckFilesLocked.this.logError(BaseMessages.getString(JobEntryCheckFilesLocked.PKG, "JobCheckFilesLocked.Error.Exception.ProcessError", new String[0]), new Object[] { BaseMessages.getString(JobEntryCheckFilesLocked.PKG, "JobCheckFilesLocked.Error.Exception.Process", new String[] { info.getFile().toString(), e.getMessage() }) });
/*     */         
/*     */ 
/* 364 */         returncode = false;
/*     */       }
/*     */       finally
/*     */       {
/* 368 */         if (file_name != null)
/*     */         {
/*     */           try
/*     */           {
/* 372 */             file_name.close();
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 379 */       return returncode;
/*     */     }
/*     */     
/*     */     public boolean traverseDescendents(FileSelectInfo info)
/*     */     {
/* 384 */       return (info.getDepth() == 0) || (JobEntryCheckFilesLocked.this.includeSubfolders);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*     */   {
/* 396 */     Pattern pattern = null;
/* 397 */     boolean getIt = true;
/*     */     
/* 399 */     if (!Const.isEmpty(wildcard))
/*     */     {
/* 401 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 403 */       if (pattern != null)
/*     */       {
/* 405 */         Matcher matcher = pattern.matcher(selectedfile);
/* 406 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 410 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIncludeSubfolders(boolean includeSubfolders)
/*     */   {
/* 416 */     this.includeSubfolders = includeSubfolders;
/*     */   }
/*     */   
/* 419 */   public void setargFromPrevious(boolean argFromPrevious) { this.argFromPrevious = argFromPrevious; }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluates()
/*     */   {
/* 426 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isArgFromPrevious()
/*     */   {
/* 433 */     return this.argFromPrevious;
/*     */   }
/*     */   
/*     */   public String[] getArguments()
/*     */   {
/* 438 */     return this.arguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getFilemasks()
/*     */   {
/* 445 */     return this.filemasks;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubfolders()
/*     */   {
/* 450 */     return this.includeSubfolders;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 455 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */     
/* 457 */     if (!res)
/*     */     {
/* 459 */       return;
/*     */     }
/*     */     
/* 462 */     ValidatorContext ctx = new ValidatorContext();
/* 463 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 464 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*     */     
/* 466 */     for (int i = 0; i < this.arguments.length; i++)
/*     */     {
/* 468 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\checkfilelocked\JobEntryCheckFilesLocked.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */