/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogChannelFileWriter
/*     */ {
/*     */   private String logChannelId;
/*     */   private FileObject logFile;
/*     */   private boolean appending;
/*     */   private int pollingInterval;
/*     */   private AtomicBoolean active;
/*     */   private KettleException exception;
/*     */   private int lastBufferLineNr;
/*     */   protected OutputStream logFileOutputStream;
/*     */   
/*     */   public LogChannelFileWriter(String logChannelId, FileObject logFile, boolean appending, int pollingInterval)
/*     */     throws KettleException
/*     */   {
/*  61 */     this.logChannelId = logChannelId;
/*  62 */     this.logFile = logFile;
/*  63 */     this.appending = appending;
/*  64 */     this.pollingInterval = pollingInterval;
/*     */     
/*  66 */     this.active = new AtomicBoolean(false);
/*  67 */     this.lastBufferLineNr = CentralLogStore.getLastBufferLineNr();
/*     */     try
/*     */     {
/*  70 */       this.logFileOutputStream = KettleVFS.getOutputStream(logFile, appending);
/*     */     } catch (IOException e) {
/*  72 */       throw new KettleException("There was an error while trying to open file '" + logFile + "' for writing", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LogChannelFileWriter(String logChannelId, FileObject logFile, boolean appending)
/*     */     throws KettleException
/*     */   {
/*  85 */     this(logChannelId, logFile, appending, 1000);
/*     */     
/*  87 */     this.active = new AtomicBoolean(false);
/*  88 */     this.lastBufferLineNr = CentralLogStore.getLastBufferLineNr();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startLogging()
/*     */   {
/*  97 */     this.exception = null;
/*  98 */     this.active.set(true);
/*     */     
/* 100 */     Thread thread = new Thread(new Runnable()
/*     */     {
/*     */       public void run() {
/*     */         try {
/* 104 */           while ((LogChannelFileWriter.this.active.get()) && (LogChannelFileWriter.this.exception == null))
/*     */           {
/* 106 */             Thread.sleep(LogChannelFileWriter.this.pollingInterval);
/*     */             
/* 108 */             int last = CentralLogStore.getLastBufferLineNr();
/* 109 */             StringBuffer buffer = CentralLogStore.getAppender().getBuffer(LogChannelFileWriter.this.logChannelId, false, LogChannelFileWriter.this.lastBufferLineNr, last);
/* 110 */             LogChannelFileWriter.this.logFileOutputStream.write(buffer.toString().getBytes());
/* 111 */             LogChannelFileWriter.this.lastBufferLineNr = last;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 116 */           StringBuffer buffer = CentralLogStore.getAppender().getBuffer(LogChannelFileWriter.this.logChannelId, false, LogChannelFileWriter.this.lastBufferLineNr);
/* 117 */           LogChannelFileWriter.this.logFileOutputStream.write(buffer.toString().getBytes());
/*     */         }
/*     */         catch (Exception e) {
/* 120 */           LogChannelFileWriter.this.exception = new KettleException("There was an error logging to file '" + LogChannelFileWriter.this.logFile + "'", e);
/*     */         } finally {
/*     */           try {
/* 123 */             if (LogChannelFileWriter.this.logFileOutputStream != null) {
/* 124 */               LogChannelFileWriter.this.logFileOutputStream.close();
/* 125 */               LogChannelFileWriter.this.logFileOutputStream = null;
/*     */             }
/*     */           } catch (Exception e) {
/* 128 */             LogChannelFileWriter.this.exception = new KettleException("There was an error closing log file file '" + LogChannelFileWriter.this.logFile + "'", e);
/*     */           }
/*     */         }
/* 131 */       } });
/* 132 */     thread.start();
/*     */   }
/*     */   
/*     */   public void stopLogging() {
/* 136 */     this.active.set(false);
/*     */   }
/*     */   
/*     */   public KettleException getException() {
/* 140 */     return this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getLogChannelId()
/*     */   {
/* 147 */     return this.logChannelId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogChannelId(String logChannelId)
/*     */   {
/* 154 */     this.logChannelId = logChannelId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FileObject getLogFile()
/*     */   {
/* 161 */     return this.logFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLogFile(FileObject logFile)
/*     */   {
/* 168 */     this.logFile = logFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAppending()
/*     */   {
/* 175 */     return this.appending;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAppending(boolean appending)
/*     */   {
/* 182 */     this.appending = appending;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPollingInterval()
/*     */   {
/* 189 */     return this.pollingInterval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setPollingInterval(int pollingInterval)
/*     */   {
/* 196 */     this.pollingInterval = pollingInterval;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\LogChannelFileWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */