/*     */ package org.pentaho.di.job.entries.checkdbconnection;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.Database;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryCheckDbConnections
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  62 */   private static Class<?> PKG = JobEntryCheckDbConnections.class;
/*     */   
/*     */   public DatabaseMeta[] connections;
/*     */   
/*  66 */   public static final String[] unitTimeDesc = { BaseMessages.getString(PKG, "JobEntryCheckDbConnections.UnitTimeMilliSecond.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryCheckDbConnections.UnitTimeSecond.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryCheckDbConnections.UnitTimeMinute.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryCheckDbConnections.UnitTimeHour.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   public static final String[] unitTimeCode = { "millisecond", "second", "minute", "hour" };
/*     */   
/*     */   public static final int UNIT_TIME_MILLI_SECOND = 0;
/*     */   
/*     */   public static final int UNIT_TIME_SECOND = 1;
/*     */   
/*     */   public static final int UNIT_TIME_MINUTE = 2;
/*     */   
/*     */   public static final int UNIT_TIME_HOUR = 3;
/*     */   
/*     */   public String[] waitfors;
/*     */   
/*     */   public int[] waittimes;
/*     */   
/*     */ 
/*     */   public JobEntryCheckDbConnections(String n)
/*     */   {
/*  89 */     super(n, "");
/*  90 */     this.connections = null;
/*  91 */     this.waitfors = null;
/*  92 */     this.waittimes = null;
/*  93 */     setID(-1L);
/*     */   }
/*     */   
/*     */ 
/*     */   public JobEntryCheckDbConnections()
/*     */   {
/*  99 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone() {
/* 103 */     JobEntryCheckDbConnections je = (JobEntryCheckDbConnections)super.clone();
/* 104 */     return je;
/*     */   }
/*     */   
/* 107 */   private static String getWaitTimeCode(int i) { if ((i < 0) || (i >= unitTimeCode.length))
/* 108 */       return unitTimeCode[0];
/* 109 */     return unitTimeCode[i];
/*     */   }
/*     */   
/* 112 */   public static String getWaitTimeDesc(int i) { if ((i < 0) || (i >= unitTimeDesc.length))
/* 113 */       return unitTimeDesc[0];
/* 114 */     return unitTimeDesc[i];
/*     */   }
/*     */   
/* 117 */   public static int getWaitTimeByDesc(String tt) { if (tt == null) {
/* 118 */       return 0;
/*     */     }
/* 120 */     for (int i = 0; i < unitTimeDesc.length; i++) {
/* 121 */       if (unitTimeDesc[i].equalsIgnoreCase(tt)) {
/* 122 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 126 */     return getWaitTimeByCode(tt);
/*     */   }
/*     */   
/* 129 */   private static int getWaitTimeByCode(String tt) { if (tt == null) {
/* 130 */       return 0;
/*     */     }
/* 132 */     for (int i = 0; i < unitTimeCode.length; i++) {
/* 133 */       if (unitTimeCode[i].equalsIgnoreCase(tt))
/* 134 */         return i;
/*     */     }
/* 136 */     return 0;
/*     */   }
/*     */   
/*     */   public String getXML() {
/* 140 */     StringBuffer retval = new StringBuffer();
/* 141 */     retval.append(super.getXML());
/* 142 */     retval.append("      <connections>").append(Const.CR);
/* 143 */     if (this.connections != null) {
/* 144 */       for (int i = 0; i < this.connections.length; i++) {
/* 145 */         retval.append("        <connection>").append(Const.CR);
/* 146 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.connections[i] == null ? null : this.connections[i].getName()));
/* 147 */         retval.append("          ").append(XMLHandler.addTagValue("waitfor", this.waitfors[i]));
/* 148 */         retval.append("          ").append(XMLHandler.addTagValue("waittime", getWaitTimeCode(this.waittimes[i])));
/* 149 */         retval.append("        </connection>").append(Const.CR);
/*     */       }
/*     */     }
/* 152 */     retval.append("      </connections>").append(Const.CR);
/*     */     
/* 154 */     return retval.toString();
/*     */   }
/*     */   
/* 157 */   private static int getWaitByCode(String tt) { if (tt == null) {
/* 158 */       return 0;
/*     */     }
/* 160 */     for (int i = 0; i < unitTimeCode.length; i++) {
/* 161 */       if (unitTimeCode[i].equalsIgnoreCase(tt))
/* 162 */         return i;
/*     */     }
/* 164 */     return 0;
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try {
/* 170 */       super.loadXML(entrynode, databases, slaveServers);
/* 171 */       Node fields = XMLHandler.getSubNode(entrynode, "connections");
/*     */       
/*     */ 
/* 174 */       int nrFields = XMLHandler.countNodes(fields, "connection");
/* 175 */       this.connections = new DatabaseMeta[nrFields];
/* 176 */       this.waitfors = new String[nrFields];
/* 177 */       this.waittimes = new int[nrFields];
/*     */       
/* 179 */       for (int i = 0; i < nrFields; i++) {
/* 180 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "connection", i);
/* 181 */         String dbname = XMLHandler.getTagValue(fnode, "name");
/* 182 */         this.connections[i] = DatabaseMeta.findDatabase(databases, dbname);
/* 183 */         this.waitfors[i] = XMLHandler.getTagValue(fnode, "waitfor");
/* 184 */         this.waittimes[i] = getWaitByCode(Const.NVL(XMLHandler.getTagValue(fnode, "waittime"), ""));
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 189 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.ERROR_0001_Cannot_Load_Job_Entry_From_Xml_Node", new String[] { xe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 198 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "id_database");
/* 199 */       this.connections = new DatabaseMeta[argnr];
/* 200 */       this.waitfors = new String[argnr];
/* 201 */       this.waittimes = new int[argnr];
/*     */       
/* 203 */       for (int a = 0; a < argnr; a++)
/*     */       {
/* 205 */         this.connections[a] = rep.loadDatabaseMetaFromJobEntryAttribute(id_jobentry, "connection", a, "id_database", databases);
/* 206 */         this.waitfors[a] = rep.getJobEntryAttributeString(id_jobentry, a, "waitfor");
/* 207 */         this.waittimes[a] = getWaitByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, a, "waittime"), ""));
/*     */       }
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 212 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.ERROR_0002_Cannot_Load_Job_From_Repository", new String[] { "" + id_jobentry, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 221 */       if (this.connections != null) {
/* 222 */         for (int i = 0; i < this.connections.length; i++) {
/* 223 */           rep.saveDatabaseMetaJobEntryAttribute(id_job, getObjectId(), i, "connection", "id_database", this.connections[i]);
/*     */           
/* 225 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "waittime", getWaitTimeCode(this.waittimes[i]));
/* 226 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "waitfor", this.waitfors[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 232 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.ERROR_0003_Cannot_Save_Job_Entry", new String[] { "" + id_job, dbe.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 238 */     Result result = previousResult;
/* 239 */     result.setResult(true);
/* 240 */     int nrerrors = 0;
/* 241 */     int nrsuccess = 0;
/*     */     
/* 243 */     if (this.connections != null)
/*     */     {
/* 245 */       for (int i = 0; (i < this.connections.length) && (!this.parentJob.isStopped()); i++)
/*     */       {
/* 247 */         Database db = new Database(this, this.connections[i]);
/* 248 */         db.shareVariablesWith(this);
/*     */         try
/*     */         {
/* 251 */           db.connect();
/*     */           
/* 253 */           if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.Connected", new String[] { this.connections[i].getDatabaseName(), this.connections[i].getName() }));
/*     */           }
/* 255 */           int iMaximumTimeout = Const.toInt(environmentSubstitute(this.waitfors[i]), 0);
/* 256 */           if (iMaximumTimeout > 0)
/*     */           {
/*     */ 
/* 259 */             int Multiple = 1;
/* 260 */             String waitTimeMessage = unitTimeDesc[0];
/* 261 */             switch (this.waittimes[i])
/*     */             {
/*     */             case 1: 
/* 264 */               Multiple = 1000;
/* 265 */               waitTimeMessage = unitTimeDesc[1];
/* 266 */               break;
/*     */             case 2: 
/* 268 */               Multiple = 60000;
/* 269 */               waitTimeMessage = unitTimeDesc[2];
/* 270 */               break;
/*     */             case 3: 
/* 272 */               Multiple = 3600000;
/* 273 */               waitTimeMessage = unitTimeDesc[3];
/* 274 */               break;
/*     */             default: 
/* 276 */               Multiple = 1000;
/* 277 */               waitTimeMessage = unitTimeDesc[1];
/*     */             }
/*     */             
/* 280 */             if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.Wait", new String[] { "" + iMaximumTimeout, waitTimeMessage }));
/*     */             }
/*     */             
/* 283 */             long timeStart = System.currentTimeMillis() / Multiple;
/*     */             
/* 285 */             boolean continueLoop = true;
/* 286 */             while ((continueLoop) && (!this.parentJob.isStopped()))
/*     */             {
/*     */ 
/* 289 */               long now = System.currentTimeMillis() / Multiple;
/*     */               
/* 291 */               if (now >= timeStart + iMaximumTimeout)
/*     */               {
/*     */ 
/* 294 */                 if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.WaitTimeIsElapsed.Label", new String[] { this.connections[i].getDatabaseName(), this.connections[i].getName() }));
/*     */                 }
/* 296 */                 continueLoop = false;
/*     */               }
/*     */               else {
/*     */                 try {
/* 300 */                   Thread.sleep(100L);
/*     */                 } catch (Exception e) {}
/*     */               }
/*     */             }
/*     */           }
/* 305 */           nrsuccess++;
/* 306 */           if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.ConnectionOK", new String[] { this.connections[i].getDatabaseName(), this.connections[i].getName() }));
/*     */         }
/*     */         catch (KettleDatabaseException e)
/*     */         {
/* 310 */           nrerrors++;
/* 311 */           logError(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.Exception", new String[] { this.connections[i].getDatabaseName(), this.connections[i].getName(), e.toString() }));
/*     */         }
/*     */         finally
/*     */         {
/* 315 */           if (db != null) {
/* 316 */             try { db.disconnect();
/* 317 */               db = null;
/*     */             } catch (Exception e) {}
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 323 */     if (nrerrors > 0)
/*     */     {
/* 325 */       result.setNrErrors(nrerrors);
/* 326 */       result.setResult(false);
/*     */     }
/*     */     
/* 329 */     if (isDetailed()) {
/* 330 */       logDetailed("=======================================");
/* 331 */       logDetailed(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.Log.Info.ConnectionsInError", new String[] { "" + nrerrors }));
/* 332 */       logDetailed(BaseMessages.getString(PKG, "JobEntryCheckDbConnections.Log.Info.ConnectionsInSuccess", new String[] { "" + nrsuccess }));
/* 333 */       logDetailed("=======================================");
/*     */     }
/*     */     
/* 336 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 341 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public DatabaseMeta[] getUsedDatabaseConnections()
/*     */   {
/* 347 */     return this.connections;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 351 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 352 */     if (this.connections != null) {
/* 353 */       for (int i = 0; i < this.connections.length; i++) {
/* 354 */         DatabaseMeta connection = this.connections[i];
/* 355 */         ResourceReference reference = new ResourceReference(this);
/* 356 */         reference.getEntries().add(new ResourceEntry(connection.getHostname(), ResourceEntry.ResourceType.SERVER));
/* 357 */         reference.getEntries().add(new ResourceEntry(connection.getDatabaseName(), ResourceEntry.ResourceType.DATABASENAME));
/* 358 */         references.add(reference);
/*     */       }
/*     */     }
/* 361 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 367 */     JobEntryValidatorUtils.andValidator().validate(this, "tablename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 368 */     JobEntryValidatorUtils.andValidator().validate(this, "columnname", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\checkdbconnection\JobEntryCheckDbConnections.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */