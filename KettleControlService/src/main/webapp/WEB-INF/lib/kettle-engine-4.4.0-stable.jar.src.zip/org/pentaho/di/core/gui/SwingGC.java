/*     */ package org.pentaho.di.core.gui;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import javax.imageio.IIOException;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.jfree.text.TextUtilities;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.job.entry.JobEntryCopy;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.laf.BasePropertyHandler;
/*     */ import org.pentaho.di.trans.step.StepMeta;
/*     */ import org.pentaho.reporting.libraries.base.util.WaitingImageObserver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingGC
/*     */   implements GCInterface
/*     */ {
/*     */   private static BufferedImage imageLocked;
/*     */   private static BufferedImage imageStepError;
/*     */   private static BufferedImage imageEdit;
/*     */   private static BufferedImage imageContextMenu;
/*     */   private static BufferedImage imageTrue;
/*     */   private static BufferedImage imageFalse;
/*     */   private static BufferedImage imageErrorHop;
/*     */   private static BufferedImage imageInfoHop;
/*     */   private static BufferedImage imageHopTarget;
/*     */   private static BufferedImage imageHopInput;
/*     */   private static BufferedImage imageHopOutput;
/*     */   private static BufferedImage imageArrow;
/*     */   private static BufferedImage imageCopyHop;
/*     */   private static BufferedImage imageParallelHop;
/*     */   private static BufferedImage imageUnconditionalHop;
/*     */   private static BufferedImage imageStart;
/*     */   private static BufferedImage imageDummy;
/*     */   private static BufferedImage imageBusy;
/*     */   protected Color background;
/*     */   protected Color black;
/*     */   protected Color red;
/*     */   protected Color yellow;
/*     */   protected Color orange;
/*     */   protected Color green;
/*     */   protected Color blue;
/*     */   protected Color magenta;
/*     */   protected Color gray;
/*     */   protected Color lightGray;
/*     */   protected Color darkGray;
/*     */   private Graphics2D gc;
/*     */   private int iconsize;
/*     */   private Map<String, BufferedImage> stepImages;
/*     */   private Map<String, BufferedImage> entryImages;
/*     */   private BufferedImage image;
/*     */   private ImageObserver observer;
/*     */   private Point area;
/*     */   private int alpha;
/*     */   private Font fontGraph;
/*     */   private Font fontNote;
/*     */   private Font fontSmall;
/*     */   private int lineWidth;
/*     */   private GCInterface.ELineStyle lineStyle;
/*     */   private int yOffset;
/*     */   private int xOffset;
/*     */   private boolean drawingPixelatedImages;
/*     */   
/*     */   public SwingGC(ImageObserver observer, Point area, int iconsize, int xOffset, int yOffset)
/*     */     throws KettleException
/*     */   {
/* 135 */     this.image = new BufferedImage(area.x, area.y, 1);
/* 136 */     this.gc = this.image.createGraphics();
/* 137 */     this.observer = observer;
/* 138 */     this.stepImages = SwingGUIResource.getInstance().getStepImages();
/* 139 */     this.entryImages = SwingGUIResource.getInstance().getEntryImages();
/* 140 */     this.iconsize = iconsize;
/* 141 */     this.area = area;
/* 142 */     this.xOffset = xOffset;
/* 143 */     this.yOffset = yOffset;
/*     */     
/* 145 */     init();
/*     */   }
/*     */   
/*     */   public SwingGC(Graphics2D gc, Rectangle2D rect, int iconsize, int xOffset, int yOffset) throws KettleException {
/* 149 */     this.image = null;
/* 150 */     this.gc = gc;
/* 151 */     this.observer = null;
/* 152 */     this.stepImages = SwingGUIResource.getInstance().getStepImages();
/* 153 */     this.entryImages = SwingGUIResource.getInstance().getEntryImages();
/* 154 */     this.iconsize = iconsize;
/* 155 */     this.area = new Point((int)rect.getWidth(), (int)rect.getHeight());
/* 156 */     this.xOffset = xOffset;
/* 157 */     this.yOffset = yOffset;
/*     */     
/* 159 */     init();
/*     */   }
/*     */   
/*     */   private void init() throws KettleException {
/* 163 */     this.lineStyle = GCInterface.ELineStyle.SOLID;
/* 164 */     this.lineWidth = 1;
/* 165 */     this.alpha = 255;
/*     */     
/* 167 */     this.background = new Color(255, 255, 255);
/* 168 */     this.black = new Color(0, 0, 0);
/* 169 */     this.red = new Color(255, 0, 0);
/* 170 */     this.yellow = new Color(255, 255, 0);
/* 171 */     this.orange = new Color(255, 165, 0);
/* 172 */     this.green = new Color(0, 255, 0);
/* 173 */     this.blue = new Color(0, 0, 255);
/* 174 */     this.magenta = new Color(255, 0, 255);
/* 175 */     this.gray = new Color(128, 128, 128);
/* 176 */     this.lightGray = new Color(200, 200, 200);
/* 177 */     this.darkGray = new Color(80, 80, 80);
/*     */     
/* 179 */     imageLocked = getImageIcon(BasePropertyHandler.getProperty("Locked_image"));
/* 180 */     imageStepError = getImageIcon(BasePropertyHandler.getProperty("StepErrorLines_image"));
/* 181 */     imageEdit = getImageIcon(BasePropertyHandler.getProperty("Edit_image"));
/* 182 */     imageContextMenu = getImageIcon(BasePropertyHandler.getProperty("ContextMenu_image"));
/* 183 */     imageTrue = getImageIcon(BasePropertyHandler.getProperty("True_image"));
/* 184 */     imageFalse = getImageIcon(BasePropertyHandler.getProperty("False_image"));
/* 185 */     imageErrorHop = getImageIcon(BasePropertyHandler.getProperty("ErrorHop_image"));
/* 186 */     imageInfoHop = getImageIcon(BasePropertyHandler.getProperty("InfoHop_image"));
/* 187 */     imageHopTarget = getImageIcon(BasePropertyHandler.getProperty("HopTarget_image"));
/* 188 */     imageHopInput = getImageIcon(BasePropertyHandler.getProperty("HopInput_image"));
/* 189 */     imageHopOutput = getImageIcon(BasePropertyHandler.getProperty("HopOutput_image"));
/* 190 */     imageArrow = getImageIcon(BasePropertyHandler.getProperty("ArrowIcon_image"));
/* 191 */     imageCopyHop = getImageIcon(BasePropertyHandler.getProperty("CopyHop_image"));
/* 192 */     imageParallelHop = getImageIcon(BasePropertyHandler.getProperty("ParallelHop_image"));
/* 193 */     imageUnconditionalHop = getImageIcon(BasePropertyHandler.getProperty("UnconditionalHop_image"));
/* 194 */     imageStart = getImageIcon(BasePropertyHandler.getProperty("STR_image"));
/* 195 */     imageDummy = getImageIcon(BasePropertyHandler.getProperty("DUM_image"));
/* 196 */     imageBusy = getImageIcon(BasePropertyHandler.getProperty("Busy_image"));
/*     */     
/* 198 */     this.fontGraph = new Font("FreeSans", 0, 10);
/* 199 */     this.fontNote = new Font("FreeSans", 0, 10);
/* 200 */     this.fontSmall = new Font("FreeSans", 0, 8);
/*     */     
/* 202 */     this.gc.setFont(this.fontGraph);
/*     */     
/* 204 */     this.gc.setColor(this.background);
/* 205 */     this.gc.fillRect(0, 0, this.area.x, this.area.y);
/*     */   }
/*     */   
/*     */   private BufferedImage getImageIcon(String fileName) throws KettleException {
/* 209 */     InputStream inputStream = null;
/* 210 */     BufferedImage image = null;
/*     */     try
/*     */     {
/* 213 */       image = ImageIO.read(new File(fileName));
/* 214 */       if (image == null) {
/* 215 */         image = ImageIO.read(new File("/" + fileName));
/*     */       }
/*     */     }
/*     */     catch (IIOException iioe) {}catch (IOException ioe) {}
/*     */     
/*     */ 
/* 221 */     if (image == null) {
/*     */       try {
/* 223 */         inputStream = getClass().getResourceAsStream(fileName);
/* 224 */         if (inputStream == null) {
/* 225 */           inputStream = getClass().getResourceAsStream("/" + fileName);
/*     */         }
/* 227 */         if (inputStream == null) {
/* 228 */           throw new KettleException("Unable to load image from classpath : '" + fileName + "'");
/*     */         }
/* 230 */         image = ImageIO.read(inputStream);
/*     */       }
/*     */       catch (IOException ioe) {
/* 233 */         throw new KettleException("Unable to close image reading stream", ioe);
/*     */       }
/*     */       finally {
/* 236 */         if (inputStream != null) {
/*     */           try {
/* 238 */             inputStream.close();
/*     */           }
/*     */           catch (IOException e) {
/* 241 */             throw new KettleException("Unable to close image reading stream", e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 247 */     WaitingImageObserver observer = new WaitingImageObserver(image);
/* 248 */     observer.waitImageLoaded();
/*     */     
/* 250 */     return image;
/*     */   }
/*     */   
/*     */   public void dispose() {}
/*     */   
/*     */   public void drawLine(int x, int y, int x2, int y2)
/*     */   {
/* 257 */     this.gc.drawLine(x + this.xOffset, y + this.yOffset, x2 + this.xOffset, y2 + this.yOffset);
/*     */   }
/*     */   
/*     */   public void drawImage(GCInterface.EImage image, int locationX, int locationY)
/*     */   {
/* 262 */     BufferedImage img = getNativeImage(image);
/*     */     
/* 264 */     drawPixelatedImage(img, locationX, locationY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawPixelatedImage(BufferedImage img, int locationX, int locationY)
/*     */   {
/* 272 */     if (isDrawingPixelatedImages()) {
/* 273 */       BufferedImage bi = new BufferedImage(img.getWidth(), img.getHeight(), 1);
/* 274 */       Graphics2D g2 = (Graphics2D)bi.getGraphics();
/* 275 */       g2.setColor(Color.WHITE);
/* 276 */       g2.fillRect(0, 0, img.getWidth(), img.getHeight());
/* 277 */       g2.drawImage(img, 0, 0, this.observer);
/* 278 */       g2.dispose();
/*     */       
/* 280 */       for (int x = 0; x < bi.getWidth(this.observer); x++) {
/* 281 */         for (int y = 0; y < bi.getHeight(this.observer); y++) {
/* 282 */           int rgb = bi.getRGB(x, y);
/* 283 */           this.gc.setColor(new Color(rgb));
/* 284 */           this.gc.setStroke(new BasicStroke(1.0F));
/* 285 */           this.gc.drawLine(locationX + this.xOffset + x, locationY + this.yOffset + y, locationX + this.xOffset + x, locationY + this.yOffset + y);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 294 */       while (!this.gc.drawImage(img, locationX, locationY, this.observer)) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public Point getImageBounds(GCInterface.EImage image)
/*     */   {
/* 300 */     BufferedImage img = getNativeImage(image);
/* 301 */     int width = img.getWidth(this.observer);
/* 302 */     int height = img.getHeight(this.observer);
/* 303 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   public static final BufferedImage getNativeImage(GCInterface.EImage image) {
/* 307 */     switch (image) {
/* 308 */     case LOCK:  return imageLocked;
/* 309 */     case STEP_ERROR:  return imageStepError;
/* 310 */     case EDIT:  return imageEdit;
/* 311 */     case CONTEXT_MENU:  return imageContextMenu;
/* 312 */     case TRUE:  return imageTrue;
/* 313 */     case FALSE:  return imageFalse;
/* 314 */     case ERROR:  return imageErrorHop;
/* 315 */     case INFO:  return imageInfoHop;
/* 316 */     case TARGET:  return imageHopTarget;
/* 317 */     case INPUT:  return imageHopInput;
/* 318 */     case OUTPUT:  return imageHopOutput;
/* 319 */     case ARROW:  return imageArrow;
/* 320 */     case COPY_ROWS:  return imageCopyHop;
/* 321 */     case PARALLEL:  return imageParallelHop;
/* 322 */     case UNCONDITIONAL:  return imageUnconditionalHop;
/* 323 */     case BUSY:  return imageBusy;
/*     */     }
/* 325 */     return null;
/*     */   }
/*     */   
/*     */   public void drawPoint(int x, int y) {
/* 329 */     this.gc.drawLine(x + this.xOffset, y + this.yOffset, x + this.xOffset, y + this.yOffset);
/*     */   }
/*     */   
/*     */   public void drawPolygon(int[] polygon)
/*     */   {
/* 334 */     this.gc.drawPolygon(getSwingPolygon(polygon));
/*     */   }
/*     */   
/*     */   private Polygon getSwingPolygon(int[] polygon) {
/* 338 */     int nPoints = polygon.length / 2;
/* 339 */     int[] xPoints = new int[polygon.length / 2];
/* 340 */     int[] yPoints = new int[polygon.length / 2];
/* 341 */     for (int i = 0; i < nPoints; i++) {
/* 342 */       xPoints[i] = (polygon[(2 * i + 0)] + this.xOffset);
/* 343 */       yPoints[i] = (polygon[(2 * i + 1)] + this.yOffset);
/*     */     }
/*     */     
/* 346 */     return new Polygon(xPoints, yPoints, nPoints);
/*     */   }
/*     */   
/*     */   public void drawPolyline(int[] polyline) {
/* 350 */     int nPoints = polyline.length / 2;
/* 351 */     int[] xPoints = new int[polyline.length / 2];
/* 352 */     int[] yPoints = new int[polyline.length / 2];
/* 353 */     for (int i = 0; i < nPoints; i++) {
/* 354 */       xPoints[i] = (polyline[(2 * i + 0)] + this.xOffset);
/* 355 */       yPoints[i] = (polyline[(2 * i + 1)] + this.yOffset);
/*     */     }
/* 357 */     this.gc.drawPolyline(xPoints, yPoints, nPoints);
/*     */   }
/*     */   
/*     */   public void drawRectangle(int x, int y, int width, int height) {
/* 361 */     this.gc.drawRect(x + this.xOffset, y + this.yOffset, width, height);
/*     */   }
/*     */   
/*     */   public void drawRoundRectangle(int x, int y, int width, int height, int circleWidth, int circleHeight) {
/* 365 */     this.gc.drawRoundRect(x + this.xOffset, y + this.yOffset, width, height, circleWidth, circleHeight);
/*     */   }
/*     */   
/*     */   public void drawText(String text, int x, int y)
/*     */   {
/* 370 */     int height = this.gc.getFontMetrics().getHeight();
/*     */     
/* 372 */     String[] lines = text.split("\n");
/* 373 */     for (String line : lines) {
/* 374 */       this.gc.drawString(line, x + this.xOffset, y + height + this.yOffset);
/* 375 */       y += height;
/*     */     }
/*     */   }
/*     */   
/*     */   public void drawText(String text, int x, int y, boolean transparent) {
/* 380 */     drawText(text, x, y);
/*     */   }
/*     */   
/*     */   public void fillPolygon(int[] polygon) {
/* 384 */     switchForegroundBackgroundColors();
/* 385 */     this.gc.fillPolygon(getSwingPolygon(polygon));
/* 386 */     switchForegroundBackgroundColors();
/*     */   }
/*     */   
/*     */   public void fillRectangle(int x, int y, int width, int height) {
/* 390 */     switchForegroundBackgroundColors();
/* 391 */     this.gc.fillRect(x + this.xOffset, y + this.yOffset, width, height);
/* 392 */     switchForegroundBackgroundColors();
/*     */   }
/*     */   
/*     */   public void fillRoundRectangle(int x, int y, int width, int height, int circleWidth, int circleHeight) {
/* 396 */     switchForegroundBackgroundColors();
/* 397 */     this.gc.fillRoundRect(x + this.xOffset, y + this.yOffset, width, height, circleWidth, circleHeight);
/* 398 */     switchForegroundBackgroundColors();
/*     */   }
/*     */   
/*     */   public Point getDeviceBounds() {
/* 402 */     return this.area;
/*     */   }
/*     */   
/*     */   public void setAlpha(int alpha) {
/* 406 */     this.alpha = alpha;
/* 407 */     AlphaComposite alphaComposite = AlphaComposite.getInstance(3, alpha / 255);
/* 408 */     this.gc.setComposite(alphaComposite);
/*     */   }
/*     */   
/*     */   public int getAlpha() {
/* 412 */     return this.alpha;
/*     */   }
/*     */   
/*     */   public void setBackground(GCInterface.EColor color) {
/* 416 */     this.gc.setBackground(getColor(color));
/*     */   }
/*     */   
/*     */   private Color getColor(GCInterface.EColor color) {
/* 420 */     switch (color) {
/* 421 */     case BACKGROUND:  return this.background;
/* 422 */     case BLACK:  return this.black;
/* 423 */     case RED:  return this.red;
/* 424 */     case YELLOW:  return this.yellow;
/* 425 */     case ORANGE:  return this.orange;
/* 426 */     case GREEN:  return this.green;
/* 427 */     case BLUE:  return this.blue;
/* 428 */     case MAGENTA:  return this.magenta;
/* 429 */     case GRAY:  return this.gray;
/* 430 */     case LIGHTGRAY:  return this.lightGray;
/* 431 */     case DARKGRAY:  return this.darkGray;
/*     */     }
/* 433 */     return null;
/*     */   }
/*     */   
/*     */   public void setFont(GCInterface.EFont font) {
/* 437 */     switch (font) {
/* 438 */     case GRAPH:  this.gc.setFont(this.fontGraph); break;
/* 439 */     case NOTE:  this.gc.setFont(this.fontNote); break;
/* 440 */     case SMALL:  this.gc.setFont(this.fontSmall);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setForeground(GCInterface.EColor color) {
/* 445 */     this.gc.setColor(getColor(color));
/*     */   }
/*     */   
/*     */   public void setLineStyle(GCInterface.ELineStyle lineStyle) {
/* 449 */     this.lineStyle = lineStyle;
/* 450 */     this.gc.setStroke(createStroke());
/*     */   }
/*     */   
/*     */   private Stroke createStroke() {
/*     */     float[] dash;
/* 455 */     switch (this.lineStyle) {
/* 456 */     case SOLID:  dash = null; break;
/* 457 */     case DOT:  dash = new float[] { 5.0F }; break;
/* 458 */     case DASHDOT:  dash = new float[] { 10.0F, 5.0F, 5.0F, 5.0F }; break;
/* 459 */     case PARALLEL:  dash = new float[] { 10.0F, 5.0F, 10.0F, 5.0F }; break;
/* 460 */     default:  throw new RuntimeException("Unhandled line style!");
/*     */     }
/* 462 */     return new BasicStroke(this.lineWidth, 0, 0, 2.0F, dash, 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLineWidth(int width)
/*     */   {
/* 473 */     this.lineWidth = width;
/* 474 */     this.gc.setStroke(createStroke());
/*     */   }
/*     */   
/*     */   public void setTransform(float translationX, float translationY, int shadowsize, float magnification) {
/* 478 */     AffineTransform transform = new AffineTransform();
/* 479 */     transform.translate(translationX + shadowsize * magnification, translationY + shadowsize * magnification);
/* 480 */     transform.scale(magnification, magnification);
/* 481 */     this.gc.setTransform(transform);
/*     */   }
/*     */   
/*     */   public Point textExtent(String text)
/*     */   {
/* 486 */     String[] lines = text.split(Const.CR);
/* 487 */     int maxWidth = 0;
/* 488 */     for (String line : lines) {
/* 489 */       Rectangle2D bounds = TextUtilities.getTextBounds(line, this.gc, this.gc.getFontMetrics());
/* 490 */       if (bounds.getWidth() > maxWidth) maxWidth = (int)bounds.getWidth();
/*     */     }
/* 492 */     int height = this.gc.getFontMetrics().getHeight() * lines.length;
/*     */     
/* 494 */     return new Point(maxWidth, height);
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawStepIcon(int x, int y, StepMeta stepMeta)
/*     */   {
/* 500 */     this.gc.fillRect(x + this.xOffset, y + this.yOffset, this.iconsize, this.iconsize);
/* 501 */     String steptype = stepMeta.getStepID();
/* 502 */     BufferedImage im = (BufferedImage)this.stepImages.get(steptype);
/* 503 */     if (im != null)
/*     */     {
/* 505 */       drawPixelatedImage(im, x + this.xOffset, y + this.xOffset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawJobEntryIcon(int x, int y, JobEntryCopy jobEntryCopy)
/*     */   {
/* 512 */     if (jobEntryCopy == null) {
/* 513 */       return;
/*     */     }
/* 515 */     BufferedImage image = null;
/*     */     
/* 517 */     if (jobEntryCopy.isSpecial()) {
/* 518 */       if (jobEntryCopy.isStart()) {
/* 519 */         image = imageStart;
/*     */       }
/* 521 */       if (jobEntryCopy.isDummy()) {
/* 522 */         image = imageDummy;
/*     */       }
/*     */     } else {
/* 525 */       String configId = jobEntryCopy.getEntry().getPluginId();
/* 526 */       if (configId != null) {
/* 527 */         image = (BufferedImage)this.entryImages.get(configId);
/*     */       }
/*     */     }
/* 530 */     if (image == null) {
/* 531 */       return;
/*     */     }
/*     */     
/* 534 */     drawPixelatedImage(image, x + this.xOffset, y + this.xOffset);
/*     */   }
/*     */   
/*     */   public void setAntialias(boolean antiAlias)
/*     */   {
/* 539 */     if (antiAlias)
/*     */     {
/* 541 */       RenderingHints hints = new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 542 */       hints.add(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
/* 543 */       hints.add(new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON));
/*     */       
/* 545 */       this.gc.setRenderingHints(hints);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBackground(int r, int g, int b) {
/* 550 */     Color color = getColor(r, g, b);
/* 551 */     this.gc.setBackground(color);
/*     */   }
/*     */   
/*     */   public void setForeground(int r, int g, int b) {
/* 555 */     Color color = getColor(r, g, b);
/* 556 */     this.gc.setColor(color);
/*     */   }
/*     */   
/*     */   private Color getColor(int r, int g, int b) {
/* 560 */     return new Color(r, g, b);
/*     */   }
/*     */   
/*     */   public void setFont(String fontName, int fontSize, boolean fontBold, boolean fontItalic) {
/* 564 */     int style = 0;
/* 565 */     if (fontBold) style = 1;
/* 566 */     if (fontItalic) { style |= 0x2;
/*     */     }
/* 568 */     Font font = new Font(fontName, style, fontSize);
/* 569 */     this.gc.setFont(font);
/*     */   }
/*     */   
/*     */   public Object getImage() {
/* 573 */     return this.image;
/*     */   }
/*     */   
/*     */   public void switchForegroundBackgroundColors() {
/* 577 */     Color fg = this.gc.getColor();
/* 578 */     Color bg = this.gc.getBackground();
/*     */     
/* 580 */     this.gc.setColor(bg);
/* 581 */     this.gc.setBackground(fg);
/*     */   }
/*     */   
/*     */   public Point getArea() {
/* 585 */     return this.area;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDrawingPixelatedImages()
/*     */   {
/* 592 */     return this.drawingPixelatedImages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDrawingPixelatedImages(boolean drawingPixelatedImages)
/*     */   {
/* 599 */     this.drawingPixelatedImages = drawingPixelatedImages;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\SwingGC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */