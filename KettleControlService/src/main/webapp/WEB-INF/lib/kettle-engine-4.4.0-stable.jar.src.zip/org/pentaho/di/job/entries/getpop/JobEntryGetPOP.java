/*      */ package org.pentaho.di.job.entries.getpop;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.text.DateFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Message;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.apache.commons.vfs.FileType;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.pentaho.di.resource.ResourceEntry;
/*      */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*      */ import org.pentaho.di.resource.ResourceReference;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryGetPOP
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   75 */   private static Class<?> PKG = JobEntryGetPOP.class;
/*      */   
/*      */   public int actiontype;
/*      */   
/*      */   public int conditionReceivedDate;
/*      */   
/*      */   public int valueimaplist;
/*      */   
/*      */   public int aftergetimap;
/*      */   
/*      */   private String servername;
/*      */   
/*      */   private String username;
/*      */   
/*      */   private String password;
/*      */   
/*      */   private boolean usessl;
/*      */   private String sslport;
/*      */   private boolean useproxy;
/*      */   private String proxyusername;
/*      */   private String outputdirectory;
/*      */   private String filenamepattern;
/*      */   private String firstmails;
/*      */   public int retrievemails;
/*      */   private boolean delete;
/*      */   private String protocol;
/*      */   private boolean saveattachment;
/*      */   private boolean savemessage;
/*      */   private boolean usedifferentfolderforattachment;
/*      */   private String attachmentfolder;
/*      */   private String attachmentwildcard;
/*      */   private String imapfirstmails;
/*      */   private String imapfolder;
/*      */   private String senderSearch;
/*      */   private boolean notTermSenderSearch;
/*      */   private String receipientSearch;
/*      */   private String subjectSearch;
/*      */   private String bodySearch;
/*      */   private boolean notTermBodySearch;
/*      */   private String receivedDate1;
/*      */   private String receivedDate2;
/*      */   private boolean notTermSubjectSearch;
/*      */   private boolean notTermReceipientSearch;
/*      */   private boolean notTermReceivedDateSearch;
/*      */   private boolean includesubfolders;
/*      */   private String moveToIMAPFolder;
/*      */   private boolean createmovetofolder;
/*      */   private boolean createlocalfolder;
/*      */   private static final String DEFAULT_FILE_NAME_PATTERN = "name_{SYS|hhmmss_MMddyyyy|}_#IdFile#.mail";
/*      */   public static final String DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
/*      */   private static final String FILENAME_ID_PATTERN = "#IdFile#";
/*      */   private static final String FILENAME_SYS_DATE_OPEN = "{SYS|";
/*      */   private static final String FILENAME_SYS_DATE_CLOSE = "|}";
/*      */   private Pattern attachementPattern;
/*      */   
/*      */   public JobEntryGetPOP(String n)
/*      */   {
/*  132 */     super(n, "");
/*  133 */     this.servername = null;
/*  134 */     this.username = null;
/*  135 */     this.password = null;
/*  136 */     this.usessl = false;
/*  137 */     this.sslport = null;
/*  138 */     this.useproxy = false;
/*  139 */     this.proxyusername = null;
/*  140 */     this.outputdirectory = null;
/*  141 */     this.filenamepattern = "name_{SYS|hhmmss_MMddyyyy|}_#IdFile#.mail";
/*  142 */     this.retrievemails = 0;
/*  143 */     this.firstmails = null;
/*  144 */     this.delete = false;
/*  145 */     this.protocol = "POP3";
/*  146 */     this.saveattachment = true;
/*  147 */     this.savemessage = true;
/*  148 */     this.usedifferentfolderforattachment = false;
/*  149 */     this.attachmentfolder = null;
/*  150 */     this.attachmentwildcard = null;
/*  151 */     this.imapfirstmails = "0";
/*  152 */     this.valueimaplist = 0;
/*  153 */     this.imapfolder = null;
/*      */     
/*  155 */     this.senderSearch = null;
/*  156 */     this.notTermSenderSearch = false;
/*  157 */     this.notTermReceipientSearch = false;
/*  158 */     this.notTermSubjectSearch = false;
/*  159 */     this.bodySearch = null;
/*  160 */     this.notTermBodySearch = false;
/*  161 */     this.receivedDate1 = null;
/*  162 */     this.receivedDate2 = null;
/*  163 */     this.notTermReceivedDateSearch = false;
/*  164 */     this.receipientSearch = null;
/*  165 */     this.subjectSearch = null;
/*  166 */     this.actiontype = 0;
/*  167 */     this.moveToIMAPFolder = null;
/*  168 */     this.createmovetofolder = false;
/*  169 */     this.createlocalfolder = false;
/*  170 */     this.aftergetimap = 0;
/*  171 */     this.includesubfolders = false;
/*  172 */     setID(-1L);
/*      */   }
/*      */   
/*      */   public JobEntryGetPOP() {
/*  176 */     this("");
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  181 */     JobEntryGetPOP je = (JobEntryGetPOP)super.clone();
/*  182 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML() {
/*  186 */     StringBuffer retval = new StringBuffer();
/*  187 */     retval.append(super.getXML());
/*  188 */     retval.append("      ").append(XMLHandler.addTagValue("servername", this.servername));
/*  189 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.username));
/*  190 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(this.password)));
/*  191 */     retval.append("      ").append(XMLHandler.addTagValue("usessl", this.usessl));
/*  192 */     retval.append("      ").append(XMLHandler.addTagValue("sslport", this.sslport));
/*  193 */     retval.append("      ").append(XMLHandler.addTagValue("outputdirectory", this.outputdirectory));
/*  194 */     retval.append("      ").append(XMLHandler.addTagValue("filenamepattern", this.filenamepattern));
/*  195 */     retval.append("      ").append(XMLHandler.addTagValue("retrievemails", this.retrievemails));
/*  196 */     retval.append("      ").append(XMLHandler.addTagValue("firstmails", this.firstmails));
/*  197 */     retval.append("      ").append(XMLHandler.addTagValue("delete", this.delete));
/*  198 */     retval.append("      ").append(XMLHandler.addTagValue("savemessage", this.savemessage));
/*  199 */     retval.append("      ").append(XMLHandler.addTagValue("saveattachment", this.saveattachment));
/*  200 */     retval.append("      ").append(XMLHandler.addTagValue("usedifferentfolderforattachment", this.usedifferentfolderforattachment));
/*  201 */     retval.append("      ").append(XMLHandler.addTagValue("protocol", this.protocol));
/*  202 */     retval.append("      ").append(XMLHandler.addTagValue("attachmentfolder", this.attachmentfolder));
/*  203 */     retval.append("      ").append(XMLHandler.addTagValue("attachmentwildcard", this.attachmentwildcard));
/*  204 */     retval.append("      ").append(XMLHandler.addTagValue("valueimaplist", MailConnectionMeta.getValueImapListCode(this.valueimaplist)));
/*  205 */     retval.append("      ").append(XMLHandler.addTagValue("imapfirstmails", this.imapfirstmails));
/*  206 */     retval.append("      ").append(XMLHandler.addTagValue("imapfolder", this.imapfolder));
/*      */     
/*  208 */     retval.append("      ").append(XMLHandler.addTagValue("sendersearch", this.senderSearch));
/*  209 */     retval.append("      ").append(XMLHandler.addTagValue("nottermsendersearch", this.notTermSenderSearch));
/*      */     
/*  211 */     retval.append("      ").append(XMLHandler.addTagValue("receipientsearch", this.receipientSearch));
/*  212 */     retval.append("      ").append(XMLHandler.addTagValue("nottermreceipientsearch", this.notTermReceipientSearch));
/*  213 */     retval.append("      ").append(XMLHandler.addTagValue("subjectsearch", this.subjectSearch));
/*  214 */     retval.append("      ").append(XMLHandler.addTagValue("nottermsubjectsearch", this.notTermSubjectSearch));
/*  215 */     retval.append("      ").append(XMLHandler.addTagValue("bodysearch", this.bodySearch));
/*  216 */     retval.append("      ").append(XMLHandler.addTagValue("nottermbodysearch", this.notTermBodySearch));
/*  217 */     retval.append("      ").append(XMLHandler.addTagValue("conditionreceiveddate", MailConnectionMeta.getConditionDateCode(this.conditionReceivedDate)));
/*  218 */     retval.append("      ").append(XMLHandler.addTagValue("nottermreceiveddatesearch", this.notTermReceivedDateSearch));
/*  219 */     retval.append("      ").append(XMLHandler.addTagValue("receiveddate1", this.receivedDate1));
/*  220 */     retval.append("      ").append(XMLHandler.addTagValue("receiveddate2", this.receivedDate2));
/*  221 */     retval.append("      ").append(XMLHandler.addTagValue("actiontype", MailConnectionMeta.getActionTypeCode(this.actiontype)));
/*  222 */     retval.append("      ").append(XMLHandler.addTagValue("movetoimapfolder", this.moveToIMAPFolder));
/*      */     
/*  224 */     retval.append("      ").append(XMLHandler.addTagValue("createmovetofolder", this.createmovetofolder));
/*  225 */     retval.append("      ").append(XMLHandler.addTagValue("createlocalfolder", this.createlocalfolder));
/*  226 */     retval.append("      ").append(XMLHandler.addTagValue("aftergetimap", MailConnectionMeta.getAfterGetIMAPCode(this.aftergetimap)));
/*  227 */     retval.append("      ").append(XMLHandler.addTagValue("includesubfolders", this.includesubfolders));
/*  228 */     retval.append("      ").append(XMLHandler.addTagValue("useproxy", this.useproxy));
/*  229 */     retval.append("      ").append(XMLHandler.addTagValue("proxyusername", this.proxyusername));
/*  230 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*      */   {
/*      */     try {
/*  236 */       super.loadXML(entrynode, databases, slaveServers);
/*  237 */       this.servername = XMLHandler.getTagValue(entrynode, "servername");
/*  238 */       this.username = XMLHandler.getTagValue(entrynode, "username");
/*  239 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/*  240 */       this.usessl = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "usessl"));
/*  241 */       this.sslport = XMLHandler.getTagValue(entrynode, "sslport");
/*  242 */       this.outputdirectory = XMLHandler.getTagValue(entrynode, "outputdirectory");
/*  243 */       this.filenamepattern = XMLHandler.getTagValue(entrynode, "filenamepattern");
/*  244 */       if (Const.isEmpty(this.filenamepattern)) this.filenamepattern = "name_{SYS|hhmmss_MMddyyyy|}_#IdFile#.mail";
/*  245 */       this.retrievemails = Const.toInt(XMLHandler.getTagValue(entrynode, "retrievemails"), -1);
/*  246 */       this.firstmails = XMLHandler.getTagValue(entrynode, "firstmails");
/*  247 */       this.delete = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "delete"));
/*      */       
/*  249 */       this.protocol = Const.NVL(XMLHandler.getTagValue(entrynode, "protocol"), "POP3");
/*      */       
/*  251 */       String sm = XMLHandler.getTagValue(entrynode, "savemessage");
/*  252 */       if (Const.isEmpty(sm)) {
/*  253 */         this.savemessage = true;
/*      */       } else {
/*  255 */         this.savemessage = "Y".equalsIgnoreCase(sm);
/*      */       }
/*      */       
/*  258 */       String sa = XMLHandler.getTagValue(entrynode, "saveattachment");
/*  259 */       if (Const.isEmpty(sa)) {
/*  260 */         this.saveattachment = true;
/*      */       } else {
/*  262 */         this.saveattachment = "Y".equalsIgnoreCase(sa);
/*      */       }
/*  264 */       this.usedifferentfolderforattachment = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "usedifferentfolderforattachment"));
/*  265 */       this.attachmentfolder = XMLHandler.getTagValue(entrynode, "attachmentfolder");
/*  266 */       this.attachmentwildcard = XMLHandler.getTagValue(entrynode, "attachmentwildcard");
/*  267 */       this.valueimaplist = MailConnectionMeta.getValueImapListByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "valueimaplist"), ""));
/*  268 */       this.imapfirstmails = XMLHandler.getTagValue(entrynode, "imapfirstmails");
/*  269 */       this.imapfolder = XMLHandler.getTagValue(entrynode, "imapfolder");
/*      */       
/*  271 */       this.senderSearch = XMLHandler.getTagValue(entrynode, "sendersearch");
/*  272 */       this.notTermSenderSearch = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "nottermsendersearch"));
/*  273 */       this.receipientSearch = XMLHandler.getTagValue(entrynode, "receipientsearch");
/*  274 */       this.notTermReceipientSearch = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "nottermreceipientsearch"));
/*  275 */       this.subjectSearch = XMLHandler.getTagValue(entrynode, "subjectsearch");
/*  276 */       this.notTermSubjectSearch = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "nottermsubjectsearch"));
/*  277 */       this.bodySearch = XMLHandler.getTagValue(entrynode, "bodysearch");
/*  278 */       this.notTermBodySearch = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "nottermbodysearch"));
/*  279 */       this.conditionReceivedDate = MailConnectionMeta.getConditionByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "conditionreceiveddate"), ""));
/*  280 */       this.notTermReceivedDateSearch = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "nottermreceiveddatesearch"));
/*  281 */       this.receivedDate1 = XMLHandler.getTagValue(entrynode, "receivedDate1");
/*  282 */       this.receivedDate2 = XMLHandler.getTagValue(entrynode, "receivedDate2");
/*  283 */       this.actiontype = MailConnectionMeta.getActionTypeByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "actiontype"), ""));
/*  284 */       this.moveToIMAPFolder = XMLHandler.getTagValue(entrynode, "movetoimapfolder");
/*  285 */       this.createmovetofolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "createmovetofolder"));
/*  286 */       this.createlocalfolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "createlocalfolder"));
/*  287 */       this.aftergetimap = MailConnectionMeta.getAfterGetIMAPByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "aftergetimap"), ""));
/*  288 */       this.includesubfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "includesubfolders"));
/*  289 */       this.useproxy = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "useproxy"));
/*  290 */       this.proxyusername = XMLHandler.getTagValue(entrynode, "proxyusername");
/*      */     }
/*      */     catch (KettleXMLException xe)
/*      */     {
/*  294 */       throw new KettleXMLException("Unable to load job entry of type 'get pop' from XML node", xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public int getValueImapList()
/*      */   {
/*  300 */     return this.valueimaplist;
/*      */   }
/*      */   
/*      */   public void setValueImapList(int value) {
/*  304 */     this.valueimaplist = value;
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException {
/*      */     try {
/*  309 */       this.servername = rep.getJobEntryAttributeString(id_jobentry, "servername");
/*  310 */       this.username = rep.getJobEntryAttributeString(id_jobentry, "username");
/*  311 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/*  312 */       this.usessl = rep.getJobEntryAttributeBoolean(id_jobentry, "usessl");
/*  313 */       this.sslport = rep.getJobEntryAttributeString(id_jobentry, "sslport");
/*  314 */       this.outputdirectory = rep.getJobEntryAttributeString(id_jobentry, "outputdirectory");
/*  315 */       this.filenamepattern = rep.getJobEntryAttributeString(id_jobentry, "filenamepattern");
/*  316 */       if (Const.isEmpty(this.filenamepattern)) this.filenamepattern = "name_{SYS|hhmmss_MMddyyyy|}_#IdFile#.mail";
/*  317 */       this.retrievemails = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "retrievemails"));
/*  318 */       this.firstmails = rep.getJobEntryAttributeString(id_jobentry, "firstmails");
/*  319 */       this.delete = rep.getJobEntryAttributeBoolean(id_jobentry, "delete");
/*      */       
/*  321 */       this.protocol = Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "protocol"), "POP3");
/*      */       
/*  323 */       String sv = rep.getStepAttributeString(id_jobentry, "savemessage");
/*  324 */       if (Const.isEmpty(sv)) {
/*  325 */         this.savemessage = true;
/*      */       } else {
/*  327 */         this.savemessage = rep.getStepAttributeBoolean(id_jobentry, "savemessage");
/*      */       }
/*  329 */       String sa = rep.getStepAttributeString(id_jobentry, "saveattachment");
/*  330 */       if (Const.isEmpty(sa)) {
/*  331 */         this.saveattachment = true;
/*      */       } else {
/*  333 */         this.saveattachment = rep.getStepAttributeBoolean(id_jobentry, "saveattachment");
/*      */       }
/*  335 */       this.usedifferentfolderforattachment = rep.getJobEntryAttributeBoolean(id_jobentry, "usedifferentfolderforattachment");
/*  336 */       this.attachmentfolder = rep.getJobEntryAttributeString(id_jobentry, "attachmentfolder");
/*  337 */       this.attachmentwildcard = rep.getJobEntryAttributeString(id_jobentry, "attachmentwildcard");
/*  338 */       this.valueimaplist = MailConnectionMeta.getValueListImapListByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "valueimaplist"), ""));
/*  339 */       this.imapfirstmails = rep.getJobEntryAttributeString(id_jobentry, "imapfirstmails");
/*  340 */       this.imapfolder = rep.getJobEntryAttributeString(id_jobentry, "imapfolder");
/*      */       
/*  342 */       this.senderSearch = rep.getJobEntryAttributeString(id_jobentry, "sendersearch");
/*  343 */       this.notTermSenderSearch = rep.getJobEntryAttributeBoolean(id_jobentry, "nottermsendersearch");
/*  344 */       this.receipientSearch = rep.getJobEntryAttributeString(id_jobentry, "receipientsearch");
/*  345 */       this.notTermReceipientSearch = rep.getJobEntryAttributeBoolean(id_jobentry, "nottermreceipientsearch");
/*  346 */       this.subjectSearch = rep.getJobEntryAttributeString(id_jobentry, "subjectsearch");
/*  347 */       this.notTermSubjectSearch = rep.getJobEntryAttributeBoolean(id_jobentry, "nottermsubjectsearch");
/*  348 */       this.bodySearch = rep.getJobEntryAttributeString(id_jobentry, "bodysearch");
/*  349 */       this.notTermBodySearch = rep.getJobEntryAttributeBoolean(id_jobentry, "nottermbodysearch");
/*  350 */       this.conditionReceivedDate = MailConnectionMeta.getConditionByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "conditionreceiveddate"), ""));
/*  351 */       this.notTermReceivedDateSearch = rep.getJobEntryAttributeBoolean(id_jobentry, "nottermreceiveddatesearch");
/*  352 */       this.receivedDate1 = rep.getJobEntryAttributeString(id_jobentry, "receiveddate1");
/*  353 */       this.receivedDate2 = rep.getJobEntryAttributeString(id_jobentry, "receiveddate2");
/*  354 */       this.actiontype = MailConnectionMeta.getActionTypeByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "actiontype"), ""));
/*  355 */       this.moveToIMAPFolder = rep.getJobEntryAttributeString(id_jobentry, "movetoimapfolder");
/*  356 */       this.createmovetofolder = rep.getJobEntryAttributeBoolean(id_jobentry, "createmovetofolder");
/*  357 */       this.createlocalfolder = rep.getJobEntryAttributeBoolean(id_jobentry, "createlocalfolder");
/*  358 */       this.aftergetimap = MailConnectionMeta.getAfterGetIMAPByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "aftergetimap"), ""));
/*  359 */       this.includesubfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "includesubfolders");
/*  360 */       this.useproxy = rep.getJobEntryAttributeBoolean(id_jobentry, "useproxy");
/*  361 */       this.proxyusername = rep.getJobEntryAttributeString(id_jobentry, "proxyusername");
/*      */     }
/*      */     catch (KettleException dbe) {
/*  364 */       throw new KettleException("Unable to load job entry of type 'get pop' exists from the repository for id_jobentry=" + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  372 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "servername", this.servername);
/*  373 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.username);
/*  374 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/*  375 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "usessl", this.usessl);
/*  376 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "sslport", this.sslport);
/*  377 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "outputdirectory", this.outputdirectory);
/*  378 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filenamepattern", this.filenamepattern);
/*  379 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "retrievemails", this.retrievemails);
/*  380 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "firstmails", this.firstmails);
/*  381 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "delete", this.delete);
/*      */       
/*  383 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "protocol", this.protocol);
/*  384 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "savemessage", this.savemessage);
/*  385 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "saveattachment", this.saveattachment);
/*  386 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "usedifferentfolderforattachment", this.usedifferentfolderforattachment);
/*  387 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "attachmentfolder", this.attachmentfolder);
/*  388 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "attachmentwildcard", this.attachmentwildcard);
/*  389 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "valueimaplist", MailConnectionMeta.getValueImapListCode(this.valueimaplist));
/*  390 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "imapfirstmails", this.imapfirstmails);
/*  391 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "imapfolder", this.imapfolder);
/*      */       
/*  393 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "sendersearch", this.senderSearch);
/*  394 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nottermsendersearch", this.notTermSenderSearch);
/*  395 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "receipientsearch", this.receipientSearch);
/*  396 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nottermreceipientsearch", this.notTermReceipientSearch);
/*  397 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "subjectsearch", this.subjectSearch);
/*  398 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nottermsubjectsearch", this.notTermSubjectSearch);
/*  399 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "bodysearch", this.bodySearch);
/*  400 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nottermbodysearch", this.notTermBodySearch);
/*  401 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "conditionreceiveddate", MailConnectionMeta.getConditionDateCode(this.conditionReceivedDate));
/*  402 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nottermreceiveddatesearch", this.notTermReceivedDateSearch);
/*  403 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "receiveddate1", this.receivedDate1);
/*  404 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "receiveddate2", this.receivedDate2);
/*  405 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "actiontype", MailConnectionMeta.getActionTypeCode(this.actiontype));
/*  406 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "movetoimapfolder", this.moveToIMAPFolder);
/*  407 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "createmovetofolder", this.createmovetofolder);
/*  408 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "createlocalfolder", this.createlocalfolder);
/*  409 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "aftergetimap", MailConnectionMeta.getAfterGetIMAPCode(this.aftergetimap));
/*  410 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "includesubfolders", this.includesubfolders);
/*  411 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "useproxy", this.useproxy);
/*  412 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxyusername", this.proxyusername);
/*      */     }
/*      */     catch (KettleDatabaseException dbe) {
/*  415 */       throw new KettleException("Unable to save job entry of type 'get pop' to the repository for id_job=" + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getPort()
/*      */   {
/*  421 */     return this.sslport;
/*      */   }
/*      */   
/*      */   public String getRealPort() {
/*  425 */     return environmentSubstitute(getPort());
/*      */   }
/*      */   
/*  428 */   public void setPort(String sslport) { this.sslport = sslport; }
/*      */   
/*      */   public void setFirstMails(String firstmails)
/*      */   {
/*  432 */     this.firstmails = firstmails;
/*      */   }
/*      */   
/*  435 */   public String getFirstMails() { return this.firstmails; }
/*      */   
/*      */   public boolean isIncludeSubFolders()
/*      */   {
/*  439 */     return this.includesubfolders;
/*      */   }
/*      */   
/*      */   public void setIncludeSubFolders(boolean includesubfolders) {
/*  443 */     this.includesubfolders = includesubfolders;
/*      */   }
/*      */   
/*      */   public void setFirstIMAPMails(String firstmails) {
/*  447 */     this.imapfirstmails = firstmails;
/*      */   }
/*      */   
/*  450 */   public String getFirstIMAPMails() { return this.imapfirstmails; }
/*      */   
/*      */   public void setSenderSearchTerm(String senderSearch) {
/*  453 */     this.senderSearch = senderSearch;
/*      */   }
/*      */   
/*  456 */   public String getSenderSearchTerm() { return this.senderSearch; }
/*      */   
/*      */ 
/*      */   public void setNotTermSenderSearch(boolean notTermSenderSearch)
/*      */   {
/*  461 */     this.notTermSenderSearch = notTermSenderSearch;
/*      */   }
/*      */   
/*  464 */   public boolean isNotTermSenderSearch() { return this.notTermSenderSearch; }
/*      */   
/*      */   public void setNotTermSubjectSearch(boolean notTermSubjectSearch) {
/*  467 */     this.notTermSubjectSearch = notTermSubjectSearch;
/*      */   }
/*      */   
/*  470 */   public void setNotTermBodySearch(boolean notTermBodySearch) { this.notTermBodySearch = notTermBodySearch; }
/*      */   
/*      */   public boolean isNotTermSubjectSearch() {
/*  473 */     return this.notTermSubjectSearch;
/*      */   }
/*      */   
/*  476 */   public boolean isNotTermBodySearch() { return this.notTermBodySearch; }
/*      */   
/*      */   public void setNotTermReceivedDateSearch(boolean notTermReceivedDateSearch) {
/*  479 */     this.notTermReceivedDateSearch = notTermReceivedDateSearch;
/*      */   }
/*      */   
/*  482 */   public boolean isNotTermReceivedDateSearch() { return this.notTermReceivedDateSearch; }
/*      */   
/*      */   public void setNotTermReceipientSearch(boolean notTermReceipientSearch) {
/*  485 */     this.notTermReceipientSearch = notTermReceipientSearch;
/*      */   }
/*      */   
/*  488 */   public boolean isNotTermReceipientSearch() { return this.notTermReceipientSearch; }
/*      */   
/*      */   public void setCreateMoveToFolder(boolean createfolder) {
/*  491 */     this.createmovetofolder = createfolder;
/*      */   }
/*      */   
/*  494 */   public boolean isCreateMoveToFolder() { return this.createmovetofolder; }
/*      */   
/*      */   public void setReceipientSearch(String receipientSearch) {
/*  497 */     this.receipientSearch = receipientSearch;
/*      */   }
/*      */   
/*  500 */   public String getReceipientSearch() { return this.receipientSearch; }
/*      */   
/*      */   public void setSubjectSearch(String subjectSearch)
/*      */   {
/*  504 */     this.subjectSearch = subjectSearch;
/*      */   }
/*      */   
/*  507 */   public String getSubjectSearch() { return this.subjectSearch; }
/*      */   
/*      */   public void setBodySearch(String bodySearch) {
/*  510 */     this.bodySearch = bodySearch;
/*      */   }
/*      */   
/*  513 */   public String getBodySearch() { return this.bodySearch; }
/*      */   
/*      */   public String getReceivedDate1() {
/*  516 */     return this.receivedDate1;
/*      */   }
/*      */   
/*  519 */   public void setReceivedDate1(String inputDate) { this.receivedDate1 = inputDate; }
/*      */   
/*      */   public String getReceivedDate2() {
/*  522 */     return this.receivedDate2;
/*      */   }
/*      */   
/*  525 */   public void setReceivedDate2(String inputDate) { this.receivedDate2 = inputDate; }
/*      */   
/*      */   public void setMoveToIMAPFolder(String foldername) {
/*  528 */     this.moveToIMAPFolder = foldername;
/*      */   }
/*      */   
/*  531 */   public String getMoveToIMAPFolder() { return this.moveToIMAPFolder; }
/*      */   
/*      */   public void setCreateLocalFolder(boolean createfolder)
/*      */   {
/*  535 */     this.createlocalfolder = createfolder;
/*      */   }
/*      */   
/*  538 */   public boolean isCreateLocalFolder() { return this.createlocalfolder; }
/*      */   
/*      */   public void setConditionOnReceivedDate(int conditionReceivedDate) {
/*  541 */     this.conditionReceivedDate = conditionReceivedDate;
/*      */   }
/*      */   
/*  544 */   public int getConditionOnReceivedDate() { return this.conditionReceivedDate; }
/*      */   
/*      */   public void setActionType(int actiontype) {
/*  547 */     this.actiontype = actiontype;
/*      */   }
/*      */   
/*  550 */   public int getActionType() { return this.actiontype; }
/*      */   
/*      */   public void setAfterGetIMAP(int afterget)
/*      */   {
/*  554 */     this.aftergetimap = afterget;
/*      */   }
/*      */   
/*  557 */   public int getAfterGetIMAP() { return this.aftergetimap; }
/*      */   
/*      */   public String getRealFirstMails() {
/*  560 */     return environmentSubstitute(getFirstMails());
/*      */   }
/*      */   
/*  563 */   public void setServerName(String servername) { this.servername = servername; }
/*      */   
/*      */   public String getServerName()
/*      */   {
/*  567 */     return this.servername;
/*      */   }
/*      */   
/*  570 */   public void setUserName(String username) { this.username = username; }
/*      */   
/*      */   public String getUserName()
/*      */   {
/*  574 */     return this.username;
/*      */   }
/*      */   
/*      */   public void setOutputDirectory(String outputdirectory) {
/*  578 */     this.outputdirectory = outputdirectory;
/*      */   }
/*      */   
/*  581 */   public void setFilenamePattern(String filenamepattern) { this.filenamepattern = filenamepattern; }
/*      */   
/*      */   public void setRetrievemails(int nr) {
/*  584 */     this.retrievemails = nr;
/*      */   }
/*      */   
/*  587 */   public int getRetrievemails() { return this.retrievemails; }
/*      */   
/*      */   public String getFilenamePattern() {
/*  590 */     return this.filenamepattern;
/*      */   }
/*      */   
/*      */   public String getOutputDirectory() {
/*  594 */     return this.outputdirectory;
/*      */   }
/*      */   
/*  597 */   public String getRealOutputDirectory() { return environmentSubstitute(getOutputDirectory()); }
/*      */   
/*      */   public String getRealFilenamePattern() {
/*  600 */     return environmentSubstitute(getFilenamePattern());
/*      */   }
/*      */   
/*  603 */   public String getRealUsername() { return environmentSubstitute(getUserName()); }
/*      */   
/*      */   public String getRealServername() {
/*  606 */     return environmentSubstitute(getServerName());
/*      */   }
/*      */   
/*  609 */   public String getRealProxyUsername() { return environmentSubstitute(geProxyUsername()); }
/*      */   
/*      */   public String geProxyUsername() {
/*  612 */     return this.proxyusername;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getPassword()
/*      */   {
/*  618 */     return this.password;
/*      */   }
/*      */   
/*      */   public String getRealPassword() {
/*  622 */     return environmentSubstitute(getPassword());
/*      */   }
/*      */   
/*  625 */   public String getAttachmentFolder() { return this.attachmentfolder; }
/*      */   
/*      */   public void setAttachmentFolder(String foldername) {
/*  628 */     this.attachmentfolder = foldername;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setDelete(boolean delete)
/*      */   {
/*  634 */     this.delete = delete;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getDelete()
/*      */   {
/*  641 */     return this.delete;
/*      */   }
/*      */   
/*  644 */   public String getProtocol() { return this.protocol; }
/*      */   
/*      */   public void setProtocol(String protocol) {
/*  647 */     this.protocol = protocol;
/*      */   }
/*      */   
/*  650 */   public String getIMAPFolder() { return this.imapfolder; }
/*      */   
/*      */   public void setIMAPFolder(String folder) {
/*  653 */     this.imapfolder = folder;
/*      */   }
/*      */   
/*  656 */   public void setAttachmentWildcard(String wildcard) { this.attachmentwildcard = wildcard; }
/*      */   
/*      */   public String getAttachmentWildcard() {
/*  659 */     return this.attachmentwildcard;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setUseSSL(boolean usessl)
/*      */   {
/*  665 */     this.usessl = usessl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isUseSSL()
/*      */   {
/*  672 */     return this.usessl;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isUseProxy()
/*      */   {
/*  678 */     return this.useproxy;
/*      */   }
/*      */   
/*      */   public void setUseProxy(boolean useprox) {
/*  682 */     this.useproxy = useprox;
/*      */   }
/*      */   
/*  685 */   public boolean isSaveAttachment() { return this.saveattachment; }
/*      */   
/*      */   public void setProxyUsername(String username)
/*      */   {
/*  689 */     this.proxyusername = username;
/*      */   }
/*      */   
/*      */   public String getProxyUsername() {
/*  693 */     return this.proxyusername;
/*      */   }
/*      */   
/*      */   public void setSaveAttachment(boolean saveattachment) {
/*  697 */     this.saveattachment = saveattachment;
/*      */   }
/*      */   
/*  700 */   public boolean isSaveMessage() { return this.savemessage; }
/*      */   
/*      */   public void setSaveMessage(boolean savemessage)
/*      */   {
/*  704 */     this.savemessage = savemessage;
/*      */   }
/*      */   
/*  707 */   public void setDifferentFolderForAttachment(boolean usedifferentfolder) { this.usedifferentfolderforattachment = usedifferentfolder; }
/*      */   
/*      */   public boolean isDifferentFolderForAttachment() {
/*  710 */     return this.usedifferentfolderforattachment;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/*  716 */     this.password = password;
/*      */   }
/*      */   
/*      */   public Result execute(Result previousResult, int nr) throws KettleException {
/*  720 */     Result result = previousResult;
/*  721 */     result.setResult(false);
/*      */     
/*  723 */     FileObject fileObject = null;
/*  724 */     MailConnection mailConn = null;
/*  725 */     Date beginDate = null;
/*  726 */     Date endDate = null;
/*      */     
/*  728 */     SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*      */     
/*      */     try
/*      */     {
/*  732 */       boolean usePOP3 = getProtocol().equals("POP3");
/*  733 */       boolean moveafter = false;
/*  734 */       int nbrmailtoretrieve = usePOP3 ? 0 : getRetrievemails() == 2 ? Const.toInt(getFirstMails(), 0) : Const.toInt(getFirstIMAPMails(), 0);
/*      */       
/*  736 */       String realOutputFolder = getRealOutputDirectory();
/*  737 */       fileObject = KettleVFS.getFileObject(realOutputFolder, this);
/*      */       
/*      */ 
/*  740 */       if (fileObject.exists()) {
/*  741 */         if (fileObject.getType() != FileType.FOLDER) throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.NotAFolderNot", new String[] { realOutputFolder }));
/*  742 */         if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Log.OutputFolderExists", new String[] { realOutputFolder }));
/*      */       }
/*  744 */       else if (isCreateLocalFolder()) {
/*  745 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Log.OutputFolderNotExist", new String[] { realOutputFolder }));
/*      */         }
/*  747 */         fileObject.createFolder();
/*      */       } else {
/*  749 */         throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderNotExists1.Label", new String[0]) + realOutputFolder + BaseMessages.getString(PKG, "JobGetMailsFromPOP.FolderNotExists2.Label", new String[0]));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  754 */       String targetAttachmentFolder = KettleVFS.getFilename(fileObject);
/*      */       
/*  756 */       boolean useDifferentFolderForAttachment = (isSaveAttachment()) && (isDifferentFolderForAttachment());
/*      */       
/*  758 */       if (useDifferentFolderForAttachment) {
/*  759 */         String realFolderAttachment = environmentSubstitute(getAttachmentFolder());
/*  760 */         if (Const.isEmpty(realFolderAttachment)) {
/*  761 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.AttachmentFolderEmpty", new String[0]));
/*      */         }
/*  763 */         fileObject = KettleVFS.getFileObject(realFolderAttachment, this);
/*      */         
/*  765 */         if (!fileObject.exists()) {
/*  766 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.AttachmentFolderNotExist", new String[] { realFolderAttachment }));
/*      */         }
/*  768 */         if (fileObject.getType() != FileType.FOLDER) {
/*  769 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.AttachmentFolderNotAFolder", new String[] { realFolderAttachment }));
/*      */         }
/*  771 */         targetAttachmentFolder = KettleVFS.getFilename(fileObject);
/*      */       }
/*      */       try {
/*  774 */         fileObject.close();fileObject = null;
/*      */       }
/*      */       catch (IOException ex) {}
/*  777 */       String realMoveToIMAPFolder = environmentSubstitute(getMoveToIMAPFolder());
/*  778 */       if (((getProtocol().equals("IMAP")) && (getActionType() == 1)) || ((getActionType() == 0) && (getAfterGetIMAP() == 2)))
/*      */       {
/*      */ 
/*  781 */         if (Const.isEmpty(realMoveToIMAPFolder))
/*  782 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.MoveToIMAPFolderEmpty", new String[0]));
/*  783 */         moveafter = true;
/*      */       }
/*      */       
/*      */       String realBeginDate;
/*      */       
/*  788 */       switch (getConditionOnReceivedDate()) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*  792 */         realBeginDate = environmentSubstitute(getReceivedDate1());
/*  793 */         if (Const.isEmpty(realBeginDate))
/*  794 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.ReceivedDateSearchTermEmpty", new String[0]));
/*  795 */         beginDate = df.parse(realBeginDate);
/*  796 */         break;
/*      */       case 4: 
/*  798 */         realBeginDate = environmentSubstitute(getReceivedDate1());
/*  799 */         if (Const.isEmpty(realBeginDate))
/*  800 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.ReceivedDatesSearchTermEmpty", new String[0]));
/*  801 */         beginDate = df.parse(realBeginDate);
/*  802 */         String realEndDate = environmentSubstitute(getReceivedDate2());
/*  803 */         if (Const.isEmpty(realEndDate))
/*  804 */           throw new KettleException(BaseMessages.getString(PKG, "JobGetMailsFromPOP.Error.ReceivedDatesSearchTermEmpty", new String[0]));
/*  805 */         endDate = df.parse(realEndDate);
/*  806 */         break;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*  812 */       String realserver = getRealServername();
/*  813 */       String realusername = getRealUsername();
/*  814 */       String realpassword = getRealPassword();
/*  815 */       String realFilenamePattern = getRealFilenamePattern();
/*  816 */       int realport = Const.toInt(environmentSubstitute(this.sslport), -1);
/*  817 */       String realIMAPFolder = environmentSubstitute(getIMAPFolder());
/*  818 */       String realProxyUsername = getRealProxyUsername();
/*      */       
/*  820 */       initVariables();
/*      */       
/*  822 */       mailConn = new MailConnection(this.log, usePOP3 ? 0 : 1, realserver, realport, realusername, realpassword, isUseSSL(), isUseProxy(), realProxyUsername);
/*      */       
/*      */ 
/*  825 */       mailConn.connect();
/*      */       
/*  827 */       if (moveafter)
/*      */       {
/*      */ 
/*  830 */         mailConn.setDestinationFolder(realMoveToIMAPFolder, isCreateMoveToFolder());
/*      */       }
/*      */       
/*      */ 
/*  834 */       String realSearchSender = environmentSubstitute(getSenderSearchTerm());
/*  835 */       if (!Const.isEmpty(realSearchSender))
/*      */       {
/*  837 */         mailConn.setSenderTerm(realSearchSender, isNotTermSenderSearch());
/*      */       }
/*  839 */       String realSearchReceipient = environmentSubstitute(getReceipientSearch());
/*  840 */       if (!Const.isEmpty(realSearchReceipient))
/*      */       {
/*  842 */         mailConn.setReceipientTerm(realSearchReceipient);
/*      */       }
/*  844 */       String realSearchSubject = environmentSubstitute(getSubjectSearch());
/*  845 */       if (!Const.isEmpty(realSearchSubject))
/*      */       {
/*  847 */         mailConn.setSubjectTerm(realSearchSubject, isNotTermSubjectSearch());
/*      */       }
/*  849 */       String realSearchBody = environmentSubstitute(getBodySearch());
/*  850 */       if (!Const.isEmpty(realSearchBody))
/*      */       {
/*  852 */         mailConn.setBodyTerm(realSearchBody, isNotTermBodySearch());
/*      */       }
/*      */       
/*  855 */       switch (getConditionOnReceivedDate()) {
/*      */       case 1: 
/*  857 */         mailConn.setReceivedDateTermEQ(beginDate);
/*  858 */         break;
/*      */       case 3: 
/*  860 */         mailConn.setReceivedDateTermGT(beginDate);
/*  861 */         break;
/*      */       case 2: 
/*  863 */         mailConn.setReceivedDateTermLT(beginDate);
/*  864 */         break;
/*      */       case 4: 
/*  866 */         mailConn.setReceivedDateTermBetween(beginDate, endDate);
/*  867 */         break;
/*      */       }
/*      */       
/*      */       
/*      */ 
/*  872 */       if (usePOP3)
/*      */       {
/*  874 */         if (getRetrievemails() == 1)
/*      */         {
/*      */ 
/*      */ 
/*  878 */           mailConn.setFlagTermUnread();
/*      */         }
/*      */       } else {
/*  881 */         switch (getValueImapList()) {
/*      */         case 1: 
/*  883 */           mailConn.setFlagTermNew();
/*  884 */           break;
/*      */         case 2: 
/*  886 */           mailConn.setFlagTermOld();
/*  887 */           break;
/*      */         case 3: 
/*  889 */           mailConn.setFlagTermRead();
/*  890 */           break;
/*      */         case 4: 
/*  892 */           mailConn.setFlagTermUnread();
/*  893 */           break;
/*      */         case 5: 
/*  895 */           mailConn.setFlagTermFlagged();
/*  896 */           break;
/*      */         case 6: 
/*  898 */           mailConn.setFlagTermNotFlagged();
/*  899 */           break;
/*      */         case 7: 
/*  901 */           mailConn.setFlagTermDraft();
/*  902 */           break;
/*      */         case 8: 
/*  904 */           mailConn.setFlagTermNotDraft();
/*  905 */           break;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*  911 */       fetchOneFolder(mailConn, usePOP3, realIMAPFolder, realOutputFolder, targetAttachmentFolder, realMoveToIMAPFolder, realFilenamePattern, nbrmailtoretrieve, df);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  916 */       if (isIncludeSubFolders())
/*      */       {
/*  918 */         if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetPOP.FetchingSubFolders", new String[0]));
/*  919 */         String[] subfolders = mailConn.returnAllFolders();
/*  920 */         if (subfolders.length == 0) {
/*  921 */           if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetPOP.NoSubFolders", new String[0]));
/*      */         } else {
/*  923 */           for (int i = 0; i < subfolders.length; i++) {
/*  924 */             fetchOneFolder(mailConn, usePOP3, subfolders[i], realOutputFolder, targetAttachmentFolder, realMoveToIMAPFolder, realFilenamePattern, nbrmailtoretrieve, df);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  932 */       result.setResult(true);
/*  933 */       result.setNrFilesRetrieved(mailConn.getSavedAttachedFilesCounter());
/*  934 */       result.setNrLinesWritten(mailConn.getSavedMessagesCounter());
/*  935 */       result.setNrLinesDeleted(mailConn.getDeletedMessagesCounter());
/*  936 */       result.setNrLinesUpdated(mailConn.getMovedMessagesCounter());
/*      */       
/*  938 */       if (isDetailed()) {
/*  939 */         logDetailed("=======================================");
/*  940 */         logDetailed(BaseMessages.getString(PKG, "JobGetPOP.Log.Info.SavedMessages", new String[] { "" + mailConn.getSavedMessagesCounter() }));
/*  941 */         logDetailed(BaseMessages.getString(PKG, "JobGetPOP.Log.Info.DeletedMessages", new String[] { "" + mailConn.getDeletedMessagesCounter() }));
/*  942 */         logDetailed(BaseMessages.getString(PKG, "JobGetPOP.Log.Info.MovedMessages", new String[] { "" + mailConn.getMovedMessagesCounter() }));
/*  943 */         if ((getActionType() == 0) && (isSaveAttachment())) logDetailed(BaseMessages.getString(PKG, "JobGetPOP.Log.Info.AttachedMessagesSuccess", new String[] { "" + mailConn.getSavedAttachedFilesCounter() }));
/*  944 */         logDetailed("=======================================");
/*      */       }
/*      */     } catch (Exception e) {
/*  947 */       result.setNrErrors(1L);
/*  948 */       logError("Unexpected error: " + e.getMessage());
/*  949 */       logError(Const.getStackTracker(e));
/*      */     } finally {
/*  951 */       if (fileObject != null) {
/*  952 */         try { fileObject.close();
/*  953 */           fileObject = null;
/*      */         } catch (IOException ex) {}
/*      */       }
/*      */       try {
/*  957 */         if (mailConn != null) {
/*  958 */           mailConn.disconnect();
/*  959 */           mailConn = null;
/*      */         }
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*  964 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   private void fetchOneFolder(MailConnection mailConn, boolean usePOP3, String realIMAPFolder, String realOutputFolder, String targetAttachmentFolder, String realMoveToIMAPFolder, String realFilenamePattern, int nbrmailtoretrieve, SimpleDateFormat df)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  973 */       if ((!usePOP3) && (!Const.isEmpty(realIMAPFolder))) {
/*  974 */         mailConn.openFolder(realIMAPFolder, (getActionType() != 0) || (getAfterGetIMAP() != 0));
/*      */       }
/*      */       else {
/*  977 */         mailConn.openFolder((getActionType() != 0) || (getAfterGetIMAP() != 0) || ((usePOP3) && (this.delete)));
/*      */       }
/*      */       
/*  980 */       mailConn.retrieveMessages();
/*      */       
/*  982 */       int messagesCount = mailConn.getMessagesCount();
/*      */       
/*  984 */       if (isDetailed()) {
/*  985 */         logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.TotalMessagesFolder.Label", new String[] { "" + messagesCount, Const.NVL(mailConn.getFolderName(), "INBOX") }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  990 */       messagesCount = nbrmailtoretrieve > 0 ? nbrmailtoretrieve : nbrmailtoretrieve > messagesCount ? messagesCount : messagesCount;
/*      */       
/*      */ 
/*      */ 
/*  994 */       if (messagesCount > 0) {
/*  995 */         switch (getActionType()) {
/*      */         case 2: 
/*  997 */           if (nbrmailtoretrieve > 0)
/*      */           {
/*      */ 
/* 1000 */             for (int i = 0; (i < messagesCount) && (!this.parentJob.isStopped()); i++)
/*      */             {
/* 1002 */               mailConn.fetchNext();
/*      */               
/* 1004 */               mailConn.deleteMessage();
/* 1005 */               if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageDeleted", new String[] { "" + i }));
/*      */             }
/*      */           }
/*      */           else {
/* 1009 */             mailConn.deleteMessages(true);
/* 1010 */             if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessagesDeleted", new String[] { "" + messagesCount }));
/*      */           }
/*      */           break;
/*      */         case 1: 
/* 1014 */           if (nbrmailtoretrieve > 0)
/*      */           {
/*      */ 
/* 1017 */             for (int i = 0; (i < messagesCount) && (!this.parentJob.isStopped()); i++)
/*      */             {
/* 1019 */               mailConn.fetchNext();
/*      */               
/* 1021 */               mailConn.moveMessage();
/* 1022 */               if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageMoved", new String[] { "" + i, realMoveToIMAPFolder }));
/*      */             }
/*      */           }
/*      */           else {
/* 1026 */             mailConn.moveMessages();
/* 1027 */             if (isDebug()) { logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessagesMoved", new String[] { "" + messagesCount, realMoveToIMAPFolder }));
/*      */             }
/*      */           }
/*      */           
/*      */           break;
/*      */         default: 
/* 1033 */           for (int i = 0; (i < messagesCount) && (!this.parentJob.isStopped()); i++)
/*      */           {
/* 1035 */             mailConn.fetchNext();
/* 1036 */             int messagenumber = mailConn.getMessage().getMessageNumber();
/* 1037 */             boolean okPOP3 = usePOP3;
/* 1038 */             boolean okIMAP = !usePOP3;
/*      */             
/* 1040 */             if ((okPOP3) || (okIMAP))
/*      */             {
/*      */ 
/* 1043 */               if ((isDebug()) && (mailConn.getMessage() != null)) {
/* 1044 */                 logDebug("--------------------------------------------------");
/* 1045 */                 logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageNumber.Label", new String[] { "" + messagenumber }));
/* 1046 */                 if (mailConn.getMessage().getReceivedDate() != null) {
/* 1047 */                   logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.ReceivedDate.Label", new String[] { df.format(mailConn.getMessage().getReceivedDate()) }));
/*      */                 }
/* 1049 */                 logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.ContentType.Label", new String[] { mailConn.getMessage().getContentType() }));
/* 1050 */                 logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.EmailFrom.Label", new String[] { Const.NVL(mailConn.getMessage().getFrom()[0].toString(), "") }));
/* 1051 */                 logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.EmailSubject.Label", new String[] { Const.NVL(mailConn.getMessage().getSubject(), "") }));
/*      */               }
/* 1053 */               if (isSaveMessage())
/*      */               {
/* 1055 */                 String localfilename_message = replaceTokens(realFilenamePattern, i);
/*      */                 
/* 1057 */                 if (isDebug()) {
/* 1058 */                   logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.LocalFilename.Label", new String[] { localfilename_message }));
/*      */                 }
/*      */                 
/* 1061 */                 mailConn.saveMessageContentToFile(localfilename_message, realOutputFolder);
/*      */                 
/* 1063 */                 if (isDetailed()) {
/* 1064 */                   logDetailed(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageSaved.Label", new String[] { "" + messagenumber, localfilename_message, realOutputFolder }));
/*      */                 }
/*      */               }
/*      */               
/* 1068 */               if (isSaveAttachment()) {
/* 1069 */                 mailConn.saveAttachedFiles(targetAttachmentFolder, this.attachementPattern);
/*      */               }
/*      */               
/*      */ 
/* 1073 */               if (usePOP3) {
/* 1074 */                 if (getDelete()) {
/* 1075 */                   mailConn.deleteMessage();
/* 1076 */                   if (isDebug()) logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageDeleted", new String[] { "" + messagenumber }));
/*      */                 }
/*      */               } else {
/* 1079 */                 switch (getAfterGetIMAP())
/*      */                 {
/*      */                 case 1: 
/* 1082 */                   mailConn.deleteMessage();
/* 1083 */                   if (isDebug()) { logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageDeleted", new String[] { "" + messagenumber }));
/*      */                   }
/*      */                   break;
/*      */                 case 2: 
/* 1087 */                   mailConn.moveMessage();
/* 1088 */                   if (isDebug()) { logDebug(BaseMessages.getString(PKG, "JobGetMailsFromPOP.MessageMoved", new String[] { "" + messagenumber, realMoveToIMAPFolder }));
/*      */                   }
/*      */                   break;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1100 */       throw new KettleException(e);
/*      */     }
/*      */   }
/*      */   
/* 1104 */   public boolean evaluates() { return true; }
/*      */   
/*      */   private String replaceTokens(String aString, int idfile)
/*      */   {
/* 1108 */     String localfilename_message = aString;
/* 1109 */     localfilename_message = localfilename_message.replaceAll("#IdFile#", "" + (idfile + 1));
/* 1110 */     localfilename_message = substituteDate(localfilename_message, "{SYS|", "|}", new Date());
/* 1111 */     return localfilename_message;
/*      */   }
/*      */   
/*      */   private String substituteDate(String aString, String open, String close, Date datetime) {
/* 1115 */     if (aString == null) return null;
/* 1116 */     StringBuffer buffer = new StringBuffer();
/* 1117 */     String rest = aString;
/*      */     
/*      */ 
/* 1120 */     int i = rest.indexOf(open);
/* 1121 */     while (i > -1)
/*      */     {
/* 1123 */       int j = rest.indexOf(close, i + open.length());
/*      */       
/* 1125 */       if (j > -1)
/*      */       {
/* 1127 */         String varName = rest.substring(i + open.length(), j);
/* 1128 */         DateFormat dateFormat = new SimpleDateFormat(varName);
/* 1129 */         Object Value = dateFormat.format(datetime);
/*      */         
/* 1131 */         buffer.append(rest.substring(0, i));
/* 1132 */         buffer.append(Value);
/* 1133 */         rest = rest.substring(j + close.length());
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1138 */         buffer.append(rest);
/* 1139 */         rest = "";
/*      */       }
/*      */       
/* 1142 */       i = rest.indexOf(close);
/*      */     }
/* 1144 */     buffer.append(rest);
/* 1145 */     return buffer.toString();
/*      */   }
/*      */   
/*      */   private void initVariables() {
/* 1149 */     this.attachementPattern = null;
/* 1150 */     String realAttachmentWildcard = environmentSubstitute(getAttachmentWildcard());
/* 1151 */     if (!Const.isEmpty(realAttachmentWildcard)) {
/* 1152 */       this.attachementPattern = Pattern.compile(realAttachmentWildcard);
/*      */     }
/*      */   }
/*      */   
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1158 */     JobEntryValidatorUtils.andValidator().validate(this, "serverName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1159 */     JobEntryValidatorUtils.andValidator().validate(this, "userName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1160 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */     
/* 1162 */     ValidatorContext ctx = new ValidatorContext();
/* 1163 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 1164 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 1165 */     JobEntryValidatorUtils.andValidator().validate(this, "outputDirectory", remarks, ctx);
/*      */     
/* 1167 */     JobEntryValidatorUtils.andValidator().validate(this, "SSLPort", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*      */   }
/*      */   
/*      */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*      */   {
/* 1172 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 1173 */     if (!Const.isEmpty(this.servername))
/*      */     {
/* 1175 */       String realServername = jobMeta.environmentSubstitute(this.servername);
/* 1176 */       ResourceReference reference = new ResourceReference(this);
/* 1177 */       reference.getEntries().add(new ResourceEntry(realServername, ResourceEntry.ResourceType.SERVER));
/* 1178 */       references.add(reference);
/*      */     }
/* 1180 */     return references;
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\getpop\JobEntryGetPOP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */