/*     */ package org.pentaho.di.job.entries.connectedtorepository;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.repository.IUser;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.repository.RepositorySecurityProvider;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryConnectedToRepository
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  53 */   private static Class<?> PKG = JobEntryConnectedToRepository.class;
/*     */   private boolean isspecificrep;
/*     */   private String repname;
/*     */   private boolean isspecificuser;
/*     */   private String username;
/*     */   
/*     */   public JobEntryConnectedToRepository(String n, String scr)
/*     */   {
/*  61 */     super(n, "");
/*  62 */     this.isspecificrep = false;
/*  63 */     this.repname = null;
/*  64 */     this.isspecificuser = false;
/*  65 */     this.username = null;
/*     */   }
/*     */   
/*     */   public JobEntryConnectedToRepository()
/*     */   {
/*  70 */     this("", "");
/*     */   }
/*     */   
/*     */   public void setSpecificRep(boolean isspecificrep) {
/*  74 */     this.isspecificrep = isspecificrep;
/*     */   }
/*     */   
/*     */   public String getRepName()
/*     */   {
/*  79 */     return this.repname;
/*     */   }
/*     */   
/*     */   public void setRepName(String repname) {
/*  83 */     this.repname = repname;
/*     */   }
/*     */   
/*     */   public String getUserName() {
/*  87 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUserName(String username) {
/*  91 */     this.username = username;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSpecificRep()
/*     */   {
/*  97 */     return this.isspecificrep;
/*     */   }
/*     */   
/*     */   public boolean isSpecificUser()
/*     */   {
/* 102 */     return this.isspecificuser;
/*     */   }
/*     */   
/*     */   public void setSpecificUser(boolean isspecificuser)
/*     */   {
/* 107 */     this.isspecificuser = isspecificuser;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 112 */     JobEntryConnectedToRepository je = (JobEntryConnectedToRepository)super.clone();
/* 113 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 118 */     StringBuffer retval = new StringBuffer();
/* 119 */     retval.append("      ").append(XMLHandler.addTagValue("isspecificrep", this.isspecificrep));
/* 120 */     retval.append("      ").append(XMLHandler.addTagValue("repname", this.repname));
/* 121 */     retval.append("      ").append(XMLHandler.addTagValue("isspecificuser", this.isspecificuser));
/* 122 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.username));
/*     */     
/* 124 */     retval.append(super.getXML());
/*     */     
/* 126 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 134 */       super.loadXML(entrynode, databases, slaveServers);
/* 135 */       this.isspecificrep = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "isspecificrep"));
/* 136 */       this.repname = XMLHandler.getTagValue(entrynode, "repname");
/* 137 */       this.isspecificuser = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "isspecificuser"));
/* 138 */       this.username = XMLHandler.getTagValue(entrynode, "username");
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/* 144 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Meta.UnableToLoadFromXML", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 153 */       this.isspecificrep = rep.getJobEntryAttributeBoolean(id_jobentry, "isspecificrep");
/* 154 */       this.repname = rep.getJobEntryAttributeString(id_jobentry, "repname");
/* 155 */       this.isspecificuser = rep.getJobEntryAttributeBoolean(id_jobentry, "isspecificuser");
/* 156 */       this.username = rep.getJobEntryAttributeString(id_jobentry, "username");
/*     */ 
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 161 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Meta.UnableToLoadFromRep", new String[0]) + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 173 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "isspecificrep", this.isspecificrep);
/* 174 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "repname", this.repname);
/* 175 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "isspecificuser", this.isspecificuser);
/* 176 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.username);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 180 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Meta.UnableToSaveToRep", new String[0]) + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 193 */     Result result = previousResult;
/* 194 */     result.setNrErrors(1L);
/* 195 */     result.setResult(false);
/*     */     
/* 197 */     if (this.rep == null)
/*     */     {
/* 199 */       logError(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Log.NotConnected", new String[0]));
/* 200 */       return result;
/*     */     }
/* 202 */     if (this.isspecificrep)
/*     */     {
/* 204 */       if (Const.isEmpty(this.repname))
/*     */       {
/* 206 */         logError(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Error.NoRep", new String[0]));
/* 207 */         return result;
/*     */       }
/* 209 */       String Reponame = environmentSubstitute(this.repname);
/* 210 */       if (!Reponame.equals(this.rep.getName()))
/*     */       {
/* 212 */         logError(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Error.DiffRep", new String[] { this.rep.getName(), Reponame }));
/* 213 */         return result;
/*     */       }
/*     */     }
/* 216 */     if (this.isspecificuser)
/*     */     {
/* 218 */       if (Const.isEmpty(this.username))
/*     */       {
/* 220 */         logError(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Error.NoUser", new String[0]));
/* 221 */         return result;
/*     */       }
/* 223 */       String Username = environmentSubstitute(this.username);
/*     */       
/* 225 */       if (!Username.equals(this.rep.getSecurityProvider().getUserInfo().getLogin()))
/*     */       {
/* 227 */         logError(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Error.DiffUser", new String[] { this.rep.getUserInfo().getLogin(), Username }));
/* 228 */         return result;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 233 */     if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryConnectedToRepository.Log.Connected", new String[] { this.rep.getName(), this.rep.getUserInfo().getLogin() }));
/*     */     }
/* 235 */     result.setResult(true);
/* 236 */     result.setNrErrors(0L);
/*     */     
/* 238 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 243 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 248 */     return false;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\connectedtorepository\JobEntryConnectedToRepository.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */