/*    */ package org.pentaho.di.core.playlist;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.vfs.FileObject;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilePlayListReplayErrorFile
/*    */   extends FilePlayListReplayFile
/*    */ {
/*    */   private FileObject errorFile;
/*    */   
/*    */   public FilePlayListReplayErrorFile(FileObject errorFile, FileObject processingFile)
/*    */   {
/* 37 */     super(processingFile, "NO_PARTS");
/* 38 */     this.errorFile = errorFile;
/*    */   }
/*    */   
/*    */   public boolean isProcessingNeeded(FileObject file, long lineNr, String filePart) throws KettleException
/*    */   {
/*    */     try
/*    */     {
/* 45 */       return this.errorFile.exists();
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 49 */       throw new KettleException(e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\playlist\FilePlayListReplayErrorFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */