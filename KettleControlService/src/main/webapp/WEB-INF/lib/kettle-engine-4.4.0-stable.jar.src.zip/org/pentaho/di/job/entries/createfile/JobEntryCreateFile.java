/*     */ package org.pentaho.di.job.entries.createfile;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryCreateFile
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  66 */   private static Class<?> PKG = JobEntryCreateFile.class;
/*     */   
/*     */   private String filename;
/*     */   private boolean failIfFileExists;
/*     */   private boolean addfilenameresult;
/*     */   
/*     */   public JobEntryCreateFile(String n)
/*     */   {
/*  74 */     super(n, "");
/*  75 */     this.filename = null;
/*  76 */     this.failIfFileExists = true;
/*  77 */     this.addfilenameresult = false;
/*  78 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryCreateFile()
/*     */   {
/*  83 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  88 */     JobEntryCreateFile je = (JobEntryCreateFile)super.clone();
/*  89 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  94 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/*  96 */     retval.append(super.getXML());
/*  97 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/*  98 */     retval.append("      ").append(XMLHandler.addTagValue("fail_if_file_exists", this.failIfFileExists));
/*  99 */     retval.append("      ").append(XMLHandler.addTagValue("add_filename_result", this.addfilenameresult));
/*     */     
/*     */ 
/* 102 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 109 */       super.loadXML(entrynode, databases, slaveServers);
/* 110 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/* 111 */       this.failIfFileExists = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "fail_if_file_exists"));
/* 112 */       this.addfilenameresult = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_filename_result"));
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 116 */       throw new KettleXMLException("Unable to load job entry of type 'create file' from XML node", xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 124 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/* 125 */       this.failIfFileExists = rep.getJobEntryAttributeBoolean(id_jobentry, "fail_if_file_exists");
/* 126 */       this.addfilenameresult = rep.getJobEntryAttributeBoolean(id_jobentry, "add_filename_result");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 130 */       throw new KettleException("Unable to load job entry of type 'create file' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 139 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/* 140 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "fail_if_file_exists", this.failIfFileExists);
/* 141 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_filename_result", this.addfilenameresult);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 145 */       throw new KettleException("Unable to save job entry of type 'create file' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFilename(String filename)
/*     */   {
/* 152 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 157 */     return this.filename;
/*     */   }
/*     */   
/*     */   public String getRealFilename()
/*     */   {
/* 162 */     return environmentSubstitute(getFilename());
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr) throws KettleException
/*     */   {
/* 167 */     Result result = previousResult;
/* 168 */     result.setResult(false);
/*     */     
/* 170 */     if (this.filename != null)
/*     */     {
/* 172 */       String realFilename = getRealFilename();
/* 173 */       FileObject fileObject = null;
/*     */       try
/*     */       {
/* 176 */         fileObject = KettleVFS.getFileObject(realFilename, this);
/*     */         
/* 178 */         if (fileObject.exists())
/*     */         {
/* 180 */           if (isFailIfFileExists())
/*     */           {
/*     */ 
/* 183 */             result.setResult(false);
/* 184 */             logError("File [" + realFilename + "] exists, failing.");
/*     */           }
/*     */           else
/*     */           {
/* 188 */             result.setResult(true);
/* 189 */             logBasic("File [" + realFilename + "] already exists, not recreating.");
/*     */           }
/*     */           
/* 192 */           if (isAddFilenameToResult()) {
/* 193 */             addFilenameToResult(realFilename, result, this.parentJob);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 198 */           fileObject.createFile();
/* 199 */           logBasic("File [" + realFilename + "] created!");
/*     */           
/* 201 */           if (isAddFilenameToResult())
/* 202 */             addFilenameToResult(realFilename, result, this.parentJob);
/* 203 */           result.setResult(true);
/*     */         }
/*     */       }
/*     */       catch (IOException e) {
/* 207 */         logError("Could not create file [" + realFilename + "], exception: " + e.getMessage());
/* 208 */         result.setResult(false);
/* 209 */         result.setNrErrors(1L);
/*     */       }
/*     */       finally {
/* 212 */         if (fileObject != null)
/*     */         {
/*     */           try
/*     */           {
/* 216 */             fileObject.close();
/* 217 */             fileObject = null;
/*     */ 
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 226 */       logError("No filename is defined.");
/*     */     }
/*     */     
/* 229 */     return result;
/*     */   }
/*     */   
/*     */   private void addFilenameToResult(String targetFilename, Result result, Job parentJob) throws KettleException {
/* 233 */     FileObject targetFile = null;
/*     */     try
/*     */     {
/* 236 */       targetFile = KettleVFS.getFileObject(targetFilename, this);
/*     */       
/*     */ 
/* 239 */       ResultFile resultFile = new ResultFile(0, targetFile, parentJob.getJobname(), toString());
/* 240 */       resultFile.setComment("");
/* 241 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */       
/* 243 */       if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryCreateFile.FileAddedToResult", new String[] { targetFilename }));
/*     */     }
/*     */     catch (Exception e) {
/* 246 */       throw new KettleException(e);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 251 */         targetFile.close();
/* 252 */         targetFile = null;
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 259 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isFailIfFileExists()
/*     */   {
/* 264 */     return this.failIfFileExists;
/*     */   }
/*     */   
/*     */   public void setFailIfFileExists(boolean failIfFileExists)
/*     */   {
/* 269 */     this.failIfFileExists = failIfFileExists;
/*     */   }
/*     */   
/*     */   public boolean isAddFilenameToResult() {
/* 273 */     return this.addfilenameresult;
/*     */   }
/*     */   
/*     */   public void setAddFilenameToResult(boolean addfilenameresult)
/*     */   {
/* 278 */     this.addfilenameresult = addfilenameresult;
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 283 */     List<CheckResultInterface> remarks = new ArrayList();
/* 284 */     new JobEntryCreateFile().check(remarks, null);
/* 285 */     System.out.printf("Remarks: %s\n", new Object[] { remarks });
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 290 */     ValidatorContext ctx = new ValidatorContext();
/* 291 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 292 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileDoesNotExistValidator() });
/* 293 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\createfile\JobEntryCreateFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */