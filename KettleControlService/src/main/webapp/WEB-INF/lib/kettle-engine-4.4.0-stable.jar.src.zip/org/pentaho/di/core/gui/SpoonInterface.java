package org.pentaho.di.core.gui;

import org.pentaho.di.trans.TransMeta;

public abstract interface SpoonInterface
  extends OverwritePrompter
{
  public static final int STATE_CORE_OBJECTS_NONE = 1;
  public static final int STATE_CORE_OBJECTS_CHEF = 2;
  public static final int STATE_CORE_OBJECTS_SPOON = 3;
  public static final String XUL_FILE_MENUBAR = "ui/menubar.xul";
  public static final String XUL_FILE_MENUS = "ui/menus.xul";
  public static final String XUL_FILE_MENU_PROPERTIES = "ui/menubar.properties";
  
  public abstract boolean addSpoonBrowser(String paramString1, String paramString2);
  
  public abstract void addTransGraph(TransMeta paramTransMeta);
  
  public abstract Object[] messageDialogWithToggle(String paramString1, Object paramObject, String paramString2, int paramInt1, String[] paramArrayOfString, int paramInt2, String paramString3, boolean paramBoolean);
  
  public abstract boolean messageBox(String paramString1, String paramString2, boolean paramBoolean, int paramInt);
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\SpoonInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */