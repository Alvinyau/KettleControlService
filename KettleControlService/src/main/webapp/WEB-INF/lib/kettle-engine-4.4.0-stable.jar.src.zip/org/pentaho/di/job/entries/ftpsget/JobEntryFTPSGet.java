/*      */ package org.pentaho.di.job.entries.ftpsget;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.ftp4che.util.ftpfile.FTPFile;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.util.StringUtil;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.pentaho.di.resource.ResourceEntry;
/*      */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*      */ import org.pentaho.di.resource.ResourceReference;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryFTPSGet
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   77 */   private static Class<?> PKG = JobEntryFTPSGet.class;
/*      */   
/*      */   private String serverName;
/*      */   
/*      */   private String userName;
/*      */   
/*      */   private String password;
/*      */   
/*      */   private String FTPSDirectory;
/*      */   
/*      */   private String targetDirectory;
/*      */   
/*      */   private String wildcard;
/*      */   
/*      */   private boolean binaryMode;
/*      */   
/*      */   private int timeout;
/*      */   
/*      */   private boolean remove;
/*      */   private boolean onlyGettingNewFiles;
/*      */   private boolean activeConnection;
/*      */   private boolean movefiles;
/*      */   private String movetodirectory;
/*      */   private boolean adddate;
/*      */   private boolean addtime;
/*      */   private boolean SpecifyFormat;
/*      */   private String date_time_format;
/*      */   private boolean AddDateBeforeExtension;
/*      */   private boolean isaddresult;
/*      */   private boolean createmovefolder;
/*      */   private String port;
/*      */   private String proxyHost;
/*      */   private String proxyPort;
/*      */   private String proxyUsername;
/*      */   private String proxyPassword;
/*      */   private int connectionType;
/*  113 */   public int ifFileExistsSkip = 0;
/*  114 */   public String SifFileExistsSkip = "ifFileExistsSkip";
/*      */   
/*  116 */   public int ifFileExistsCreateUniq = 1;
/*  117 */   public String SifFileExistsCreateUniq = "ifFileExistsCreateUniq";
/*      */   
/*  119 */   public int ifFileExistsFail = 2;
/*  120 */   public String SifFileExistsFail = "ifFileExistsFail";
/*      */   
/*      */   public int ifFileExists;
/*      */   
/*      */   public String SifFileExists;
/*  125 */   public String SUCCESS_IF_AT_LEAST_X_FILES_DOWNLOADED = "success_when_at_least";
/*  126 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*  127 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*      */   
/*      */   private String nr_limit;
/*      */   
/*      */   private String success_condition;
/*      */   
/*  133 */   long NrErrors = 0L;
/*  134 */   long NrfilesRetrieved = 0L;
/*  135 */   boolean successConditionBroken = false;
/*  136 */   int limitFiles = 0;
/*      */   
/*  138 */   String localFolder = null;
/*  139 */   String realMoveToFolder = null;
/*      */   
/*      */ 
/*      */ 
/*  143 */   static String FILE_SEPARATOR = "/";
/*      */   
/*      */   public JobEntryFTPSGet(String n)
/*      */   {
/*  147 */     super(n, "");
/*  148 */     this.nr_limit = "10";
/*  149 */     this.port = "21";
/*  150 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/*  151 */     this.ifFileExists = this.ifFileExistsSkip;
/*  152 */     this.SifFileExists = this.SifFileExistsSkip;
/*      */     
/*  154 */     this.serverName = null;
/*  155 */     this.movefiles = false;
/*  156 */     this.movetodirectory = null;
/*  157 */     this.adddate = false;
/*  158 */     this.addtime = false;
/*  159 */     this.SpecifyFormat = false;
/*  160 */     this.AddDateBeforeExtension = false;
/*  161 */     this.isaddresult = true;
/*  162 */     this.createmovefolder = false;
/*  163 */     this.connectionType = 0;
/*      */     
/*  165 */     setID(-1L);
/*      */   }
/*      */   
/*      */   public JobEntryFTPSGet()
/*      */   {
/*  170 */     this("");
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  175 */     JobEntryFTPSGet je = (JobEntryFTPSGet)super.clone();
/*  176 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  181 */     StringBuffer retval = new StringBuffer(128);
/*      */     
/*  183 */     retval.append(super.getXML());
/*  184 */     retval.append("      ").append(XMLHandler.addTagValue("port", this.port));
/*  185 */     retval.append("      ").append(XMLHandler.addTagValue("servername", this.serverName));
/*  186 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.userName));
/*  187 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(this.password)));
/*  188 */     retval.append("      ").append(XMLHandler.addTagValue("FTPSdirectory", this.FTPSDirectory));
/*  189 */     retval.append("      ").append(XMLHandler.addTagValue("targetdirectory", this.targetDirectory));
/*  190 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/*  191 */     retval.append("      ").append(XMLHandler.addTagValue("binary", this.binaryMode));
/*  192 */     retval.append("      ").append(XMLHandler.addTagValue("timeout", this.timeout));
/*  193 */     retval.append("      ").append(XMLHandler.addTagValue("remove", this.remove));
/*  194 */     retval.append("      ").append(XMLHandler.addTagValue("only_new", this.onlyGettingNewFiles));
/*  195 */     retval.append("      ").append(XMLHandler.addTagValue("active", this.activeConnection));
/*  196 */     retval.append("      ").append(XMLHandler.addTagValue("movefiles", this.movefiles));
/*  197 */     retval.append("      ").append(XMLHandler.addTagValue("movetodirectory", this.movetodirectory));
/*      */     
/*  199 */     retval.append("      ").append(XMLHandler.addTagValue("adddate", this.adddate));
/*  200 */     retval.append("      ").append(XMLHandler.addTagValue("addtime", this.addtime));
/*  201 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyFormat", this.SpecifyFormat));
/*  202 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_format", this.date_time_format));
/*  203 */     retval.append("      ").append(XMLHandler.addTagValue("AddDateBeforeExtension", this.AddDateBeforeExtension));
/*  204 */     retval.append("      ").append(XMLHandler.addTagValue("isaddresult", this.isaddresult));
/*  205 */     retval.append("      ").append(XMLHandler.addTagValue("createmovefolder", this.createmovefolder));
/*      */     
/*  207 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_host", this.proxyHost));
/*  208 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_port", this.proxyPort));
/*  209 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_username", this.proxyUsername));
/*  210 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword)));
/*      */     
/*  212 */     retval.append("      ").append(XMLHandler.addTagValue("ifFileExists", this.SifFileExists));
/*      */     
/*  214 */     retval.append("      ").append(XMLHandler.addTagValue("nr_limit", this.nr_limit));
/*  215 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*  216 */     retval.append("      ").append(XMLHandler.addTagValue("connection_type", FTPSConnection.getConnectionTypeCode(this.connectionType)));
/*      */     
/*  218 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  225 */       super.loadXML(entrynode, databases, slaveServers);
/*  226 */       this.port = XMLHandler.getTagValue(entrynode, "port");
/*  227 */       this.serverName = XMLHandler.getTagValue(entrynode, "servername");
/*  228 */       this.userName = XMLHandler.getTagValue(entrynode, "username");
/*  229 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/*  230 */       this.FTPSDirectory = XMLHandler.getTagValue(entrynode, "FTPSdirectory");
/*  231 */       this.targetDirectory = XMLHandler.getTagValue(entrynode, "targetdirectory");
/*  232 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/*  233 */       this.binaryMode = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "binary"));
/*  234 */       this.timeout = Const.toInt(XMLHandler.getTagValue(entrynode, "timeout"), 10000);
/*  235 */       this.remove = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "remove"));
/*  236 */       this.onlyGettingNewFiles = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "only_new"));
/*  237 */       this.activeConnection = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "active"));
/*      */       
/*  239 */       this.movefiles = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "movefiles"));
/*  240 */       this.movetodirectory = XMLHandler.getTagValue(entrynode, "movetodirectory");
/*      */       
/*  242 */       this.adddate = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "adddate"));
/*  243 */       this.addtime = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "addtime"));
/*  244 */       this.SpecifyFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyFormat"));
/*  245 */       this.date_time_format = XMLHandler.getTagValue(entrynode, "date_time_format");
/*  246 */       this.AddDateBeforeExtension = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "AddDateBeforeExtension"));
/*      */       
/*  248 */       String addresult = XMLHandler.getTagValue(entrynode, "isaddresult");
/*      */       
/*  250 */       if (Const.isEmpty(addresult)) {
/*  251 */         this.isaddresult = true;
/*      */       } else {
/*  253 */         this.isaddresult = "Y".equalsIgnoreCase(addresult);
/*      */       }
/*  255 */       this.createmovefolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "createmovefolder"));
/*      */       
/*  257 */       this.proxyHost = XMLHandler.getTagValue(entrynode, "proxy_host");
/*  258 */       this.proxyPort = XMLHandler.getTagValue(entrynode, "proxy_port");
/*  259 */       this.proxyUsername = XMLHandler.getTagValue(entrynode, "proxy_username");
/*  260 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "proxy_password"));
/*      */       
/*  262 */       this.SifFileExists = XMLHandler.getTagValue(entrynode, "ifFileExists");
/*  263 */       if (Const.isEmpty(this.SifFileExists))
/*      */       {
/*  265 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */ 
/*      */       }
/*  268 */       else if (this.SifFileExists.equals(this.SifFileExistsCreateUniq)) {
/*  269 */         this.ifFileExists = this.ifFileExistsCreateUniq;
/*  270 */       } else if (this.SifFileExists.equals(this.SifFileExistsFail)) {
/*  271 */         this.ifFileExists = this.ifFileExistsFail;
/*      */       } else {
/*  273 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */       }
/*  275 */       this.nr_limit = XMLHandler.getTagValue(entrynode, "nr_limit");
/*  276 */       this.success_condition = Const.NVL(XMLHandler.getTagValue(entrynode, "success_condition"), this.SUCCESS_IF_NO_ERRORS);
/*  277 */       this.connectionType = FTPSConnection.getConnectionTypeByCode(Const.NVL(XMLHandler.getTagValue(entrynode, "connection_type"), ""));
/*      */     }
/*      */     catch (Exception xe)
/*      */     {
/*  281 */       throw new KettleXMLException("Unable to load job entry of type 'FTPS' from XML node", xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  290 */       this.port = rep.getJobEntryAttributeString(id_jobentry, "port");
/*  291 */       this.serverName = rep.getJobEntryAttributeString(id_jobentry, "servername");
/*  292 */       this.userName = rep.getJobEntryAttributeString(id_jobentry, "username");
/*  293 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/*  294 */       this.FTPSDirectory = rep.getJobEntryAttributeString(id_jobentry, "FTPSdirectory");
/*  295 */       this.targetDirectory = rep.getJobEntryAttributeString(id_jobentry, "targetdirectory");
/*  296 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/*  297 */       this.binaryMode = rep.getJobEntryAttributeBoolean(id_jobentry, "binary");
/*  298 */       this.timeout = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "timeout"));
/*  299 */       this.remove = rep.getJobEntryAttributeBoolean(id_jobentry, "remove");
/*  300 */       this.onlyGettingNewFiles = rep.getJobEntryAttributeBoolean(id_jobentry, "only_new");
/*  301 */       this.activeConnection = rep.getJobEntryAttributeBoolean(id_jobentry, "active");
/*      */       
/*  303 */       this.movefiles = rep.getJobEntryAttributeBoolean(id_jobentry, "movefiles");
/*  304 */       this.movetodirectory = rep.getJobEntryAttributeString(id_jobentry, "movetodirectory");
/*      */       
/*  306 */       this.adddate = rep.getJobEntryAttributeBoolean(id_jobentry, "adddate");
/*  307 */       this.addtime = rep.getJobEntryAttributeBoolean(id_jobentry, "adddate");
/*  308 */       this.SpecifyFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyFormat");
/*  309 */       this.date_time_format = rep.getJobEntryAttributeString(id_jobentry, "date_time_format");
/*  310 */       this.AddDateBeforeExtension = rep.getJobEntryAttributeBoolean(id_jobentry, "AddDateBeforeExtension");
/*      */       
/*  312 */       String addToResult = rep.getStepAttributeString(id_jobentry, "add_to_result_filenames");
/*  313 */       if (Const.isEmpty(addToResult)) {
/*  314 */         this.isaddresult = true;
/*      */       } else {
/*  316 */         this.isaddresult = rep.getStepAttributeBoolean(id_jobentry, "add_to_result_filenames");
/*      */       }
/*  318 */       this.createmovefolder = rep.getJobEntryAttributeBoolean(id_jobentry, "createmovefolder");
/*      */       
/*  320 */       this.proxyHost = rep.getJobEntryAttributeString(id_jobentry, "proxy_host");
/*  321 */       this.proxyPort = rep.getJobEntryAttributeString(id_jobentry, "proxy_port");
/*  322 */       this.proxyUsername = rep.getJobEntryAttributeString(id_jobentry, "proxy_username");
/*  323 */       this.proxyPassword = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "proxy_password"));
/*      */       
/*  325 */       this.SifFileExists = rep.getJobEntryAttributeString(id_jobentry, "ifFileExists");
/*  326 */       if (Const.isEmpty(this.SifFileExists))
/*      */       {
/*  328 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */ 
/*      */       }
/*  331 */       else if (this.SifFileExists.equals(this.SifFileExistsCreateUniq)) {
/*  332 */         this.ifFileExists = this.ifFileExistsCreateUniq;
/*  333 */       } else if (this.SifFileExists.equals(this.SifFileExistsFail)) {
/*  334 */         this.ifFileExists = this.ifFileExistsFail;
/*      */       } else {
/*  336 */         this.ifFileExists = this.ifFileExistsSkip;
/*      */       }
/*  338 */       this.nr_limit = rep.getJobEntryAttributeString(id_jobentry, "nr_limit");
/*  339 */       this.success_condition = Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "success_condition"), this.SUCCESS_IF_NO_ERRORS);
/*  340 */       this.connectionType = FTPSConnection.getConnectionTypeByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "connection_type"), ""));
/*      */     }
/*      */     catch (KettleException dbe)
/*      */     {
/*  344 */       throw new KettleException("Unable to load job entry of type 'FTPS' from the repository for id_jobentry=" + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  352 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "port", this.port);
/*  353 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "servername", this.serverName);
/*  354 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.userName);
/*  355 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/*  356 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "FTPSdirectory", this.FTPSDirectory);
/*  357 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "targetdirectory", this.targetDirectory);
/*  358 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/*  359 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "binary", this.binaryMode);
/*  360 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "timeout", this.timeout);
/*  361 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remove", this.remove);
/*  362 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "only_new", this.onlyGettingNewFiles);
/*  363 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "active", this.activeConnection);
/*      */       
/*  365 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "movefiles", this.movefiles);
/*  366 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "movetodirectory", this.movetodirectory);
/*      */       
/*  368 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "addtime", this.addtime);
/*  369 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "adddate", this.adddate);
/*  370 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyFormat", this.SpecifyFormat);
/*  371 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_format", this.date_time_format);
/*      */       
/*  373 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "AddDateBeforeExtension", this.AddDateBeforeExtension);
/*  374 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "isaddresult", this.isaddresult);
/*  375 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "createmovefolder", this.createmovefolder);
/*      */       
/*  377 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_host", this.proxyHost);
/*  378 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_port", this.proxyPort);
/*  379 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_username", this.proxyUsername);
/*  380 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_password", Encr.encryptPasswordIfNotUsingVariables(this.proxyPassword));
/*  381 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "ifFileExists", this.SifFileExists);
/*      */       
/*  383 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_limit", this.nr_limit);
/*  384 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*  385 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "connection_type", FTPSConnection.getConnectionType(this.connectionType));
/*      */ 
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  390 */       throw new KettleException("Unable to save job entry of type 'FTPS' to the repository for id_job=" + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLimit(String nr_limitin)
/*      */   {
/*  397 */     this.nr_limit = nr_limitin;
/*      */   }
/*      */   
/*      */   public String getLimit()
/*      */   {
/*  402 */     return this.nr_limit;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSuccessCondition(String success_condition)
/*      */   {
/*  408 */     this.success_condition = success_condition;
/*      */   }
/*      */   
/*      */   public String getSuccessCondition() {
/*  412 */     return this.success_condition;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setCreateMoveFolder(boolean createmovefolderin)
/*      */   {
/*  418 */     this.createmovefolder = createmovefolderin;
/*      */   }
/*      */   
/*      */   public boolean isCreateMoveFolder()
/*      */   {
/*  423 */     return this.createmovefolder;
/*      */   }
/*      */   
/*      */   public void setAddDateBeforeExtension(boolean AddDateBeforeExtension)
/*      */   {
/*  428 */     this.AddDateBeforeExtension = AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public boolean isAddDateBeforeExtension()
/*      */   {
/*  433 */     return this.AddDateBeforeExtension;
/*      */   }
/*      */   
/*      */   public void setAddToResult(boolean isaddresultin)
/*      */   {
/*  438 */     this.isaddresult = isaddresultin;
/*      */   }
/*      */   
/*      */   public boolean isAddToResult()
/*      */   {
/*  443 */     return this.isaddresult;
/*      */   }
/*      */   
/*      */   public void setDateInFilename(boolean adddate)
/*      */   {
/*  448 */     this.adddate = adddate;
/*      */   }
/*      */   
/*      */   public boolean isDateInFilename()
/*      */   {
/*  453 */     return this.adddate;
/*      */   }
/*      */   
/*      */   public void setTimeInFilename(boolean addtime)
/*      */   {
/*  458 */     this.addtime = addtime;
/*      */   }
/*      */   
/*      */   public boolean isTimeInFilename() {
/*  462 */     return this.addtime;
/*      */   }
/*      */   
/*      */   public boolean isSpecifyFormat() {
/*  466 */     return this.SpecifyFormat;
/*      */   }
/*      */   
/*      */   public void setSpecifyFormat(boolean SpecifyFormat) {
/*  470 */     this.SpecifyFormat = SpecifyFormat;
/*      */   }
/*      */   
/*      */   public String getDateTimeFormat() {
/*  474 */     return this.date_time_format;
/*      */   }
/*      */   
/*      */   public void setDateTimeFormat(String date_time_format) {
/*  478 */     this.date_time_format = date_time_format;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMoveFiles()
/*      */   {
/*  486 */     return this.movefiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMoveFiles(boolean movefilesin)
/*      */   {
/*  493 */     this.movefiles = movefilesin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMoveToDirectory()
/*      */   {
/*  502 */     return this.movetodirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMoveToDirectory(String movetoin)
/*      */   {
/*  510 */     this.movetodirectory = movetoin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBinaryMode()
/*      */   {
/*  518 */     return this.binaryMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBinaryMode(boolean binaryMode)
/*      */   {
/*  526 */     this.binaryMode = binaryMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFTPSDirectory()
/*      */   {
/*  534 */     return this.FTPSDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFTPSDirectory(String directory)
/*      */   {
/*  542 */     this.FTPSDirectory = directory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPassword()
/*      */   {
/*  550 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/*  558 */     this.password = password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getServerName()
/*      */   {
/*  566 */     return this.serverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setServerName(String serverName)
/*      */   {
/*  574 */     this.serverName = serverName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPort()
/*      */   {
/*  582 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(String port)
/*      */   {
/*  590 */     this.port = port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */   {
/*  600 */     return this.userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserName(String userName)
/*      */   {
/*  608 */     this.userName = userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWildcard()
/*      */   {
/*  616 */     return this.wildcard;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWildcard(String wildcard)
/*      */   {
/*  624 */     this.wildcard = wildcard;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getTargetDirectory()
/*      */   {
/*  632 */     return this.targetDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTargetDirectory(String targetDirectory)
/*      */   {
/*  640 */     this.targetDirectory = targetDirectory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTimeout(int timeout)
/*      */   {
/*  648 */     this.timeout = timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTimeout()
/*      */   {
/*  656 */     return this.timeout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemove(boolean remove)
/*      */   {
/*  664 */     this.remove = remove;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getRemove()
/*      */   {
/*  672 */     return this.remove;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isOnlyGettingNewFiles()
/*      */   {
/*  680 */     return this.onlyGettingNewFiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOnlyGettingNewFiles(boolean onlyGettingNewFilesin)
/*      */   {
/*  688 */     this.onlyGettingNewFiles = onlyGettingNewFilesin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyHost()
/*      */   {
/*  697 */     return this.proxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyHost(String proxyHost)
/*      */   {
/*  705 */     this.proxyHost = proxyHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyPassword()
/*      */   {
/*  713 */     return this.proxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPassword(String proxyPassword)
/*      */   {
/*  721 */     this.proxyPassword = proxyPassword;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyPort()
/*      */   {
/*  729 */     return this.proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(String proxyPort)
/*      */   {
/*  737 */     this.proxyPort = proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getProxyUsername()
/*      */   {
/*  744 */     return this.proxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setProxyUsername(String proxyUsername)
/*      */   {
/*  751 */     this.proxyUsername = proxyUsername;
/*      */   }
/*      */   
/*      */ 
/*      */   public Result execute(Result previousResult, int nr)
/*      */     throws KettleException
/*      */   {
/*  758 */     logBasic(BaseMessages.getString(PKG, "JobEntryFTPS.Started", new String[] { this.serverName }));
/*      */     
/*  760 */     Result result = previousResult;
/*  761 */     result.setNrErrors(1L);
/*  762 */     result.setResult(false);
/*  763 */     this.NrErrors = 0L;
/*  764 */     this.NrfilesRetrieved = 0L;
/*  765 */     this.successConditionBroken = false;
/*  766 */     boolean exitjobentry = false;
/*  767 */     this.limitFiles = Const.toInt(environmentSubstitute(getLimit()), 10);
/*      */     
/*      */ 
/*      */ 
/*  771 */     if ((this.movefiles) && 
/*  772 */       (Const.isEmpty(this.movetodirectory))) {
/*  773 */       logError(BaseMessages.getString(PKG, "JobEntryFTPS.MoveToFolderEmpty", new String[0]));
/*  774 */       return result;
/*      */     }
/*      */     
/*      */ 
/*  778 */     this.localFolder = environmentSubstitute(this.targetDirectory);
/*      */     
/*  780 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.Start", new String[0]));
/*      */     }
/*  782 */     FTPSConnection connection = null;
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  788 */       String realServername = environmentSubstitute(this.serverName);
/*  789 */       String realUsername = environmentSubstitute(this.userName);
/*  790 */       String realPassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password));
/*  791 */       int realPort = Const.toInt(environmentSubstitute(this.port), 0);
/*      */       
/*  793 */       connection = new FTPSConnection(getConnectionType(), realServername, realPort, realUsername, realPassword);
/*      */       
/*  795 */       if (!Const.isEmpty(this.proxyHost)) {
/*  796 */         String realProxy_host = environmentSubstitute(this.proxyHost);
/*  797 */         String realProxy_username = environmentSubstitute(this.proxyUsername);
/*  798 */         String realProxy_password = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.proxyPassword));
/*      */         
/*  800 */         connection.setProxyHost(realProxy_host);
/*  801 */         if (!Const.isEmpty(realProxy_username)) {
/*  802 */           connection.setProxyUser(realProxy_username);
/*      */         }
/*  804 */         if (!Const.isEmpty(realProxy_password)) {
/*  805 */           connection.setProxyPassword(realProxy_password);
/*      */         }
/*  807 */         if (isDetailed()) {
/*  808 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.OpenedProxyConnectionOn", new String[] { realProxy_host }));
/*      */         }
/*  810 */         int proxyport = Const.toInt(environmentSubstitute(this.proxyPort), 21);
/*  811 */         if (proxyport != 0) {
/*  812 */           connection.setProxyPort(proxyport);
/*      */         }
/*      */       }
/*  815 */       else if (isDetailed()) {
/*  816 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.OpenedConnectionTo", new String[] { realServername }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  821 */       if (this.activeConnection) {
/*  822 */         connection.setPassiveMode(false);
/*  823 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.SetActive", new String[0]));
/*      */       } else {
/*  825 */         connection.setPassiveMode(true);
/*  826 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.SetPassive", new String[0]));
/*      */         }
/*      */       }
/*      */       
/*  830 */       if (isBinaryMode()) {
/*  831 */         connection.setBinaryMode(true);
/*  832 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.SetBinary", new String[0]));
/*      */         }
/*      */       }
/*      */       
/*  836 */       connection.setTimeOut(this.timeout);
/*  837 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.SetTimeout", new String[] { String.valueOf(this.timeout) }));
/*      */       }
/*      */       
/*  840 */       connection.connect();
/*  841 */       if (isDetailed()) {
/*  842 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.LoggedIn", new String[] { realUsername }));
/*  843 */         logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.WorkingDirectory", new String[] { connection.getWorkingDirectory() }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  848 */       if (!Const.isEmpty(this.FTPSDirectory)) {
/*  849 */         String realFTPSDirectory = environmentSubstitute(this.FTPSDirectory);
/*  850 */         realFTPSDirectory = normalizePath(realFTPSDirectory);
/*  851 */         connection.changeDirectory(realFTPSDirectory);
/*  852 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.ChangedDir", new String[] { realFTPSDirectory }));
/*      */         }
/*      */       }
/*      */       
/*  856 */       if ((this.movefiles) && (!Const.isEmpty(this.movetodirectory))) {
/*  857 */         this.realMoveToFolder = normalizePath(environmentSubstitute(this.movetodirectory));
/*      */         
/*  859 */         boolean folderExist = connection.isDirectoryExists(this.realMoveToFolder);
/*  860 */         if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.CheckMoveToFolder", new String[] { this.realMoveToFolder }));
/*      */         }
/*  862 */         if (!folderExist) {
/*  863 */           if (this.createmovefolder) {
/*  864 */             connection.createDirectory(this.realMoveToFolder);
/*  865 */             if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.MoveToFolderCreated", new String[] { this.realMoveToFolder }));
/*      */           } else {
/*  867 */             logError(BaseMessages.getString(PKG, "JobEntryFTPS.MoveToFolderNotExist", new String[0]));
/*  868 */             exitjobentry = true;
/*  869 */             this.NrErrors += 1L;
/*      */           }
/*      */         }
/*      */       }
/*  873 */       if (!exitjobentry) {
/*  874 */         Pattern pattern = null;
/*  875 */         if (!Const.isEmpty(this.wildcard)) {
/*  876 */           String realWildcard = environmentSubstitute(this.wildcard);
/*  877 */           pattern = Pattern.compile(realWildcard);
/*      */         }
/*      */         
/*  880 */         if (!getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS)) {
/*  881 */           this.limitFiles = Const.toInt(environmentSubstitute(getLimit()), 10);
/*      */         }
/*      */         
/*      */ 
/*  885 */         downloadFiles(connection, connection.getWorkingDirectory(), pattern, result);
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  889 */       if ((!this.successConditionBroken) && (!exitjobentry)) updateErrors();
/*  890 */       logError(BaseMessages.getString(PKG, "JobEntryFTPS.ErrorGetting", new String[] { e.getMessage() }));
/*      */     } finally {
/*  892 */       if (connection != null) {
/*      */         try {
/*  894 */           connection.disconnect();
/*      */         } catch (Exception e) {
/*  896 */           logError(BaseMessages.getString(PKG, "JobEntryFTPS.ErrorQuitting", new String[] { e.getMessage() }));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  901 */     result.setNrErrors(this.NrErrors);
/*  902 */     result.setNrFilesRetrieved(this.NrfilesRetrieved);
/*  903 */     if (getSuccessStatus()) result.setResult(true);
/*  904 */     if (exitjobentry) { result.setResult(false);
/*      */     }
/*  906 */     displayResults();
/*      */     
/*  908 */     return result;
/*      */   }
/*      */   
/*      */   private void downloadFiles(FTPSConnection connection, String folder, Pattern pattern, Result result) throws KettleException
/*      */   {
/*  913 */     List<FTPFile> fileList = connection.getFileList(folder);
/*  914 */     if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.FoundNFiles", new Object[] { Integer.valueOf(fileList.size()) }));
/*      */     }
/*  916 */     for (int i = 0; i < fileList.size(); i++)
/*      */     {
/*  918 */       if (this.parentJob.isStopped()) {
/*  919 */         throw new KettleException(BaseMessages.getString(PKG, "JobEntryFTPS.JobStopped", new String[0]));
/*      */       }
/*      */       
/*  922 */       if (this.successConditionBroken) {
/*  923 */         throw new KettleException(BaseMessages.getString(PKG, "JobEntryFTPS.SuccesConditionBroken", new Object[] { Long.valueOf(this.NrErrors) }));
/*      */       }
/*      */       
/*  926 */       FTPFile file = (FTPFile)fileList.get(i);
/*  927 */       if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.AnalysingFile", new String[] { file.getPath(), file.getName(), file.getMode(), file.getDate().toString(), file.getFileType() == 0 ? "File" : "Folder", String.valueOf(file.getSize()) }));
/*      */       }
/*      */       
/*      */ 
/*  931 */       if ((!file.isDirectory()) && (!file.isLink()))
/*      */       {
/*  933 */         boolean getIt = true;
/*  934 */         if (getIt) {
/*      */           try
/*      */           {
/*  937 */             if (pattern != null) {
/*  938 */               Matcher matcher = pattern.matcher(file.getName());
/*  939 */               getIt = matcher.matches();
/*      */             }
/*      */             
/*  942 */             if (getIt)
/*      */             {
/*  944 */               String localFilename = returnTargetFilename(file.getName());
/*      */               
/*  946 */               if ((!this.onlyGettingNewFiles) || ((this.onlyGettingNewFiles) && (needsDownload(localFilename))))
/*      */               {
/*      */ 
/*  949 */                 if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.GettingFile", new String[] { file.getName(), this.targetDirectory }));
/*      */                 }
/*      */                 
/*  952 */                 connection.downloadFile(file, returnTargetFilename(file.getName()));
/*      */                 
/*      */ 
/*  955 */                 updateRetrievedFiles();
/*      */                 
/*  957 */                 if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.GotFile", new String[] { file.getName() }));
/*      */                 }
/*      */                 
/*  960 */                 addFilenameToResultFilenames(result, localFilename);
/*      */                 
/*      */ 
/*  963 */                 if (this.remove) {
/*  964 */                   connection.deleteFile(file);
/*      */                   
/*  966 */                   if ((isDetailed()) && 
/*  967 */                     (isDetailed())) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.DeletedFile", new String[] { file.getName() }));
/*      */                 }
/*  969 */                 else if (this.movefiles)
/*      */                 {
/*  971 */                   connection.moveToFolder(file, this.realMoveToFolder);
/*      */                   
/*  973 */                   if (isDetailed()) {
/*  974 */                     logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.MovedFile", new String[] { file.getName(), this.realMoveToFolder }));
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception e) {
/*  981 */             updateErrors();
/*  982 */             logError(BaseMessages.getString(PKG, "JobFTPS.UnexpectedError", new String[] { e.toString() }));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String normalizePath(String path)
/*      */     throws Exception
/*      */   {
/*  998 */     String normalizedPath = path.replaceAll("\\\\", FILE_SEPARATOR);
/*  999 */     while ((normalizedPath.endsWith("\\")) || (normalizedPath.endsWith(FILE_SEPARATOR))) {
/* 1000 */       normalizedPath = normalizedPath.substring(0, normalizedPath.length() - 1);
/*      */     }
/*      */     
/* 1003 */     return normalizedPath;
/*      */   }
/*      */   
/*      */   private void addFilenameToResultFilenames(Result result, String filename) throws KettleException {
/* 1007 */     if (this.isaddresult) {
/* 1008 */       FileObject targetFile = null;
/*      */       try {
/* 1010 */         targetFile = KettleVFS.getFileObject(filename);
/*      */         
/*      */ 
/* 1013 */         ResultFile resultFile = new ResultFile(0, targetFile, this.parentJob.getJobname(), toString());
/* 1014 */         resultFile.setComment(BaseMessages.getString(PKG, "JobEntryFTPS.Downloaded", new String[] { this.serverName }));
/* 1015 */         result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*      */         
/* 1017 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.FileAddedToResult", new String[] { filename }));
/*      */       } catch (Exception e) {
/* 1019 */         throw new KettleException(e);
/*      */       } finally {
/*      */         try {
/* 1022 */           targetFile.close();
/* 1023 */           targetFile = null;
/*      */         } catch (Exception e) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void displayResults() {
/* 1030 */     if (isDetailed()) {
/* 1031 */       logDetailed("=======================================");
/* 1032 */       logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.Log.Info.FilesInError", new String[] { "" + this.NrErrors }));
/* 1033 */       logDetailed(BaseMessages.getString(PKG, "JobEntryFTPS.Log.Info.FilesRetrieved", new String[] { "" + this.NrfilesRetrieved }));
/* 1034 */       logDetailed("=======================================");
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean getSuccessStatus() {
/* 1039 */     boolean retval = false;
/*      */     
/* 1041 */     if (((this.NrErrors == 0L) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrfilesRetrieved >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST_X_FILES_DOWNLOADED))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/*      */ 
/* 1045 */       retval = true;
/*      */     }
/*      */     
/* 1048 */     return retval;
/*      */   }
/*      */   
/*      */   private void updateErrors() {
/* 1052 */     this.NrErrors += 1L;
/* 1053 */     if (checkIfSuccessConditionBroken())
/*      */     {
/*      */ 
/* 1056 */       this.successConditionBroken = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean checkIfSuccessConditionBroken() {
/* 1061 */     boolean retval = false;
/* 1062 */     if (((this.NrErrors > 0L) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*      */     {
/*      */ 
/* 1065 */       retval = true;
/*      */     }
/* 1067 */     return retval;
/*      */   }
/*      */   
/*      */   private void updateRetrievedFiles() {
/* 1071 */     this.NrfilesRetrieved += 1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String returnTargetFilename(String filename)
/*      */   {
/* 1082 */     String retval = null;
/*      */     
/* 1084 */     if (filename != null) retval = filename; else {
/* 1085 */       return null;
/*      */     }
/* 1087 */     int lenstring = retval.length();
/* 1088 */     int lastindexOfDot = retval.lastIndexOf(".");
/* 1089 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */     }
/* 1091 */     if (isAddDateBeforeExtension()) { retval = retval.substring(0, lastindexOfDot);
/*      */     }
/* 1093 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 1094 */     Date now = new Date();
/*      */     
/* 1096 */     if ((this.SpecifyFormat) && (!Const.isEmpty(this.date_time_format)))
/*      */     {
/* 1098 */       daf.applyPattern(this.date_time_format);
/* 1099 */       String dt = daf.format(now);
/* 1100 */       retval = retval + dt;
/*      */     } else {
/* 1102 */       if (this.adddate) {
/* 1103 */         daf.applyPattern("yyyyMMdd");
/* 1104 */         String d = daf.format(now);
/* 1105 */         retval = retval + "_" + d;
/*      */       }
/* 1107 */       if (this.addtime) {
/* 1108 */         daf.applyPattern("HHmmssSSS");
/* 1109 */         String t = daf.format(now);
/* 1110 */         retval = retval + "_" + t;
/*      */       }
/*      */     }
/*      */     
/* 1114 */     if (isAddDateBeforeExtension()) {
/* 1115 */       retval = retval + retval.substring(lastindexOfDot, lenstring);
/*      */     }
/*      */     
/* 1118 */     retval = this.localFolder + Const.FILE_SEPARATOR + retval;
/* 1119 */     return retval;
/*      */   }
/*      */   
/*      */   public boolean evaluates()
/*      */   {
/* 1124 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean needsDownload(String filename)
/*      */   {
/* 1138 */     boolean retval = false;
/*      */     
/* 1140 */     File file = new File(filename);
/*      */     
/* 1142 */     if (!file.exists())
/*      */     {
/* 1144 */       if (isDebug()) logDebug(toString(), new Object[] { BaseMessages.getString(PKG, "JobEntryFTPS.LocalFileNotExists", new String[0]), filename });
/* 1145 */       return true;
/*      */     }
/*      */     
/* 1148 */     if (this.ifFileExists == this.ifFileExistsCreateUniq) {
/* 1149 */       if (isDebug()) { logDebug(toString(), new Object[] { BaseMessages.getString(PKG, "JobEntryFTPS.LocalFileExists", new String[0]), filename });
/*      */       }
/*      */       
/* 1152 */       int lenstring = filename.length();
/* 1153 */       int lastindexOfDot = filename.lastIndexOf('.');
/* 1154 */       if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*      */       }
/* 1156 */       filename = filename.substring(0, lastindexOfDot) + StringUtil.getFormattedDateTimeNow(true) + filename.substring(lastindexOfDot, lenstring);
/*      */       
/*      */ 
/*      */ 
/* 1160 */       return true; }
/* 1161 */     if (this.ifFileExists == this.ifFileExistsFail) {
/* 1162 */       logError(toString(), new Object[] { BaseMessages.getString(PKG, "JobEntryFTPS.LocalFileExists", new String[0]), filename });
/* 1163 */       updateErrors();
/*      */     }
/* 1165 */     else if (isDebug()) { logDebug(toString(), new Object[] { BaseMessages.getString(PKG, "JobEntryFTPS.LocalFileExists", new String[0]), filename });
/*      */     }
/*      */     
/*      */ 
/* 1169 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActiveConnection()
/*      */   {
/* 1177 */     return this.activeConnection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getConnectionType()
/*      */   {
/* 1184 */     return this.connectionType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConnectionType(int type)
/*      */   {
/* 1193 */     this.connectionType = type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1201 */   public void setActiveConnection(boolean passive) { this.activeConnection = passive; }
/*      */   
/*      */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 1204 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 1205 */     if (!Const.isEmpty(this.serverName)) {
/* 1206 */       String realServerName = jobMeta.environmentSubstitute(this.serverName);
/* 1207 */       ResourceReference reference = new ResourceReference(this);
/* 1208 */       reference.getEntries().add(new ResourceEntry(realServerName, ResourceEntry.ResourceType.SERVER));
/* 1209 */       references.add(reference);
/*      */     }
/* 1211 */     return references;
/*      */   }
/*      */   
/*      */ 
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1217 */     JobEntryValidatorUtils.andValidator().validate(this, "serverName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1218 */     JobEntryValidatorUtils.andValidator().validate(this, "localDirectory", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() }));
/*      */     
/* 1220 */     JobEntryValidatorUtils.andValidator().validate(this, "userName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 1221 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/* 1222 */     JobEntryValidatorUtils.andValidator().validate(this, "serverPort", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftpsget\JobEntryFTPSGet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */