package org.pentaho.di.core.util;

import org.pentaho.di.trans.step.BaseStepData;
import org.pentaho.di.trans.step.StepDataInterface;

public class GenericStepData
  extends BaseStepData
  implements StepDataInterface
{}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\GenericStepData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */