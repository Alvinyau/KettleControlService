/*     */ package org.pentaho.di.job.entries.delay;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDelay
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  57 */   private static Class<?> PKG = JobEntryDelay.class;
/*     */   
/*  59 */   private static String DEFAULT_MAXIMUM_TIMEOUT = "0";
/*     */   
/*     */   private String maximumTimeout;
/*     */   
/*     */   public int scaleTime;
/*     */   
/*     */   public JobEntryDelay(String n)
/*     */   {
/*  67 */     super(n, "");
/*  68 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryDelay()
/*     */   {
/*  73 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  78 */     JobEntryDelay je = (JobEntryDelay)super.clone();
/*  79 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  84 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/*  86 */     retval.append(super.getXML());
/*  87 */     retval.append("      ").append(XMLHandler.addTagValue("maximumTimeout", this.maximumTimeout));
/*  88 */     retval.append("      ").append(XMLHandler.addTagValue("scaletime", this.scaleTime));
/*     */     
/*  90 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/*  97 */       super.loadXML(entrynode, databases, slaveServers);
/*  98 */       this.maximumTimeout = XMLHandler.getTagValue(entrynode, "maximumTimeout");
/*  99 */       this.scaleTime = Integer.parseInt(XMLHandler.getTagValue(entrynode, "scaletime"));
/*     */     }
/*     */     catch (Exception e) {
/* 102 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDelay.UnableToLoadFromXml.Label", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 110 */       this.maximumTimeout = rep.getJobEntryAttributeString(id_jobentry, "maximumTimeout");
/* 111 */       this.scaleTime = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "scaletime"));
/*     */     }
/*     */     catch (KettleDatabaseException dbe) {
/* 114 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDelay.UnableToLoadFromRepo.Label", new String[0]) + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 126 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "maximumTimeout", this.maximumTimeout);
/* 127 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "scaletime", this.scaleTime);
/*     */     }
/*     */     catch (KettleDatabaseException dbe) {
/* 130 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDelay.UnableToSaveToRepo.Label", new String[0]) + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 142 */     Result result = previousResult;
/* 143 */     result.setResult(false);
/*     */     
/*     */     int Multiple;
/*     */     
/*     */     String Waitscale;
/* 148 */     switch (this.scaleTime)
/*     */     {
/*     */ 
/*     */     case 0: 
/* 152 */       Multiple = 1000;
/* 153 */       Waitscale = BaseMessages.getString(PKG, "JobEntryDelay.SScaleTime.Label", new String[0]);
/* 154 */       break;
/*     */     
/*     */     case 1: 
/* 157 */       Multiple = 60000;
/* 158 */       Waitscale = BaseMessages.getString(PKG, "JobEntryDelay.MnScaleTime.Label", new String[0]);
/* 159 */       break;
/*     */     
/*     */     default: 
/* 162 */       Multiple = 3600000;
/* 163 */       Waitscale = BaseMessages.getString(PKG, "JobEntryDelay.HrScaleTime.Label", new String[0]);
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 171 */       long timeStart = System.currentTimeMillis() / Multiple;
/*     */       
/* 173 */       long iMaximumTimeout = Const.toInt(getrealMaximumTimeout(), Const.toInt(DEFAULT_MAXIMUM_TIMEOUT, 0));
/*     */       
/* 175 */       if (isDetailed())
/*     */       {
/* 177 */         logDetailed(BaseMessages.getString(PKG, "JobEntryDelay.LetsWaitFor.Label", new Object[] { Long.valueOf(iMaximumTimeout), Waitscale }));
/*     */       }
/*     */       
/* 180 */       boolean continueLoop = true;
/*     */       
/*     */ 
/*     */ 
/* 184 */       if (iMaximumTimeout < 0L)
/*     */       {
/* 186 */         iMaximumTimeout = Const.toInt(DEFAULT_MAXIMUM_TIMEOUT, 0);
/* 187 */         logBasic(BaseMessages.getString(PKG, "JobEntryDelay.MaximumTimeReset.Label", new String[] { String.valueOf(iMaximumTimeout), String.valueOf(Waitscale) }));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 192 */       while ((continueLoop) && (!this.parentJob.isStopped()))
/*     */       {
/*     */ 
/* 195 */         long now = System.currentTimeMillis() / Multiple;
/*     */         
/*     */ 
/* 198 */         if ((iMaximumTimeout > 0L) && (now >= timeStart + iMaximumTimeout))
/*     */         {
/*     */ 
/* 201 */           if (this.log.isDetailed())
/*     */           {
/* 203 */             logDetailed(BaseMessages.getString(PKG, "JobEntryDelay.WaitTimeIsElapsed.Label", new String[0]));
/*     */           }
/* 205 */           continueLoop = false;
/* 206 */           result.setResult(true);
/*     */         }
/*     */         else
/*     */         {
/* 210 */           Thread.sleep(100L);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 217 */       result.setResult(false);
/* 218 */       logError("Error  : " + e.getMessage());
/*     */     }
/*     */     
/* 221 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean resetErrorsBeforeExecution()
/*     */   {
/* 228 */     return false;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 233 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 238 */     return false;
/*     */   }
/*     */   
/*     */   public String getMaximumTimeout()
/*     */   {
/* 243 */     return this.maximumTimeout;
/*     */   }
/*     */   
/*     */   public String getrealMaximumTimeout() {
/* 247 */     return environmentSubstitute(getMaximumTimeout());
/*     */   }
/*     */   
/*     */   public void setMaximumTimeout(String s) {
/* 251 */     this.maximumTimeout = s;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 256 */     JobEntryValidatorUtils.andValidator().validate(this, "maximumTimeout", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.longValidator() }));
/* 257 */     JobEntryValidatorUtils.andValidator().validate(this, "scaleTime", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*     */   }
/*     */   
/*     */   public int getScaleTime()
/*     */   {
/* 262 */     return this.scaleTime;
/*     */   }
/*     */   
/*     */   public void setScaleTime(int scaleTime)
/*     */   {
/* 267 */     this.scaleTime = scaleTime;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\delay\JobEntryDelay.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */