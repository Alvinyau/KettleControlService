/*     */ package org.pentaho.di.imp.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*     */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatabaseConfigurationImportRule
/*     */   extends BaseImportRule
/*     */   implements ImportRuleInterface
/*     */ {
/*     */   private DatabaseMeta databaseMeta;
/*     */   
/*     */   public DatabaseConfigurationImportRule()
/*     */   {
/*  44 */     this.databaseMeta = null;
/*     */   }
/*     */   
/*     */   public boolean isUnique() {
/*  48 */     return false;
/*     */   }
/*     */   
/*     */   public ImportRuleInterface clone()
/*     */   {
/*  53 */     DatabaseConfigurationImportRule rule = new DatabaseConfigurationImportRule();
/*  54 */     rule.setId(getId());
/*  55 */     rule.setEnabled(isEnabled());
/*  56 */     if (this.databaseMeta != null) {
/*  57 */       rule.setDatabaseMeta((DatabaseMeta)this.databaseMeta.clone());
/*     */     }
/*  59 */     return rule;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*     */   {
/*  65 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*     */     
/*  67 */     if (!isEnabled()) {
/*  68 */       return feedback;
/*     */     }
/*     */     
/*  71 */     if (this.databaseMeta == null) {
/*  72 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "This rule contains no database to validate against."));
/*  73 */       return feedback;
/*     */     }
/*     */     
/*  76 */     DatabaseMeta verify = null;
/*     */     
/*  78 */     if ((subject instanceof HasDatabasesInterface)) {
/*  79 */       HasDatabasesInterface dbs = (HasDatabasesInterface)subject;
/*  80 */       verify = dbs.findDatabase(this.databaseMeta.getName());
/*  81 */     } else if ((subject instanceof DatabaseMeta))
/*     */     {
/*     */ 
/*  84 */       if (this.databaseMeta.getName().equals(((DatabaseMeta)subject).getName())) {
/*  85 */         verify = (DatabaseMeta)subject;
/*     */       }
/*     */     }
/*     */     
/*  89 */     if (verify == null) {
/*  90 */       return feedback;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  95 */     if ((!Const.isEmpty(this.databaseMeta.getDatabaseName())) && 
/*  96 */       (!this.databaseMeta.getDatabaseName().equals(verify.getDatabaseName()))) {
/*  97 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The name of the database is not set to the expected value '" + this.databaseMeta.getDatabaseName() + "'."));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 103 */     if ((!Const.isEmpty(this.databaseMeta.getHostname())) && 
/* 104 */       (!this.databaseMeta.getHostname().equals(verify.getHostname()))) {
/* 105 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The host name of the database is not set to the expected value '" + this.databaseMeta.getHostname() + "'."));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 111 */     if ((!Const.isEmpty(this.databaseMeta.getDatabasePortNumberString())) && 
/* 112 */       (!this.databaseMeta.getDatabasePortNumberString().equals(verify.getDatabasePortNumberString()))) {
/* 113 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The database port of the database is not set to the expected value '" + this.databaseMeta.getDatabasePortNumberString() + "'."));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     if ((!Const.isEmpty(this.databaseMeta.getUsername())) && 
/* 120 */       (!this.databaseMeta.getUsername().equals(verify.getUsername()))) {
/* 121 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The username of the database is not set to the expected value '" + this.databaseMeta.getUsername() + "'."));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 127 */     if ((!Const.isEmpty(this.databaseMeta.getPassword())) && 
/* 128 */       (!this.databaseMeta.getPassword().equals(verify.getPassword()))) {
/* 129 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "The password of the database is not set to the expected value."));
/*     */     }
/*     */     
/*     */ 
/* 133 */     if (feedback.isEmpty()) {
/* 134 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "The database connection was found and verified."));
/*     */     }
/*     */     
/* 137 */     return feedback;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getXML()
/*     */   {
/* 143 */     StringBuilder xml = new StringBuilder();
/* 144 */     xml.append(XMLHandler.openTag(XML_TAG));
/*     */     
/* 146 */     xml.append(super.getXML());
/*     */     
/* 148 */     if (this.databaseMeta != null) {
/* 149 */       xml.append(this.databaseMeta.getXML());
/*     */     }
/*     */     
/* 152 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 153 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node ruleNode) throws KettleException
/*     */   {
/* 158 */     super.loadXML(ruleNode);
/*     */     
/* 160 */     Node connectionNode = XMLHandler.getSubNode(ruleNode, "connection");
/* 161 */     if (connectionNode != null) {
/* 162 */       this.databaseMeta = new DatabaseMeta(connectionNode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DatabaseMeta getDatabaseMeta()
/*     */   {
/* 170 */     return this.databaseMeta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDatabaseMeta(DatabaseMeta databaseMeta)
/*     */   {
/* 177 */     this.databaseMeta = databaseMeta;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\DatabaseConfigurationImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */