/*     */ package org.pentaho.di.core.reflection;
/*     */ 
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.row.RowMeta;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringSearchResult
/*     */ {
/*  34 */   private static Class<?> PKG = Const.class;
/*     */   
/*     */ 
/*     */   private String string;
/*     */   
/*     */ 
/*     */   private Object parentObject;
/*     */   
/*     */   private String fieldName;
/*     */   
/*     */   private Object grandParentObject;
/*     */   
/*     */ 
/*     */   public StringSearchResult(String string, Object parentObject, Object grandParentObject, String fieldName)
/*     */   {
/*  49 */     this.string = string;
/*  50 */     this.parentObject = parentObject;
/*  51 */     this.grandParentObject = grandParentObject;
/*  52 */     this.fieldName = fieldName;
/*     */   }
/*     */   
/*     */   public Object getParentObject()
/*     */   {
/*  57 */     return this.parentObject;
/*     */   }
/*     */   
/*     */   public void setParentObject(Object parentObject)
/*     */   {
/*  62 */     this.parentObject = parentObject;
/*     */   }
/*     */   
/*     */   public String getString()
/*     */   {
/*  67 */     return this.string;
/*     */   }
/*     */   
/*     */   public void setString(String string)
/*     */   {
/*  72 */     this.string = string;
/*     */   }
/*     */   
/*     */   public static final RowMetaInterface getResultRowMeta()
/*     */   {
/*  77 */     RowMetaInterface rowMeta = new RowMeta();
/*  78 */     rowMeta.addValueMeta(new ValueMeta(BaseMessages.getString(PKG, "SearchResult.TransOrJob", new String[0]), 2));
/*  79 */     rowMeta.addValueMeta(new ValueMeta(BaseMessages.getString(PKG, "SearchResult.StepDatabaseNotice", new String[0]), 2));
/*  80 */     rowMeta.addValueMeta(new ValueMeta(BaseMessages.getString(PKG, "SearchResult.String", new String[0]), 2));
/*  81 */     rowMeta.addValueMeta(new ValueMeta(BaseMessages.getString(PKG, "SearchResult.FieldName", new String[0]), 2));
/*  82 */     return rowMeta;
/*     */   }
/*     */   
/*     */   public Object[] toRow()
/*     */   {
/*  87 */     return new Object[] { this.grandParentObject.toString(), this.parentObject.toString(), this.string, this.fieldName };
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  92 */     StringBuffer sb = new StringBuffer();
/*  93 */     sb.append(this.parentObject.toString()).append(" : ").append(this.string);
/*  94 */     sb.append(" (").append(this.fieldName).append(")");
/*  95 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldName()
/*     */   {
/* 103 */     return this.fieldName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldName(String fieldName)
/*     */   {
/* 111 */     this.fieldName = fieldName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getGrandParentObject()
/*     */   {
/* 119 */     return this.grandParentObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGrandParentObject(Object grandParentObject)
/*     */   {
/* 127 */     this.grandParentObject = grandParentObject;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\reflection\StringSearchResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */