/*     */ package org.pentaho.di.job.entries.folderisempty;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileSelector;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFolderIsEmpty
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  67 */   private static Class<?> PKG = JobEntryFolderIsEmpty.class;
/*     */   
/*     */   private String foldername;
/*     */   private int filescount;
/*     */   private int folderscount;
/*     */   private boolean includeSubfolders;
/*     */   private boolean specifywildcard;
/*     */   private String wildcard;
/*     */   private Pattern pattern;
/*     */   
/*     */   public JobEntryFolderIsEmpty(String n)
/*     */   {
/*  79 */     super(n, "");
/*  80 */     this.foldername = null;
/*  81 */     this.wildcard = null;
/*  82 */     this.includeSubfolders = false;
/*  83 */     this.specifywildcard = false;
/*  84 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryFolderIsEmpty()
/*     */   {
/*  89 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  94 */     JobEntryFolderIsEmpty je = (JobEntryFolderIsEmpty)super.clone();
/*  95 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 100 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 102 */     retval.append(super.getXML());
/* 103 */     retval.append("      ").append(XMLHandler.addTagValue("foldername", this.foldername));
/* 104 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.includeSubfolders));
/* 105 */     retval.append("      ").append(XMLHandler.addTagValue("specify_wildcard", this.specifywildcard));
/* 106 */     retval.append("      ").append(XMLHandler.addTagValue("wildcard", this.wildcard));
/*     */     
/* 108 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 115 */       super.loadXML(entrynode, databases, slaveServers);
/* 116 */       this.foldername = XMLHandler.getTagValue(entrynode, "foldername");
/* 117 */       this.includeSubfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/* 118 */       this.specifywildcard = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "specify_wildcard"));
/* 119 */       this.wildcard = XMLHandler.getTagValue(entrynode, "wildcard");
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 123 */       throw new KettleXMLException("Unable to load job entry of type 'create folder' from XML node", xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 131 */       this.foldername = rep.getJobEntryAttributeString(id_jobentry, "foldername");
/* 132 */       this.includeSubfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/* 133 */       this.specifywildcard = rep.getJobEntryAttributeBoolean(id_jobentry, "specify_wildcard");
/* 134 */       this.wildcard = rep.getJobEntryAttributeString(id_jobentry, "wildcard");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 138 */       throw new KettleException("Unable to load job entry of type 'create Folder' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 146 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "foldername", this.foldername);
/* 147 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.includeSubfolders);
/* 148 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "specify_wildcard", this.specifywildcard);
/* 149 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wildcard", this.wildcard);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 153 */       throw new KettleException("Unable to save job entry of type 'create Folder' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setSpecifyWildcard(boolean specifywildcard)
/*     */   {
/* 159 */     this.specifywildcard = specifywildcard;
/*     */   }
/*     */   
/*     */   public boolean isSpecifyWildcard()
/*     */   {
/* 164 */     return this.specifywildcard;
/*     */   }
/*     */   
/*     */   public void setFoldername(String foldername) {
/* 168 */     this.foldername = foldername;
/*     */   }
/*     */   
/*     */   public String getFoldername()
/*     */   {
/* 173 */     return this.foldername;
/*     */   }
/*     */   
/*     */   public String getRealFoldername()
/*     */   {
/* 178 */     return environmentSubstitute(getFoldername());
/*     */   }
/*     */   
/*     */   public String getWildcard()
/*     */   {
/* 183 */     return this.wildcard;
/*     */   }
/*     */   
/*     */   public String getRealWildcard()
/*     */   {
/* 188 */     return environmentSubstitute(getWildcard());
/*     */   }
/*     */   
/*     */   public void setWildcard(String wildcard) {
/* 192 */     this.wildcard = wildcard;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubFolders() {
/* 196 */     return this.includeSubfolders;
/*     */   }
/*     */   
/*     */   public void setIncludeSubFolders(boolean includeSubfolders)
/*     */   {
/* 201 */     this.includeSubfolders = includeSubfolders;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr) {
/* 205 */     Result result = previousResult;
/* 206 */     result.setResult(false);
/* 207 */     result.setNrErrors(1L);
/*     */     
/* 209 */     this.filescount = 0;
/* 210 */     this.folderscount = 0;
/* 211 */     this.pattern = null;
/*     */     
/* 213 */     if (!Const.isEmpty(getWildcard())) { this.pattern = Pattern.compile(getRealWildcard());
/*     */     }
/* 215 */     if (this.foldername != null)
/*     */     {
/* 217 */       String realFoldername = getRealFoldername();
/* 218 */       FileObject folderObject = null;
/*     */       try {
/* 220 */         folderObject = KettleVFS.getFileObject(realFoldername, this);
/*     */         
/* 222 */         if (folderObject.exists())
/*     */         {
/*     */ 
/* 225 */           if (folderObject.getType() == FileType.FOLDER)
/*     */           {
/*     */ 
/* 228 */             folderObject.findFiles(new TextFileSelector(folderObject.toString()));
/* 229 */             if (this.log.isBasic()) this.log.logBasic("Total files", new Object[] { "We found : " + this.filescount + " file(s)" });
/* 230 */             if (this.filescount == 0)
/*     */             {
/* 232 */               result.setResult(true);
/* 233 */               result.setNrErrors(0L);
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 239 */             this.log.logError("[" + realFoldername + "] is not a folder, failing.");
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 245 */         else if (this.log.isBasic()) logBasic("we can not find [" + realFoldername + "] !");
/*     */       }
/*     */       catch (Exception e) {
/* 248 */         logError("Error checking folder [" + realFoldername + "]", e);
/* 249 */         result.setResult(false);
/* 250 */         result.setNrErrors(1L);
/*     */       }
/*     */       finally {
/* 253 */         if (folderObject != null) {
/*     */           try
/*     */           {
/* 256 */             folderObject.close();
/* 257 */             folderObject = null;
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 265 */       logError("No Foldername is defined.");
/*     */     }
/*     */     
/* 268 */     return result;
/*     */   }
/*     */   
/*     */   private class TextFileSelector implements FileSelector
/*     */   {
/* 273 */     String root_folder = null;
/*     */     
/*     */     public TextFileSelector(String rootfolder)
/*     */     {
/* 277 */       if (rootfolder != null)
/*     */       {
/* 279 */         this.root_folder = rootfolder;
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean includeFile(FileSelectInfo info)
/*     */     {
/* 285 */       boolean returncode = false;
/* 286 */       FileObject file_name = null;
/*     */       
/*     */       try
/*     */       {
/* 290 */         if (!info.getFile().toString().equals(this.root_folder))
/*     */         {
/*     */ 
/* 293 */           if (info.getFile().getType() == FileType.FILE)
/*     */           {
/* 295 */             if (info.getFile().getParent().equals(info.getBaseFolder()))
/*     */             {
/*     */ 
/* 298 */               if (((JobEntryFolderIsEmpty.this.isSpecifyWildcard()) && (JobEntryFolderIsEmpty.this.GetFileWildcard(info.getFile().getName().getBaseName()))) || (!JobEntryFolderIsEmpty.this.isSpecifyWildcard()))
/*     */               {
/* 300 */                 if (JobEntryFolderIsEmpty.this.log.isDetailed()) JobEntryFolderIsEmpty.this.log.logDetailed("We found file : " + info.getFile().toString());
/* 301 */                 JobEntryFolderIsEmpty.access$308(JobEntryFolderIsEmpty.this);
/*     */ 
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */             }
/* 308 */             else if (JobEntryFolderIsEmpty.this.isIncludeSubFolders())
/*     */             {
/* 310 */               if (((JobEntryFolderIsEmpty.this.isSpecifyWildcard()) && (JobEntryFolderIsEmpty.this.GetFileWildcard(info.getFile().getName().getBaseName()))) || (!JobEntryFolderIsEmpty.this.isSpecifyWildcard()))
/*     */               {
/* 312 */                 if (JobEntryFolderIsEmpty.this.log.isDetailed()) JobEntryFolderIsEmpty.this.log.logDetailed("We found file : " + info.getFile().toString());
/* 313 */                 JobEntryFolderIsEmpty.access$308(JobEntryFolderIsEmpty.this);
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */           else {
/* 320 */             JobEntryFolderIsEmpty.access$608(JobEntryFolderIsEmpty.this);
/*     */           }
/*     */         }
/* 323 */         return true;
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 328 */         JobEntryFolderIsEmpty.this.log.logError(BaseMessages.getString(JobEntryFolderIsEmpty.PKG, "JobFolderIsEmpty.Error", new String[0]), new Object[] { BaseMessages.getString(JobEntryFolderIsEmpty.PKG, "JobFolderIsEmpty.Error.Exception", new String[] { info.getFile().toString(), e.getMessage() }) });
/*     */         
/*     */ 
/* 331 */         returncode = false;
/*     */       }
/*     */       finally
/*     */       {
/* 335 */         if (file_name != null)
/*     */         {
/*     */           try
/*     */           {
/* 339 */             file_name.close();
/* 340 */             file_name = null;
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/* 345 */       return returncode;
/*     */     }
/*     */     
/*     */     public boolean traverseDescendents(FileSelectInfo info)
/*     */     {
/* 350 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile)
/*     */   {
/* 361 */     boolean getIt = true;
/*     */     
/*     */ 
/* 364 */     if (this.pattern != null)
/*     */     {
/* 366 */       Matcher matcher = this.pattern.matcher(selectedfile);
/* 367 */       getIt = matcher.matches();
/*     */     }
/* 369 */     return getIt;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 374 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 380 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\folderisempty\JobEntryFolderIsEmpty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */