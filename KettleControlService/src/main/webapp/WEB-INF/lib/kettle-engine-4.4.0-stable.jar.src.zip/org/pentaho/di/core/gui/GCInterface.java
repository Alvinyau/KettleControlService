/*    */ package org.pentaho.di.core.gui;
/*    */ 
/*    */ import org.pentaho.di.job.entry.JobEntryCopy;
/*    */ import org.pentaho.di.trans.step.StepMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface GCInterface
/*    */ {
/*    */   public abstract void setLineWidth(int paramInt);
/*    */   
/*    */   public abstract void setFont(EFont paramEFont);
/*    */   
/*    */   public abstract Point textExtent(String paramString);
/*    */   
/*    */   public abstract Point getDeviceBounds();
/*    */   
/*    */   public abstract void setBackground(EColor paramEColor);
/*    */   
/*    */   public abstract void setForeground(EColor paramEColor);
/*    */   
/*    */   public abstract void setBackground(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   public abstract void setForeground(int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   public static enum EColor
/*    */   {
/* 31 */     BACKGROUND,  BLACK,  RED,  YELLOW,  ORANGE,  GREEN,  BLUE,  MAGENTA,  GRAY,  LIGHTGRAY,  DARKGRAY;
/* 32 */     private EColor() {} } public static enum EFont { NOTE,  GRAPH,  SMALL;
/* 33 */     private EFont() {} } public static enum ELineStyle { SOLID,  DASHDOT,  DOT,  PARALLEL;
/* 34 */     private ELineStyle() {} } public static enum EImage { LOCK,  STEP_ERROR,  EDIT,  CONTEXT_MENU,  TRUE,  FALSE,  ERROR,  INFO,  TARGET,  INPUT,  OUTPUT,  ARROW,  COPY_ROWS, 
/* 35 */     UNCONDITIONAL,  PARALLEL,  BUSY;
/*    */     
/*    */     private EImage() {}
/*    */   }
/*    */   
/*    */   public abstract void fillRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public abstract void drawImage(EImage paramEImage, int paramInt1, int paramInt2);
/*    */   
/*    */   public abstract void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public abstract void setLineStyle(ELineStyle paramELineStyle);
/*    */   
/*    */   public abstract void drawRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public abstract void drawPoint(int paramInt1, int paramInt2);
/*    */   
/*    */   public abstract void drawText(String paramString, int paramInt1, int paramInt2);
/*    */   
/*    */   public abstract void drawText(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);
/*    */   
/*    */   public abstract void fillRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*    */   
/*    */   public abstract void drawRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*    */   
/*    */   public abstract void fillPolygon(int[] paramArrayOfInt);
/*    */   
/*    */   public abstract void drawPolygon(int[] paramArrayOfInt);
/*    */   
/*    */   public abstract void drawPolyline(int[] paramArrayOfInt);
/*    */   
/*    */   public abstract void drawJobEntryIcon(int paramInt1, int paramInt2, JobEntryCopy paramJobEntryCopy);
/*    */   
/*    */   public abstract void drawStepIcon(int paramInt1, int paramInt2, StepMeta paramStepMeta);
/*    */   
/*    */   public abstract void setAntialias(boolean paramBoolean);
/*    */   
/*    */   public abstract void setTransform(float paramFloat1, float paramFloat2, int paramInt, float paramFloat3);
/*    */   
/*    */   public abstract void setAlpha(int paramInt);
/*    */   
/*    */   public abstract void dispose();
/*    */   
/*    */   public abstract int getAlpha();
/*    */   
/*    */   public abstract void setFont(String paramString, int paramInt, boolean paramBoolean1, boolean paramBoolean2);
/*    */   
/*    */   public abstract Object getImage();
/*    */   
/*    */   public abstract Point getImageBounds(EImage paramEImage);
/*    */   
/*    */   public abstract void switchForegroundBackgroundColors();
/*    */   
/*    */   public abstract Point getArea();
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\GCInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */