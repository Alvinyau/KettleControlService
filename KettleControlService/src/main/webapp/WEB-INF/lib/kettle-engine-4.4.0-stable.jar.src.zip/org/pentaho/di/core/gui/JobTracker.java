/*     */ package org.pentaho.di.core.gui;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.util.EnvUtil;
/*     */ import org.pentaho.di.job.JobEntryResult;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryCopy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobTracker
/*     */ {
/*     */   private List<JobTracker> jobTrackers;
/*     */   private JobEntryResult result;
/*     */   private JobTracker parentJobTracker;
/*     */   private String jobName;
/*     */   private String jobFilename;
/*     */   private int maxChildren;
/*     */   
/*     */   public JobTracker(JobMeta jobMeta)
/*     */   {
/*  61 */     if (jobMeta != null) {
/*  62 */       this.jobName = jobMeta.getName();
/*  63 */       this.jobFilename = jobMeta.getFilename();
/*     */     }
/*     */     
/*  66 */     this.jobTrackers = new LinkedList();
/*  67 */     this.maxChildren = Const.toInt(EnvUtil.getSystemProperty("KETTLE_MAX_JOB_TRACKER_SIZE"), 5000);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JobTracker(JobMeta jobMeta, int maxChildren)
/*     */   {
/*  75 */     if (jobMeta != null) {
/*  76 */       this.jobName = jobMeta.getName();
/*  77 */       this.jobFilename = jobMeta.getFilename();
/*     */     }
/*     */     
/*  80 */     this.jobTrackers = new LinkedList();
/*  81 */     this.maxChildren = maxChildren;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JobTracker(JobMeta jobMeta, JobEntryResult result)
/*     */   {
/*  91 */     this(jobMeta);
/*  92 */     this.result = result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JobTracker(JobMeta jobMeta, int maxChildren, JobEntryResult result)
/*     */   {
/* 103 */     this(jobMeta, maxChildren);
/* 104 */     this.result = result;
/*     */   }
/*     */   
/*     */   public void addJobTracker(JobTracker jobTracker) {
/* 108 */     this.jobTrackers.add(jobTracker);
/* 109 */     if (this.jobTrackers.size() > this.maxChildren + 50) {
/* 110 */       this.jobTrackers = this.jobTrackers.subList(50, this.jobTrackers.size());
/*     */     }
/*     */   }
/*     */   
/*     */   public JobTracker getJobTracker(int i) {
/* 115 */     return (JobTracker)this.jobTrackers.get(i);
/*     */   }
/*     */   
/*     */   public int nrJobTrackers() {
/* 119 */     return this.jobTrackers.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<JobTracker> getJobTrackers()
/*     */   {
/* 126 */     return this.jobTrackers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJobTrackers(List<JobTracker> jobTrackers)
/*     */   {
/* 134 */     this.jobTrackers = jobTrackers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JobEntryResult getJobEntryResult()
/*     */   {
/* 141 */     return this.result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJobEntryResult(JobEntryResult result)
/*     */   {
/* 149 */     this.result = result;
/*     */   }
/*     */   
/*     */   public void clear() {
/* 153 */     this.jobTrackers.clear();
/* 154 */     this.result = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JobTracker findJobTracker(JobEntryCopy jobEntryCopy)
/*     */   {
/* 165 */     for (int i = this.jobTrackers.size() - 1; i >= 0; i--) {
/* 166 */       JobTracker tracker = getJobTracker(i);
/* 167 */       JobEntryResult result = tracker.getJobEntryResult();
/* 168 */       if ((result != null) && 
/* 169 */         (jobEntryCopy.getName() != null) && (jobEntryCopy.getName().equals(result.getJobEntryName())) && (jobEntryCopy.getNr() == result.getJobEntryNr())) {
/* 170 */         return tracker;
/*     */       }
/*     */     }
/*     */     
/* 174 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JobTracker getParentJobTracker()
/*     */   {
/* 181 */     return this.parentJobTracker;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentJobTracker(JobTracker parentJobTracker)
/*     */   {
/* 189 */     this.parentJobTracker = parentJobTracker;
/*     */   }
/*     */   
/*     */   public int getTotalNumberOfItems() {
/* 193 */     int total = 1;
/*     */     
/* 195 */     for (int i = 0; i < nrJobTrackers(); i++) {
/* 196 */       total += getJobTracker(i).getTotalNumberOfItems();
/*     */     }
/*     */     
/* 199 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getJobFilename()
/*     */   {
/* 206 */     return this.jobFilename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJobFilename(String jobFilename)
/*     */   {
/* 214 */     this.jobFilename = jobFilename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getJobName()
/*     */   {
/* 221 */     return this.jobName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJobName(String jobName)
/*     */   {
/* 229 */     this.jobName = jobName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxChildren()
/*     */   {
/* 236 */     return this.maxChildren;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxChildren(int maxChildren)
/*     */   {
/* 244 */     this.maxChildren = maxChildren;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\JobTracker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */