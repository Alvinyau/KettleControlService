/*    */ package org.pentaho.di.imp.rules;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.xml.XMLHandler;
/*    */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*    */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*    */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*    */ import org.pentaho.di.trans.TransMeta;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformationHasANoteImportRule
/*    */   extends BaseImportRule
/*    */   implements ImportRuleInterface
/*    */ {
/*    */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*    */   {
/* 45 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*    */     
/* 47 */     if (!isEnabled()) return feedback;
/* 48 */     if (!(subject instanceof TransMeta)) { return feedback;
/*    */     }
/* 50 */     TransMeta transMeta = (TransMeta)subject;
/*    */     
/* 52 */     if (transMeta.nrNotes() == 0) {
/* 53 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "There is not even a single note in the transformation."));
/*    */     } else {
/* 55 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "At least one not is present in the transformation."));
/*    */     }
/*    */     
/* 58 */     return feedback;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getXML()
/*    */   {
/* 64 */     StringBuilder xml = new StringBuilder();
/* 65 */     xml.append(XMLHandler.openTag(XML_TAG));
/*    */     
/* 67 */     xml.append(super.getXML());
/*    */     
/* 69 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 70 */     return xml.toString();
/*    */   }
/*    */   
/*    */   public void loadXML(Node ruleNode) throws KettleException
/*    */   {
/* 75 */     super.loadXML(ruleNode);
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\TransformationHasANoteImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */