/*     */ package org.pentaho.di.job.entries.dtdvalidator;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DTDValidator
/*     */ {
/*  47 */   private static Class<?> PKG = JobEntryDTDValidator.class;
/*     */   
/*     */   private String xmlfilename;
/*     */   private String xsdfilename;
/*     */   private boolean interndtd;
/*     */   private String errormessage;
/*     */   private int errorscount;
/*     */   private LogChannelInterface log;
/*     */   
/*     */   public DTDValidator(LogChannelInterface log)
/*     */   {
/*  58 */     this.log = log;
/*  59 */     this.xmlfilename = null;
/*  60 */     this.xsdfilename = null;
/*  61 */     this.interndtd = false;
/*  62 */     this.errormessage = null;
/*  63 */     this.errorscount = 0;
/*     */   }
/*     */   
/*     */   public void setXMLFilename(String xmlfilename) {
/*  67 */     this.xmlfilename = xmlfilename;
/*     */   }
/*     */   
/*  70 */   public String getXMLFilename() { return this.xmlfilename; }
/*     */   
/*     */   public void setDTDFilename(String xsdfilename) {
/*  73 */     this.xsdfilename = xsdfilename;
/*     */   }
/*     */   
/*  76 */   public String getDTDFilename() { return this.xsdfilename; }
/*     */   
/*     */   public void setInternDTD(boolean value) {
/*  79 */     this.interndtd = value;
/*     */   }
/*     */   
/*  82 */   public boolean isInternDTD() { return this.interndtd; }
/*     */   
/*     */   private void setErrorMessage(String value)
/*     */   {
/*  86 */     this.errormessage = value;
/*     */   }
/*     */   
/*  89 */   public String getErrorMessage() { return this.errormessage; }
/*     */   
/*     */   public int getNrErrors() {
/*  92 */     return this.errorscount;
/*     */   }
/*     */   
/*  95 */   private void setNrErrors(int value) { this.errorscount = value; }
/*     */   
/*     */   public boolean validate()
/*     */   {
/*  99 */     boolean retval = false;
/*     */     
/* 101 */     FileObject xmlfile = null;
/* 102 */     FileObject DTDfile = null;
/*     */     
/* 104 */     ByteArrayInputStream ba = null;
/*     */     try {
/* 106 */       if ((this.xmlfilename != null) && (((getDTDFilename() != null) && (!isInternDTD())) || (isInternDTD()))) {
/* 107 */         xmlfile = KettleVFS.getFileObject(getXMLFilename());
/*     */         
/* 109 */         if (xmlfile.exists())
/*     */         {
/* 111 */           URL xmlFile = new File(KettleVFS.getFilename(xmlfile)).toURI().toURL();
/* 112 */           StringBuffer xmlStringbuffer = new StringBuffer("");
/*     */           
/* 114 */           BufferedReader xmlBufferedReader = null;
/* 115 */           InputStreamReader is = null;
/*     */           try
/*     */           {
/* 118 */             is = new InputStreamReader(xmlFile.openStream());
/* 119 */             xmlBufferedReader = new BufferedReader(is);
/*     */             
/* 121 */             char[] buffertXML = new char['Ѐ'];
/* 122 */             int LenXML = -1;
/* 123 */             while ((LenXML = xmlBufferedReader.read(buffertXML)) != -1)
/* 124 */               xmlStringbuffer.append(buffertXML, 0, LenXML);
/*     */           } finally {
/* 126 */             if (is != null) is.close();
/* 127 */             if (xmlBufferedReader != null) { xmlBufferedReader.close();
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 132 */           DocumentBuilderFactory DocBuilderFactory = DocumentBuilderFactory.newInstance();
/* 133 */           DocumentBuilder DocBuilder = DocBuilderFactory.newDocumentBuilder();
/*     */           
/*     */ 
/*     */ 
/* 137 */           DocBuilderFactory.setValidating(false);
/* 138 */           ba = new ByteArrayInputStream(xmlStringbuffer.toString().getBytes("UTF-8"));
/* 139 */           Document xmlDocDTD = DocBuilder.parse(ba);
/* 140 */           if (ba != null) { ba.close();
/*     */           }
/* 142 */           String encoding = null;
/* 143 */           if (xmlDocDTD.getXmlEncoding() == null) {
/* 144 */             encoding = "UTF-8";
/*     */           } else {
/* 146 */             encoding = xmlDocDTD.getXmlEncoding();
/*     */           }
/*     */           
/* 149 */           int xmlStartDTD = xmlStringbuffer.indexOf("<!DOCTYPE");
/*     */           
/* 151 */           if (isInternDTD())
/*     */           {
/* 153 */             if (xmlStartDTD != -1) {
/* 154 */               this.log.logBasic(BaseMessages.getString(PKG, "JobEntryDTDValidator.ERRORDTDFound.Label", new String[] { getXMLFilename() }));
/*     */             } else {
/* 156 */               setErrorMessage(BaseMessages.getString(PKG, "JobEntryDTDValidator.ERRORDTDNotFound.Label", new String[] { getXMLFilename() }));
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 162 */             DTDfile = KettleVFS.getFileObject(getDTDFilename());
/*     */             
/* 164 */             if (DTDfile.exists()) {
/* 165 */               if (xmlStartDTD != -1) {
/* 166 */                 int EndDTD = xmlStringbuffer.indexOf(">", xmlStartDTD);
/*     */                 
/* 168 */                 xmlStringbuffer.replace(xmlStartDTD, EndDTD + 1, "");
/*     */               }
/*     */               
/* 171 */               String xmlRootnodeDTD = xmlDocDTD.getDocumentElement().getNodeName();
/*     */               
/* 173 */               String RefDTD = "<?xml version='" + xmlDocDTD.getXmlVersion() + "' encoding='" + encoding + "'?>\n<!DOCTYPE " + xmlRootnodeDTD + " SYSTEM '" + KettleVFS.getFilename(DTDfile) + "'>\n";
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 178 */               int xmloffsetDTD = xmlStringbuffer.indexOf("<" + xmlRootnodeDTD);
/* 179 */               xmlStringbuffer.replace(0, xmloffsetDTD, RefDTD);
/*     */             } else {
/* 181 */               this.log.logError(BaseMessages.getString(PKG, "JobEntryDTDValidator.ERRORDTDFileNotExists.Subject", new String[0]), new Object[] { BaseMessages.getString(PKG, "JobEntryDTDValidator.ERRORDTDFileNotExists.Msg", new String[] { getDTDFilename() }) });
/*     */             }
/*     */           }
/*     */           
/* 185 */           if (((!isInternDTD()) || (xmlStartDTD != -1)) && ((isInternDTD()) || (DTDfile.exists())))
/*     */           {
/*     */ 
/*     */ 
/* 189 */             MyErrorHandler error = new MyErrorHandler(null);
/* 190 */             DocBuilderFactory.setValidating(true);
/* 191 */             DocBuilder = DocBuilderFactory.newDocumentBuilder();
/* 192 */             DocBuilder.setErrorHandler(error);
/*     */             
/* 194 */             ba = new ByteArrayInputStream(xmlStringbuffer.toString().getBytes(encoding));
/* 195 */             xmlDocDTD = DocBuilder.parse(ba);
/*     */             
/* 197 */             if (error.errorMessage == null) {
/* 198 */               this.log.logBasic(BaseMessages.getString(PKG, "JobEntryDTDValidator.DTDValidatorOK.Subject", new String[0]), new Object[] { BaseMessages.getString(PKG, "JobEntryDTDValidator.DTDValidatorOK.Label", new String[] { getXMLFilename() }) });
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 203 */               retval = true;
/*     */             }
/*     */             else {
/* 206 */               setNrErrors(error.nrErrors);
/* 207 */               setErrorMessage(BaseMessages.getString(PKG, "JobEntryDTDValidator.DTDValidatorKO", new Object[] { getXMLFilename(), Integer.valueOf(error.nrErrors), error.errorMessage }));
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 212 */         else if (!xmlfile.exists()) {
/* 213 */           setErrorMessage(BaseMessages.getString(PKG, "JobEntryDTDValidator.FileDoesNotExist.Label", new String[] { getXMLFilename() }));
/*     */         }
/*     */       }
/*     */       else {
/* 217 */         setErrorMessage(BaseMessages.getString(PKG, "JobEntryDTDValidator.AllFilesNotNull.Label", new String[0]));
/*     */       }
/*     */     } catch (Exception e) {
/* 220 */       setErrorMessage(BaseMessages.getString(PKG, "JobEntryDTDValidator.ErrorDTDValidator.Label", new String[] { getXMLFilename(), getDTDFilename(), e.getMessage() }));
/*     */     }
/*     */     finally {
/*     */       try {
/* 224 */         if (xmlfile != null) xmlfile.close();
/* 225 */         if (DTDfile != null) DTDfile.close();
/* 226 */         if (ba != null) ba.close();
/*     */       } catch (IOException e) {}
/*     */     }
/* 229 */     return retval;
/*     */   }
/*     */   
/*     */   private static class MyErrorHandler implements ErrorHandler {
/* 233 */     String errorMessage = null;
/* 234 */     int error = -1;
/* 235 */     int nrErrors = 0;
/*     */     
/* 237 */     public void warning(SAXParseException e) throws SAXException { this.error = 0;
/* 238 */       allErrors(e);
/*     */     }
/*     */     
/* 241 */     public void error(SAXParseException e) throws SAXException { this.error = 1;
/* 242 */       allErrors(e);
/*     */     }
/*     */     
/* 245 */     public void fatalError(SAXParseException e) throws SAXException { this.error = 2;
/* 246 */       allErrors(e);
/*     */     }
/*     */     
/* 249 */     private void allErrors(SAXParseException e) { this.nrErrors += 1;
/* 250 */       if (this.errorMessage == null) this.errorMessage = "";
/* 251 */       this.errorMessage = (this.errorMessage + Const.CR + Const.CR + "Error Nr." + this.nrErrors + " (");
/* 252 */       switch (this.error) {
/* 253 */       case 0:  this.errorMessage += "Warning"; break;
/* 254 */       case 1:  this.errorMessage += "Error"; break;
/* 255 */       case 2:  this.errorMessage += "FatalError"; break;
/*     */       }
/*     */       
/* 258 */       this.errorMessage = (this.errorMessage + ")" + Const.CR + "              Public ID: " + e.getPublicId() + Const.CR + "              System ID: " + e.getSystemId() + Const.CR + "              Line number: " + e.getLineNumber() + Const.CR + "              Column number: " + e.getColumnNumber() + Const.CR + "              Message: " + e.getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\dtdvalidator\DTDValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */