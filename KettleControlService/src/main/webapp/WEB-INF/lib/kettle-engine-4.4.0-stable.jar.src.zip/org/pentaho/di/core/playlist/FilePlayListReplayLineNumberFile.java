/*    */ package org.pentaho.di.core.playlist;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.vfs.FileName;
/*    */ import org.apache.commons.vfs.FileObject;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.vfs.KettleVFS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilePlayListReplayLineNumberFile
/*    */   extends FilePlayListReplayFile
/*    */ {
/* 37 */   Set<Long> lineNumbers = new HashSet();
/*    */   
/*    */   public FilePlayListReplayLineNumberFile(FileObject lineNumberFile, String encoding, FileObject processingFile, String filePart) throws KettleException
/*    */   {
/* 41 */     super(processingFile, filePart);
/* 42 */     initialize(lineNumberFile, encoding);
/*    */   }
/*    */   
/*    */   private void initialize(FileObject lineNumberFile, String encoding) throws KettleException
/*    */   {
/* 47 */     BufferedReader reader = null;
/*    */     try
/*    */     {
/* 50 */       if (encoding == null) {
/* 51 */         reader = new BufferedReader(new InputStreamReader(KettleVFS.getInputStream(lineNumberFile)));
/*    */       } else
/* 53 */         reader = new BufferedReader(new InputStreamReader(KettleVFS.getInputStream(lineNumberFile), encoding));
/* 54 */       String line = null;
/* 55 */       while ((line = reader.readLine()) != null)
/*    */       {
/* 57 */         if (line.length() > 0) this.lineNumbers.add(Long.valueOf(line));
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 62 */       throw new KettleException("Could not read line number file " + lineNumberFile.getName().getURI(), e);
/*    */     }
/*    */     finally
/*    */     {
/* 66 */       if (reader != null) {
/*    */         try {
/* 68 */           reader.close();
/*    */         }
/*    */         catch (IOException e)
/*    */         {
/* 72 */           throw new KettleException("Could not close line number file " + lineNumberFile.getName().getURI(), e);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isProcessingNeeded(FileObject file, long lineNr, String filePart) throws KettleException {
/* 79 */     return this.lineNumbers.contains(new Long(lineNr));
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\playlist\FilePlayListReplayLineNumberFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */