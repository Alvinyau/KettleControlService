/*      */ package org.pentaho.di.job.entries.job;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.UUID;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.ObjectLocationSpecificationMethod;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.RowMetaAndData;
/*      */ import org.pentaho.di.core.SQLStatement;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.gui.JobTracker;
/*      */ import org.pentaho.di.core.logging.LogChannelFileWriter;
/*      */ import org.pentaho.di.core.logging.LogChannelInterface;
/*      */ import org.pentaho.di.core.logging.LogLevel;
/*      */ import org.pentaho.di.core.parameters.DuplicateParamException;
/*      */ import org.pentaho.di.core.parameters.NamedParams;
/*      */ import org.pentaho.di.core.parameters.NamedParamsDefault;
/*      */ import org.pentaho.di.core.variables.VariableSpace;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobExecutionConfiguration;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.pentaho.di.repository.RepositoryDirectory;
/*      */ import org.pentaho.di.repository.RepositoryDirectoryInterface;
/*      */ import org.pentaho.di.repository.RepositoryImportLocation;
/*      */ import org.pentaho.di.repository.RepositoryObject;
/*      */ import org.pentaho.di.repository.RepositoryObjectType;
/*      */ import org.pentaho.di.repository.StringObjectId;
/*      */ import org.pentaho.di.resource.ResourceDefinition;
/*      */ import org.pentaho.di.resource.ResourceEntry;
/*      */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*      */ import org.pentaho.di.resource.ResourceNamingInterface;
/*      */ import org.pentaho.di.resource.ResourceReference;
/*      */ import org.pentaho.di.www.SlaveServerJobStatus;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryJob
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   90 */   private static Class<?> PKG = JobEntryJob.class;
/*      */   
/*      */   private String filename;
/*      */   
/*      */   private String jobname;
/*      */   
/*      */   private String directory;
/*      */   
/*      */   private ObjectId jobObjectId;
/*      */   private ObjectLocationSpecificationMethod specificationMethod;
/*      */   public String[] arguments;
/*      */   public boolean argFromPrevious;
/*      */   public boolean paramsFromPrevious;
/*      */   public boolean execPerRow;
/*      */   public String[] parameters;
/*      */   public String[] parameterFieldNames;
/*      */   public String[] parameterValues;
/*      */   public boolean setLogfile;
/*      */   public String logfile;
/*      */   public String logext;
/*      */   public boolean addDate;
/*      */   public boolean addTime;
/*      */   public LogLevel logFileLevel;
/*      */   public boolean parallel;
/*      */   private String directoryPath;
/*      */   public boolean setAppendLogfile;
/*      */   public boolean createParentFolder;
/*  117 */   public boolean waitingToFinish = true;
/*      */   
/*      */   public boolean followingAbortRemotely;
/*      */   private String remoteSlaveServerName;
/*  121 */   public boolean passingAllParameters = true;
/*      */   
/*      */   private boolean passingExport;
/*      */   
/*  125 */   public static final LogLevel DEFAULT_LOG_LEVEL = LogLevel.NOTHING;
/*      */   private Job job;
/*      */   
/*      */   public JobEntryJob(String name)
/*      */   {
/*  130 */     super(name, "");
/*      */   }
/*      */   
/*      */   public JobEntryJob() {
/*  134 */     this("");
/*  135 */     clear();
/*      */   }
/*      */   
/*      */   public Object clone() {
/*  139 */     JobEntryJob je = (JobEntryJob)super.clone();
/*  140 */     return je;
/*      */   }
/*      */   
/*      */   public void setFileName(String n) {
/*  144 */     this.filename = n;
/*      */   }
/*      */   
/*      */   /**
/*      */    * @deprecated
/*      */    */
/*      */   public String getFileName()
/*      */   {
/*  152 */     return this.filename;
/*      */   }
/*      */   
/*      */   public String getFilename() {
/*  156 */     return this.filename;
/*      */   }
/*      */   
/*      */   public String getRealFilename() {
/*  160 */     return environmentSubstitute(getFilename());
/*      */   }
/*      */   
/*      */   public void setJobName(String jobname) {
/*  164 */     this.jobname = jobname;
/*      */   }
/*      */   
/*      */   public String getJobName() {
/*  168 */     return this.jobname;
/*      */   }
/*      */   
/*      */   public String getDirectory() {
/*  172 */     return this.directory;
/*      */   }
/*      */   
/*      */   public void setDirectory(String directory) {
/*  176 */     this.directory = directory;
/*      */   }
/*      */   
/*      */   public boolean isPassingExport() {
/*  180 */     return this.passingExport;
/*      */   }
/*      */   
/*      */   public void setPassingExport(boolean passingExport) {
/*  184 */     this.passingExport = passingExport;
/*      */   }
/*      */   
/*      */   public String getLogFilename() {
/*  188 */     String retval = "";
/*  189 */     if (this.setLogfile) {
/*  190 */       retval = retval + (this.logfile == null ? "" : this.logfile);
/*  191 */       Calendar cal = Calendar.getInstance();
/*  192 */       if (this.addDate) {
/*  193 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/*  194 */         retval = retval + "_" + sdf.format(cal.getTime());
/*      */       }
/*  196 */       if (this.addTime) {
/*  197 */         SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
/*  198 */         retval = retval + "_" + sdf.format(cal.getTime());
/*      */       }
/*  200 */       if ((this.logext != null) && (this.logext.length() > 0)) {
/*  201 */         retval = retval + "." + this.logext;
/*      */       }
/*      */     }
/*  204 */     return retval;
/*      */   }
/*      */   
/*      */   public String getXML() {
/*  208 */     StringBuffer retval = new StringBuffer(200);
/*      */     
/*  210 */     retval.append(super.getXML());
/*      */     
/*      */ 
/*      */ 
/*  214 */     retval.append("      ").append(XMLHandler.addTagValue("specification_method", this.specificationMethod == null ? null : this.specificationMethod.getCode()));
/*  215 */     retval.append("      ").append(XMLHandler.addTagValue("job_object_id", this.jobObjectId == null ? null : this.jobObjectId.toString()));
/*      */     
/*      */ 
/*  218 */     if ((this.rep != null) && (this.jobObjectId != null)) {
/*      */       try {
/*  220 */         RepositoryObject objectInformation = this.rep.getObjectInformation(this.jobObjectId, RepositoryObjectType.JOB);
/*  221 */         if (objectInformation != null) {
/*  222 */           this.jobname = objectInformation.getName();
/*  223 */           this.directory = objectInformation.getRepositoryDirectory().getPath();
/*      */         }
/*      */       }
/*      */       catch (KettleException e) {}
/*      */     }
/*      */     
/*  229 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/*  230 */     retval.append("      ").append(XMLHandler.addTagValue("jobname", this.jobname));
/*      */     
/*  232 */     if (this.directory != null) {
/*  233 */       retval.append("      ").append(XMLHandler.addTagValue("directory", this.directory));
/*  234 */     } else if (this.directoryPath != null) {
/*  235 */       retval.append("      ").append(XMLHandler.addTagValue("directory", this.directoryPath));
/*      */     }
/*  237 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.argFromPrevious));
/*  238 */     retval.append("      ").append(XMLHandler.addTagValue("params_from_previous", this.paramsFromPrevious));
/*  239 */     retval.append("      ").append(XMLHandler.addTagValue("exec_per_row", this.execPerRow));
/*  240 */     retval.append("      ").append(XMLHandler.addTagValue("set_logfile", this.setLogfile));
/*  241 */     retval.append("      ").append(XMLHandler.addTagValue("logfile", this.logfile));
/*  242 */     retval.append("      ").append(XMLHandler.addTagValue("logext", this.logext));
/*  243 */     retval.append("      ").append(XMLHandler.addTagValue("add_date", this.addDate));
/*  244 */     retval.append("      ").append(XMLHandler.addTagValue("add_time", this.addTime));
/*  245 */     retval.append("      ").append(XMLHandler.addTagValue("loglevel", this.logFileLevel != null ? this.logFileLevel.getCode() : DEFAULT_LOG_LEVEL.getCode()));
/*  246 */     retval.append("      ").append(XMLHandler.addTagValue("slave_server_name", this.remoteSlaveServerName));
/*  247 */     retval.append("      ").append(XMLHandler.addTagValue("wait_until_finished", this.waitingToFinish));
/*  248 */     retval.append("      ").append(XMLHandler.addTagValue("follow_abort_remote", this.followingAbortRemotely));
/*  249 */     retval.append("      ").append(XMLHandler.addTagValue("create_parent_folder", this.createParentFolder));
/*  250 */     retval.append("      ").append(XMLHandler.addTagValue("pass_export", this.passingExport));
/*      */     
/*  252 */     if (this.arguments != null) {
/*  253 */       for (int i = 0; i < this.arguments.length; i++)
/*      */       {
/*      */ 
/*  256 */         retval.append("      ").append(XMLHandler.addTagValue("argument" + i, this.arguments[i]));
/*      */       }
/*      */     }
/*      */     
/*  260 */     if (this.parameters != null) {
/*  261 */       retval.append("      ").append(XMLHandler.openTag("parameters"));
/*      */       
/*  263 */       retval.append("        ").append(XMLHandler.addTagValue("pass_all_parameters", this.passingAllParameters));
/*      */       
/*  265 */       for (int i = 0; i < this.parameters.length; i++)
/*      */       {
/*  267 */         retval.append("            ").append(XMLHandler.openTag("parameter"));
/*      */         
/*  269 */         retval.append("            ").append(XMLHandler.addTagValue("name", this.parameters[i]));
/*  270 */         retval.append("            ").append(XMLHandler.addTagValue("stream_name", this.parameterFieldNames[i]));
/*  271 */         retval.append("            ").append(XMLHandler.addTagValue("value", this.parameterValues[i]));
/*      */         
/*  273 */         retval.append("            ").append(XMLHandler.closeTag("parameter"));
/*      */       }
/*  275 */       retval.append("      ").append(XMLHandler.closeTag("parameters"));
/*      */     }
/*  277 */     retval.append("      ").append(XMLHandler.addTagValue("set_append_logfile", this.setAppendLogfile));
/*      */     
/*  279 */     return retval.toString();
/*      */   }
/*      */   
/*      */   private void checkObjectLocationSpecificationMethod() {
/*  283 */     if (this.specificationMethod == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  288 */       this.specificationMethod = ObjectLocationSpecificationMethod.FILENAME;
/*      */       
/*  290 */       if (!Const.isEmpty(this.filename)) {
/*  291 */         this.specificationMethod = ObjectLocationSpecificationMethod.FILENAME;
/*  292 */       } else if (this.jobObjectId != null) {
/*  293 */         this.specificationMethod = ObjectLocationSpecificationMethod.REPOSITORY_BY_REFERENCE;
/*  294 */       } else if (!Const.isEmpty(this.jobname)) {
/*  295 */         this.specificationMethod = ObjectLocationSpecificationMethod.REPOSITORY_BY_NAME;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException {
/*      */     try {
/*  302 */       super.loadXML(entrynode, databases, slaveServers);
/*      */       
/*  304 */       String method = XMLHandler.getTagValue(entrynode, "specification_method");
/*  305 */       this.specificationMethod = ObjectLocationSpecificationMethod.getSpecificationMethodByCode(method);
/*  306 */       String jobId = XMLHandler.getTagValue(entrynode, "job_object_id");
/*  307 */       this.jobObjectId = (Const.isEmpty(jobId) ? null : new StringObjectId(jobId));
/*  308 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/*  309 */       this.jobname = XMLHandler.getTagValue(entrynode, "jobname");
/*      */       
/*      */ 
/*      */ 
/*  313 */       checkObjectLocationSpecificationMethod();
/*      */       
/*  315 */       this.argFromPrevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/*  316 */       this.paramsFromPrevious = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "params_from_previous"));
/*  317 */       this.execPerRow = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "exec_per_row"));
/*  318 */       this.setLogfile = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "set_logfile"));
/*  319 */       this.addDate = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_date"));
/*  320 */       this.addTime = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_time"));
/*  321 */       this.logfile = XMLHandler.getTagValue(entrynode, "logfile");
/*  322 */       this.logext = XMLHandler.getTagValue(entrynode, "logext");
/*  323 */       this.logFileLevel = LogLevel.getLogLevelForCode(XMLHandler.getTagValue(entrynode, "loglevel"));
/*  324 */       this.setAppendLogfile = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "set_append_logfile"));
/*  325 */       this.remoteSlaveServerName = XMLHandler.getTagValue(entrynode, "slave_server_name");
/*  326 */       this.passingExport = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "pass_export"));
/*  327 */       this.directory = XMLHandler.getTagValue(entrynode, "directory");
/*  328 */       this.createParentFolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "create_parent_folder"));
/*      */       
/*  330 */       String wait = XMLHandler.getTagValue(entrynode, "wait_until_finished");
/*  331 */       if (Const.isEmpty(wait)) {
/*  332 */         this.waitingToFinish = true;
/*      */       } else {
/*  334 */         this.waitingToFinish = "Y".equalsIgnoreCase(wait);
/*      */       }
/*  336 */       this.followingAbortRemotely = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "follow_abort_remote"));
/*      */       
/*      */ 
/*  339 */       int argnr = 0;
/*  340 */       while (XMLHandler.getTagValue(entrynode, "argument" + argnr) != null)
/*  341 */         argnr++;
/*  342 */       this.arguments = new String[argnr];
/*      */       
/*      */ 
/*      */ 
/*  346 */       for (int a = 0; a < argnr; a++) {
/*  347 */         this.arguments[a] = XMLHandler.getTagValue(entrynode, "argument" + a);
/*      */       }
/*      */       
/*  350 */       Node parametersNode = XMLHandler.getSubNode(entrynode, "parameters");
/*      */       
/*  352 */       String passAll = XMLHandler.getTagValue(parametersNode, "pass_all_parameters");
/*  353 */       this.passingAllParameters = ((Const.isEmpty(passAll)) || ("Y".equalsIgnoreCase(passAll)));
/*      */       
/*  355 */       int nrParameters = XMLHandler.countNodes(parametersNode, "parameter");
/*      */       
/*  357 */       this.parameters = new String[nrParameters];
/*  358 */       this.parameterFieldNames = new String[nrParameters];
/*  359 */       this.parameterValues = new String[nrParameters];
/*      */       
/*  361 */       for (int i = 0; i < nrParameters; i++) {
/*  362 */         Node knode = XMLHandler.getSubNodeByNr(parametersNode, "parameter", i);
/*      */         
/*  364 */         this.parameters[i] = XMLHandler.getTagValue(knode, "name");
/*  365 */         this.parameterFieldNames[i] = XMLHandler.getTagValue(knode, "stream_name");
/*  366 */         this.parameterValues[i] = XMLHandler.getTagValue(knode, "value");
/*      */       }
/*      */     } catch (KettleXMLException xe) {
/*  369 */       throw new KettleXMLException("Unable to load 'job' job entry from XML node", xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*      */     throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  378 */       String method = rep.getJobEntryAttributeString(id_jobentry, "specification_method");
/*  379 */       this.specificationMethod = ObjectLocationSpecificationMethod.getSpecificationMethodByCode(method);
/*  380 */       String jobId = rep.getJobEntryAttributeString(id_jobentry, "job_object_id");
/*  381 */       this.jobObjectId = (Const.isEmpty(jobId) ? null : new StringObjectId(jobId));
/*  382 */       this.jobname = rep.getJobEntryAttributeString(id_jobentry, "name");
/*  383 */       this.directory = rep.getJobEntryAttributeString(id_jobentry, "dir_path");
/*  384 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "file_name");
/*      */       
/*      */ 
/*      */ 
/*  388 */       checkObjectLocationSpecificationMethod();
/*      */       
/*  390 */       this.argFromPrevious = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/*  391 */       this.paramsFromPrevious = rep.getJobEntryAttributeBoolean(id_jobentry, "params_from_previous");
/*  392 */       this.execPerRow = rep.getJobEntryAttributeBoolean(id_jobentry, "exec_per_row");
/*  393 */       this.setLogfile = rep.getJobEntryAttributeBoolean(id_jobentry, "set_logfile");
/*  394 */       this.addDate = rep.getJobEntryAttributeBoolean(id_jobentry, "add_date");
/*  395 */       this.addTime = rep.getJobEntryAttributeBoolean(id_jobentry, "add_time");
/*  396 */       this.logfile = rep.getJobEntryAttributeString(id_jobentry, "logfile");
/*  397 */       this.logext = rep.getJobEntryAttributeString(id_jobentry, "logext");
/*  398 */       this.logFileLevel = LogLevel.getLogLevelForCode(rep.getJobEntryAttributeString(id_jobentry, "loglevel"));
/*  399 */       this.setAppendLogfile = rep.getJobEntryAttributeBoolean(id_jobentry, "set_append_logfile");
/*  400 */       this.remoteSlaveServerName = rep.getJobEntryAttributeString(id_jobentry, "slave_server_name");
/*  401 */       this.passingExport = rep.getJobEntryAttributeBoolean(id_jobentry, "pass_export");
/*  402 */       this.waitingToFinish = rep.getJobEntryAttributeBoolean(id_jobentry, "wait_until_finished", true);
/*  403 */       this.followingAbortRemotely = rep.getJobEntryAttributeBoolean(id_jobentry, "follow_abort_remote");
/*  404 */       this.createParentFolder = rep.getJobEntryAttributeBoolean(id_jobentry, "create_parent_folder");
/*      */       
/*      */ 
/*  407 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "argument");
/*  408 */       this.arguments = new String[argnr];
/*      */       
/*      */ 
/*  411 */       for (int a = 0; a < argnr; a++) {
/*  412 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "argument");
/*      */       }
/*      */       
/*      */ 
/*  416 */       int parameternr = rep.countNrJobEntryAttributes(id_jobentry, "parameter_name");
/*  417 */       this.parameters = new String[parameternr];
/*  418 */       this.parameterFieldNames = new String[parameternr];
/*  419 */       this.parameterValues = new String[parameternr];
/*      */       
/*      */ 
/*  422 */       for (int a = 0; a < parameternr; a++) {
/*  423 */         this.parameters[a] = rep.getJobEntryAttributeString(id_jobentry, a, "parameter_name");
/*  424 */         this.parameterFieldNames[a] = rep.getJobEntryAttributeString(id_jobentry, a, "parameter_stream_name");
/*  425 */         this.parameterValues[a] = rep.getJobEntryAttributeString(id_jobentry, a, "parameter_value");
/*      */       }
/*      */       
/*  428 */       this.passingAllParameters = rep.getJobEntryAttributeBoolean(id_jobentry, "pass_all_parameters", true);
/*      */     }
/*      */     catch (KettleDatabaseException dbe) {
/*  431 */       throw new KettleException("Unable to load job entry of type 'job' from the repository with id_jobentry=" + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  439 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "specification_method", this.specificationMethod == null ? null : this.specificationMethod.getCode());
/*  440 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "job_object_id", this.jobObjectId == null ? null : this.jobObjectId.toString());
/*  441 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "name", getJobName());
/*  442 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "dir_path", getDirectory() != null ? getDirectory() : "");
/*  443 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "file_name", this.filename);
/*  444 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.argFromPrevious);
/*  445 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "params_from_previous", this.paramsFromPrevious);
/*  446 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "exec_per_row", this.execPerRow);
/*  447 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "set_logfile", this.setLogfile);
/*  448 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_date", this.addDate);
/*  449 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_time", this.addTime);
/*  450 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "logfile", this.logfile);
/*  451 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "logext", this.logext);
/*  452 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "set_append_logfile", this.setAppendLogfile);
/*  453 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "loglevel", this.logFileLevel != null ? this.logFileLevel.getCode() : DEFAULT_LOG_LEVEL.getCode());
/*  454 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "slave_server_name", this.remoteSlaveServerName);
/*  455 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "pass_export", this.passingExport);
/*  456 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "wait_until_finished", this.waitingToFinish);
/*  457 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "follow_abort_remote", this.followingAbortRemotely);
/*  458 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "create_parent_folder", this.createParentFolder);
/*      */       
/*      */ 
/*  461 */       if (this.arguments != null) {
/*  462 */         for (int i = 0; i < this.arguments.length; i++) {
/*  463 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "argument", this.arguments[i]);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  468 */       if (this.parameters != null) {
/*  469 */         for (int i = 0; i < this.parameters.length; i++) {
/*  470 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "parameter_name", this.parameters[i]);
/*  471 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "parameter_stream_name", Const.NVL(this.parameterFieldNames[i], ""));
/*  472 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "parameter_value", Const.NVL(this.parameterValues[i], ""));
/*      */         }
/*      */       }
/*      */       
/*  476 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "pass_all_parameters", this.passingAllParameters);
/*      */     } catch (KettleDatabaseException dbe) {
/*  478 */       throw new KettleException("Unable to save job entry of type job to the repository with id_job=" + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public Result execute(Result result, int nr) throws KettleException {
/*  483 */     result.setEntryNr(nr);
/*      */     
/*  485 */     LogChannelFileWriter logChannelFileWriter = null;
/*      */     
/*  487 */     LogLevel jobLogLevel = this.parentJob.getLogLevel();
/*  488 */     if (this.setLogfile) {
/*  489 */       String realLogFilename = environmentSubstitute(getLogFilename());
/*      */       
/*      */ 
/*  492 */       if (Const.isEmpty(realLogFilename)) {
/*  493 */         logError(BaseMessages.getString(PKG, "JobJob.Exception.LogFilenameMissing", new String[0]));
/*  494 */         result.setNrErrors(1L);
/*  495 */         result.setResult(false);
/*  496 */         return result;
/*      */       }
/*      */       
/*      */ 
/*  500 */       if (!createParentFolder(realLogFilename)) {
/*  501 */         result.setNrErrors(1L);
/*  502 */         result.setResult(false);
/*  503 */         return result;
/*      */       }
/*      */       try {
/*  506 */         logChannelFileWriter = new LogChannelFileWriter(getLogChannelId(), KettleVFS.getFileObject(realLogFilename), this.setAppendLogfile);
/*  507 */         logChannelFileWriter.startLogging();
/*      */       } catch (KettleException e) {
/*  509 */         logError("Unable to open file appender for file [" + getLogFilename() + "] : " + e.toString());
/*  510 */         logError(Const.getStackTracker(e));
/*  511 */         result.setNrErrors(1L);
/*  512 */         result.setResult(false);
/*  513 */         return result;
/*      */       }
/*  515 */       jobLogLevel = this.logFileLevel;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  520 */     SlaveServer remoteSlaveServer = null;
/*  521 */     if (!Const.isEmpty(this.remoteSlaveServerName)) {
/*  522 */       String realRemoteSlaveServerName = environmentSubstitute(this.remoteSlaveServerName);
/*  523 */       remoteSlaveServer = this.parentJob.getJobMeta().findSlaveServer(realRemoteSlaveServerName);
/*  524 */       if (remoteSlaveServer == null) {
/*  525 */         throw new KettleException(BaseMessages.getString(PKG, "JobJob.Exception.UnableToFindRemoteSlaveServer", new String[] { realRemoteSlaveServerName }));
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  530 */       if (this.parentJob.getJobMeta() != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  535 */         this.parentJob.getJobMeta().setInternalKettleVariables();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  540 */       switch (this.specificationMethod) {
/*      */       case REPOSITORY_BY_NAME: 
/*  542 */         if (this.log.isDetailed()) {
/*  543 */           logDetailed("Loading job from repository : [" + this.directory + " : " + environmentSubstitute(this.jobname) + "]");
/*      */         }
/*      */         break;
/*      */       case FILENAME: 
/*  547 */         if (this.log.isDetailed()) {
/*  548 */           logDetailed("Loading job from XML file : [" + environmentSubstitute(this.filename) + "]");
/*      */         }
/*      */         break;
/*      */       case REPOSITORY_BY_REFERENCE: 
/*  552 */         if (this.log.isDetailed()) {
/*  553 */           logDetailed("Loading job from repository by reference : [" + this.jobObjectId + "]");
/*      */         }
/*      */         break;
/*      */       }
/*      */       
/*  558 */       JobMeta jobMeta = getJobMeta(this.rep, this);
/*      */       
/*      */ 
/*      */ 
/*  562 */       if (jobMeta == null) {
/*  563 */         throw new KettleException("Unable to load the job: please specify the name and repository directory OR a filename");
/*      */       }
/*      */       
/*  566 */       verifyRecursiveExecution(this.parentJob, jobMeta);
/*      */       
/*      */ 
/*  569 */       int iteration = 0;
/*  570 */       String[] args1 = this.arguments;
/*      */       
/*  572 */       if ((args1 == null) || (args1.length == 0))
/*      */       {
/*  574 */         args1 = this.parentJob.getJobMeta().getArguments();
/*      */       }
/*      */       
/*  577 */       copyVariablesFrom(this.parentJob);
/*  578 */       setParentVariableSpace(this.parentJob);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  584 */       String[] args = null;
/*  585 */       if (args1 != null) {
/*  586 */         args = new String[args1.length];
/*  587 */         for (int idx = 0; idx < args1.length; idx++) {
/*  588 */           args[idx] = environmentSubstitute(args1[idx]);
/*      */         }
/*      */       }
/*      */       
/*  592 */       RowMetaAndData resultRow = null;
/*  593 */       boolean first = true;
/*  594 */       List<RowMetaAndData> rows = new ArrayList(result.getRows());
/*      */       
/*  596 */       while (((first) && (!this.execPerRow)) || ((this.execPerRow) && (rows != null) && (iteration < rows.size()) && (result.getNrErrors() == 0L))) {
/*  597 */         first = false;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  602 */         if (this.execPerRow) {
/*  603 */           result.getRows().clear();
/*      */         }
/*      */         
/*  606 */         if ((rows != null) && (this.execPerRow)) {
/*  607 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*      */         } else {
/*  609 */           resultRow = null;
/*      */         }
/*      */         
/*  612 */         NamedParams namedParam = new NamedParamsDefault();
/*      */         
/*      */ 
/*      */ 
/*  616 */         if (this.paramsFromPrevious) {
/*  617 */           String[] parentParameters = this.parentJob.listParameters();
/*  618 */           for (int idx = 0; idx < parentParameters.length; idx++) {
/*  619 */             String par = parentParameters[idx];
/*  620 */             String def = this.parentJob.getParameterDefault(par);
/*  621 */             String val = this.parentJob.getParameterValue(par);
/*  622 */             String des = this.parentJob.getParameterDescription(par);
/*      */             
/*  624 */             namedParam.addParameterDefinition(par, def, des);
/*  625 */             namedParam.setParameterValue(par, val);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  631 */         if (this.parameters != null) {
/*  632 */           for (int idx = 0; idx < this.parameters.length; idx++) {
/*  633 */             if (!Const.isEmpty(this.parameters[idx]))
/*      */             {
/*      */ 
/*      */ 
/*  637 */               if (Const.indexOfString(this.parameters[idx], namedParam.listParameters()) < 0) {
/*      */                 try
/*      */                 {
/*  640 */                   namedParam.addParameterDefinition(this.parameters[idx], "", "Job entry runtime");
/*      */                 }
/*      */                 catch (DuplicateParamException e)
/*      */                 {
/*  644 */                   logError("Duplicate parameter definition for " + this.parameters[idx]);
/*      */                 }
/*      */               }
/*      */               
/*  648 */               if (Const.isEmpty(Const.trim(this.parameterFieldNames[idx]))) {
/*  649 */                 namedParam.setParameterValue(this.parameters[idx], Const.NVL(environmentSubstitute(this.parameterValues[idx]), ""));
/*      */               }
/*      */               else
/*      */               {
/*  653 */                 String value = "";
/*  654 */                 if (resultRow != null) {
/*  655 */                   value = resultRow.getString(this.parameterFieldNames[idx], "");
/*      */                 }
/*  657 */                 namedParam.setParameterValue(this.parameters[idx], value);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  663 */         Result oneResult = new Result();
/*      */         
/*  665 */         List<RowMetaAndData> sourceRows = null;
/*      */         
/*  667 */         if (this.execPerRow)
/*      */         {
/*  669 */           if (this.argFromPrevious)
/*      */           {
/*      */ 
/*  672 */             args = null;
/*  673 */             if (resultRow != null) {
/*  674 */               args = new String[resultRow.size()];
/*  675 */               for (int i = 0; i < resultRow.size(); i++) {
/*  676 */                 args[i] = resultRow.getString(i, null);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/*  681 */             List<RowMetaAndData> newList = new ArrayList();
/*  682 */             newList.add(resultRow);
/*  683 */             sourceRows = newList;
/*      */           }
/*      */           
/*  686 */           if (this.paramsFromPrevious)
/*      */           {
/*  688 */             if (this.parameters != null) {
/*  689 */               for (int idx = 0; idx < this.parameters.length; idx++) {
/*  690 */                 if (!Const.isEmpty(this.parameters[idx]))
/*      */                 {
/*  692 */                   if (Const.isEmpty(Const.trim(this.parameterFieldNames[idx]))) {
/*  693 */                     namedParam.setParameterValue(this.parameters[idx], Const.NVL(environmentSubstitute(this.parameterValues[idx]), ""));
/*      */                   } else {
/*  695 */                     String fieldValue = "";
/*      */                     
/*  697 */                     if (resultRow != null) {
/*  698 */                       fieldValue = resultRow.getString(this.parameterFieldNames[idx], "");
/*      */                     }
/*      */                     
/*  701 */                     namedParam.setParameterValue(this.parameters[idx], Const.NVL(fieldValue, ""));
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  708 */           if (this.argFromPrevious)
/*      */           {
/*  710 */             args = null;
/*  711 */             if (resultRow != null) {
/*  712 */               args = new String[resultRow.size()];
/*  713 */               for (int i = 0; i < resultRow.size(); i++) {
/*  714 */                 args[i] = resultRow.getString(i, null);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/*  719 */             sourceRows = result.getRows();
/*      */           }
/*      */           
/*  722 */           if (this.paramsFromPrevious)
/*      */           {
/*  724 */             if (this.parameters != null) {
/*  725 */               for (int idx = 0; idx < this.parameters.length; idx++) {
/*  726 */                 if (!Const.isEmpty(this.parameters[idx]))
/*      */                 {
/*  728 */                   if (Const.isEmpty(Const.trim(this.parameterFieldNames[idx]))) {
/*  729 */                     namedParam.setParameterValue(this.parameters[idx], Const.NVL(environmentSubstitute(this.parameterValues[idx]), ""));
/*      */                   } else {
/*  731 */                     String fieldValue = "";
/*      */                     
/*  733 */                     if (resultRow != null) {
/*  734 */                       fieldValue = resultRow.getString(this.parameterFieldNames[idx], "");
/*      */                     }
/*      */                     
/*  737 */                     namedParam.setParameterValue(this.parameters[idx], Const.NVL(fieldValue, ""));
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  745 */         if (remoteSlaveServer == null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  751 */           this.job = new Job(this.rep, jobMeta, this);
/*  752 */           this.job.setParentJob(this.parentJob);
/*  753 */           this.job.setLogLevel(jobLogLevel);
/*  754 */           this.job.shareVariablesWith(this);
/*  755 */           this.job.setInternalKettleVariables(this);
/*  756 */           this.job.copyParametersFrom(jobMeta);
/*  757 */           this.job.setInteractive(this.parentJob.isInteractive());
/*  758 */           if (this.job.isInteractive()) {
/*  759 */             this.job.getJobEntryListeners().addAll(this.parentJob.getJobEntryListeners());
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  764 */           this.job.setSocketRepository(this.parentJob.getSocketRepository());
/*      */           
/*      */ 
/*      */ 
/*  768 */           this.job.clearParameters();
/*  769 */           String[] parameterNames = this.job.listParameters();
/*  770 */           for (int idx = 0; idx < parameterNames.length; idx++)
/*      */           {
/*      */ 
/*  773 */             String thisValue = namedParam.getParameterValue(parameterNames[idx]);
/*  774 */             if (!Const.isEmpty(thisValue))
/*      */             {
/*      */ 
/*  777 */               this.job.setParameterValue(parameterNames[idx], thisValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             }
/*  783 */             else if (isPassingAllParameters()) {
/*  784 */               String parentValue = this.parentJob.getParameterValue(parameterNames[idx]);
/*  785 */               if (!Const.isEmpty(parentValue)) {
/*  786 */                 this.job.setParameterValue(parameterNames[idx], parentValue);
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*  791 */           this.job.activateParameters();
/*      */           
/*      */ 
/*      */ 
/*  795 */           this.job.setSourceRows(sourceRows);
/*      */           
/*      */ 
/*  798 */           this.job.beginProcessing();
/*      */           
/*      */ 
/*  801 */           this.parentJob.getJobTracker().addJobTracker(this.job.getJobTracker());
/*      */           
/*      */ 
/*  804 */           this.job.getJobTracker().setParentJobTracker(this.parentJob.getJobTracker());
/*      */           
/*  806 */           if (this.parentJob.getJobMeta().isBatchIdPassed()) {
/*  807 */             this.job.setPassedBatchId(this.parentJob.getBatchId());
/*      */           }
/*      */           
/*  810 */           this.job.getJobMeta().setArguments(args);
/*      */           
/*  812 */           JobEntryJobRunner runner = new JobEntryJobRunner(this.job, result, nr, this.log);
/*  813 */           Thread jobRunnerThread = new Thread(runner);
/*      */           
/*      */ 
/*      */ 
/*  817 */           jobRunnerThread.setName(Const.NVL(this.job.getJobMeta().getName(), this.job.getJobMeta().getFilename()) + " UUID: " + UUID.randomUUID().toString());
/*  818 */           jobRunnerThread.start();
/*      */           
/*      */ 
/*      */ 
/*  822 */           while ((!runner.isFinished()) && (!this.parentJob.isStopped())) {
/*      */             try {
/*  824 */               Thread.sleep(0L, 1);
/*      */             }
/*      */             catch (InterruptedException e) {}
/*      */           }
/*      */           
/*  829 */           if (this.parentJob.isStopped())
/*      */           {
/*  831 */             this.job.stopAll();
/*  832 */             runner.waitUntilFinished();
/*      */           }
/*      */           
/*  835 */           oneResult = runner.getResult();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*  841 */           remoteSlaveServer.shareVariablesWith(this);
/*      */           
/*      */ 
/*      */ 
/*  845 */           JobExecutionConfiguration jobExecutionConfiguration = new JobExecutionConfiguration();
/*      */           
/*  847 */           jobExecutionConfiguration.setPreviousResult(result.lightClone());
/*  848 */           jobExecutionConfiguration.getPreviousResult().setRows(sourceRows);
/*  849 */           jobExecutionConfiguration.setArgumentStrings(args);
/*  850 */           jobExecutionConfiguration.setVariables(this);
/*  851 */           jobExecutionConfiguration.setRemoteServer(remoteSlaveServer);
/*  852 */           jobExecutionConfiguration.setRepository(this.rep);
/*  853 */           jobExecutionConfiguration.setLogLevel(jobLogLevel);
/*  854 */           jobExecutionConfiguration.setPassingExport(this.passingExport);
/*      */           
/*  856 */           for (String param : namedParam.listParameters()) {
/*  857 */             String defValue = namedParam.getParameterDefault(param);
/*  858 */             String value = namedParam.getParameterValue(param);
/*  859 */             jobExecutionConfiguration.getParams().put(param, Const.NVL(value, defValue));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  865 */           String carteObjectId = null;
/*      */           try {
/*  867 */             carteObjectId = Job.sendToSlaveServer(jobMeta, jobExecutionConfiguration, this.rep);
/*      */ 
/*      */ 
/*      */           }
/*      */           catch (KettleException e)
/*      */           {
/*      */ 
/*  874 */             this.parentJob.stopAll();
/*      */             
/*      */ 
/*      */ 
/*  878 */             throw e;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  883 */           SlaveServerJobStatus jobStatus = null;
/*  884 */           while ((!this.parentJob.isStopped()) && (this.waitingToFinish)) {
/*      */             try {
/*  886 */               jobStatus = remoteSlaveServer.getJobStatus(jobMeta.getName(), carteObjectId, 0);
/*  887 */               if (jobStatus.getResult() != null)
/*      */               {
/*      */ 
/*  890 */                 oneResult = jobStatus.getResult();
/*  891 */                 break;
/*      */               }
/*      */             } catch (Exception e1) {
/*  894 */               logError("Unable to contact slave server [" + remoteSlaveServer + "] to verify the status of job [" + jobMeta.getName() + "]", e1);
/*  895 */               oneResult.setNrErrors(1L);
/*  896 */               break;
/*      */             }
/*      */             
/*      */             try
/*      */             {
/*  901 */               Thread.sleep(10000L);
/*      */             }
/*      */             catch (InterruptedException e) {}
/*      */           }
/*      */           
/*      */ 
/*  907 */           if (!this.waitingToFinish)
/*      */           {
/*      */ 
/*  910 */             oneResult = new Result();
/*  911 */             oneResult.setResult(true);
/*      */           }
/*      */           
/*  914 */           if (this.parentJob.isStopped())
/*      */           {
/*      */             try
/*      */             {
/*      */ 
/*  919 */               if ((jobStatus == null) || (jobStatus.isRunning()))
/*      */               {
/*      */ 
/*  922 */                 remoteSlaveServer.stopJob(jobMeta.getName(), carteObjectId);
/*      */               }
/*      */             } catch (Exception e1) {
/*  925 */               logError("Unable to contact slave server [" + remoteSlaveServer + "] to stop job [" + jobMeta.getName() + "]", e1);
/*  926 */               oneResult.setNrErrors(1L);
/*  927 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  934 */         if (iteration == 0) {
/*  935 */           result.clear();
/*      */         }
/*      */         
/*  938 */         result.add(oneResult);
/*      */         
/*      */ 
/*      */ 
/*  942 */         if (!oneResult.getResult())
/*      */         {
/*  944 */           result.setNrErrors(result.getNrErrors() + 1L);
/*      */         }
/*      */         
/*  947 */         iteration++;
/*      */       }
/*      */     }
/*      */     catch (KettleException ke) {
/*  951 */       logError("Error running job entry 'job' : ", ke);
/*      */       
/*  953 */       result.setResult(false);
/*  954 */       result.setNrErrors(1L);
/*      */     }
/*      */     
/*  957 */     if ((this.setLogfile) && 
/*  958 */       (logChannelFileWriter != null)) {
/*  959 */       logChannelFileWriter.stopLogging();
/*      */       
/*  961 */       ResultFile resultFile = new ResultFile(1, logChannelFileWriter.getLogFile(), this.parentJob.getJobname(), getName());
/*  962 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*      */       
/*      */ 
/*      */ 
/*  966 */       if (logChannelFileWriter.getException() != null) {
/*  967 */         logError("Unable to open log file [" + getLogFilename() + "] : ");
/*  968 */         logError(Const.getStackTracker(logChannelFileWriter.getException()));
/*  969 */         result.setNrErrors(1L);
/*  970 */         result.setResult(false);
/*  971 */         return result;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  976 */     if (result.getNrErrors() > 0L) {
/*  977 */       result.setResult(false);
/*      */     } else {
/*  979 */       result.setResult(true);
/*      */     }
/*      */     
/*  982 */     return result;
/*      */   }
/*      */   
/*      */   private boolean createParentFolder(String filename)
/*      */   {
/*  987 */     FileObject parentfolder = null;
/*  988 */     boolean resultat = true;
/*      */     try
/*      */     {
/*  991 */       parentfolder = KettleVFS.getFileObject(filename, this).getParent();
/*  992 */       if (!parentfolder.exists()) {
/*  993 */         if (this.createParentFolder) {
/*  994 */           if (this.log.isDebug())
/*  995 */             this.log.logDebug(BaseMessages.getString(PKG, "JobJob.Log.ParentLogFolderNotExist", new String[] { parentfolder.getName().toString() }));
/*  996 */           parentfolder.createFolder();
/*  997 */           if (this.log.isDebug())
/*  998 */             this.log.logDebug(BaseMessages.getString(PKG, "JobJob.Log.ParentLogFolderCreated", new String[] { parentfolder.getName().toString() }));
/*      */         } else {
/* 1000 */           this.log.logError(BaseMessages.getString(PKG, "JobJob.Log.ParentLogFolderNotExist", new String[] { parentfolder.getName().toString() }));
/* 1001 */           resultat = false;
/*      */         }
/*      */       }
/* 1004 */       else if (this.log.isDebug()) {
/* 1005 */         this.log.logDebug(BaseMessages.getString(PKG, "JobJob.Log.ParentLogFolderExists", new String[] { parentfolder.getName().toString() }));
/*      */       }
/*      */     } catch (Exception e) {
/* 1008 */       resultat = false;
/* 1009 */       this.log.logError(BaseMessages.getString(PKG, "JobJob.Error.ChekingParentLogFolderTitle", new String[0]), new Object[] { BaseMessages.getString(PKG, "JobJob.Error.ChekingParentLogFolder", new String[] { parentfolder.getName().toString() }), e });
/*      */     } finally {
/* 1011 */       if (parentfolder != null) {
/*      */         try {
/* 1013 */           parentfolder.close();
/* 1014 */           parentfolder = null;
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1021 */     return resultat;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void verifyRecursiveExecution(Job parentJob, JobMeta jobMeta)
/*      */     throws KettleException
/*      */   {
/* 1036 */     if (parentJob == null) {
/* 1037 */       return;
/*      */     }
/* 1039 */     JobMeta parentJobMeta = parentJob.getJobMeta();
/*      */     
/* 1041 */     if ((parentJobMeta.getName() == null) && (jobMeta.getName() != null))
/* 1042 */       return;
/* 1043 */     if ((parentJobMeta.getName() != null) && (jobMeta.getName() == null)) {
/* 1044 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1048 */     if ((jobMeta.getFilename() != null) && (jobMeta.getFilename().equals(parentJobMeta.getFilename()))) {
/* 1049 */       throw new KettleException(BaseMessages.getString(PKG, "JobJobError.Recursive", new String[] { jobMeta.getFilename() }));
/*      */     }
/*      */     
/*      */ 
/* 1053 */     if ((parentJobMeta.getRepositoryDirectory() == null) && (jobMeta.getRepositoryDirectory() != null))
/* 1054 */       return;
/* 1055 */     if ((parentJobMeta.getRepositoryDirectory() != null) && (jobMeta.getRepositoryDirectory() == null))
/* 1056 */       return;
/* 1057 */     if (jobMeta.getRepositoryDirectory().getObjectId() != parentJobMeta.getRepositoryDirectory().getObjectId()) {
/* 1058 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1064 */     if (parentJobMeta.getName().equals(jobMeta.getName())) {
/* 1065 */       throw new KettleException(BaseMessages.getString(PKG, "JobJobError.Recursive", new String[] { jobMeta.getFilename() }));
/*      */     }
/*      */     
/*      */ 
/* 1069 */     verifyRecursiveExecution(parentJob.getParentJob(), jobMeta);
/*      */   }
/*      */   
/*      */   public void clear() {
/* 1073 */     super.clear();
/*      */     
/* 1075 */     this.specificationMethod = ObjectLocationSpecificationMethod.FILENAME;
/* 1076 */     this.jobname = null;
/* 1077 */     this.filename = null;
/* 1078 */     this.directory = null;
/* 1079 */     this.arguments = null;
/* 1080 */     this.argFromPrevious = false;
/* 1081 */     this.addDate = false;
/* 1082 */     this.addTime = false;
/* 1083 */     this.logfile = null;
/* 1084 */     this.logext = null;
/* 1085 */     this.setLogfile = false;
/* 1086 */     this.setAppendLogfile = false;
/*      */   }
/*      */   
/*      */   public boolean evaluates() {
/* 1090 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isUnconditional() {
/* 1094 */     return true;
/*      */   }
/*      */   
/*      */   public List<SQLStatement> getSQLStatements(Repository repository) throws KettleException {
/* 1098 */     return getSQLStatements(repository, null);
/*      */   }
/*      */   
/*      */   public List<SQLStatement> getSQLStatements(Repository repository, VariableSpace space) throws KettleException {
/* 1102 */     copyVariablesFrom(space);
/* 1103 */     JobMeta jobMeta = getJobMeta(repository, space);
/* 1104 */     return jobMeta.getSQLStatements(repository, null);
/*      */   }
/*      */   
/*      */   public JobMeta getJobMeta(Repository rep, VariableSpace space) throws KettleException {
/*      */     try {
/* 1109 */       switch (this.specificationMethod) {
/*      */       case FILENAME: 
/* 1111 */         return new JobMeta(space != null ? space.environmentSubstitute(getFilename()) : getFilename(), rep, null);
/*      */       case REPOSITORY_BY_NAME: 
/* 1113 */         if (rep != null) {
/* 1114 */           String realDirectory = environmentSubstitute(getDirectory());
/* 1115 */           RepositoryDirectoryInterface repositoryDirectory = rep.loadRepositoryDirectoryTree().findDirectory(realDirectory);
/* 1116 */           if (repositoryDirectory == null) {
/* 1117 */             throw new KettleException("Unable to find repository directory [" + Const.NVL(realDirectory, "") + "]");
/*      */           }
/* 1119 */           return rep.loadJob(space != null ? space.environmentSubstitute(getJobName()) : getJobName(), repositoryDirectory, null, null);
/*      */         }
/* 1121 */         throw new KettleException("Could not execute job specified in a repository since we're not connected to one");
/*      */       
/*      */       case REPOSITORY_BY_REFERENCE: 
/* 1124 */         if (rep != null)
/*      */         {
/*      */ 
/* 1127 */           return rep.loadJob(this.jobObjectId, null);
/*      */         }
/* 1129 */         throw new KettleException("Could not execute job specified in a repository since we're not connected to one");
/*      */       }
/*      */       
/* 1132 */       throw new KettleException("The specified object location specification method '" + this.specificationMethod + "' is not yet supported in this job entry.");
/*      */     }
/*      */     catch (Exception e) {
/* 1135 */       throw new KettleException("Unexpected error during job metadata load", e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isExecPerRow()
/*      */   {
/* 1144 */     return this.execPerRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExecPerRow(boolean runEveryResultRow)
/*      */   {
/* 1152 */     this.execPerRow = runEveryResultRow;
/*      */   }
/*      */   
/*      */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 1156 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 1157 */     if (!Const.isEmpty(this.filename)) {
/* 1158 */       String realFileName = jobMeta.environmentSubstitute(this.filename);
/* 1159 */       ResourceReference reference = new ResourceReference(this);
/* 1160 */       reference.getEntries().add(new ResourceEntry(realFileName, ResourceEntry.ResourceType.ACTIONFILE));
/* 1161 */       references.add(reference);
/*      */     }
/* 1163 */     return references;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String exportResources(VariableSpace space, Map<String, ResourceDefinition> definitions, ResourceNamingInterface namingInterface, Repository repository)
/*      */     throws KettleException
/*      */   {
/* 1181 */     copyVariablesFrom(space);
/* 1182 */     JobMeta jobMeta = getJobMeta(repository, space);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1187 */     String proposedNewFilename = jobMeta.exportResources(jobMeta, definitions, namingInterface, repository);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1192 */     String newFilename = "${Internal.Job.Filename.Directory}/" + proposedNewFilename;
/*      */     
/*      */ 
/*      */ 
/* 1196 */     jobMeta.setFilename(newFilename);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1201 */     jobMeta.setRepositoryDirectory(new RepositoryDirectory());
/*      */     
/*      */ 
/*      */ 
/* 1205 */     this.filename = newFilename;
/*      */     
/* 1207 */     return proposedNewFilename;
/*      */   }
/*      */   
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1212 */     if (this.setLogfile) {
/* 1213 */       JobEntryValidatorUtils.andValidator().validate(this, "logfile", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*      */     }
/*      */     
/* 1216 */     if (null != this.directory)
/*      */     {
/* 1218 */       JobEntryValidatorUtils.andValidator().validate(this, "directory", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/* 1219 */       JobEntryValidatorUtils.andValidator().validate(this, "jobName", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*      */     }
/*      */     else {
/* 1222 */       JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void main(String[] args) {
/* 1227 */     List<CheckResultInterface> remarks = new ArrayList();
/* 1228 */     new JobEntryJob().check(remarks, null);
/* 1229 */     System.out.printf("Remarks: %s\n", new Object[] { remarks });
/*      */   }
/*      */   
/*      */   protected String getLogfile() {
/* 1233 */     return this.logfile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getRemoteSlaveServerName()
/*      */   {
/* 1240 */     return this.remoteSlaveServerName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRemoteSlaveServerName(String remoteSlaveServerName)
/*      */   {
/* 1248 */     this.remoteSlaveServerName = remoteSlaveServerName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isWaitingToFinish()
/*      */   {
/* 1255 */     return this.waitingToFinish;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWaitingToFinish(boolean waitingToFinish)
/*      */   {
/* 1263 */     this.waitingToFinish = waitingToFinish;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isFollowingAbortRemotely()
/*      */   {
/* 1270 */     return this.followingAbortRemotely;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFollowingAbortRemotely(boolean followingAbortRemotely)
/*      */   {
/* 1278 */     this.followingAbortRemotely = followingAbortRemotely;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean isPassingAllParameters()
/*      */   {
/* 1285 */     return this.passingAllParameters;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassingAllParameters(boolean passingAllParameters)
/*      */   {
/* 1293 */     this.passingAllParameters = passingAllParameters;
/*      */   }
/*      */   
/*      */   public Job getJob() {
/* 1297 */     return this.job;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectId getJobObjectId()
/*      */   {
/* 1304 */     return this.jobObjectId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setJobObjectId(ObjectId jobObjectId)
/*      */   {
/* 1311 */     this.jobObjectId = jobObjectId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public ObjectLocationSpecificationMethod getSpecificationMethod()
/*      */   {
/* 1318 */     return this.specificationMethod;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSpecificationMethod(ObjectLocationSpecificationMethod specificationMethod)
/*      */   {
/* 1325 */     this.specificationMethod = specificationMethod;
/*      */   }
/*      */   
/*      */   public boolean hasRepositoryReferences()
/*      */   {
/* 1330 */     return this.specificationMethod == ObjectLocationSpecificationMethod.REPOSITORY_BY_REFERENCE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void lookupRepositoryReferences(Repository repository)
/*      */     throws KettleException
/*      */   {
/* 1340 */     RepositoryDirectoryInterface repositoryDirectoryInterface = RepositoryImportLocation.getRepositoryImportLocation().findDirectory(this.directory);
/* 1341 */     this.jobObjectId = repository.getJobId(this.jobname, repositoryDirectoryInterface);
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\job\JobEntryJob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */