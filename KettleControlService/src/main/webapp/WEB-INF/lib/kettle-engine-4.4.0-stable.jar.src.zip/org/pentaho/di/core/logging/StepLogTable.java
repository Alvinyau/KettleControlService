/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.pentaho.di.trans.Trans;
/*     */ import org.pentaho.di.trans.step.StepInterface;
/*     */ import org.pentaho.di.trans.step.StepMetaDataCombi;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StepLogTable
/*     */   extends BaseLogTable
/*     */   implements Cloneable, LogTableInterface
/*     */ {
/*  49 */   private static Class<?> PKG = StepLogTable.class;
/*     */   
/*     */   public static final String XML_TAG = "step-log-table";
/*     */   
/*     */   public static enum ID
/*     */   {
/*  55 */     ID_BATCH("ID_BATCH"), 
/*  56 */     CHANNEL_ID("CHANNEL_ID"), 
/*  57 */     LOG_DATE("LOG_DATE"), 
/*  58 */     TRANSNAME("TRANSNAME"), 
/*  59 */     STEPNAME("STEPNAME"), 
/*  60 */     STEP_COPY("STEP_COPY"), 
/*  61 */     LINES_READ("LINES_READ"), 
/*  62 */     LINES_WRITTEN("LINES_WRITTEN"), 
/*  63 */     LINES_UPDATED("LINES_UPDATED"), 
/*  64 */     LINES_INPUT("LINES_INPUT"), 
/*  65 */     LINES_OUTPUT("LINES_OUTPUT"), 
/*  66 */     LINES_REJECTED("LINES_REJECTED"), 
/*  67 */     ERRORS("ERRORS"), 
/*  68 */     LOG_FIELD("LOG_FIELD");
/*     */     
/*     */     private String id;
/*     */     
/*     */     private ID(String id) {
/*  73 */       this.id = id;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  77 */       return this.id;
/*     */     }
/*     */   }
/*     */   
/*     */   private StepLogTable(VariableSpace space, HasDatabasesInterface databasesInterface) {
/*  82 */     super(space, databasesInterface, null, null, null);
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/*  88 */       StepLogTable table = (StepLogTable)super.clone();
/*  89 */       table.fields = new ArrayList();
/*  90 */       for (LogTableField field : this.fields) {
/*  91 */         table.fields.add((LogTableField)field.clone());
/*     */       }
/*  93 */       return table;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 101 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 103 */     retval.append(XMLHandler.openTag("step-log-table"));
/* 104 */     retval.append(XMLHandler.addTagValue("connection", this.connectionName));
/* 105 */     retval.append(XMLHandler.addTagValue("schema", this.schemaName));
/* 106 */     retval.append(XMLHandler.addTagValue("table", this.tableName));
/* 107 */     retval.append(XMLHandler.addTagValue("timeout_days", this.timeoutInDays));
/* 108 */     retval.append(super.getFieldsXML());
/* 109 */     retval.append(XMLHandler.closeTag("step-log-table")).append(Const.CR);
/*     */     
/* 111 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node node, List<DatabaseMeta> databases) {
/* 115 */     this.connectionName = XMLHandler.getTagValue(node, "connection");
/* 116 */     this.schemaName = XMLHandler.getTagValue(node, "schema");
/* 117 */     this.tableName = XMLHandler.getTagValue(node, "table");
/* 118 */     this.timeoutInDays = XMLHandler.getTagValue(node, "timeout_days");
/*     */     
/* 120 */     super.loadFieldsXML(node);
/*     */   }
/*     */   
/*     */   public static StepLogTable getDefault(VariableSpace space, HasDatabasesInterface databasesInterface) {
/* 124 */     StepLogTable table = new StepLogTable(space, databasesInterface);
/*     */     
/* 126 */     table.fields.add(new LogTableField(ID.ID_BATCH.id, true, false, "ID_BATCH", BaseMessages.getString(PKG, "StepLogTable.FieldName.IdBatch", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.IdBatch", new String[0]), 5, 8));
/* 127 */     table.fields.add(new LogTableField(ID.CHANNEL_ID.id, true, false, "CHANNEL_ID", BaseMessages.getString(PKG, "StepLogTable.FieldName.ChannelId", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.ChannelId", new String[0]), 2, 255));
/* 128 */     table.fields.add(new LogTableField(ID.LOG_DATE.id, true, false, "LOG_DATE", BaseMessages.getString(PKG, "StepLogTable.FieldName.LogDate", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LogDate", new String[0]), 3, -1));
/* 129 */     table.fields.add(new LogTableField(ID.TRANSNAME.id, true, false, "TRANSNAME", BaseMessages.getString(PKG, "StepLogTable.FieldName.TransName", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.TransName", new String[0]), 2, 255));
/* 130 */     table.fields.add(new LogTableField(ID.STEPNAME.id, true, false, "STEPNAME", BaseMessages.getString(PKG, "StepLogTable.FieldName.StepName", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.StepName", new String[0]), 2, 255));
/* 131 */     table.fields.add(new LogTableField(ID.STEP_COPY.id, true, false, "STEP_COPY", BaseMessages.getString(PKG, "StepLogTable.FieldName.StepCopy", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.StepCopy", new String[0]), 5, 3));
/* 132 */     table.fields.add(new LogTableField(ID.LINES_READ.id, true, false, "LINES_READ", BaseMessages.getString(PKG, "StepLogTable.FieldName.LinesRead", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LinesRead", new String[0]), 5, 18));
/* 133 */     table.fields.add(new LogTableField(ID.LINES_WRITTEN.id, true, false, "LINES_WRITTEN", BaseMessages.getString(PKG, "StepLogTable.FieldName.LinesWritten", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LinesWritten", new String[0]), 5, 18));
/* 134 */     table.fields.add(new LogTableField(ID.LINES_UPDATED.id, true, false, "LINES_UPDATED", BaseMessages.getString(PKG, "StepLogTable.FieldName.LinesUpdated", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LinesUpdated", new String[0]), 5, 18));
/* 135 */     table.fields.add(new LogTableField(ID.LINES_INPUT.id, true, false, "LINES_INPUT", BaseMessages.getString(PKG, "StepLogTable.FieldName.LinesInput", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LinesInput", new String[0]), 5, 18));
/* 136 */     table.fields.add(new LogTableField(ID.LINES_OUTPUT.id, true, false, "LINES_OUTPUT", BaseMessages.getString(PKG, "StepLogTable.FieldName.LinesOutput", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LinesOutput", new String[0]), 5, 18));
/* 137 */     table.fields.add(new LogTableField(ID.LINES_REJECTED.id, true, false, "LINES_REJECTED", BaseMessages.getString(PKG, "StepLogTable.FieldName.LinesRejected", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LinesRejected", new String[0]), 5, 18));
/* 138 */     table.fields.add(new LogTableField(ID.ERRORS.id, true, false, "ERRORS", BaseMessages.getString(PKG, "StepLogTable.FieldName.Errors", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.Errors", new String[0]), 5, 18));
/* 139 */     table.fields.add(new LogTableField(ID.LOG_FIELD.id, false, false, "LOG_FIELD", BaseMessages.getString(PKG, "StepLogTable.FieldName.LogField", new String[0]), BaseMessages.getString(PKG, "StepLogTable.FieldDescription.LogField", new String[0]), 2, 9999999));
/*     */     
/* 141 */     table.findField(ID.TRANSNAME.id).setNameField(true);
/* 142 */     table.findField(ID.LOG_DATE.id).setLogDateField(true);
/* 143 */     table.findField(ID.ID_BATCH.id).setKey(true);
/* 144 */     table.findField(ID.CHANNEL_ID.id).setVisible(false);
/* 145 */     table.findField(ID.LOG_FIELD.id).setLogField(true);
/* 146 */     table.findField(ID.ERRORS.id).setErrorsField(true);
/*     */     
/* 148 */     return table;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowMetaAndData getLogRecord(LogStatus status, Object subject, Object parent)
/*     */   {
/* 157 */     if ((subject == null) || ((subject instanceof StepMetaDataCombi)))
/*     */     {
/* 159 */       StepMetaDataCombi combi = (StepMetaDataCombi)subject;
/*     */       
/* 161 */       RowMetaAndData row = new RowMetaAndData();
/*     */       
/* 163 */       for (LogTableField field : this.fields) {
/* 164 */         if (field.isEnabled()) {
/* 165 */           Object value = null;
/* 166 */           if (subject != null) {
/* 167 */             switch (ID.valueOf(field.getId())) {
/*     */             case ID_BATCH: 
/* 169 */               value = new Long(combi.step.getTrans().getBatchId()); break;
/* 170 */             case CHANNEL_ID:  value = combi.step.getLogChannel().getLogChannelId(); break;
/* 171 */             case LOG_DATE:  value = new Date(); break;
/* 172 */             case TRANSNAME:  value = combi.step.getTrans().getName(); break;
/* 173 */             case STEPNAME:  value = combi.stepname; break;
/* 174 */             case STEP_COPY:  value = new Long(combi.copy); break;
/* 175 */             case LINES_READ:  value = new Long(combi.step.getLinesRead()); break;
/* 176 */             case LINES_WRITTEN:  value = new Long(combi.step.getLinesWritten()); break;
/* 177 */             case LINES_UPDATED:  value = new Long(combi.step.getLinesUpdated()); break;
/* 178 */             case LINES_INPUT:  value = new Long(combi.step.getLinesInput()); break;
/* 179 */             case LINES_OUTPUT:  value = new Long(combi.step.getLinesOutput()); break;
/* 180 */             case LINES_REJECTED:  value = new Long(combi.step.getLinesRejected()); break;
/* 181 */             case ERRORS:  value = new Long(combi.step.getErrors()); break;
/*     */             case LOG_FIELD: 
/* 183 */               value = getLogBuffer(combi.step, combi.step.getLogChannel().getLogChannelId(), status, null);
/*     */             }
/*     */             
/*     */           }
/*     */           
/* 188 */           row.addValue(field.getFieldName(), field.getDataType(), value);
/* 189 */           row.getRowMeta().getValueMeta(row.size() - 1).setLength(field.getLength());
/*     */         }
/*     */       }
/*     */       
/* 193 */       return row;
/*     */     }
/*     */     
/* 196 */     return null;
/*     */   }
/*     */   
/*     */   public String getLogTableCode()
/*     */   {
/* 201 */     return "STEP";
/*     */   }
/*     */   
/*     */   public String getLogTableType() {
/* 205 */     return BaseMessages.getString(PKG, "StepLogTable.Type.Description", new String[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionNameVariable() {
/* 209 */     return "KETTLE_STEP_LOG_DB";
/*     */   }
/*     */   
/*     */   public String getSchemaNameVariable() {
/* 213 */     return "KETTLE_STEP_LOG_SCHEMA";
/*     */   }
/*     */   
/*     */   public String getTableNameVariable() {
/* 217 */     return "KETTLE_STEP_LOG_TABLE";
/*     */   }
/*     */   
/*     */   public List<RowMetaInterface> getRecommendedIndexes() {
/* 221 */     List<RowMetaInterface> indexes = new ArrayList();
/* 222 */     return indexes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\StepLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */