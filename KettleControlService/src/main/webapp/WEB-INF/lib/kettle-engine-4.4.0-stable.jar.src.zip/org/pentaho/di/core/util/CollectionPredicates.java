/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CollectionPredicates
/*     */ {
/*  37 */   private static final String TO_STRING_PREFIX = CollectionPredicates.class.getName() + ".";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  43 */   public static final Predicate EMPTY_COLLECTION = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/*     */ 
/*  51 */       return ((Collection)object).isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  61 */       return CollectionPredicates.TO_STRING_PREFIX + "EMPTY_COLLECTION";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   public static final Predicate NOT_EMPTY_COLLECTION = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/*     */ 
/*  77 */       return !CollectionPredicates.EMPTY_COLLECTION.evaluate(object);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/*  87 */       return CollectionPredicates.TO_STRING_PREFIX + "NOT_EMPTY_COLLECTION";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   public static final Predicate EMPTY_ARRAY = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/*     */ 
/* 103 */       return ((Object[])object).length == 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 113 */       return CollectionPredicates.TO_STRING_PREFIX + "EMPTY_ARRAY";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 120 */   public static final Predicate NOT_EMPTY_ARRAY = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 127 */       return !CollectionPredicates.EMPTY_ARRAY.evaluate(object);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 137 */       return CollectionPredicates.TO_STRING_PREFIX + "NOT_EMPTY_ARRAY";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 144 */   public static final Predicate EMPTY_MAP = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/*     */ 
/* 152 */       return ((Map)object).isEmpty();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 162 */       return CollectionPredicates.TO_STRING_PREFIX + "EMPTY_MAP";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */   public static final Predicate NOT_EMPTY_MAP = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 177 */       return !CollectionPredicates.EMPTY_MAP.evaluate(object);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 187 */       return CollectionPredicates.TO_STRING_PREFIX + "NOT_EMPTY_MAP";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 194 */   public static final Predicate NOT_NULL_OR_EMPTY_COLLECTION = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/*     */ 
/* 202 */       return (object != null) && (!CollectionPredicates.EMPTY_COLLECTION.evaluate(object));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 212 */       return CollectionPredicates.TO_STRING_PREFIX + "NOT_NULL_OR_EMPTY_COLLECTION";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */   public static final Predicate NOT_NULL_OR_EMPTY_ARRAY = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 227 */       return (object != null) && (!CollectionPredicates.EMPTY_ARRAY.evaluate(object));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 237 */       return CollectionPredicates.TO_STRING_PREFIX + "NOT_NULL_OR_EMPTY_ARRAY";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */   public static final Predicate NOT_NULL_OR_EMPTY_MAP = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 253 */       return (object != null) && (!CollectionPredicates.EMPTY_MAP.evaluate(object));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 263 */       return CollectionPredicates.TO_STRING_PREFIX + "NOT_NULL_OR_EMPTY_MAP";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 270 */   public static final Predicate NULL_OR_EMPTY_COLLECTION = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 277 */       return (object == null) || (CollectionPredicates.EMPTY_COLLECTION.evaluate(object));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 287 */       return CollectionPredicates.TO_STRING_PREFIX + "NULL_OR_EMPTY_COLLECTION";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 294 */   public static final Predicate NULL_OR_EMPTY_ARRAY = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 301 */       return (object == null) || (CollectionPredicates.EMPTY_ARRAY.evaluate(object));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 311 */       return CollectionPredicates.TO_STRING_PREFIX + "NULL_OR_EMPTY_ARRAY";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 318 */   public static final Predicate NULL_OR_EMPTY_MAP = new Predicate()
/*     */   {
/*     */ 
/*     */ 
/*     */     public boolean evaluate(Object object)
/*     */     {
/*     */ 
/* 325 */       return (object == null) || (CollectionPredicates.EMPTY_MAP.evaluate(object));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 335 */       return CollectionPredicates.TO_STRING_PREFIX + "NULL_OR_EMPTY_MAP";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNullOrEmpty(Collection<?> subject)
/*     */   {
/* 352 */     return NULL_OR_EMPTY_COLLECTION.evaluate(subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotNullOrEmpty(Collection<?> subject)
/*     */   {
/* 361 */     return NOT_NULL_OR_EMPTY_COLLECTION.evaluate(subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNullOrEmpty(Object[] subject)
/*     */   {
/* 371 */     return NULL_OR_EMPTY_ARRAY.evaluate(subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotNullOrEmpty(Object[] subject)
/*     */   {
/* 381 */     return NOT_NULL_OR_EMPTY_ARRAY.evaluate(subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNullOrEmpty(Map<?, ?> subject)
/*     */   {
/* 391 */     return NULL_OR_EMPTY_MAP.evaluate(subject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isNotNullOrEmpty(Map<?, ?> subject)
/*     */   {
/* 401 */     return NOT_NULL_OR_EMPTY_MAP.evaluate(subject);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\CollectionPredicates.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */