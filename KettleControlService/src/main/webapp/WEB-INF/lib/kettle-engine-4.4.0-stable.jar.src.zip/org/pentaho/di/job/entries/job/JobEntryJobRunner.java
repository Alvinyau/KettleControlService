/*     */ package org.pentaho.di.job.entries.job;
/*     */ 
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryJobRunner
/*     */   implements Runnable
/*     */ {
/*  39 */   private static Class<?> PKG = Job.class;
/*     */   
/*     */   private Job job;
/*     */   
/*     */   private Result result;
/*     */   
/*     */   private LogChannelInterface log;
/*     */   
/*     */   private int entryNr;
/*     */   private boolean finished;
/*     */   
/*     */   public JobEntryJobRunner(Job job, Result result, int entryNr, LogChannelInterface log)
/*     */   {
/*  52 */     this.job = job;
/*  53 */     this.result = result;
/*  54 */     this.log = log;
/*  55 */     this.entryNr = entryNr;
/*  56 */     this.finished = false;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*  63 */       if ((this.job.isStopped()) || ((this.job.getParentJob() != null) && (this.job.getParentJob().isStopped()))) { return;
/*     */       }
/*     */       
/*     */ 
/*  67 */       this.job.fireJobStartListeners();
/*  68 */       this.result = this.job.execute(this.entryNr + 1, this.result);
/*     */     }
/*     */     catch (KettleException e)
/*     */     {
/*  72 */       e.printStackTrace();
/*  73 */       this.log.logError("An error occurred executing this job entry : ", e);
/*  74 */       this.result.setResult(false);
/*  75 */       this.result.setNrErrors(1L);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/*  80 */         this.job.fireJobFinishListeners();
/*     */       } catch (KettleException e) {
/*  82 */         this.result.setNrErrors(1L);
/*  83 */         this.result.setResult(false);
/*  84 */         this.log.logError(BaseMessages.getString(PKG, "Job.Log.ErrorExecJob", new String[] { e.getMessage() }), e);
/*     */       }
/*     */     }
/*  87 */     this.finished = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResult(Result result)
/*     */   {
/*  95 */     this.result = result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result getResult()
/*     */   {
/* 103 */     return this.result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LogChannelInterface getLog()
/*     */   {
/* 111 */     return this.log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLog(LogChannelInterface log)
/*     */   {
/* 119 */     this.log = log;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Job getJob()
/*     */   {
/* 127 */     return this.job;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJob(Job job)
/*     */   {
/* 135 */     this.job = job;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEntryNr()
/*     */   {
/* 143 */     return this.entryNr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEntryNr(int entryNr)
/*     */   {
/* 151 */     this.entryNr = entryNr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFinished()
/*     */   {
/* 159 */     return this.finished;
/*     */   }
/*     */   
/*     */   public void waitUntilFinished()
/*     */   {
/* 164 */     while ((!isFinished()) && (!this.job.isStopped())) {
/*     */       try {
/* 166 */         Thread.sleep(0L, 1);
/*     */       }
/*     */       catch (InterruptedException e) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\job\JobEntryJobRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */