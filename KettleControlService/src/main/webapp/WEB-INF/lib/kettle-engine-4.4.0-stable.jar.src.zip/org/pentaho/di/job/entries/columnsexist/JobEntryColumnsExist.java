/*     */ package org.pentaho.di.job.entries.columnsexist;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.Database;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryColumnsExist
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  63 */   private static Class<?> PKG = JobEntryColumnsExist.class;
/*     */   private String schemaname;
/*     */   private String tablename;
/*     */   private DatabaseMeta connection;
/*     */   public String[] arguments;
/*     */   
/*     */   public JobEntryColumnsExist(String n)
/*     */   {
/*  71 */     super(n, "");
/*  72 */     this.schemaname = null;
/*  73 */     this.tablename = null;
/*  74 */     this.connection = null;
/*  75 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryColumnsExist()
/*     */   {
/*  80 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  85 */     JobEntryColumnsExist je = (JobEntryColumnsExist)super.clone();
/*  86 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  91 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/*  93 */     retval.append(super.getXML());
/*     */     
/*  95 */     retval.append("      ").append(XMLHandler.addTagValue("tablename", this.tablename));
/*  96 */     retval.append("      ").append(XMLHandler.addTagValue("schemaname", this.schemaname));
/*  97 */     retval.append("      ").append(XMLHandler.addTagValue("connection", this.connection == null ? null : this.connection.getName()));
/*     */     
/*  99 */     retval.append("      <fields>").append(Const.CR);
/* 100 */     if (this.arguments != null) {
/* 101 */       for (int i = 0; i < this.arguments.length; i++) {
/* 102 */         retval.append("        <field>").append(Const.CR);
/* 103 */         retval.append("          ").append(XMLHandler.addTagValue("name", this.arguments[i]));
/* 104 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 107 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/* 109 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 116 */       super.loadXML(entrynode, databases, slaveServers);
/* 117 */       this.tablename = XMLHandler.getTagValue(entrynode, "tablename");
/* 118 */       this.schemaname = XMLHandler.getTagValue(entrynode, "schemaname");
/*     */       
/* 120 */       String dbname = XMLHandler.getTagValue(entrynode, "connection");
/* 121 */       this.connection = DatabaseMeta.findDatabase(databases, dbname);
/*     */       
/*     */ 
/* 124 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 127 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 128 */       this.arguments = new String[nrFields];
/*     */       
/*     */ 
/* 131 */       for (int i = 0; i < nrFields; i++) {
/* 132 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/* 133 */         this.arguments[i] = XMLHandler.getTagValue(fnode, "name");
/*     */       }
/*     */       
/*     */     }
/*     */     catch (KettleException e)
/*     */     {
/* 139 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryColumnsExist.Meta.UnableLoadXml", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 147 */       this.tablename = rep.getJobEntryAttributeString(id_jobentry, "tablename");
/* 148 */       this.schemaname = rep.getJobEntryAttributeString(id_jobentry, "schemaname");
/*     */       
/* 150 */       this.connection = rep.loadDatabaseMetaFromJobEntryAttribute(id_jobentry, "connection", "id_database", databases);
/*     */       
/*     */ 
/* 153 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "name");
/* 154 */       this.arguments = new String[argnr];
/*     */       
/*     */ 
/* 157 */       for (int a = 0; a < argnr; a++)
/*     */       {
/* 159 */         this.arguments[a] = rep.getJobEntryAttributeString(id_jobentry, a, "name");
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 166 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryColumnsExist.Meta.UnableLoadRep", new String[] { "" + id_jobentry }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 174 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "tablename", this.tablename);
/* 175 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "schemaname", this.schemaname);
/*     */       
/* 177 */       rep.saveDatabaseMetaJobEntryAttribute(id_job, getObjectId(), "connection", "id_database", this.connection);
/*     */       
/*     */ 
/* 180 */       if (this.arguments != null) {
/* 181 */         for (int i = 0; i < this.arguments.length; i++) {
/* 182 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "name", this.arguments[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 188 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryColumnsExist.Meta.UnableSaveRep", new String[] { "" + id_job }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setTablename(String tablename)
/*     */   {
/* 194 */     this.tablename = tablename;
/*     */   }
/*     */   
/*     */   public String getTablename()
/*     */   {
/* 199 */     return this.tablename;
/*     */   }
/*     */   
/*     */   public void setSchemaname(String schemaname)
/*     */   {
/* 204 */     this.schemaname = schemaname;
/*     */   }
/*     */   
/*     */   public String getSchemaname()
/*     */   {
/* 209 */     return this.schemaname;
/*     */   }
/*     */   
/*     */   public void setDatabase(DatabaseMeta database)
/*     */   {
/* 214 */     this.connection = database;
/*     */   }
/*     */   
/*     */   public DatabaseMeta getDatabase()
/*     */   {
/* 219 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 224 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 229 */     return false;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 234 */     Result result = previousResult;
/* 235 */     result.setResult(false);
/* 236 */     result.setNrErrors(1L);
/*     */     
/* 238 */     int nrexistcolums = 0;
/* 239 */     int nrnotexistcolums = 0;
/*     */     
/* 241 */     if (Const.isEmpty(this.tablename))
/*     */     {
/* 243 */       logError(BaseMessages.getString(PKG, "JobEntryColumnsExist.Error.TablenameEmpty", new String[0]));
/* 244 */       return result;
/*     */     }
/* 246 */     if (this.arguments == null)
/*     */     {
/* 248 */       logError(BaseMessages.getString(PKG, "JobEntryColumnsExist.Error.ColumnameEmpty", new String[0]));
/* 249 */       return result;
/*     */     }
/* 251 */     if (this.connection != null)
/*     */     {
/* 253 */       Database db = new Database(this, this.connection);
/* 254 */       db.shareVariablesWith(this);
/*     */       try
/*     */       {
/* 257 */         String realSchemaname = environmentSubstitute(this.schemaname);
/* 258 */         String realTablename = environmentSubstitute(this.tablename);
/*     */         
/* 260 */         if (!Const.isEmpty(realSchemaname)) {
/* 261 */           realTablename = db.getDatabaseMeta().getQuotedSchemaTableCombination(realSchemaname, realTablename);
/*     */         } else {
/* 263 */           realTablename = db.getDatabaseMeta().quoteField(realTablename);
/*     */         }
/* 265 */         db.connect();
/*     */         
/* 267 */         if (db.checkTableExists(realTablename))
/*     */         {
/* 269 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobEntryColumnsExist.Log.TableExists", new String[] { realTablename }));
/*     */           }
/* 271 */           for (int i = 0; (i < this.arguments.length) && (!this.parentJob.isStopped()); i++)
/*     */           {
/* 273 */             String realColumnname = environmentSubstitute(this.arguments[i]);
/* 274 */             realColumnname = db.getDatabaseMeta().quoteField(realColumnname);
/*     */             
/* 276 */             if (db.checkColumnExists(realColumnname, realTablename))
/*     */             {
/* 278 */               if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobEntryColumnsExist.Log.ColumnExists", new String[] { realColumnname, realTablename }));
/* 279 */               nrexistcolums++;
/*     */             }
/*     */             else {
/* 282 */               logError(BaseMessages.getString(PKG, "JobEntryColumnsExist.Log.ColumnNotExists", new String[] { realColumnname, realTablename }));
/* 283 */               nrnotexistcolums++;
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 289 */           logError(BaseMessages.getString(PKG, "JobEntryColumnsExist.Log.TableNotExists", new String[] { realTablename }));
/*     */         }
/*     */       }
/*     */       catch (KettleDatabaseException dbe)
/*     */       {
/* 294 */         logError(BaseMessages.getString(PKG, "JobEntryColumnsExist.Error.UnexpectedError", new String[] { dbe.getMessage() }));
/*     */       }
/*     */       finally {
/* 297 */         if (db != null) try { db.disconnect();
/*     */           }
/*     */           catch (Exception e) {}
/*     */       }
/*     */     } else {
/* 302 */       logError(BaseMessages.getString(PKG, "JobEntryColumnsExist.Error.NoDbConnection", new String[0]));
/*     */     }
/*     */     
/* 305 */     result.setEntryNr(nrnotexistcolums);
/* 306 */     result.setNrLinesWritten(nrexistcolums);
/* 307 */     if (nrnotexistcolums == 0) result.setResult(true);
/* 308 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 314 */   public DatabaseMeta[] getUsedDatabaseConnections() { return new DatabaseMeta[] { this.connection }; }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 317 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 318 */     if (this.connection != null) {
/* 319 */       ResourceReference reference = new ResourceReference(this);
/* 320 */       reference.getEntries().add(new ResourceEntry(this.connection.getHostname(), ResourceEntry.ResourceType.SERVER));
/* 321 */       reference.getEntries().add(new ResourceEntry(this.connection.getDatabaseName(), ResourceEntry.ResourceType.DATABASENAME));
/* 322 */       references.add(reference);
/*     */     }
/* 324 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 330 */     JobEntryValidatorUtils.andValidator().validate(this, "tablename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 331 */     JobEntryValidatorUtils.andValidator().validate(this, "columnname", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\columnsexist\JobEntryColumnsExist.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */