/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.gui.JobTracker;
/*     */ import org.pentaho.di.core.row.RowMeta;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobEntryResult;
/*     */ import org.pentaho.di.job.entry.JobEntryCopy;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.trans.HasDatabasesInterface;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryLogTable
/*     */   extends BaseLogTable
/*     */   implements Cloneable, LogTableInterface
/*     */ {
/*  56 */   private static Class<?> PKG = JobEntryLogTable.class;
/*     */   
/*     */   public static final String XML_TAG = "jobentry-log-table";
/*     */   
/*     */   public static enum ID
/*     */   {
/*  62 */     ID_BATCH("ID_BATCH"), 
/*  63 */     CHANNEL_ID("CHANNEL_ID"), 
/*  64 */     LOG_DATE("LOG_DATE"), 
/*  65 */     JOBNAME("JOBNAME"), 
/*  66 */     JOBENTRYNAME("JOBENTRYNAME"), 
/*  67 */     LINES_READ("LINES_READ"), 
/*  68 */     LINES_WRITTEN("LINES_WRITTEN"), 
/*  69 */     LINES_UPDATED("LINES_UPDATED"), 
/*  70 */     LINES_INPUT("LINES_INPUT"), 
/*  71 */     LINES_OUTPUT("LINES_OUTPUT"), 
/*  72 */     LINES_REJECTED("LINES_REJECTED"), 
/*  73 */     ERRORS("ERRORS"), 
/*  74 */     RESULT("RESULT"), 
/*  75 */     NR_RESULT_ROWS("NR_RESULT_ROWS"), 
/*  76 */     NR_RESULT_FILES("NR_RESULT_FILES"), 
/*  77 */     LOG_FIELD("LOG_FIELD"), 
/*  78 */     COPY_NR("COPY_NR");
/*     */     
/*     */     private String id;
/*     */     
/*     */     private ID(String id) {
/*  83 */       this.id = id;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  87 */       return this.id;
/*     */     }
/*     */   }
/*     */   
/*     */   private JobEntryLogTable(VariableSpace space, HasDatabasesInterface databasesInterface) {
/*  92 */     super(space, databasesInterface, null, null, null);
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/*  98 */       JobEntryLogTable table = (JobEntryLogTable)super.clone();
/*  99 */       table.fields = new ArrayList();
/* 100 */       for (LogTableField field : this.fields) {
/* 101 */         table.fields.add((LogTableField)field.clone());
/*     */       }
/* 103 */       return table;
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/* 106 */     return null;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 111 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 113 */     retval.append(XMLHandler.openTag("jobentry-log-table"));
/* 114 */     retval.append(XMLHandler.addTagValue("connection", this.connectionName));
/* 115 */     retval.append(XMLHandler.addTagValue("schema", this.schemaName));
/* 116 */     retval.append(XMLHandler.addTagValue("table", this.tableName));
/* 117 */     retval.append(XMLHandler.addTagValue("timeout_days", this.timeoutInDays));
/* 118 */     retval.append(super.getFieldsXML());
/* 119 */     retval.append(XMLHandler.closeTag("jobentry-log-table")).append(Const.CR);
/*     */     
/* 121 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node node, List<DatabaseMeta> databases) {
/* 125 */     this.connectionName = XMLHandler.getTagValue(node, "connection");
/* 126 */     this.schemaName = XMLHandler.getTagValue(node, "schema");
/* 127 */     this.tableName = XMLHandler.getTagValue(node, "table");
/* 128 */     this.timeoutInDays = XMLHandler.getTagValue(node, "timeout_days");
/*     */     
/* 130 */     super.loadFieldsXML(node);
/*     */   }
/*     */   
/*     */   public static JobEntryLogTable getDefault(VariableSpace space, HasDatabasesInterface databasesInterface) {
/* 134 */     JobEntryLogTable table = new JobEntryLogTable(space, databasesInterface);
/*     */     
/* 136 */     table.fields.add(new LogTableField(ID.ID_BATCH.id, true, false, "ID_BATCH", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.IdBatch", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.IdBatch", new String[0]), 5, 8));
/* 137 */     table.fields.add(new LogTableField(ID.CHANNEL_ID.id, true, false, "CHANNEL_ID", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.ChannelId", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.ChannelId", new String[0]), 2, 255));
/* 138 */     table.fields.add(new LogTableField(ID.LOG_DATE.id, true, false, "LOG_DATE", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LogDate", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LogDate", new String[0]), 3, -1));
/* 139 */     table.fields.add(new LogTableField(ID.JOBNAME.id, true, false, "TRANSNAME", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.JobName", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.JobName", new String[0]), 2, 255));
/* 140 */     table.fields.add(new LogTableField(ID.JOBENTRYNAME.id, true, false, "STEPNAME", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.JobEntryName", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.JobEntryName", new String[0]), 2, 255));
/* 141 */     table.fields.add(new LogTableField(ID.LINES_READ.id, true, false, "LINES_READ", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LinesRead", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LinesRead", new String[0]), 5, 18));
/* 142 */     table.fields.add(new LogTableField(ID.LINES_WRITTEN.id, true, false, "LINES_WRITTEN", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LinesWritten", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LinesWritten", new String[0]), 5, 18));
/* 143 */     table.fields.add(new LogTableField(ID.LINES_UPDATED.id, true, false, "LINES_UPDATED", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LinesUpdated", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LinesUpdated", new String[0]), 5, 18));
/* 144 */     table.fields.add(new LogTableField(ID.LINES_INPUT.id, true, false, "LINES_INPUT", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LinesInput", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LinesInput", new String[0]), 5, 18));
/* 145 */     table.fields.add(new LogTableField(ID.LINES_OUTPUT.id, true, false, "LINES_OUTPUT", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LinesOutput", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LinesOutput", new String[0]), 5, 18));
/* 146 */     table.fields.add(new LogTableField(ID.LINES_REJECTED.id, true, false, "LINES_REJECTED", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LinesRejected", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LinesRejected", new String[0]), 5, 18));
/* 147 */     table.fields.add(new LogTableField(ID.ERRORS.id, true, false, "ERRORS", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.Errors", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.Errors", new String[0]), 5, 18));
/* 148 */     table.fields.add(new LogTableField(ID.RESULT.id, true, false, "RESULT", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.Result", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.Result", new String[0]), 4, -1));
/* 149 */     table.fields.add(new LogTableField(ID.NR_RESULT_ROWS.id, true, false, "NR_RESULT_ROWS", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.NrResultRows", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.NrResultRows", new String[0]), 5, 18));
/* 150 */     table.fields.add(new LogTableField(ID.NR_RESULT_FILES.id, true, false, "NR_RESULT_FILES", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.NrResultFiles", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.NrResultFiles", new String[0]), 5, 18));
/* 151 */     table.fields.add(new LogTableField(ID.LOG_FIELD.id, false, false, "LOG_FIELD", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.LogField", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.LogField", new String[0]), 2, 9999999));
/* 152 */     table.fields.add(new LogTableField(ID.COPY_NR.id, false, false, "COPY_NR", BaseMessages.getString(PKG, "JobEntryLogTable.FieldName.CopyNr", new String[0]), BaseMessages.getString(PKG, "JobEntryLogTable.FieldDescription.CopyNr", new String[0]), 5, 8));
/*     */     
/* 154 */     table.findField(ID.JOBNAME.id).setNameField(true);
/* 155 */     table.findField(ID.LOG_DATE.id).setLogDateField(true);
/* 156 */     table.findField(ID.ID_BATCH.id).setKey(true);
/* 157 */     table.findField(ID.CHANNEL_ID.id).setVisible(false);
/* 158 */     table.findField(ID.LOG_FIELD.id).setLogField(true);
/* 159 */     table.findField(ID.ERRORS.id).setErrorsField(true);
/*     */     
/* 161 */     return table;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowMetaAndData getLogRecord(LogStatus status, Object subject, Object parent)
/*     */   {
/* 172 */     if ((subject == null) || ((subject instanceof JobEntryCopy)))
/*     */     {
/* 174 */       JobEntryCopy jobEntryCopy = (JobEntryCopy)subject;
/* 175 */       Job parentJob = (Job)parent;
/*     */       
/* 177 */       RowMetaAndData row = new RowMetaAndData();
/*     */       
/* 179 */       for (LogTableField field : this.fields) {
/* 180 */         if (field.isEnabled()) {
/* 181 */           Object value = null;
/* 182 */           if (subject != null)
/*     */           {
/* 184 */             JobEntryInterface jobEntry = jobEntryCopy.getEntry();
/* 185 */             JobTracker jobTracker = parentJob.getJobTracker();
/* 186 */             JobTracker entryTracker = jobTracker.findJobTracker(jobEntryCopy);
/* 187 */             JobEntryResult jobEntryResult = null;
/* 188 */             if (entryTracker != null) {
/* 189 */               jobEntryResult = entryTracker.getJobEntryResult();
/*     */             }
/* 191 */             Result result = null;
/* 192 */             if (jobEntryResult != null) {
/* 193 */               result = jobEntryResult.getResult();
/*     */             }
/*     */             
/* 196 */             switch (ID.valueOf(field.getId())) {
/*     */             case ID_BATCH: 
/* 198 */               value = new Long(parentJob.getBatchId()); break;
/* 199 */             case CHANNEL_ID:  value = jobEntry.getLogChannel().getLogChannelId(); break;
/* 200 */             case LOG_DATE:  value = new Date(); break;
/* 201 */             case JOBNAME:  value = parentJob.getJobname(); break;
/* 202 */             case JOBENTRYNAME:  value = jobEntry.getName(); break;
/* 203 */             case LINES_READ:  value = new Long(result != null ? result.getNrLinesRead() : 0L); break;
/* 204 */             case LINES_WRITTEN:  value = new Long(result != null ? result.getNrLinesWritten() : 0L); break;
/* 205 */             case LINES_UPDATED:  value = new Long(result != null ? result.getNrLinesUpdated() : 0L); break;
/* 206 */             case LINES_INPUT:  value = new Long(result != null ? result.getNrLinesInput() : 0L); break;
/* 207 */             case LINES_OUTPUT:  value = new Long(result != null ? result.getNrLinesOutput() : 0L); break;
/* 208 */             case LINES_REJECTED:  value = new Long(result != null ? result.getNrLinesRejected() : 0L); break;
/* 209 */             case ERRORS:  value = new Long(result != null ? result.getNrErrors() : 0L); break;
/* 210 */             case RESULT:  value = new Boolean(result != null ? result.getResult() : false); break;
/* 211 */             case NR_RESULT_FILES:  value = new Long((result != null) && (result.getResultFiles() != null) ? result.getResultFiles().size() : 0L); break;
/* 212 */             case NR_RESULT_ROWS:  value = new Long((result != null) && (result.getRows() != null) ? result.getRows().size() : 0L); break;
/*     */             case LOG_FIELD: 
/* 214 */               if (result != null)
/* 215 */                 value = result.getLogText();
/*     */               break;
/*     */             case COPY_NR: 
/* 218 */               value = new Long(jobEntryCopy.getNr());
/*     */             }
/*     */             
/*     */           }
/* 222 */           row.addValue(field.getFieldName(), field.getDataType(), value);
/* 223 */           row.getRowMeta().getValueMeta(row.size() - 1).setLength(field.getLength());
/*     */         }
/*     */       }
/*     */       
/* 227 */       return row;
/*     */     }
/*     */     
/* 230 */     return null;
/*     */   }
/*     */   
/*     */   public String getLogTableCode()
/*     */   {
/* 235 */     return "JOB_ENTRY";
/*     */   }
/*     */   
/*     */   public String getLogTableType() {
/* 239 */     return BaseMessages.getString(PKG, "JobEntryLogTable.Type.Description", new String[0]);
/*     */   }
/*     */   
/*     */   public String getConnectionNameVariable() {
/* 243 */     return "KETTLE_JOBENTRY_LOG_DB";
/*     */   }
/*     */   
/*     */   public String getSchemaNameVariable() {
/* 247 */     return "KETTLE_JOBENTRY_LOG_SCHEMA";
/*     */   }
/*     */   
/*     */   public String getTableNameVariable() {
/* 251 */     return "KETTLE_JOBENTRY_LOG_TABLE";
/*     */   }
/*     */   
/*     */   public List<RowMetaInterface> getRecommendedIndexes() {
/* 255 */     List<RowMetaInterface> indexes = new ArrayList();
/* 256 */     LogTableField keyField = getKeyField();
/*     */     
/* 258 */     if (keyField.isEnabled()) {
/* 259 */       RowMetaInterface batchIndex = new RowMeta();
/*     */       
/* 261 */       ValueMetaInterface keyMeta = new ValueMeta(keyField.getFieldName(), keyField.getDataType());
/* 262 */       keyMeta.setLength(keyField.getLength());
/* 263 */       batchIndex.addValueMeta(keyMeta);
/*     */       
/* 265 */       indexes.add(batchIndex);
/*     */     }
/*     */     
/* 268 */     return indexes;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\JobEntryLogTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */