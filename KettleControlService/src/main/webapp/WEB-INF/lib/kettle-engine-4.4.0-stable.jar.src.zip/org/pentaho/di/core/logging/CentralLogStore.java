/*     */ package org.pentaho.di.core.logging;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.util.EnvUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CentralLogStore
/*     */ {
/*     */   private static CentralLogStore store;
/*     */   private Log4jBufferAppender appender;
/*     */   private Timer logCleanerTimer;
/*     */   
/*     */   private CentralLogStore(int maxSize, int maxLogTimeoutMinutes)
/*     */   {
/*  50 */     this.appender = new Log4jBufferAppender(maxSize);
/*  51 */     LogWriter.getInstance().addAppender(this.appender);
/*  52 */     replaceLogCleaner(maxLogTimeoutMinutes);
/*     */   }
/*     */   
/*     */   public void replaceLogCleaner(final int maxLogTimeoutMinutes) {
/*  56 */     if (this.logCleanerTimer != null) {
/*  57 */       this.logCleanerTimer.cancel();
/*     */     }
/*  59 */     this.logCleanerTimer = new Timer(true);
/*  60 */     final AtomicBoolean busy = new AtomicBoolean(false);
/*  61 */     TimerTask timerTask = new TimerTask() {
/*     */       public void run() {
/*  63 */         if (!busy.get()) {
/*  64 */           busy.set(true);
/*  65 */           if (maxLogTimeoutMinutes > 0) {
/*  66 */             long minTimeBoundary = new Date().getTime() - maxLogTimeoutMinutes * 60 * 1000;
/*  67 */             synchronized (CentralLogStore.this.appender) {
/*  68 */               Iterator<BufferLine> i = CentralLogStore.this.appender.getBufferIterator();
/*  69 */               while (i.hasNext()) {
/*  70 */                 BufferLine bufferLine = (BufferLine)i.next();
/*     */                 
/*  72 */                 if (bufferLine.getEvent().timeStamp >= minTimeBoundary) break;
/*  73 */                 i.remove();
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*  80 */           busy.set(false);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*  86 */     };
/*  87 */     this.logCleanerTimer.schedule(timerTask, 10000L, 10000L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init(int maxSize, int maxLogTimeoutMinutes)
/*     */   {
/*  98 */     if ((maxSize > 0) || (maxLogTimeoutMinutes > 0)) {
/*  99 */       init0(maxSize, maxLogTimeoutMinutes);
/*     */     } else {
/* 101 */       init();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void init() {
/* 106 */     int maxSize = Const.toInt(EnvUtil.getSystemProperty("KETTLE_MAX_LOG_SIZE_IN_LINES"), 5000);
/* 107 */     int maxLogTimeoutMinutes = Const.toInt(EnvUtil.getSystemProperty("KETTLE_MAX_LOG_TIMEOUT_IN_MINUTES"), 1440);
/* 108 */     init0(maxSize, maxLogTimeoutMinutes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static synchronized void init0(int maxSize, int maxLogTimeoutMinutes)
/*     */   {
/* 119 */     if (store != null)
/*     */     {
/* 121 */       store.appender.setMaxNrLines(maxSize);
/* 122 */       store.replaceLogCleaner(maxLogTimeoutMinutes);
/*     */     } else {
/* 124 */       store = new CentralLogStore(maxSize, maxLogTimeoutMinutes);
/*     */     }
/*     */   }
/*     */   
/*     */   private static CentralLogStore getInstance() {
/* 129 */     if (store == null) {
/* 130 */       throw new RuntimeException("Central Log Store is not initialized!!!");
/*     */     }
/* 132 */     return store;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getLastBufferLineNr()
/*     */   {
/* 140 */     return getInstance().appender.getLastBufferLineNr();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<LoggingEvent> getLogBufferFromTo(String parentLogChannelId, boolean includeGeneral, int from, int to)
/*     */   {
/* 154 */     return getInstance().appender.getLogBufferFromTo(parentLogChannelId, includeGeneral, from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<LoggingEvent> getLogBufferFromTo(List<String> channelId, boolean includeGeneral, int from, int to)
/*     */   {
/* 168 */     return getInstance().appender.getLogBufferFromTo(channelId, includeGeneral, from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Log4jBufferAppender getAppender()
/*     */   {
/* 175 */     return getInstance().appender;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void discardLines(String parentLogChannelId, boolean includeGeneralMessages)
/*     */   {
/* 184 */     LoggingRegistry registry = LoggingRegistry.getInstance();
/* 185 */     List<String> ids = registry.getLogChannelChildren(parentLogChannelId);
/*     */     
/*     */ 
/*     */ 
/* 189 */     Log4jBufferAppender bufferAppender = getInstance().appender;
/*     */     
/* 191 */     for (String id : ids)
/*     */     {
/*     */ 
/* 194 */       bufferAppender.removeChannelFromBuffer(id);
/*     */       
/*     */ 
/*     */ 
/* 198 */       registry.getMap().remove(id);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 203 */     if (includeGeneralMessages) {
/* 204 */       bufferAppender.removeGeneralMessages();
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\logging\CentralLogStore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */