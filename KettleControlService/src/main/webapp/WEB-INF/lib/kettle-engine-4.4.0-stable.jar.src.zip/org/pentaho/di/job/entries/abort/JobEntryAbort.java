/*     */ package org.pentaho.di.job.entries.abort;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryAbort
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  52 */   private static Class<?> PKG = JobEntryAbort.class;
/*     */   private String messageAbort;
/*     */   
/*     */   public JobEntryAbort(String n, String scr)
/*     */   {
/*  57 */     super(n, "");
/*  58 */     this.messageAbort = null;
/*     */   }
/*     */   
/*     */   public JobEntryAbort() {
/*  62 */     this("", "");
/*     */   }
/*     */   
/*     */   public Object clone() {
/*  66 */     JobEntryAbort je = (JobEntryAbort)super.clone();
/*  67 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML() {
/*  71 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  73 */     retval.append(super.getXML());
/*  74 */     retval.append("      ").append(XMLHandler.addTagValue("message", this.messageAbort));
/*     */     
/*  76 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException {
/*     */     try {
/*  81 */       super.loadXML(entrynode, databases, slaveServers);
/*  82 */       this.messageAbort = XMLHandler.getTagValue(entrynode, "message");
/*     */     } catch (Exception e) {
/*  84 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryAbort.UnableToLoadFromXml.Label", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException {
/*     */     try {
/*  90 */       this.messageAbort = rep.getJobEntryAttributeString(id_jobentry, "message");
/*     */     } catch (KettleDatabaseException dbe) {
/*  92 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryAbort.UnableToLoadFromRepo.Label", new String[] { String.valueOf(id_jobentry) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 100 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "message", this.messageAbort);
/*     */     }
/*     */     catch (KettleDatabaseException dbe) {
/* 103 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryAbort.UnableToSaveToRepo.Label", new String[] { String.valueOf(id_job) }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean evaluate(Result result)
/*     */   {
/* 109 */     String Returnmessage = null;
/* 110 */     String RealMessageabort = environmentSubstitute(getMessageabort());
/*     */     
/*     */     try
/*     */     {
/* 114 */       if (RealMessageabort == null) {
/* 115 */         Returnmessage = BaseMessages.getString(PKG, "JobEntryAbort.Meta.CheckResult.Label", new String[0]);
/*     */       } else {
/* 117 */         Returnmessage = RealMessageabort;
/*     */       }
/*     */       
/* 120 */       logError(Returnmessage);
/* 121 */       result.setNrErrors(1L);
/* 122 */       return false;
/*     */     } catch (Exception e) {
/* 124 */       result.setNrErrors(1L);
/* 125 */       logError(BaseMessages.getString(PKG, "JobEntryAbort.Meta.CheckResult.CouldNotExecute", new String[0]) + e.toString()); }
/* 126 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 137 */     previousResult.setResult(evaluate(previousResult));
/*     */     
/*     */ 
/* 140 */     this.parentJob.stopAll();
/* 141 */     return previousResult;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean resetErrorsBeforeExecution()
/*     */   {
/* 147 */     return false;
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 151 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional() {
/* 155 */     return false;
/*     */   }
/*     */   
/*     */   public void setMessageabort(String messageabort) {
/* 159 */     this.messageAbort = messageabort;
/*     */   }
/*     */   
/*     */   public String getMessageabort() {
/* 163 */     return this.messageAbort;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {
/* 167 */     JobEntryValidatorUtils.addOkRemark(this, "messageabort", remarks);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\abort\JobEntryAbort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */