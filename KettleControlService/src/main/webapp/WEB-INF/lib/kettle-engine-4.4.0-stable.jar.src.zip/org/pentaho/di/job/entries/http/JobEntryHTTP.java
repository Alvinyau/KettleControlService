/*     */ package org.pentaho.di.job.entries.http;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Authenticator;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.PasswordAuthentication;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.encryption.Encr;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryHTTP
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  81 */   private static Class<?> PKG = JobEntryHTTP.class;
/*     */   
/*     */ 
/*     */   private static final String URL_FIELDNAME = "URL";
/*     */   
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */   private String targetFilename;
/*     */   
/*     */ 
/*     */   private boolean fileAppended;
/*     */   
/*     */ 
/*     */   private boolean dateTimeAdded;
/*     */   
/*     */   private String targetFilenameExtention;
/*     */   
/*     */   private String uploadFilename;
/*     */   
/*     */   private String urlFieldname;
/*     */   
/*     */   private boolean runForEveryRow;
/*     */   
/*     */   private String proxyHostname;
/*     */   
/*     */   private String proxyPort;
/*     */   
/*     */   private String nonProxyHosts;
/*     */   
/*     */   private String username;
/*     */   
/*     */   private String password;
/*     */   
/*     */   private boolean addfilenameresult;
/*     */   
/*     */   private String[] headerName;
/*     */   
/*     */   private String[] headerValue;
/*     */   
/*     */ 
/*     */   public JobEntryHTTP(String n)
/*     */   {
/* 125 */     super(n, "");
/* 126 */     this.url = null;
/* 127 */     this.addfilenameresult = true;
/* 128 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryHTTP()
/*     */   {
/* 133 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 138 */     JobEntryHTTP je = (JobEntryHTTP)super.clone();
/* 139 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 144 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 146 */     retval.append(super.getXML());
/*     */     
/* 148 */     retval.append("      ").append(XMLHandler.addTagValue("url", this.url));
/* 149 */     retval.append("      ").append(XMLHandler.addTagValue("targetfilename", this.targetFilename));
/* 150 */     retval.append("      ").append(XMLHandler.addTagValue("file_appended", this.fileAppended));
/* 151 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_added", this.dateTimeAdded));
/* 152 */     retval.append("      ").append(XMLHandler.addTagValue("targetfilename_extention", this.targetFilenameExtention));
/* 153 */     retval.append("      ").append(XMLHandler.addTagValue("uploadfilename", this.uploadFilename));
/*     */     
/* 155 */     retval.append("      ").append(XMLHandler.addTagValue("url_fieldname", this.urlFieldname));
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("run_every_row", this.runForEveryRow));
/*     */     
/* 158 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.username));
/* 159 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(this.password)));
/*     */     
/* 161 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_host", this.proxyHostname));
/* 162 */     retval.append("      ").append(XMLHandler.addTagValue("proxy_port", this.proxyPort));
/* 163 */     retval.append("      ").append(XMLHandler.addTagValue("non_proxy_hosts", this.nonProxyHosts));
/* 164 */     retval.append("      ").append(XMLHandler.addTagValue("addfilenameresult", this.addfilenameresult));
/* 165 */     retval.append("      <headers>").append(Const.CR);
/* 166 */     if (this.headerName != null) {
/* 167 */       for (int i = 0; i < this.headerName.length; i++) {
/* 168 */         retval.append("        <header>").append(Const.CR);
/* 169 */         retval.append("          ").append(XMLHandler.addTagValue("header_name", this.headerName[i]));
/* 170 */         retval.append("          ").append(XMLHandler.addTagValue("header_value", this.headerValue[i]));
/* 171 */         retval.append("        </header>").append(Const.CR);
/*     */       }
/*     */     }
/* 174 */     retval.append("      </headers>").append(Const.CR);
/*     */     
/*     */ 
/*     */ 
/* 178 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 185 */       super.loadXML(entrynode, databases, slaveServers);
/* 186 */       this.url = XMLHandler.getTagValue(entrynode, "url");
/* 187 */       this.targetFilename = XMLHandler.getTagValue(entrynode, "targetfilename");
/* 188 */       this.fileAppended = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "file_appended"));
/* 189 */       this.dateTimeAdded = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "date_time_added"));
/* 190 */       this.targetFilenameExtention = XMLHandler.getTagValue(entrynode, "targetfilename_extention");
/*     */       
/* 192 */       this.uploadFilename = XMLHandler.getTagValue(entrynode, "uploadfilename");
/*     */       
/* 194 */       this.urlFieldname = XMLHandler.getTagValue(entrynode, "url_fieldname");
/* 195 */       this.runForEveryRow = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "run_every_row"));
/*     */       
/* 197 */       this.username = XMLHandler.getTagValue(entrynode, "username");
/* 198 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/*     */       
/* 200 */       this.proxyHostname = XMLHandler.getTagValue(entrynode, "proxy_host");
/* 201 */       this.proxyPort = XMLHandler.getTagValue(entrynode, "proxy_port");
/* 202 */       this.nonProxyHosts = XMLHandler.getTagValue(entrynode, "non_proxy_hosts");
/* 203 */       this.addfilenameresult = "Y".equalsIgnoreCase(Const.NVL(XMLHandler.getTagValue(entrynode, "addfilenameresult"), "Y"));
/* 204 */       Node headers = XMLHandler.getSubNode(entrynode, "headers");
/*     */       
/*     */ 
/* 207 */       int nrHeaders = XMLHandler.countNodes(headers, "header");
/* 208 */       this.headerName = new String[nrHeaders];
/* 209 */       this.headerValue = new String[nrHeaders];
/* 210 */       for (int i = 0; i < nrHeaders; i++) {
/* 211 */         Node fnode = XMLHandler.getSubNodeByNr(headers, "header", i);
/* 212 */         this.headerName[i] = XMLHandler.getTagValue(fnode, "header_name");
/* 213 */         this.headerValue[i] = XMLHandler.getTagValue(fnode, "header_value");
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException xe) {
/* 217 */       throw new KettleXMLException("Unable to load job entry of type 'HTTP' from XML node", xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 225 */       this.url = rep.getJobEntryAttributeString(id_jobentry, "url");
/* 226 */       this.targetFilename = rep.getJobEntryAttributeString(id_jobentry, "targetfilename");
/* 227 */       this.fileAppended = rep.getJobEntryAttributeBoolean(id_jobentry, "file_appended");
/* 228 */       this.dateTimeAdded = "Y".equalsIgnoreCase(rep.getJobEntryAttributeString(id_jobentry, "date_time_added"));
/* 229 */       this.targetFilenameExtention = rep.getJobEntryAttributeString(id_jobentry, "targetfilename_extention");
/*     */       
/* 231 */       this.uploadFilename = rep.getJobEntryAttributeString(id_jobentry, "uploadfilename");
/*     */       
/* 233 */       this.urlFieldname = rep.getJobEntryAttributeString(id_jobentry, "url_fieldname");
/* 234 */       this.runForEveryRow = rep.getJobEntryAttributeBoolean(id_jobentry, "run_every_row");
/*     */       
/* 236 */       this.username = rep.getJobEntryAttributeString(id_jobentry, "username");
/* 237 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/*     */       
/* 239 */       this.proxyHostname = rep.getJobEntryAttributeString(id_jobentry, "proxy_host");
/* 240 */       int intPort = (int)rep.getJobEntryAttributeInteger(id_jobentry, "proxy_port");
/* 241 */       this.proxyPort = rep.getJobEntryAttributeString(id_jobentry, "proxy_port");
/* 242 */       if ((intPort > 0) && (Const.isEmpty(this.proxyPort))) {
/* 243 */         this.proxyPort = Integer.toString(intPort);
/*     */       }
/* 245 */       this.nonProxyHosts = rep.getJobEntryAttributeString(id_jobentry, "non_proxy_hosts");
/* 246 */       this.addfilenameresult = "Y".equalsIgnoreCase(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "addfilenameresult"), "Y"));
/*     */       
/*     */ 
/* 249 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "header_name");
/* 250 */       this.headerName = new String[argnr];
/* 251 */       this.headerValue = new String[argnr];
/* 252 */       for (int a = 0; a < argnr; a++) {
/* 253 */         this.headerName[a] = rep.getJobEntryAttributeString(id_jobentry, a, "header_name");
/* 254 */         this.headerValue[a] = rep.getJobEntryAttributeString(id_jobentry, a, "header_value");
/*     */       }
/*     */     }
/*     */     catch (KettleException dbe) {
/* 258 */       throw new KettleException("Unable to load job entry of type 'HTTP' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 267 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "url", this.url);
/* 268 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "targetfilename", this.targetFilename);
/* 269 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "file_appended", this.fileAppended);
/* 270 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_added", this.dateTimeAdded);
/* 271 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "targetfilename_extention", this.targetFilenameExtention);
/*     */       
/* 273 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "uploadfilename", this.uploadFilename);
/*     */       
/* 275 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "url_fieldname", this.urlFieldname);
/* 276 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "run_every_row", this.runForEveryRow);
/*     */       
/* 278 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.username);
/* 279 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/*     */       
/* 281 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_host", this.proxyHostname);
/* 282 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "proxy_port", this.proxyPort);
/* 283 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "non_proxy_hosts", this.nonProxyHosts);
/* 284 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "addfilenameresult", this.addfilenameresult);
/* 285 */       if (this.headerName != null) {
/* 286 */         for (int i = 0; i < this.headerName.length; i++) {
/* 287 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "header_name", this.headerName[i]);
/* 288 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "header_value", this.headerValue[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 294 */       throw new KettleException("Unable to load job entry of type 'HTTP' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 303 */     return this.url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrl(String url)
/*     */   {
/* 311 */     this.url = url;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTargetFilename()
/*     */   {
/* 319 */     return this.targetFilename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetFilename(String targetFilename)
/*     */   {
/* 327 */     this.targetFilename = targetFilename;
/*     */   }
/*     */   
/*     */   public String getNonProxyHosts()
/*     */   {
/* 332 */     return this.nonProxyHosts;
/*     */   }
/*     */   
/*     */   public void setNonProxyHosts(String nonProxyHosts)
/*     */   {
/* 337 */     this.nonProxyHosts = nonProxyHosts;
/*     */   }
/*     */   
/*     */   public boolean isAddFilenameToResult() {
/* 341 */     return this.addfilenameresult;
/*     */   }
/*     */   
/*     */   public void setAddFilenameToResult(boolean addfilenameresult)
/*     */   {
/* 346 */     this.addfilenameresult = addfilenameresult;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 350 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password)
/*     */   {
/* 355 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getProxyHostname()
/*     */   {
/* 360 */     return this.proxyHostname;
/*     */   }
/*     */   
/*     */   public void setProxyHostname(String proxyHostname)
/*     */   {
/* 365 */     this.proxyHostname = proxyHostname;
/*     */   }
/*     */   
/*     */   public String getProxyPort()
/*     */   {
/* 370 */     return this.proxyPort;
/*     */   }
/*     */   
/*     */   public void setProxyPort(String proxyPort)
/*     */   {
/* 375 */     this.proxyPort = proxyPort;
/*     */   }
/*     */   
/*     */   public String getUsername()
/*     */   {
/* 380 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username)
/*     */   {
/* 385 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String[] getHeaderName()
/*     */   {
/* 390 */     return this.headerName;
/*     */   }
/*     */   
/*     */   public void setHeaderName(String[] headerName)
/*     */   {
/* 395 */     this.headerName = headerName;
/*     */   }
/*     */   
/*     */   public String[] getHeaderValue()
/*     */   {
/* 400 */     return this.headerValue;
/*     */   }
/*     */   
/*     */   public void setHeaderValue(String[] headerValue)
/*     */   {
/* 405 */     this.headerValue = headerValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Result execute(Result previousResult, int nr)
/*     */   {
/* 415 */     Result result = previousResult;
/* 416 */     result.setResult(false);
/*     */     
/* 418 */     logBasic(BaseMessages.getString(PKG, "JobHTTP.StartJobEntry", new String[0]));
/*     */     
/*     */     String urlFieldnameToUse;
/*     */     
/*     */     String urlFieldnameToUse;
/*     */     
/* 424 */     if (Const.isEmpty(this.urlFieldname)) {
/* 425 */       urlFieldnameToUse = "URL";
/*     */     } else
/* 427 */       urlFieldnameToUse = this.urlFieldname;
/*     */     List<RowMetaAndData> resultRows;
/* 429 */     if (this.runForEveryRow)
/*     */     {
/* 431 */       List<RowMetaAndData> resultRows = previousResult.getRows();
/* 432 */       if (resultRows == null)
/*     */       {
/* 434 */         result.setNrErrors(1L);
/* 435 */         logError(BaseMessages.getString(PKG, "JobHTTP.Error.UnableGetResultPrevious", new String[0]));
/* 436 */         return result;
/*     */       }
/*     */     }
/*     */     else {
/* 440 */       resultRows = new ArrayList();
/* 441 */       RowMetaAndData row = new RowMetaAndData();
/* 442 */       row.addValue(new ValueMeta(urlFieldnameToUse, 2), environmentSubstitute(this.url));
/* 443 */       resultRows.add(row);
/*     */     }
/*     */     
/* 446 */     URL server = null;
/*     */     
/* 448 */     String beforeProxyHost = System.getProperty("http.proxyHost");
/* 449 */     String beforeProxyPort = System.getProperty("http.proxyPort");
/* 450 */     String beforeNonProxyHosts = System.getProperty("http.nonProxyHosts");
/*     */     
/* 452 */     for (int i = 0; (i < resultRows.size()) && (result.getNrErrors() == 0L); i++)
/*     */     {
/* 454 */       RowMetaAndData row = (RowMetaAndData)resultRows.get(i);
/*     */       
/* 456 */       OutputStream outputFile = null;
/* 457 */       OutputStream uploadStream = null;
/* 458 */       BufferedInputStream fileStream = null;
/* 459 */       InputStream input = null;
/*     */       
/*     */       try
/*     */       {
/* 463 */         String urlToUse = environmentSubstitute(row.getString(urlFieldnameToUse, ""));
/*     */         
/* 465 */         logBasic(BaseMessages.getString(PKG, "JobHTTP.Log.ConnectingURL", new String[] { urlToUse }));
/*     */         
/* 467 */         if (!Const.isEmpty(this.proxyHostname))
/*     */         {
/* 469 */           System.setProperty("http.proxyHost", environmentSubstitute(this.proxyHostname));
/* 470 */           System.setProperty("http.proxyPort", environmentSubstitute(this.proxyPort));
/* 471 */           if (this.nonProxyHosts != null) {
/* 472 */             System.setProperty("http.nonProxyHosts", environmentSubstitute(this.nonProxyHosts));
/*     */           }
/*     */         }
/* 475 */         if (!Const.isEmpty(this.username))
/*     */         {
/* 477 */           Authenticator.setDefault(new Authenticator()
/*     */           {
/*     */             protected PasswordAuthentication getPasswordAuthentication()
/*     */             {
/* 481 */               String realPassword = Encr.decryptPasswordOptionallyEncrypted(JobEntryHTTP.this.environmentSubstitute(JobEntryHTTP.this.password));
/* 482 */               return new PasswordAuthentication(JobEntryHTTP.this.environmentSubstitute(JobEntryHTTP.this.username), realPassword != null ? realPassword.toCharArray() : new char[0]);
/*     */             }
/*     */           });
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 489 */         String realTargetFile = environmentSubstitute(this.targetFilename);
/* 490 */         if (this.dateTimeAdded)
/*     */         {
/* 492 */           SimpleDateFormat daf = new SimpleDateFormat();
/* 493 */           Date now = new Date();
/*     */           
/* 495 */           daf.applyPattern("yyyMMdd");
/* 496 */           realTargetFile = realTargetFile + "_" + daf.format(now);
/* 497 */           daf.applyPattern("HHmmss");
/* 498 */           realTargetFile = realTargetFile + "_" + daf.format(now);
/*     */           
/* 500 */           if (!Const.isEmpty(this.targetFilenameExtention))
/*     */           {
/* 502 */             realTargetFile = realTargetFile + "." + environmentSubstitute(this.targetFilenameExtention);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 507 */         outputFile = KettleVFS.getOutputStream(realTargetFile, this, this.fileAppended);
/*     */         
/*     */ 
/* 510 */         server = new URL(urlToUse);
/* 511 */         URLConnection connection = server.openConnection();
/*     */         
/*     */ 
/* 514 */         if (!Const.isEmpty(this.headerName)) {
/* 515 */           if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "JobHTTP.Log.HeadersProvided", new String[0]));
/* 516 */           for (int j = 0; j < this.headerName.length; j++) {
/* 517 */             if (!Const.isEmpty(this.headerValue[j])) {
/* 518 */               connection.setRequestProperty(environmentSubstitute(this.headerName[j]), environmentSubstitute(this.headerValue[j]));
/* 519 */               if (this.log.isDebug()) { this.log.logDebug(BaseMessages.getString(PKG, "JobHTTP.Log.HeaderSet", new String[] { environmentSubstitute(this.headerName[j]), environmentSubstitute(this.headerValue[j]) }));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 524 */         connection.setDoOutput(true);
/*     */         
/*     */ 
/* 527 */         String realUploadFilename = environmentSubstitute(this.uploadFilename);
/* 528 */         if (!Const.isEmpty(realUploadFilename))
/*     */         {
/* 530 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobHTTP.Log.SendingFile", new String[] { realUploadFilename }));
/*     */           }
/*     */           
/* 533 */           uploadStream = connection.getOutputStream();
/* 534 */           fileStream = new BufferedInputStream(new FileInputStream(new File(realUploadFilename)));
/*     */           try {
/*     */             int c;
/* 537 */             while ((c = fileStream.read()) >= 0)
/*     */             {
/* 539 */               uploadStream.write(c);
/*     */             }
/*     */           }
/*     */           finally {
/* 543 */             if (uploadStream != null) {
/* 544 */               uploadStream.close();
/* 545 */               uploadStream = null;
/*     */             }
/* 547 */             if (fileStream != null) {
/* 548 */               fileStream.close();
/* 549 */               fileStream = null;
/*     */             }
/*     */           }
/* 552 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobHTTP.Log.FinishedSendingFile", new String[0]));
/*     */           }
/*     */         }
/* 555 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobHTTP.Log.StartReadingReply", new String[0]));
/*     */         }
/*     */         
/* 558 */         input = connection.getInputStream();
/* 559 */         Date date = new Date(connection.getLastModified());
/* 560 */         logBasic(BaseMessages.getString(PKG, "JobHTTP.Log.ReplayInfo", new Object[] { connection.getContentType(), date }));
/*     */         
/*     */ 
/* 563 */         long bytesRead = 0L;
/* 564 */         int oneChar; while ((oneChar = input.read()) != -1)
/*     */         {
/* 566 */           outputFile.write(oneChar);
/* 567 */           bytesRead += 1L;
/*     */         }
/*     */         
/* 570 */         logBasic(BaseMessages.getString(PKG, "JobHTTP.Log.FinisedWritingReply", new Object[] { Long.valueOf(bytesRead), realTargetFile }));
/*     */         
/* 572 */         if (this.addfilenameresult)
/*     */         {
/* 574 */           ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(realTargetFile, this), this.parentJob.getJobname(), toString());
/*     */           
/* 576 */           result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */         }
/*     */         
/* 579 */         result.setResult(true);
/*     */       }
/*     */       catch (MalformedURLException e) {
/* 582 */         result.setNrErrors(1L);
/* 583 */         logError(BaseMessages.getString(PKG, "JobHTTP.Error.NotValidURL", new String[] { this.url, e.getMessage() }));
/* 584 */         logError(Const.getStackTracker(e));
/*     */       }
/*     */       catch (IOException e) {
/* 587 */         result.setNrErrors(1L);
/* 588 */         logError(BaseMessages.getString(PKG, "JobHTTP.Error.CanNotSaveHTTPResult", new String[] { e.getMessage() }));
/* 589 */         logError(Const.getStackTracker(e));
/*     */       }
/*     */       catch (Exception e) {
/* 592 */         result.setNrErrors(1L);
/* 593 */         logError(BaseMessages.getString(PKG, "JobHTTP.Error.ErrorGettingFromHTTP", new String[] { e.getMessage() }));
/* 594 */         logError(Const.getStackTracker(e));
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 600 */           if (uploadStream != null)
/* 601 */             uploadStream.close();
/* 602 */           if (fileStream != null) {
/* 603 */             fileStream.close();
/*     */           }
/* 605 */           if (input != null)
/* 606 */             input.close();
/* 607 */           if (outputFile != null) {
/* 608 */             outputFile.close();
/*     */           }
/*     */         } catch (Exception e) {
/* 611 */           logError(BaseMessages.getString(PKG, "JobHTTP.Error.CanNotCloseStream", new String[] { e.getMessage() }));
/* 612 */           result.setNrErrors(1L);
/*     */         }
/*     */         
/*     */ 
/* 616 */         System.setProperty("http.proxyHost", Const.NVL(beforeProxyHost, ""));
/* 617 */         System.setProperty("http.proxyPort", Const.NVL(beforeProxyPort, ""));
/* 618 */         System.setProperty("http.nonProxyHosts", Const.NVL(beforeNonProxyHosts, ""));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 623 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 628 */     return true;
/*     */   }
/*     */   
/*     */   public String getUploadFilename()
/*     */   {
/* 633 */     return this.uploadFilename;
/*     */   }
/*     */   
/*     */   public void setUploadFilename(String uploadFilename)
/*     */   {
/* 638 */     this.uploadFilename = uploadFilename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getUrlFieldname()
/*     */   {
/* 646 */     return this.urlFieldname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlFieldname(String getFieldname)
/*     */   {
/* 654 */     this.urlFieldname = getFieldname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRunForEveryRow()
/*     */   {
/* 662 */     return this.runForEveryRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRunForEveryRow(boolean runForEveryRow)
/*     */   {
/* 670 */     this.runForEveryRow = runForEveryRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFileAppended()
/*     */   {
/* 678 */     return this.fileAppended;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileAppended(boolean fileAppended)
/*     */   {
/* 686 */     this.fileAppended = fileAppended;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDateTimeAdded()
/*     */   {
/* 694 */     return this.dateTimeAdded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateTimeAdded(boolean dateTimeAdded)
/*     */   {
/* 702 */     this.dateTimeAdded = dateTimeAdded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTargetFilenameExtention()
/*     */   {
/* 710 */     return this.targetFilenameExtention;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetFilenameExtention(String uploadFilenameExtention)
/*     */   {
/* 718 */     this.targetFilenameExtention = uploadFilenameExtention;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*     */   {
/* 723 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 724 */     String realUrl = jobMeta.environmentSubstitute(this.url);
/* 725 */     ResourceReference reference = new ResourceReference(this);
/* 726 */     reference.getEntries().add(new ResourceEntry(realUrl, ResourceEntry.ResourceType.URL));
/* 727 */     references.add(reference);
/* 728 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 734 */     JobEntryValidatorUtils.andValidator().validate(this, "targetFilename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 735 */     JobEntryValidatorUtils.andValidator().validate(this, "targetFilenameExtention", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 736 */     JobEntryValidatorUtils.andValidator().validate(this, "uploadFilename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 737 */     JobEntryValidatorUtils.andValidator().validate(this, "proxyPort", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.integerValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\http\JobEntryHTTP.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */