/*     */ package org.pentaho.di.imp.rules;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.plugins.ImportRulePluginType;
/*     */ import org.pentaho.di.core.plugins.PluginInterface;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.row.ValueMeta;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseImportRule
/*     */   implements ImportRuleInterface
/*     */ {
/*  39 */   public static String XML_TAG = "rule";
/*     */   private String id;
/*     */   private boolean enabled;
/*     */   
/*     */   public BaseImportRule()
/*     */   {
/*  45 */     this.enabled = false;
/*     */   }
/*     */   
/*     */   public ImportRuleInterface clone() {
/*     */     try {
/*  50 */       return (ImportRuleInterface)super.clone();
/*     */     } catch (CloneNotSupportedException e) {
/*  52 */       throw new RuntimeException("Unable to clone import rule", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isUnique() {
/*  57 */     return true;
/*     */   }
/*     */   
/*     */   public abstract List<ImportValidationFeedback> verifyRule(Object paramObject);
/*     */   
/*     */   public String getXML() {
/*  63 */     StringBuilder xml = new StringBuilder();
/*     */     
/*  65 */     xml.append(XMLHandler.addTagValue("id", this.id));
/*  66 */     xml.append(XMLHandler.addTagValue("enabled", this.enabled));
/*     */     
/*  68 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node ruleNode) throws KettleException {
/*  72 */     this.id = XMLHandler.getTagValue(ruleNode, "id");
/*  73 */     this.enabled = ValueMeta.convertStringToBoolean(XMLHandler.getTagValue(ruleNode, "enabled")).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  80 */     String pluginId = PluginRegistry.getInstance().getPluginId(this);
/*  81 */     PluginInterface plugin = PluginRegistry.getInstance().findPluginWithId(ImportRulePluginType.class, pluginId);
/*  82 */     return plugin.getName() + " (" + (this.enabled ? "enabled" : "disabled") + ").";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/*  89 */     return this.enabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnabled(boolean enabled)
/*     */   {
/*  97 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 104 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/* 111 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCompositeClassName()
/*     */   {
/* 133 */     String className = getClass().getCanonicalName();
/* 134 */     className = className.replaceFirst("\\.di\\.", ".di.ui.");
/* 135 */     className = className + "Composite";
/* 136 */     return className;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\BaseImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */