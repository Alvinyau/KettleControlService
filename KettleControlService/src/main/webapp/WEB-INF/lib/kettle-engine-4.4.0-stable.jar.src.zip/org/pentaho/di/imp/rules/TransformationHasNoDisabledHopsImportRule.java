/*    */ package org.pentaho.di.imp.rules;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.xml.XMLHandler;
/*    */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*    */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*    */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*    */ import org.pentaho.di.trans.TransHopMeta;
/*    */ import org.pentaho.di.trans.TransMeta;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformationHasNoDisabledHopsImportRule
/*    */   extends BaseImportRule
/*    */   implements ImportRuleInterface
/*    */ {
/*    */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*    */   {
/* 46 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*    */     
/* 48 */     if (!isEnabled()) return feedback;
/* 49 */     if (!(subject instanceof TransMeta)) { return feedback;
/*    */     }
/* 51 */     TransMeta transMeta = (TransMeta)subject;
/*    */     
/* 53 */     for (int i = 0; i < transMeta.nrTransHops(); i++) {
/* 54 */       TransHopMeta hop = transMeta.getTransHop(i);
/* 55 */       if (!hop.isEnabled()) {
/* 56 */         feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "There is a disabled hop in the transformation."));
/*    */       }
/*    */     }
/*    */     
/* 60 */     if (feedback.isEmpty()) {
/* 61 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "All hops are enabled in this transformation."));
/*    */     }
/*    */     
/* 64 */     return feedback;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getXML()
/*    */   {
/* 70 */     StringBuilder xml = new StringBuilder();
/* 71 */     xml.append(XMLHandler.openTag(XML_TAG));
/*    */     
/* 73 */     xml.append(super.getXML());
/*    */     
/* 75 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 76 */     return xml.toString();
/*    */   }
/*    */   
/*    */   public void loadXML(Node ruleNode) throws KettleException
/*    */   {
/* 81 */     super.loadXML(ruleNode);
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\TransformationHasNoDisabledHopsImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */