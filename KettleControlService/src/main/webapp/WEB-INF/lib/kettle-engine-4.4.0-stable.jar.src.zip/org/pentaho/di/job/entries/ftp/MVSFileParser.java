/*     */ package org.pentaho.di.job.entries.ftp;
/*     */ 
/*     */ import com.enterprisedt.net.ftp.FTPFile;
/*     */ import com.enterprisedt.net.ftp.FTPFileParser;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MVSFileParser
/*     */   extends FTPFileParser
/*     */ {
/*  67 */   private static Class<?> PKG = MVSFileParser.class;
/*  68 */   private static Logger log4j = Logger.getLogger(MVSFileParser.class);
/*     */   
/*     */   private static final String PARSER_KEY = "MVS";
/*     */   
/*     */   private static final String HEADER_VOLUME = "Volume";
/*     */   
/*     */   private static final String HEADER_NAME = "Name";
/*     */   
/*     */   private static final String LINE_TYPE_ARCIVE = "ARCIVE";
/*     */   
/*     */   private static final String ENTRY_FILE_TYPE = "PS";
/*     */   
/*     */   private static final String LINE_TYPE_MIGRATED = "Migrated";
/*     */   private static final int FOLDER_HEADER_TYPE_IDX = 0;
/*     */   private static final int FOLDER_LISTING_LENGTH_NORMAL = 10;
/*     */   private static final int FOLDER_LISTING_LENGTH_ARCIVE = 8;
/*     */   private String dateFormatString;
/*     */   private String alternateFormatString;
/*     */   private SimpleDateFormat dateFormat;
/*     */   private SimpleDateFormat dateTimeFormat;
/*  88 */   private boolean partitionedDataset = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValidFormat(String[] listing)
/*     */   {
/* 122 */     if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Checking.Parser", new String[0]));
/* 123 */     if (listing.length > 0) {
/* 124 */       String[] header = splitMVSLine(listing[0]);
/* 125 */       if ((header.length == 10) || (header.length == 8)) {
/* 126 */         if (header[0].equals("Volume")) {
/* 127 */           this.partitionedDataset = false;
/* 128 */           if (log4j.isInfoEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.INFO.Detected.Dir", new String[0]));
/* 129 */           return isValidDirectoryFormat(listing); }
/* 130 */         if (header[0].equals("Name")) {
/* 131 */           this.partitionedDataset = true;
/* 132 */           if (log4j.isInfoEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.INFO.Detected.PDS", new String[0]));
/* 133 */           return isValidPDSFormat(listing);
/*     */         }
/*     */       }
/*     */     }
/* 137 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FTPFile parse(String raw)
/*     */     throws ParseException
/*     */   {
/* 148 */     String[] aLine = splitMVSLine(raw);
/* 149 */     FTPFile rtn = null;
/* 150 */     if (this.partitionedDataset) {
/* 151 */       rtn = parsePDSLine(aLine, raw);
/*     */     } else {
/* 153 */       rtn = parseFolder(aLine, raw);
/*     */     }
/* 155 */     return rtn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(Locale arg0)
/*     */   {
/* 167 */     if (log4j.isDebugEnabled()) { log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Ignore.Locale", new String[0]));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 175 */     return "MVS";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FTPFile parsePDSLine(String[] aLine, String raw)
/*     */     throws ParseException
/*     */   {
/* 188 */     FTPFile rtn = null;
/* 189 */     if (aLine[0].equals("Name")) {
/* 190 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Skip.Header", new String[0]));
/* 191 */       return null;
/*     */     }
/* 193 */     rtn = new FTPFile(raw);
/* 194 */     rtn.setName(aLine[0]);
/* 195 */     if (this.dateTimeFormat == null) {
/* 196 */       this.dateTimeFormat = new SimpleDateFormat(this.dateFormatString + " HH:mm");
/*     */     }
/* 198 */     rtn.setCreated(this.dateFormat.parse(aLine[2]));
/* 199 */     String modDateTime = aLine[3] + ' ' + aLine[4];
/* 200 */     rtn.setLastModified(this.dateTimeFormat.parse(modDateTime));
/* 201 */     rtn.setDir(false);
/* 202 */     return rtn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FTPFile parseFolder(String[] aLine, String raw)
/*     */   {
/* 217 */     if (aLine[0].equals("Volume")) {
/* 218 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Skip.Header", new String[0]));
/* 219 */       return null;
/*     */     }
/*     */     
/* 222 */     if (aLine[0].equals("ARCIVE")) {
/* 223 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Skip.ARCIVE", new String[0]));
/* 224 */       return null;
/*     */     }
/* 226 */     if (aLine[0].equals("Migrated")) {
/* 227 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Skip.Migrated", new String[0]));
/* 228 */       return null;
/*     */     }
/* 230 */     if ((aLine[5].charAt(0) != 'F') && (aLine[5].charAt(0) != 'V')) {
/* 231 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Skip.recf", new String[0]));
/* 232 */       return null;
/*     */     }
/* 234 */     if (aLine[8].charAt(0) != 'P') {
/* 235 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Skip.dso", new String[0]));
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     FTPFile rtn = new FTPFile(raw);
/* 240 */     rtn.setName(aLine[9]);
/*     */     
/* 242 */     rtn.setCreated(new Date());
/* 243 */     rtn.setLastModified(new Date());
/* 244 */     if (aLine[8].equals("PS")) {
/* 245 */       if (log4j.isDebugEnabled()) { log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Found.File", new String[] { aLine[9] }));
/*     */       }
/* 247 */       rtn.setDir(false);
/* 248 */       long l = -1L;
/*     */       try {
/* 250 */         l = Long.parseLong(aLine[4]);
/*     */       } catch (Exception ignored) {}
/* 252 */       rtn.setSize(l);
/*     */     } else {
/* 254 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Found.Folder", new String[] { aLine[9] }));
/* 255 */       rtn.setDir(true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 261 */     return rtn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] splitMVSLine(String raw)
/*     */   {
/* 276 */     if (raw == null) {
/* 277 */       return new String[0];
/*     */     }
/* 279 */     StringTokenizer st = new StringTokenizer(raw);
/* 280 */     String[] rtn = new String[st.countTokens()];
/* 281 */     int i = 0;
/* 282 */     while (st.hasMoreTokens()) {
/* 283 */       String nextToken = st.nextToken();
/* 284 */       rtn[i] = nextToken.trim();
/* 285 */       i++;
/*     */     }
/* 287 */     return rtn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isValidDirectoryFormat(String[] listing)
/*     */   {
/* 299 */     for (int i = 1; i < listing.length; i++) {
/* 300 */       String[] aLine = splitMVSLine(listing[i]);
/* 301 */       if ((aLine.length == 2) && (aLine[0].equals("Migrated"))) {
/* 302 */         if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Detected.Migrated", new String[0]));
/* 303 */       } else if ((aLine.length != 10) && (!aLine[0].equals("ARCIVE"))) {
/* 304 */         log4j.error(BaseMessages.getString(PKG, "MVSFileParser.ERROR.Invalid.Folder.Line", new String[] { listing[i] }));
/* 305 */         return false;
/*     */       }
/* 307 */       if (this.dateFormatString != null)
/*     */       {
/* 309 */         if (!checkDateFormat(aLine[2])) {
/* 310 */           return false;
/*     */         }
/*     */       }
/* 313 */       else if (aLine.length == 10)
/*     */       {
/* 315 */         guessDateFormat(aLine[2]);
/*     */       }
/*     */     }
/*     */     
/* 319 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isValidPDSFormat(String[] listing)
/*     */   {
/* 330 */     for (int i = 1; i < listing.length; i++) {
/* 331 */       String[] aLine = splitMVSLine(listing[i]);
/* 332 */       if (aLine.length != 9) {
/* 333 */         log4j.error(BaseMessages.getString(PKG, "MVSFileParser.ERROR.Invalid.PDS.Line", new String[] { listing[i] }));
/* 334 */         return false;
/*     */       }
/* 336 */       if (this.dateFormatString != null) {
/* 337 */         if (!checkDateFormat(aLine[3])) {
/* 338 */           return false;
/*     */         }
/*     */       } else {
/* 341 */         guessDateFormat(aLine[2]);
/*     */       }
/*     */     }
/* 344 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean checkDateFormat(String dateStr)
/*     */   {
/*     */     try
/*     */     {
/* 369 */       this.dateFormat.parse(dateStr);
/*     */     } catch (ParseException ex) {
/* 371 */       if ((log4j.isDebugEnabled()) && 
/* 372 */         (log4j.isDebugEnabled())) { log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Date.Parse.Error", new String[0]));
/*     */       }
/* 374 */       if (this.alternateFormatString != null) {
/* 375 */         if ((log4j.isDebugEnabled()) && 
/* 376 */           (log4j.isDebugEnabled())) { log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Date.Parse.Choose.Alt", new String[0]));
/*     */         }
/* 378 */         this.dateFormatString = this.alternateFormatString;
/* 379 */         this.dateFormat = new SimpleDateFormat(this.dateFormatString);
/* 380 */         this.alternateFormatString = null;
/*     */         try {
/* 382 */           this.dateFormat.parse(dateStr);
/*     */         } catch (ParseException ex2) {
/* 384 */           return false;
/*     */         }
/*     */       } else {
/* 387 */         log4j.error(BaseMessages.getString(PKG, "MVSFileParser.ERROR.Date.Parse.Fail", new String[] { dateStr }));
/* 388 */         return false;
/*     */       }
/*     */     }
/* 391 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void guessDateFormat(String dateStr)
/*     */   {
/* 411 */     if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Guess.Date", new String[0]));
/* 412 */     String[] dateSplit = dateStr.split("/");
/* 413 */     String yrFmt = null;
/* 414 */     int yrPos = -1;
/* 415 */     int dayPos = -1;
/*     */     
/* 417 */     for (int i = 0; i < dateSplit.length; i++) {
/* 418 */       int aDigit = Integer.parseInt(dateSplit[i]);
/* 419 */       if (dateSplit[i].length() == 4) {
/* 420 */         yrFmt = "yyyy";
/* 421 */         yrPos = i;
/* 422 */       } else if (aDigit > 31)
/*     */       {
/* 424 */         yrFmt = "yy";
/* 425 */         yrPos = i;
/* 426 */       } else if (aDigit > 12)
/*     */       {
/* 428 */         dayPos = i;
/*     */       }
/*     */     }
/* 431 */     if (yrFmt != null) {
/* 432 */       StringBuffer fmt = new StringBuffer();
/* 433 */       if (dayPos >= 0)
/*     */       {
/* 435 */         String[] tmp = new String[3];
/* 436 */         tmp[yrPos] = yrFmt;
/* 437 */         tmp[dayPos] = "dd";
/* 438 */         for (int i = 0; i < tmp.length; i++) {
/* 439 */           fmt.append(i > 0 ? "/" : "");
/* 440 */           fmt.append(tmp[i] == null ? "MM" : tmp[i]);
/*     */         }
/* 442 */         if (log4j.isDebugEnabled()) { log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Guess.Date.Obvious", new String[0]));
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 448 */         StringBuffer altFmt = new StringBuffer();
/* 449 */         if (yrPos == 0) {
/* 450 */           fmt.append(yrFmt).append("/MM/dd");
/* 451 */           altFmt.append(yrFmt).append("/dd/MM");
/*     */         } else {
/* 453 */           fmt.append("MM/dd/").append(yrFmt);
/* 454 */           altFmt.append("dd/MM/").append(yrFmt);
/*     */         }
/* 456 */         this.alternateFormatString = altFmt.toString();
/* 457 */         if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Guess.Date.Ambiguous", new String[0]));
/*     */       }
/* 459 */       this.dateFormatString = fmt.toString();
/* 460 */       this.dateFormat = new SimpleDateFormat(this.dateFormatString);
/* 461 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Guess.Date.Decided", new String[] { this.dateFormatString }));
/*     */       try {
/* 463 */         this.dateFormat.parse(dateStr);
/*     */       } catch (ParseException ex) {
/* 465 */         if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Guess.Date.Unparsable", new String[] { dateStr }));
/*     */       }
/*     */     }
/*     */     else {
/* 469 */       if (log4j.isDebugEnabled()) log4j.debug(BaseMessages.getString(PKG, "MVSFileParser.DEBUG.Guess.Date.Year.Ambiguous", new String[0]));
/* 470 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPartitionedDataset()
/*     */   {
/* 482 */     return this.partitionedDataset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDateFormatString()
/*     */   {
/* 491 */     return this.dateFormatString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDateFormatString(String value)
/*     */   {
/* 500 */     this.dateFormatString = value;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftp\MVSFileParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */