/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ import org.apache.commons.lang.builder.ToStringStyle;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PluginMessages
/*     */ {
/*  46 */   private static final Map<String, PluginMessages> MESSAGES_MAP = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */   private final String packageName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PluginMessages getMessages(String packageName)
/*     */     throws IllegalArgumentException
/*     */   {
/*  58 */     Assert.assertNotBlank(packageName, "Package name cannot be blank");
/*  59 */     synchronized (PluginMessages.class) {
/*  60 */       if (MESSAGES_MAP.containsKey(packageName)) {
/*  61 */         return (PluginMessages)MESSAGES_MAP.get(packageName);
/*     */       }
/*  63 */       MESSAGES_MAP.put(packageName, new PluginMessages(packageName));
/*     */     }
/*  65 */     return (PluginMessages)MESSAGES_MAP.get(packageName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PluginMessages getMessages(Class<?> someClassInPackage)
/*     */     throws IllegalArgumentException
/*     */   {
/*  78 */     Assert.assertNotNull(someClassInPackage, "Class cannot be null");
/*  79 */     return getMessages(someClassInPackage.getPackage().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private PluginMessages(String packageName)
/*     */   {
/*  89 */     this.packageName = packageName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPackageName()
/*     */   {
/*  96 */     return this.packageName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key)
/*     */   {
/* 106 */     return BaseMessages.getString(this.packageName, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key, String param1)
/*     */   {
/* 118 */     return BaseMessages.getString(this.packageName, key, new String[] { param1 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key, String param1, String param2)
/*     */   {
/* 132 */     return BaseMessages.getString(this.packageName, key, new String[] { param1, param2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key, String param1, String param2, String param3)
/*     */   {
/* 147 */     return BaseMessages.getString(this.packageName, key, new String[] { param1, param2, param3 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key, String param1, String param2, String param3, String param4)
/*     */   {
/* 166 */     return BaseMessages.getString(this.packageName, key, new String[] { param1, param2, param3, param4 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key, String param1, String param2, String param3, String param4, String param5)
/*     */   {
/* 187 */     return BaseMessages.getString(this.packageName, key, new String[] { param1, param2, param3, param4, param5 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getString(String key, String param1, String param2, String param3, String param4, String param5, String param6)
/*     */   {
/* 210 */     return BaseMessages.getString(this.packageName, key, new String[] { param1, param2, param3, param4, param5, param6 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 220 */     ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
/* 221 */     builder.append("packageName", this.packageName);
/* 222 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\PluginMessages.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */