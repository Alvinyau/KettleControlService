/*     */ package org.pentaho.di.core;
/*     */ 
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.gui.GUIPositionInterface;
/*     */ import org.pentaho.di.core.gui.GUISizeInterface;
/*     */ import org.pentaho.di.core.gui.Point;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.core.xml.XMLInterface;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NotePadMeta
/*     */   implements Cloneable, XMLInterface, GUIPositionInterface, GUISizeInterface
/*     */ {
/*     */   public static final String XML_TAG = "notepad";
/*     */   public static final int COLOR_RGB_BLACK_RED = 0;
/*     */   public static final int COLOR_RGB_BLACK_GREEN = 0;
/*     */   public static final int COLOR_RGB_BLACK_BLUE = 0;
/*     */   public static final int COLOR_RGB_DEFAULT_BG_RED = 255;
/*     */   public static final int COLOR_RGB_DEFAULT_BG_GREEN = 165;
/*     */   public static final int COLOR_RGB_DEFAULT_BG_BLUE = 0;
/*     */   public static final int COLOR_RGB_DEFAULT_BORDER_RED = 100;
/*     */   public static final int COLOR_RGB_DEFAULT_BORDER_GREEN = 100;
/*     */   public static final int COLOR_RGB_DEFAULT_BORDER_BLUE = 100;
/*     */   private String note;
/*     */   private String fontname;
/*     */   private int fontsize;
/*     */   private boolean fontbold;
/*     */   private boolean fontitalic;
/*     */   private int fontcolorred;
/*     */   private int fontcolorgreen;
/*     */   private int fontcolorblue;
/*     */   private int backgroundcolorred;
/*     */   private int backgroundcolorgreen;
/*     */   private int backgroundcolorblue;
/*     */   private int bordercolorred;
/*     */   private int bordercolorgreen;
/*     */   private int bordercolorblue;
/*     */   private boolean drawshadow;
/*     */   private Point location;
/*     */   public int width;
/*     */   public int height;
/*     */   private boolean selected;
/*     */   private boolean changed;
/*     */   private ObjectId id;
/*     */   
/*     */   public NotePadMeta()
/*     */   {
/*  87 */     this.note = null;
/*  88 */     this.location = new Point(-1, -1);
/*  89 */     this.width = -1;
/*  90 */     this.height = -1;
/*  91 */     this.selected = false;
/*  92 */     setDefaultFont();
/*     */     
/*  94 */     this.backgroundcolorred = 255;
/*  95 */     this.backgroundcolorgreen = 165;
/*  96 */     this.backgroundcolorblue = 0;
/*     */   }
/*     */   
/*     */   public NotePadMeta(String n, int xl, int yl, int w, int h) {
/* 100 */     this.note = n;
/* 101 */     this.location = new Point(xl, yl);
/* 102 */     this.width = w;
/* 103 */     this.height = h;
/* 104 */     this.selected = false;
/* 105 */     setDefaultFont();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NotePadMeta(String n, int xl, int yl, int w, int h, String fontname, int fontsize, boolean fontbold, boolean fontitalic, int fontColorRed, int fontColorGreen, int fontColorBlue, int backGrounColorRed, int backGrounColorGreen, int backGrounColorBlue, int borderColorRed, int borderColorGreen, int borderColorBlue, boolean drawshadow)
/*     */   {
/* 115 */     this.note = n;
/* 116 */     this.location = new Point(xl, yl);
/* 117 */     this.width = w;
/* 118 */     this.height = h;
/* 119 */     this.selected = false;
/* 120 */     this.fontname = fontname;
/* 121 */     this.fontsize = fontsize;
/* 122 */     this.fontbold = fontbold;
/* 123 */     this.fontitalic = fontitalic;
/*     */     
/* 125 */     this.fontcolorred = fontColorRed;
/* 126 */     this.fontcolorgreen = fontColorGreen;
/* 127 */     this.fontcolorblue = fontColorBlue;
/*     */     
/* 129 */     this.backgroundcolorred = backGrounColorRed;
/* 130 */     this.backgroundcolorgreen = backGrounColorGreen;
/* 131 */     this.backgroundcolorblue = backGrounColorBlue;
/*     */     
/* 133 */     this.bordercolorred = borderColorRed;
/* 134 */     this.bordercolorgreen = borderColorGreen;
/* 135 */     this.bordercolorblue = borderColorBlue;
/* 136 */     this.drawshadow = drawshadow;
/*     */   }
/*     */   
/*     */   public NotePadMeta(Node notepadnode)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       this.note = XMLHandler.getTagValue(notepadnode, "note");
/* 145 */       String sxloc = XMLHandler.getTagValue(notepadnode, "xloc");
/* 146 */       String syloc = XMLHandler.getTagValue(notepadnode, "yloc");
/* 147 */       String swidth = XMLHandler.getTagValue(notepadnode, "width");
/* 148 */       String sheight = XMLHandler.getTagValue(notepadnode, "heigth");
/* 149 */       int x = Const.toInt(sxloc, 0);
/* 150 */       int y = Const.toInt(syloc, 0);
/* 151 */       this.location = new Point(x, y);
/* 152 */       this.width = Const.toInt(swidth, 0);
/* 153 */       this.height = Const.toInt(sheight, 0);
/* 154 */       this.selected = false;
/* 155 */       this.fontname = XMLHandler.getTagValue(notepadnode, "fontname");
/* 156 */       this.fontsize = Const.toInt(XMLHandler.getTagValue(notepadnode, "fontsize"), -1);
/* 157 */       this.fontbold = "Y".equalsIgnoreCase(XMLHandler.getTagValue(notepadnode, "fontbold"));
/* 158 */       this.fontitalic = "Y".equalsIgnoreCase(XMLHandler.getTagValue(notepadnode, "fontitalic"));
/*     */       
/* 160 */       this.fontcolorred = Const.toInt(XMLHandler.getTagValue(notepadnode, "fontcolorred"), 0);
/* 161 */       this.fontcolorgreen = Const.toInt(XMLHandler.getTagValue(notepadnode, "fontcolorgreen"), 0);
/* 162 */       this.fontcolorblue = Const.toInt(XMLHandler.getTagValue(notepadnode, "fontcolorblue"), 0);
/*     */       
/* 164 */       this.backgroundcolorred = Const.toInt(XMLHandler.getTagValue(notepadnode, "backgroundcolorred"), 255);
/* 165 */       this.backgroundcolorgreen = Const.toInt(XMLHandler.getTagValue(notepadnode, "backgroundcolorgreen"), 165);
/* 166 */       this.backgroundcolorblue = Const.toInt(XMLHandler.getTagValue(notepadnode, "backgroundcolorblue"), 0);
/*     */       
/* 168 */       this.bordercolorred = Const.toInt(XMLHandler.getTagValue(notepadnode, "bordercolorred"), 100);
/* 169 */       this.bordercolorgreen = Const.toInt(XMLHandler.getTagValue(notepadnode, "bordercolorgreen"), 100);
/* 170 */       this.bordercolorblue = Const.toInt(XMLHandler.getTagValue(notepadnode, "bordercolorblue"), 100);
/* 171 */       this.drawshadow = "Y".equalsIgnoreCase(XMLHandler.getTagValue(notepadnode, "drawshadow"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 175 */       throw new KettleXMLException("Unable to read Notepad info from XML", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public ObjectId getObjectId()
/*     */   {
/* 181 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setObjectId(ObjectId id)
/*     */   {
/* 186 */     this.id = id;
/*     */   }
/*     */   
/*     */   public void setLocation(int x, int y)
/*     */   {
/* 191 */     if ((x != this.location.x) || (y != this.location.y)) setChanged();
/* 192 */     this.location.x = x;
/* 193 */     this.location.y = y;
/*     */   }
/*     */   
/*     */   public void setLocation(Point p)
/*     */   {
/* 198 */     setLocation(p.x, p.y);
/*     */   }
/*     */   
/*     */   public Point getLocation()
/*     */   {
/* 203 */     return this.location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNote()
/*     */   {
/* 211 */     return this.note;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNote(String note)
/*     */   {
/* 219 */     this.note = note;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorderColorRed(int red)
/*     */   {
/* 227 */     this.bordercolorred = red;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorderColorGreen(int green)
/*     */   {
/* 235 */     this.bordercolorgreen = green;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBorderColorBlue(int blue)
/*     */   {
/* 243 */     this.bordercolorblue = blue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackGroundColorRed(int red)
/*     */   {
/* 251 */     this.backgroundcolorred = red;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackGroundColorGreen(int green)
/*     */   {
/* 259 */     this.backgroundcolorgreen = green;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackGroundColorBlue(int blue)
/*     */   {
/* 267 */     this.backgroundcolorblue = blue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontColorRed(int red)
/*     */   {
/* 275 */     this.fontcolorred = red;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontColorGreen(int green)
/*     */   {
/* 283 */     this.fontcolorgreen = green;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFontColorBlue(int blue)
/*     */   {
/* 290 */     this.fontcolorblue = blue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSelected()
/*     */   {
/* 298 */     return this.selected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelected(boolean selected)
/*     */   {
/* 306 */     this.selected = selected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flipSelected()
/*     */   {
/* 314 */     this.selected = (!this.selected);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDrawShadow(boolean drawshadow)
/*     */   {
/* 321 */     this.drawshadow = drawshadow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDrawShadow()
/*     */   {
/* 329 */     return this.drawshadow;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/* 335 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException e) {}
/*     */     
/*     */ 
/* 340 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setChanged()
/*     */   {
/* 346 */     setChanged(true);
/*     */   }
/*     */   
/*     */   public void setChanged(boolean ch)
/*     */   {
/* 351 */     this.changed = ch;
/*     */   }
/*     */   
/*     */   public boolean hasChanged()
/*     */   {
/* 356 */     return this.changed;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 361 */     return this.note;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 366 */     StringBuffer retval = new StringBuffer(100);
/*     */     
/* 368 */     retval.append("    <notepad>").append(Const.CR);
/* 369 */     retval.append("      ").append(XMLHandler.addTagValue("note", this.note));
/* 370 */     retval.append("      ").append(XMLHandler.addTagValue("xloc", this.location.x));
/* 371 */     retval.append("      ").append(XMLHandler.addTagValue("yloc", this.location.y));
/* 372 */     retval.append("      ").append(XMLHandler.addTagValue("width", this.width));
/* 373 */     retval.append("      ").append(XMLHandler.addTagValue("heigth", this.height));
/*     */     
/* 375 */     retval.append("      ").append(XMLHandler.addTagValue("fontname", this.fontname));
/* 376 */     retval.append("      ").append(XMLHandler.addTagValue("fontsize", this.fontsize));
/* 377 */     retval.append("      ").append(XMLHandler.addTagValue("fontbold", this.fontbold));
/* 378 */     retval.append("      ").append(XMLHandler.addTagValue("fontitalic", this.fontitalic));
/*     */     
/* 380 */     retval.append("      ").append(XMLHandler.addTagValue("fontcolorred", this.fontcolorred));
/* 381 */     retval.append("      ").append(XMLHandler.addTagValue("fontcolorgreen", this.fontcolorgreen));
/* 382 */     retval.append("      ").append(XMLHandler.addTagValue("fontcolorblue", this.fontcolorblue));
/*     */     
/* 384 */     retval.append("      ").append(XMLHandler.addTagValue("backgroundcolorred", this.backgroundcolorred));
/* 385 */     retval.append("      ").append(XMLHandler.addTagValue("backgroundcolorgreen", this.backgroundcolorgreen));
/* 386 */     retval.append("      ").append(XMLHandler.addTagValue("backgroundcolorblue", this.backgroundcolorblue));
/*     */     
/* 388 */     retval.append("      ").append(XMLHandler.addTagValue("bordercolorred", this.bordercolorred));
/* 389 */     retval.append("      ").append(XMLHandler.addTagValue("bordercolorgreen", this.bordercolorgreen));
/* 390 */     retval.append("      ").append(XMLHandler.addTagValue("bordercolorblue", this.bordercolorblue));
/*     */     
/* 392 */     retval.append("      ").append(XMLHandler.addTagValue("drawshadow", this.drawshadow));
/* 393 */     retval.append("    </notepad>").append(Const.CR);
/*     */     
/* 395 */     return retval.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 403 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 411 */     this.height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 419 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 427 */     this.width = width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFontName()
/*     */   {
/* 434 */     return this.fontname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontName(String fontname)
/*     */   {
/* 442 */     this.fontname = fontname;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFontSize()
/*     */   {
/* 449 */     return this.fontsize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontBold(boolean fontbold)
/*     */   {
/* 457 */     this.fontbold = fontbold;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFontBold()
/*     */   {
/* 464 */     return this.fontbold;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFontItalic(boolean fontitalic)
/*     */   {
/* 471 */     this.fontitalic = fontitalic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFontItalic()
/*     */   {
/* 479 */     return this.fontitalic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBorderColorRed()
/*     */   {
/* 487 */     return this.bordercolorred;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBorderColorGreen()
/*     */   {
/* 494 */     return this.bordercolorgreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBorderColorBlue()
/*     */   {
/* 501 */     return this.bordercolorblue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBackGroundColorRed()
/*     */   {
/* 508 */     return this.backgroundcolorred;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBackGroundColorGreen()
/*     */   {
/* 515 */     return this.backgroundcolorgreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBackGroundColorBlue()
/*     */   {
/* 522 */     return this.backgroundcolorblue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFontColorRed()
/*     */   {
/* 529 */     return this.fontcolorred;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFontColorGreen()
/*     */   {
/* 536 */     return this.fontcolorgreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFontColorBlue()
/*     */   {
/* 544 */     return this.fontcolorblue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontSize(int fontsize)
/*     */   {
/* 552 */     this.fontsize = fontsize;
/*     */   }
/*     */   
/*     */   private void setDefaultFont()
/*     */   {
/* 557 */     this.fontname = null;
/* 558 */     this.fontsize = -1;
/* 559 */     this.fontbold = false;
/* 560 */     this.fontitalic = false;
/*     */     
/*     */ 
/* 563 */     this.fontcolorred = 0;
/* 564 */     this.fontcolorgreen = 0;
/* 565 */     this.fontcolorblue = 0;
/*     */     
/*     */ 
/* 568 */     this.backgroundcolorred = 255;
/* 569 */     this.backgroundcolorgreen = 165;
/* 570 */     this.backgroundcolorblue = 0;
/*     */     
/*     */ 
/* 573 */     this.bordercolorred = 100;
/* 574 */     this.bordercolorgreen = 100;
/* 575 */     this.bordercolorblue = 100;
/*     */     
/* 577 */     this.drawshadow = true;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\NotePadMeta.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */