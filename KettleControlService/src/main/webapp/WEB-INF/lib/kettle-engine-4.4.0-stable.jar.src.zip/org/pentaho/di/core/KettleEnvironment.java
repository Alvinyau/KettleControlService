/*     */ package org.pentaho.di.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.lifecycle.KettleLifecycleSupport;
/*     */ import org.pentaho.di.core.logging.CentralLogStore;
/*     */ import org.pentaho.di.core.logging.LogWriter;
/*     */ import org.pentaho.di.core.plugins.DatabasePluginType;
/*     */ import org.pentaho.di.core.plugins.ImportRulePluginType;
/*     */ import org.pentaho.di.core.plugins.JobEntryPluginType;
/*     */ import org.pentaho.di.core.plugins.KettleLifecyclePluginType;
/*     */ import org.pentaho.di.core.plugins.LifecyclePluginType;
/*     */ import org.pentaho.di.core.plugins.PartitionerPluginType;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.plugins.RepositoryPluginType;
/*     */ import org.pentaho.di.core.plugins.StepPluginType;
/*     */ import org.pentaho.di.core.util.EnvUtil;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KettleEnvironment
/*     */ {
/*  54 */   private static Class<?> PKG = Const.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Boolean initialized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */     throws KettleException
/*     */   {
/*  68 */     init(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init(boolean simpleJndi)
/*     */     throws KettleException
/*     */   {
/*  87 */     if (initialized == null)
/*     */     {
/*     */ 
/*     */ 
/*  91 */       createKettleHome();
/*     */       
/*     */ 
/*     */ 
/*  95 */       EnvUtil.environmentInit();
/*     */       
/*     */ 
/*     */ 
/*  99 */       CentralLogStore.init();
/*     */       
/*     */ 
/*     */ 
/* 103 */       LogWriter.setConsoleAppenderDebug();
/*     */       
/*     */ 
/*     */ 
/* 107 */       if (simpleJndi) {
/* 108 */         JndiUtil.initJNDI();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 113 */       PluginRegistry.addPluginType(StepPluginType.getInstance());
/* 114 */       PluginRegistry.addPluginType(PartitionerPluginType.getInstance());
/* 115 */       PluginRegistry.addPluginType(JobEntryPluginType.getInstance());
/* 116 */       PluginRegistry.addPluginType(RepositoryPluginType.getInstance());
/* 117 */       PluginRegistry.addPluginType(DatabasePluginType.getInstance());
/* 118 */       PluginRegistry.addPluginType(LifecyclePluginType.getInstance());
/* 119 */       PluginRegistry.addPluginType(KettleLifecyclePluginType.getInstance());
/* 120 */       PluginRegistry.addPluginType(ImportRulePluginType.getInstance());
/* 121 */       PluginRegistry.init();
/*     */       
/*     */ 
/*     */ 
/* 125 */       KettleVariablesList.init();
/*     */       
/*     */ 
/*     */ 
/* 129 */       initLifecycleListeners();
/*     */       
/* 131 */       initialized = Boolean.valueOf(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void initLifecycleListeners()
/*     */     throws KettleException
/*     */   {
/* 140 */     KettleLifecycleSupport s = new KettleLifecycleSupport();
/* 141 */     s.onEnvironmentInit();
/*     */     
/*     */ 
/* 144 */     Runtime.getRuntime().addShutdownHook(new Thread() {
/*     */       public void run() {
/*     */         try {
/* 147 */           this.val$s.onEnvironmentShutdown();
/*     */         } catch (Throwable t) {
/* 149 */           System.err.println(BaseMessages.getString(KettleEnvironment.PKG, "LifecycleSupport.ErrorInvokingKettleEnvironmentShutdownListeners", new String[0]));
/* 150 */           t.printStackTrace();
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void createKettleHome()
/*     */   {
/* 164 */     String directory = Const.getKettleDirectory();
/* 165 */     File dir = new File(directory);
/*     */     try
/*     */     {
/* 168 */       dir.mkdirs();
/*     */       
/*     */ 
/*     */ 
/* 172 */       createDefaultKettleProperties(directory);
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void createDefaultKettleProperties(String directory)
/*     */   {
/* 187 */     String kpFile = directory + Const.FILE_SEPARATOR + "kettle.properties";
/* 188 */     File file = new File(kpFile);
/* 189 */     if (!file.exists())
/*     */     {
/* 191 */       FileOutputStream out = null;
/*     */       try
/*     */       {
/* 194 */         out = new FileOutputStream(file);
/* 195 */         out.write(Const.getKettlePropertiesFileHeader().getBytes());
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 199 */         System.err.println(BaseMessages.getString(PKG, "Props.Log.Error.UnableToCreateDefaultKettleProperties.Message", new String[] { "kettle.properties", kpFile }));
/* 200 */         System.err.println(e.getStackTrace());
/*     */       }
/*     */       finally
/*     */       {
/* 204 */         if (out != null) {
/*     */           try {
/* 206 */             out.close();
/*     */           } catch (IOException e) {
/* 208 */             System.err.println(BaseMessages.getString(PKG, "Props.Log.Error.UnableToCreateDefaultKettleProperties.Message", new String[] { "kettle.properties", kpFile }));
/* 209 */             System.err.println(e.getStackTrace());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInitialized()
/*     */   {
/* 223 */     return initialized != null;
/*     */   }
/*     */   
/*     */   public void loadPluginRegistry()
/*     */     throws KettlePluginException
/*     */   {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\KettleEnvironment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */