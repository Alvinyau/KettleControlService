/*     */ package org.pentaho.di.job.entries.mysqlbulkfile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.Database;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleFileException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.util.StringUtil;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryMysqlBulkFile
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  69 */   private static Class<?> PKG = JobEntryMysqlBulkFile.class;
/*     */   
/*     */   private String tablename;
/*     */   
/*     */   private String schemaname;
/*     */   private String filename;
/*     */   private String separator;
/*     */   private String enclosed;
/*     */   private String lineterminated;
/*     */   private String limitlines;
/*     */   private String listcolumn;
/*     */   private boolean highpriority;
/*     */   private boolean optionenclosed;
/*     */   public int outdumpvalue;
/*     */   public int iffileexists;
/*     */   private boolean addfiletoresult;
/*     */   private DatabaseMeta connection;
/*     */   
/*     */   public JobEntryMysqlBulkFile(String n)
/*     */   {
/*  89 */     super(n, "");
/*  90 */     this.tablename = null;
/*  91 */     this.schemaname = null;
/*  92 */     this.filename = null;
/*  93 */     this.separator = null;
/*  94 */     this.enclosed = null;
/*  95 */     this.limitlines = "0";
/*  96 */     this.listcolumn = null;
/*  97 */     this.lineterminated = null;
/*  98 */     this.highpriority = true;
/*  99 */     this.optionenclosed = false;
/* 100 */     this.iffileexists = 2;
/* 101 */     this.connection = null;
/* 102 */     this.addfiletoresult = false;
/* 103 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryMysqlBulkFile()
/*     */   {
/* 108 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 113 */     JobEntryMysqlBulkFile je = (JobEntryMysqlBulkFile)super.clone();
/* 114 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 119 */     StringBuffer retval = new StringBuffer(200);
/*     */     
/* 121 */     retval.append(super.getXML());
/* 122 */     retval.append("      ").append(XMLHandler.addTagValue("schemaname", this.schemaname));
/* 123 */     retval.append("      ").append(XMLHandler.addTagValue("tablename", this.tablename));
/* 124 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/* 125 */     retval.append("      ").append(XMLHandler.addTagValue("separator", this.separator));
/* 126 */     retval.append("      ").append(XMLHandler.addTagValue("enclosed", this.enclosed));
/* 127 */     retval.append("      ").append(XMLHandler.addTagValue("optionenclosed", this.optionenclosed));
/* 128 */     retval.append("      ").append(XMLHandler.addTagValue("lineterminated", this.lineterminated));
/* 129 */     retval.append("      ").append(XMLHandler.addTagValue("limitlines", this.limitlines));
/* 130 */     retval.append("      ").append(XMLHandler.addTagValue("listcolumn", this.listcolumn));
/* 131 */     retval.append("      ").append(XMLHandler.addTagValue("highpriority", this.highpriority));
/* 132 */     retval.append("      ").append(XMLHandler.addTagValue("outdumpvalue", this.outdumpvalue));
/* 133 */     retval.append("      ").append(XMLHandler.addTagValue("iffileexists", this.iffileexists));
/* 134 */     retval.append("      ").append(XMLHandler.addTagValue("addfiletoresult", this.addfiletoresult));
/* 135 */     retval.append("      ").append(XMLHandler.addTagValue("connection", this.connection == null ? null : this.connection.getName()));
/*     */     
/* 137 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 144 */       super.loadXML(entrynode, databases, slaveServers);
/* 145 */       this.schemaname = XMLHandler.getTagValue(entrynode, "schemaname");
/* 146 */       this.tablename = XMLHandler.getTagValue(entrynode, "tablename");
/* 147 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/* 148 */       this.separator = XMLHandler.getTagValue(entrynode, "separator");
/* 149 */       this.enclosed = XMLHandler.getTagValue(entrynode, "enclosed");
/* 150 */       this.lineterminated = XMLHandler.getTagValue(entrynode, "lineterminated");
/* 151 */       this.limitlines = XMLHandler.getTagValue(entrynode, "limitlines");
/* 152 */       this.listcolumn = XMLHandler.getTagValue(entrynode, "listcolumn");
/* 153 */       this.highpriority = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "highpriority"));
/* 154 */       this.optionenclosed = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "optionenclosed"));
/* 155 */       this.outdumpvalue = Const.toInt(XMLHandler.getTagValue(entrynode, "outdumpvalue"), -1);
/* 156 */       this.iffileexists = Const.toInt(XMLHandler.getTagValue(entrynode, "iffileexists"), -1);
/* 157 */       String dbname = XMLHandler.getTagValue(entrynode, "connection");
/* 158 */       this.connection = DatabaseMeta.findDatabase(databases, dbname);
/* 159 */       this.addfiletoresult = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "addfiletoresult"));
/*     */     }
/*     */     catch (KettleException e)
/*     */     {
/* 163 */       throw new KettleXMLException("Unable to load job entry of type 'table exists' from XML node", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 172 */       this.schemaname = rep.getJobEntryAttributeString(id_jobentry, "schemaname");
/* 173 */       this.tablename = rep.getJobEntryAttributeString(id_jobentry, "tablename");
/* 174 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/* 175 */       this.separator = rep.getJobEntryAttributeString(id_jobentry, "separator");
/* 176 */       this.enclosed = rep.getJobEntryAttributeString(id_jobentry, "enclosed");
/* 177 */       this.lineterminated = rep.getJobEntryAttributeString(id_jobentry, "lineterminated");
/* 178 */       this.limitlines = rep.getJobEntryAttributeString(id_jobentry, "limitlines");
/* 179 */       this.listcolumn = rep.getJobEntryAttributeString(id_jobentry, "listcolumn");
/* 180 */       this.highpriority = rep.getJobEntryAttributeBoolean(id_jobentry, "highpriority");
/* 181 */       this.optionenclosed = rep.getJobEntryAttributeBoolean(id_jobentry, "optionenclosed");
/*     */       
/* 183 */       this.outdumpvalue = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "outdumpvalue"));
/*     */       
/* 185 */       this.iffileexists = ((int)rep.getJobEntryAttributeInteger(id_jobentry, "iffileexists"));
/*     */       
/* 187 */       this.addfiletoresult = rep.getJobEntryAttributeBoolean(id_jobentry, "addfiletoresult");
/*     */       
/* 189 */       this.connection = rep.loadDatabaseMetaFromJobEntryAttribute(id_jobentry, "connection", "id_database", databases);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 193 */       throw new KettleException("Unable to load job entry of type 'table exists' from the repository for id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 201 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "schemaname", this.schemaname);
/* 202 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "tablename", this.tablename);
/* 203 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/* 204 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "separator", this.separator);
/* 205 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "enclosed", this.enclosed);
/* 206 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "lineterminated", this.lineterminated);
/* 207 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "limitlines", this.limitlines);
/* 208 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "listcolumn", this.listcolumn);
/* 209 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "highpriority", this.highpriority);
/* 210 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "optionenclosed", this.optionenclosed);
/*     */       
/* 212 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "outdumpvalue", this.outdumpvalue);
/* 213 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "iffileexists", this.iffileexists);
/*     */       
/* 215 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "addfiletoresult", this.addfiletoresult);
/*     */       
/* 217 */       rep.saveDatabaseMetaJobEntryAttribute(id_job, getObjectId(), "connection", "id_database", this.connection);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 221 */       throw new KettleException("Unable to load job entry of type 'Mysql Bulk Load' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTablename(String tablename)
/*     */   {
/* 228 */     this.tablename = tablename;
/*     */   }
/*     */   
/*     */   public void setSchemaname(String schemaname) {
/* 232 */     this.schemaname = schemaname;
/*     */   }
/*     */   
/*     */   public String getTablename()
/*     */   {
/* 237 */     return this.tablename;
/*     */   }
/*     */   
/*     */   public String getSchemaname() {
/* 241 */     return this.schemaname;
/*     */   }
/*     */   
/*     */   public void setDatabase(DatabaseMeta database)
/*     */   {
/* 246 */     this.connection = database;
/*     */   }
/*     */   
/*     */   public DatabaseMeta getDatabase()
/*     */   {
/* 251 */     return this.connection;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 256 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 261 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 267 */     String LimitNbrLignes = "";
/* 268 */     String ListOfColumn = "*";
/* 269 */     String strHighPriority = "";
/* 270 */     String OutDumpText = "";
/* 271 */     String OptionEnclosed = "";
/* 272 */     String FieldSeparator = "";
/* 273 */     String LinesTerminated = "";
/*     */     
/* 275 */     Result result = previousResult;
/* 276 */     result.setResult(false);
/*     */     
/*     */ 
/* 279 */     if (this.filename != null)
/*     */     {
/*     */ 
/* 282 */       String realFilename = getRealFilename();
/* 283 */       File file = new File(realFilename);
/*     */       
/* 285 */       if ((file.exists()) && (this.iffileexists == 2))
/*     */       {
/*     */ 
/* 288 */         result.setResult(false);
/* 289 */         result.setNrErrors(1L);
/* 290 */         logError(BaseMessages.getString(PKG, "JobMysqlBulkFile.FileExists1.Label", new String[0]) + realFilename + BaseMessages.getString(PKG, "JobMysqlBulkFile.FileExists2.Label", new String[0]));
/*     */ 
/*     */ 
/*     */       }
/* 294 */       else if ((file.exists()) && (this.iffileexists == 1))
/*     */       {
/*     */ 
/* 297 */         result.setResult(true);
/* 298 */         if (this.log.isDetailed()) {
/* 299 */           logDetailed(BaseMessages.getString(PKG, "JobMysqlBulkFile.FileExists1.Label", new String[0]) + realFilename + BaseMessages.getString(PKG, "JobMysqlBulkFile.FileExists2.Label", new String[0]));
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 306 */         if ((file.exists()) && (this.iffileexists == 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 313 */           String wildcard = realFilename.substring(realFilename.length() - 4, realFilename.length());
/* 314 */           if (wildcard.substring(0, 1).equals("."))
/*     */           {
/*     */ 
/* 317 */             realFilename = realFilename.substring(0, realFilename.length() - 4) + "_" + StringUtil.getFormattedDateTimeNow(true) + wildcard;
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 323 */             realFilename = realFilename + "_" + StringUtil.getFormattedDateTimeNow(true);
/*     */           }
/*     */           
/* 326 */           logDebug(BaseMessages.getString(PKG, "JobMysqlBulkFile.FileNameChange1.Label", new String[0]) + realFilename + BaseMessages.getString(PKG, "JobMysqlBulkFile.FileNameChange1.Label", new String[0]));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 334 */         if (this.log.isDetailed()) {
/* 335 */           logDetailed(BaseMessages.getString(PKG, "JobMysqlBulkFile.FileExists1.Label", new String[0]) + realFilename + BaseMessages.getString(PKG, "JobMysqlBulkFile.FileExists2.Label", new String[0]));
/*     */         }
/*     */         
/*     */ 
/* 339 */         if (this.connection != null)
/*     */         {
/*     */ 
/* 342 */           Database db = new Database(this, this.connection);
/* 343 */           db.shareVariablesWith(this);
/*     */           try
/*     */           {
/* 346 */             db.connect();
/*     */             
/* 348 */             String realSchemaname = environmentSubstitute(this.schemaname);
/*     */             
/* 350 */             String realTablename = environmentSubstitute(this.tablename);
/*     */             
/* 352 */             if (db.checkTableExists(realTablename))
/*     */             {
/*     */ 
/* 355 */               if (this.log.isDetailed()) {
/* 356 */                 logDetailed(BaseMessages.getString(PKG, "JobMysqlBulkFile.TableExists1.Label", new String[0]) + realTablename + BaseMessages.getString(PKG, "JobMysqlBulkFile.TableExists2.Label", new String[0]));
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 361 */               if (this.schemaname != null)
/*     */               {
/* 363 */                 realTablename = realSchemaname + "." + realTablename;
/*     */               }
/*     */               
/*     */ 
/* 367 */               if (Const.toInt(getRealLimitlines(), 0) > 0)
/*     */               {
/* 369 */                 LimitNbrLignes = "LIMIT " + getRealLimitlines();
/*     */               }
/*     */               
/*     */ 
/* 373 */               if (getRealListColumn() != null)
/*     */               {
/* 375 */                 ListOfColumn = MysqlString(getRealListColumn());
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 380 */               if ((getRealSeparator() != null) && (this.outdumpvalue == 0))
/*     */               {
/* 382 */                 FieldSeparator = "FIELDS TERMINATED BY '" + Const.replace(getRealSeparator(), "'", "''") + "'";
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 387 */               if ((getRealLineterminated() != null) && (this.outdumpvalue == 0))
/*     */               {
/* 389 */                 LinesTerminated = "LINES TERMINATED BY '" + Const.replace(getRealLineterminated(), "'", "''") + "'";
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */               if (isHighPriority())
/*     */               {
/* 398 */                 strHighPriority = "HIGH_PRIORITY";
/*     */               }
/*     */               
/* 401 */               if ((getRealEnclosed() != null) && (this.outdumpvalue == 0))
/*     */               {
/* 403 */                 if (isOptionEnclosed())
/*     */                 {
/* 405 */                   OptionEnclosed = "OPTIONALLY ";
/*     */                 }
/* 407 */                 OptionEnclosed = OptionEnclosed + "ENCLOSED BY '" + Const.replace(getRealEnclosed(), "'", "''") + "'";
/*     */               }
/*     */               
/*     */ 
/*     */ 
/* 412 */               if (this.outdumpvalue == 0)
/*     */               {
/* 414 */                 OutDumpText = "INTO OUTFILE";
/*     */               }
/*     */               else
/*     */               {
/* 418 */                 OutDumpText = "INTO DUMPFILE";
/*     */               }
/*     */               
/*     */ 
/* 422 */               String FILEBulkFile = "SELECT " + strHighPriority + " " + ListOfColumn + " " + OutDumpText + " '" + realFilename + "' " + FieldSeparator + " " + OptionEnclosed + " " + LinesTerminated + " FROM " + realTablename + " " + LimitNbrLignes + " LOCK IN SHARE MODE";
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/* 429 */                 if (this.log.isDetailed()) {
/* 430 */                   logDetailed(FILEBulkFile);
/*     */                 }
/* 432 */                 PreparedStatement ps = db.prepareSQL(FILEBulkFile);
/* 433 */                 ps.execute();
/*     */                 
/*     */ 
/* 436 */                 db.disconnect();
/*     */                 
/* 438 */                 if (isAddFileToResult())
/*     */                 {
/*     */ 
/* 441 */                   ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(realFilename, this), this.parentJob.getJobname(), toString());
/* 442 */                   result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */                 }
/*     */                 
/* 445 */                 result.setResult(true);
/*     */ 
/*     */               }
/*     */               catch (SQLException je)
/*     */               {
/*     */ 
/* 451 */                 db.disconnect();
/* 452 */                 result.setNrErrors(1L);
/* 453 */                 logError(BaseMessages.getString(PKG, "JobMysqlBulkFile.Error.Label", new String[0]) + " " + je.getMessage());
/*     */               }
/*     */               catch (KettleFileException e)
/*     */               {
/* 457 */                 logError(BaseMessages.getString(PKG, "JobMysqlBulkFile.Error.Label", new String[0]) + e.getMessage());
/* 458 */                 result.setNrErrors(1L);
/*     */               }
/*     */               
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 466 */               db.disconnect();
/* 467 */               result.setNrErrors(1L);
/* 468 */               if (this.log.isDetailed()) {
/* 469 */                 logDetailed(BaseMessages.getString(PKG, "JobMysqlBulkFile.TableNotExists1.Label", new String[0]) + realTablename + BaseMessages.getString(PKG, "JobMysqlBulkFile.TableNotExists2.Label", new String[0]));
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */           catch (KettleDatabaseException dbe)
/*     */           {
/* 477 */             db.disconnect();
/* 478 */             result.setNrErrors(1L);
/* 479 */             logError(BaseMessages.getString(PKG, "JobMysqlBulkFile.Error.Label", new String[0]) + " " + dbe.getMessage());
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 489 */           result.setNrErrors(1L);
/* 490 */           logError(BaseMessages.getString(PKG, "JobMysqlBulkFile.Nodatabase.Label", new String[0]));
/*     */ 
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 501 */       result.setNrErrors(1L);
/* 502 */       logError(BaseMessages.getString(PKG, "JobMysqlBulkFile.Nofilename.Label", new String[0]));
/*     */     }
/*     */     
/* 505 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public DatabaseMeta[] getUsedDatabaseConnections()
/*     */   {
/* 511 */     return new DatabaseMeta[] { this.connection };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHighPriority(boolean highpriority)
/*     */   {
/* 519 */     this.highpriority = highpriority;
/*     */   }
/*     */   
/*     */   public void setOptionEnclosed(boolean optionenclosed) {
/* 523 */     this.optionenclosed = optionenclosed;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isHighPriority()
/*     */   {
/* 529 */     return this.highpriority;
/*     */   }
/*     */   
/*     */   public boolean isOptionEnclosed() {
/* 533 */     return this.optionenclosed;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFilename(String filename)
/*     */   {
/* 539 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 544 */     return this.filename;
/*     */   }
/*     */   
/*     */   public String getRealFilename()
/*     */   {
/* 549 */     String RealFile = environmentSubstitute(getFilename());
/* 550 */     return RealFile.replace('\\', '/');
/*     */   }
/*     */   
/*     */   public void setSeparator(String separator) {
/* 554 */     this.separator = separator;
/*     */   }
/*     */   
/*     */   public void setEnclosed(String enclosed)
/*     */   {
/* 559 */     this.enclosed = enclosed;
/*     */   }
/*     */   
/*     */   public void setLineterminated(String lineterminated) {
/* 563 */     this.lineterminated = lineterminated;
/*     */   }
/*     */   
/*     */   public String getLineterminated()
/*     */   {
/* 568 */     return this.lineterminated;
/*     */   }
/*     */   
/*     */   public String getRealLineterminated()
/*     */   {
/* 573 */     return environmentSubstitute(getLineterminated());
/*     */   }
/*     */   
/*     */   public String getSeparator()
/*     */   {
/* 578 */     return this.separator;
/*     */   }
/*     */   
/*     */   public String getEnclosed() {
/* 582 */     return this.enclosed;
/*     */   }
/*     */   
/*     */   public String getRealSeparator()
/*     */   {
/* 587 */     return environmentSubstitute(getSeparator());
/*     */   }
/*     */   
/*     */   public String getRealEnclosed()
/*     */   {
/* 592 */     return environmentSubstitute(getEnclosed());
/*     */   }
/*     */   
/*     */   public void setLimitlines(String limitlines)
/*     */   {
/* 597 */     this.limitlines = limitlines;
/*     */   }
/*     */   
/*     */   public String getLimitlines()
/*     */   {
/* 602 */     return this.limitlines;
/*     */   }
/*     */   
/*     */   public String getRealLimitlines()
/*     */   {
/* 607 */     return environmentSubstitute(getLimitlines());
/*     */   }
/*     */   
/*     */   public void setListColumn(String listcolumn)
/*     */   {
/* 612 */     this.listcolumn = listcolumn;
/*     */   }
/*     */   
/*     */   public String getListColumn() {
/* 616 */     return this.listcolumn;
/*     */   }
/*     */   
/*     */   public String getRealListColumn()
/*     */   {
/* 621 */     return environmentSubstitute(getListColumn());
/*     */   }
/*     */   
/*     */   public void setAddFileToResult(boolean addfiletoresultin)
/*     */   {
/* 626 */     this.addfiletoresult = addfiletoresultin;
/*     */   }
/*     */   
/*     */   public boolean isAddFileToResult()
/*     */   {
/* 631 */     return this.addfiletoresult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String MysqlString(String listcolumns)
/*     */   {
/* 638 */     String ReturnString = "";
/* 639 */     String[] split = listcolumns.split(",");
/*     */     
/* 641 */     for (int i = 0; i < split.length; i++)
/*     */     {
/* 643 */       if (ReturnString.equals("")) {
/* 644 */         ReturnString = "`" + Const.trim(split[i]) + "`";
/*     */       } else {
/* 646 */         ReturnString = ReturnString + ", `" + Const.trim(split[i]) + "`";
/*     */       }
/*     */     }
/*     */     
/* 650 */     return ReturnString;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta)
/*     */   {
/* 656 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 657 */     if (this.connection != null) {
/* 658 */       ResourceReference reference = new ResourceReference(this);
/* 659 */       reference.getEntries().add(new ResourceEntry(this.connection.getHostname(), ResourceEntry.ResourceType.SERVER));
/* 660 */       reference.getEntries().add(new ResourceEntry(this.connection.getDatabaseName(), ResourceEntry.ResourceType.DATABASENAME));
/* 661 */       references.add(reference);
/*     */     }
/* 663 */     return references;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 669 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 670 */     JobEntryValidatorUtils.andValidator().validate(this, "tablename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\mysqlbulkfile\JobEntryMysqlBulkFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */