/*     */ package org.pentaho.di.core.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ import org.apache.commons.lang.builder.ToStringStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyValueFactory<T>
/*     */ {
/*  43 */   public static final KeyValueFactory<String> STRING = new KeyValueFactory("");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   public static final KeyValueFactory<Integer> INTEGER = new KeyValueFactory(Integer.valueOf(0));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   public static final KeyValueFactory<Integer> INTEGER_ONE = new KeyValueFactory(Integer.valueOf(1));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  58 */   public static final KeyValueFactory<Boolean> BOOLEAN = new KeyValueFactory(Boolean.FALSE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  63 */   public static final KeyValueFactory<Boolean> BOOLEAN_TRUE = new KeyValueFactory(Boolean.TRUE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   public static final KeyValueFactory<Float> FLOAT = new KeyValueFactory(Float.valueOf(0.0F));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   public static final KeyValueFactory<Float> FLOAT_ONE = new KeyValueFactory(Float.valueOf(1.0F));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   public static final KeyValueFactory<Double> DOUBLE = new KeyValueFactory(Double.valueOf(0.0D));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  83 */   public static final KeyValueFactory<Double> DOUBLE_ONE = new KeyValueFactory(Double.valueOf(1.0D));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  88 */   public static final KeyValueFactory<Long> LONG = new KeyValueFactory(Long.valueOf(0L));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  93 */   public static final KeyValueFactory<Long> LONG_ONE = new KeyValueFactory(Long.valueOf(1L));
/*     */   
/*     */ 
/*     */ 
/*     */   private final T defaultValue;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValueFactory(T defaultValue)
/*     */   {
/* 104 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public T getDefaultValue()
/*     */   {
/* 111 */     return (T)this.defaultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KeyValue<T> create(String key)
/*     */     throws IllegalArgumentException
/*     */   {
/* 122 */     return new KeyValue(key, this.defaultValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<KeyValue<T>> createAll(String... keys)
/*     */     throws IllegalArgumentException
/*     */   {
/* 133 */     List<KeyValue<T>> instances = new ArrayList();
/* 134 */     for (String key : keys) {
/* 135 */       instances.add(create(key));
/*     */     }
/* 137 */     return instances;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 147 */     ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
/* 148 */     builder.append("defaultValue", this.defaultValue);
/* 149 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\KeyValueFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */