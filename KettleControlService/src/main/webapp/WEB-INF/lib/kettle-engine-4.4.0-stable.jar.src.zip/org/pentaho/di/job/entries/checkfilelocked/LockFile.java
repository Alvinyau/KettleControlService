/*     */ package org.pentaho.di.job.entries.checkfilelocked;
/*     */ 
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LockFile
/*     */ {
/*     */   private String filename;
/*     */   private boolean locked;
/*     */   
/*     */   public LockFile(String filename)
/*     */     throws KettleException
/*     */   {
/*  45 */     setFilename(filename);
/*  46 */     setLocked(false);
/*     */     
/*     */ 
/*     */ 
/*  50 */     FileObject file = null;
/*  51 */     FileObject dummyfile = null;
/*     */     
/*     */     try
/*     */     {
/*  55 */       file = KettleVFS.getFileObject(filename);
/*  56 */       if (file.exists()) {
/*  57 */         dummyfile = KettleVFS.getFileObject(filename);
/*     */         
/*  59 */         file.moveTo(dummyfile);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  64 */       setLocked(true);
/*     */     } finally {
/*  66 */       if (file != null) try { file.close(); } catch (Exception e) {}
/*  67 */       if (dummyfile != null) { try { file.close();
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getFilename()
/*     */   {
/*  77 */     return this.filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setFilename(String filename)
/*     */   {
/*  85 */     this.filename = filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLocked()
/*     */   {
/*  93 */     return this.locked;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setLocked(boolean lock)
/*     */   {
/* 101 */     this.locked = lock;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\checkfilelocked\LockFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */