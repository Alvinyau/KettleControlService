/*     */ package org.pentaho.di.job.entries.fileexists;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.variables.VariableSpace;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceDefinition;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceNamingInterface;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryFileExists
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  70 */   private static Class<?> PKG = JobEntryFileExists.class;
/*     */   
/*     */   private String filename;
/*     */   
/*     */   public JobEntryFileExists(String n)
/*     */   {
/*  76 */     super(n, "");
/*  77 */     this.filename = null;
/*  78 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryFileExists()
/*     */   {
/*  83 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  88 */     JobEntryFileExists je = (JobEntryFileExists)super.clone();
/*  89 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  94 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  96 */     retval.append(super.getXML());
/*  97 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/*     */     
/*  99 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 106 */       super.loadXML(entrynode, databases, slaveServers);
/* 107 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 111 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryFileExists.ERROR_0001_Cannot_Load_Job_Entry_From_Xml_Node", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 119 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 123 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryFileExists.ERROR_0002_Cannot_Load_Job_From_Repository", new Object[] { id_jobentry }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 131 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 135 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryFileExists.ERROR_0003_Cannot_Save_Job_Entry", new Object[] { id_job }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFilename(String filename)
/*     */   {
/* 141 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 146 */     return this.filename;
/*     */   }
/*     */   
/*     */   public String getRealFilename()
/*     */   {
/* 151 */     return environmentSubstitute(getFilename());
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 156 */     Result result = previousResult;
/* 157 */     result.setResult(false);
/*     */     
/* 159 */     if (this.filename != null)
/*     */     {
/* 161 */       String realFilename = getRealFilename();
/*     */       try
/*     */       {
/* 164 */         FileObject file = KettleVFS.getFileObject(realFilename, this);
/* 165 */         if ((file.exists()) && (file.isReadable()))
/*     */         {
/* 167 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFileExists.File_Exists", new String[] { realFilename }));
/* 168 */           result.setResult(true);
/*     */         }
/*     */         else
/*     */         {
/* 172 */           logDetailed(BaseMessages.getString(PKG, "JobEntryFileExists.File_Does_Not_Exist", new String[] { realFilename }));
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 177 */         result.setNrErrors(1L);
/* 178 */         logError(BaseMessages.getString(PKG, "JobEntryFileExists.ERROR_0004_IO_Exception", new String[] { e.getMessage() }), e);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 183 */       result.setNrErrors(1L);
/* 184 */       logError(BaseMessages.getString(PKG, "JobEntryFileExists.ERROR_0005_No_Filename_Defined", new String[0]));
/*     */     }
/*     */     
/* 187 */     return result;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 192 */     return true;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 196 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 197 */     if (!Const.isEmpty(this.filename)) {
/* 198 */       String realFileName = jobMeta.environmentSubstitute(this.filename);
/* 199 */       ResourceReference reference = new ResourceReference(this);
/* 200 */       reference.getEntries().add(new ResourceEntry(realFileName, ResourceEntry.ResourceType.FILE));
/* 201 */       references.add(reference);
/*     */     }
/* 203 */     return references;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 208 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String exportResources(VariableSpace space, Map<String, ResourceDefinition> definitions, ResourceNamingInterface resourceNamingInterface, Repository repository)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 223 */       if (!Const.isEmpty(this.filename))
/*     */       {
/*     */ 
/*     */ 
/* 227 */         FileObject fileObject = KettleVFS.getFileObject(space.environmentSubstitute(this.filename), space);
/*     */         
/*     */ 
/*     */ 
/* 231 */         if (fileObject.exists())
/*     */         {
/*     */ 
/* 234 */           this.filename = resourceNamingInterface.nameResource(fileObject, space, true);
/*     */           
/* 236 */           return this.filename;
/*     */         }
/*     */       }
/* 239 */       return null;
/*     */     } catch (Exception e) {
/* 241 */       throw new KettleException(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\fileexists\JobEntryFileExists.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */