/*    */ package org.pentaho.di.core.changed;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangedFlag
/*    */   implements ChangedFlagInterface
/*    */ {
/* 32 */   private List<PDIObserver> obs = Collections.synchronizedList(new ArrayList());
/*    */   
/* 34 */   private AtomicBoolean changed = new AtomicBoolean();
/*    */   
/*    */   public void addObserver(PDIObserver o)
/*    */   {
/* 38 */     if (o == null)
/* 39 */       throw new NullPointerException();
/* 40 */     if (!this.obs.contains(o))
/*    */     {
/* 42 */       this.obs.add(o);
/*    */     }
/*    */   }
/*    */   
/*    */   public synchronized void deleteObserver(PDIObserver o)
/*    */   {
/* 48 */     this.obs.remove(o);
/*    */   }
/*    */   
/*    */ 
/*    */   public void notifyObservers(Object arg)
/*    */   {
/*    */     PDIObserver[] lobs;
/* 55 */     synchronized (this)
/*    */     {
/* 57 */       if (!this.changed.get())
/* 58 */         return;
/* 59 */       lobs = (PDIObserver[])this.obs.toArray(new PDIObserver[this.obs.size()]);
/* 60 */       clearChanged();
/*    */     }
/* 62 */     for (int i = lobs.length - 1; i >= 0; i--) {
/* 63 */       lobs[i].update(this, arg);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setChanged()
/*    */   {
/* 71 */     this.changed.set(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setChanged(boolean b)
/*    */   {
/* 80 */     this.changed.set(b);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void clearChanged()
/*    */   {
/* 88 */     this.changed.set(false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized boolean hasChanged()
/*    */   {
/* 97 */     return this.changed.get();
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\changed\ChangedFlag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */