package org.pentaho.di.imp.rule;

public enum ImportValidationResultType
{
  APPROVAL,  ERROR,  WARNING,  NOT_VALIDATED;
  
  private ImportValidationResultType() {}
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rule\ImportValidationResultType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */