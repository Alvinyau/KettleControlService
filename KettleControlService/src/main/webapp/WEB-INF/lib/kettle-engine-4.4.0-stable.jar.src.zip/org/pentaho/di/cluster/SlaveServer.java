/*      */ package org.pentaho.di.cluster;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.httpclient.Credentials;
/*      */ import org.apache.commons.httpclient.Header;
/*      */ import org.apache.commons.httpclient.HostConfiguration;
/*      */ import org.apache.commons.httpclient.HttpClient;
/*      */ import org.apache.commons.httpclient.HttpState;
/*      */ import org.apache.commons.httpclient.UsernamePasswordCredentials;
/*      */ import org.apache.commons.httpclient.auth.AuthScope;
/*      */ import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
/*      */ import org.apache.commons.httpclient.methods.PostMethod;
/*      */ import org.apache.commons.httpclient.methods.RequestEntity;
/*      */ import org.apache.commons.httpclient.params.HttpClientParams;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.changed.ChangedFlag;
/*      */ import org.pentaho.di.core.encryption.Encr;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.logging.LogChannel;
/*      */ import org.pentaho.di.core.logging.LogChannelInterface;
/*      */ import org.pentaho.di.core.row.ValueMeta;
/*      */ import org.pentaho.di.core.variables.VariableSpace;
/*      */ import org.pentaho.di.core.variables.Variables;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.core.xml.XMLInterface;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.ObjectRevision;
/*      */ import org.pentaho.di.repository.RepositoryDirectory;
/*      */ import org.pentaho.di.repository.RepositoryDirectoryInterface;
/*      */ import org.pentaho.di.repository.RepositoryElementInterface;
/*      */ import org.pentaho.di.repository.RepositoryObjectType;
/*      */ import org.pentaho.di.shared.SharedObjectInterface;
/*      */ import org.pentaho.di.www.SlaveServerDetection;
/*      */ import org.pentaho.di.www.SlaveServerJobStatus;
/*      */ import org.pentaho.di.www.SlaveServerStatus;
/*      */ import org.pentaho.di.www.SlaveServerTransStatus;
/*      */ import org.pentaho.di.www.WebResult;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SlaveServer
/*      */   extends ChangedFlag
/*      */   implements Cloneable, SharedObjectInterface, VariableSpace, RepositoryElementInterface, XMLInterface
/*      */ {
/*   97 */   private static Class<?> PKG = SlaveServer.class;
/*      */   
/*      */   public static final String STRING_SLAVESERVER = "Slave Server";
/*      */   
/*      */   public static final String XML_TAG = "slaveserver";
/*      */   
/*  103 */   public static final RepositoryObjectType REPOSITORY_ELEMENT_TYPE = RepositoryObjectType.SLAVE_SERVER;
/*      */   
/*      */   private LogChannelInterface log;
/*      */   
/*      */   private String name;
/*      */   
/*      */   private String hostname;
/*      */   
/*      */   private String port;
/*      */   
/*      */   private String webAppName;
/*      */   
/*      */   private String username;
/*      */   private String password;
/*      */   private String proxyHostname;
/*      */   private String proxyPort;
/*      */   private String nonProxyHosts;
/*      */   private boolean master;
/*      */   private boolean shared;
/*      */   private ObjectId id;
/*  123 */   private VariableSpace variables = new Variables();
/*      */   
/*      */   private ObjectRevision objectRevision;
/*      */   
/*      */   private Date changedDate;
/*      */   
/*      */   public SlaveServer()
/*      */   {
/*  131 */     initializeVariablesFrom(null);
/*  132 */     this.id = null;
/*  133 */     this.log = new LogChannel("Slave Server");
/*  134 */     this.changedDate = new Date();
/*      */   }
/*      */   
/*      */   public SlaveServer(String name, String hostname, String port, String username, String password)
/*      */   {
/*  139 */     this(name, hostname, port, username, password, null, null, null, false);
/*      */   }
/*      */   
/*      */   public SlaveServer(String name, String hostname, String port, String username, String password, String proxyHostname, String proxyPort, String nonProxyHosts, boolean master)
/*      */   {
/*  144 */     this();
/*  145 */     this.name = name;
/*  146 */     this.hostname = hostname;
/*  147 */     this.port = port;
/*  148 */     this.username = username;
/*  149 */     this.password = password;
/*      */     
/*  151 */     this.proxyHostname = proxyHostname;
/*  152 */     this.proxyPort = proxyPort;
/*  153 */     this.nonProxyHosts = nonProxyHosts;
/*      */     
/*  155 */     this.master = master;
/*  156 */     initializeVariablesFrom(null);
/*  157 */     this.log = new LogChannel(this);
/*      */   }
/*      */   
/*      */   public SlaveServer(Node slaveNode)
/*      */   {
/*  162 */     this();
/*  163 */     this.name = XMLHandler.getTagValue(slaveNode, "name");
/*  164 */     this.hostname = XMLHandler.getTagValue(slaveNode, "hostname");
/*  165 */     this.port = XMLHandler.getTagValue(slaveNode, "port");
/*  166 */     this.webAppName = XMLHandler.getTagValue(slaveNode, "webAppName");
/*  167 */     this.username = XMLHandler.getTagValue(slaveNode, "username");
/*  168 */     this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(slaveNode, "password"));
/*  169 */     this.proxyHostname = XMLHandler.getTagValue(slaveNode, "proxy_hostname");
/*  170 */     this.proxyPort = XMLHandler.getTagValue(slaveNode, "proxy_port");
/*  171 */     this.nonProxyHosts = XMLHandler.getTagValue(slaveNode, "non_proxy_hosts");
/*  172 */     this.master = "Y".equalsIgnoreCase(XMLHandler.getTagValue(slaveNode, "master"));
/*  173 */     initializeVariablesFrom(null);
/*  174 */     this.log = new LogChannel(this);
/*      */   }
/*      */   
/*      */   public LogChannelInterface getLogChannel()
/*      */   {
/*  179 */     return this.log;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  184 */     StringBuffer xml = new StringBuffer();
/*      */     
/*  186 */     xml.append("<").append("slaveserver").append(">");
/*      */     
/*  188 */     xml.append(XMLHandler.addTagValue("name", this.name, false, new String[0]));
/*  189 */     xml.append(XMLHandler.addTagValue("hostname", this.hostname, false, new String[0]));
/*  190 */     xml.append(XMLHandler.addTagValue("port", this.port, false, new String[0]));
/*  191 */     xml.append(XMLHandler.addTagValue("webAppName", this.webAppName, false, new String[0]));
/*  192 */     xml.append(XMLHandler.addTagValue("username", this.username, false, new String[0]));
/*  193 */     xml.append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(this.password), false, new String[0]));
/*  194 */     xml.append(XMLHandler.addTagValue("proxy_hostname", this.proxyHostname, false, new String[0]));
/*  195 */     xml.append(XMLHandler.addTagValue("proxy_port", this.proxyPort, false, new String[0]));
/*  196 */     xml.append(XMLHandler.addTagValue("non_proxy_hosts", this.nonProxyHosts, false, new String[0]));
/*  197 */     xml.append(XMLHandler.addTagValue("master", this.master, false));
/*      */     
/*  199 */     xml.append("</").append("slaveserver").append(">");
/*      */     
/*  201 */     return xml.toString();
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  206 */     SlaveServer slaveServer = new SlaveServer();
/*  207 */     slaveServer.replaceMeta(this);
/*  208 */     return slaveServer;
/*      */   }
/*      */   
/*      */   public void replaceMeta(SlaveServer slaveServer)
/*      */   {
/*  213 */     this.name = slaveServer.name;
/*  214 */     this.hostname = slaveServer.hostname;
/*  215 */     this.port = slaveServer.port;
/*  216 */     this.webAppName = slaveServer.webAppName;
/*  217 */     this.username = slaveServer.username;
/*  218 */     this.password = slaveServer.password;
/*  219 */     this.proxyHostname = slaveServer.proxyHostname;
/*  220 */     this.proxyPort = slaveServer.proxyPort;
/*  221 */     this.nonProxyHosts = slaveServer.nonProxyHosts;
/*  222 */     this.master = slaveServer.master;
/*      */     
/*  224 */     this.id = slaveServer.id;
/*  225 */     this.shared = slaveServer.shared;
/*  226 */     setChanged(true);
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/*  231 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */   public String getServerAndPort()
/*      */   {
/*  237 */     String realHostname = environmentSubstitute(this.hostname);
/*  238 */     if (!Const.isEmpty(realHostname)) return realHostname + getPortSpecification();
/*  239 */     return "Slave Server";
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj)
/*      */   {
/*  244 */     if (!(obj instanceof SlaveServer)) {
/*  245 */       return false;
/*      */     }
/*  247 */     SlaveServer slave = (SlaveServer)obj;
/*  248 */     return this.name.equalsIgnoreCase(slave.getName());
/*      */   }
/*      */   
/*      */   public int hashCode()
/*      */   {
/*  253 */     return this.name.hashCode();
/*      */   }
/*      */   
/*      */   public String getHostname()
/*      */   {
/*  258 */     return this.hostname;
/*      */   }
/*      */   
/*      */   public void setHostname(String urlString)
/*      */   {
/*  263 */     this.hostname = urlString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPassword()
/*      */   {
/*  271 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPassword(String password)
/*      */   {
/*  279 */     this.password = password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUsername()
/*      */   {
/*  287 */     return this.username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUsername(String username)
/*      */   {
/*  295 */     this.username = username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getWebAppName()
/*      */   {
/*  303 */     return this.webAppName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWebAppName(String webAppName)
/*      */   {
/*  311 */     this.webAppName = webAppName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getNonProxyHosts()
/*      */   {
/*  319 */     return this.nonProxyHosts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNonProxyHosts(String nonProxyHosts)
/*      */   {
/*  327 */     this.nonProxyHosts = nonProxyHosts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyHostname()
/*      */   {
/*  335 */     return this.proxyHostname;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyHostname(String proxyHostname)
/*      */   {
/*  343 */     this.proxyHostname = proxyHostname;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getProxyPort()
/*      */   {
/*  351 */     return this.proxyPort;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setProxyPort(String proxyPort)
/*      */   {
/*  359 */     this.proxyPort = proxyPort;
/*      */   }
/*      */   
/*      */   public String getPortSpecification()
/*      */   {
/*  364 */     String realPort = environmentSubstitute(this.port);
/*  365 */     String portSpec = ":" + realPort;
/*  366 */     if ((Const.isEmpty(realPort)) || (this.port.equals("80")))
/*      */     {
/*  368 */       portSpec = "";
/*      */     }
/*  370 */     return portSpec;
/*      */   }
/*      */   
/*      */   public String constructUrl(String serviceAndArguments) throws UnsupportedEncodingException
/*      */   {
/*  375 */     String realHostname = environmentSubstitute(this.hostname);
/*  376 */     if (!StringUtils.isEmpty(this.webAppName)) {
/*  377 */       serviceAndArguments = "/" + environmentSubstitute(getWebAppName()) + serviceAndArguments;
/*      */     }
/*  379 */     String retval = "http://" + realHostname + getPortSpecification() + serviceAndArguments;
/*  380 */     retval = Const.replace(retval, " ", "%20");
/*  381 */     return retval;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getPort()
/*      */   {
/*  389 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPort(String port)
/*      */   {
/*  397 */     this.port = port;
/*      */   }
/*      */   
/*      */   public PostMethod getSendByteArrayMethod(byte[] content, String service)
/*      */     throws Exception
/*      */   {
/*  403 */     String urlString = constructUrl(service);
/*  404 */     if (this.log.isDebug()) this.log.logDebug(BaseMessages.getString(PKG, "SlaveServer.DEBUG_ConnectingTo", new String[] { urlString }));
/*  405 */     PostMethod postMethod = new PostMethod(urlString);
/*      */     
/*      */ 
/*      */ 
/*  409 */     RequestEntity entity = new ByteArrayRequestEntity(content);
/*      */     
/*  411 */     postMethod.setRequestEntity(entity);
/*  412 */     postMethod.setDoAuthentication(true);
/*  413 */     postMethod.addRequestHeader(new Header("Content-Type", "text/xml;charset=UTF-8"));
/*      */     
/*  415 */     return postMethod;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public synchronized String sendXML(String xml, String service)
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ldc 93
/*      */     //   3: invokevirtual 94	java/lang/String:getBytes	(Ljava/lang/String;)[B
/*      */     //   6: astore_3
/*      */     //   7: aload_0
/*      */     //   8: aload_3
/*      */     //   9: aload_2
/*      */     //   10: invokevirtual 95	org/pentaho/di/cluster/SlaveServer:getSendByteArrayMethod	([BLjava/lang/String;)Lorg/apache/commons/httpclient/methods/PostMethod;
/*      */     //   13: astore 4
/*      */     //   15: invokestatic 96	org/pentaho/di/cluster/SlaveConnectionManager:getInstance	()Lorg/pentaho/di/cluster/SlaveConnectionManager;
/*      */     //   18: invokevirtual 97	org/pentaho/di/cluster/SlaveConnectionManager:createHttpClient	()Lorg/apache/commons/httpclient/HttpClient;
/*      */     //   21: astore 5
/*      */     //   23: aload_0
/*      */     //   24: aload 5
/*      */     //   26: invokevirtual 98	org/pentaho/di/cluster/SlaveServer:addCredentials	(Lorg/apache/commons/httpclient/HttpClient;)V
/*      */     //   29: aload_0
/*      */     //   30: aload 5
/*      */     //   32: invokevirtual 99	org/pentaho/di/cluster/SlaveServer:addProxy	(Lorg/apache/commons/httpclient/HttpClient;)V
/*      */     //   35: aconst_null
/*      */     //   36: astore 6
/*      */     //   38: aconst_null
/*      */     //   39: astore 7
/*      */     //   41: aload 5
/*      */     //   43: aload 4
/*      */     //   45: invokevirtual 100	org/apache/commons/httpclient/HttpClient:executeMethod	(Lorg/apache/commons/httpclient/HttpMethod;)I
/*      */     //   48: istore 8
/*      */     //   50: aload_0
/*      */     //   51: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   54: invokeinterface 77 1 0
/*      */     //   59: ifeq +32 -> 91
/*      */     //   62: aload_0
/*      */     //   63: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   66: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   69: ldc 101
/*      */     //   71: iconst_1
/*      */     //   72: anewarray 46	java/lang/String
/*      */     //   75: dup
/*      */     //   76: iconst_0
/*      */     //   77: iload 8
/*      */     //   79: invokestatic 102	java/lang/Integer:toString	(I)Ljava/lang/String;
/*      */     //   82: aastore
/*      */     //   83: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   86: invokeinterface 81 2 0
/*      */     //   91: aload 4
/*      */     //   93: invokevirtual 103	org/apache/commons/httpclient/methods/PostMethod:getResponseBodyAsStream	()Ljava/io/InputStream;
/*      */     //   96: astore 6
/*      */     //   98: new 104	java/io/BufferedInputStream
/*      */     //   101: dup
/*      */     //   102: aload 6
/*      */     //   104: sipush 1000
/*      */     //   107: invokespecial 105	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;I)V
/*      */     //   110: astore 7
/*      */     //   112: new 40	java/lang/StringBuffer
/*      */     //   115: dup
/*      */     //   116: invokespecial 41	java/lang/StringBuffer:<init>	()V
/*      */     //   119: astore 9
/*      */     //   121: aload 7
/*      */     //   123: invokevirtual 106	java/io/BufferedInputStream:read	()I
/*      */     //   126: dup
/*      */     //   127: istore 10
/*      */     //   129: iconst_m1
/*      */     //   130: if_icmpeq +15 -> 145
/*      */     //   133: aload 9
/*      */     //   135: iload 10
/*      */     //   137: i2c
/*      */     //   138: invokevirtual 107	java/lang/StringBuffer:append	(C)Ljava/lang/StringBuffer;
/*      */     //   141: pop
/*      */     //   142: goto -21 -> 121
/*      */     //   145: aload 9
/*      */     //   147: invokevirtual 51	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   150: astore 11
/*      */     //   152: iload 8
/*      */     //   154: lookupswitch	default:+70->224, 401:+18->172
/*      */     //   172: new 58	java/lang/StringBuilder
/*      */     //   175: dup
/*      */     //   176: invokespecial 59	java/lang/StringBuilder:<init>	()V
/*      */     //   179: ldc 108
/*      */     //   181: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   184: aload 11
/*      */     //   186: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   189: invokevirtual 62	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   192: astore 12
/*      */     //   194: new 109	org/pentaho/di/www/WebResult
/*      */     //   197: dup
/*      */     //   198: ldc 110
/*      */     //   200: aload 12
/*      */     //   202: invokespecial 111	org/pentaho/di/www/WebResult:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   205: astore 13
/*      */     //   207: aload 9
/*      */     //   209: iconst_0
/*      */     //   210: invokevirtual 112	java/lang/StringBuffer:setLength	(I)V
/*      */     //   213: aload 9
/*      */     //   215: aload 13
/*      */     //   217: invokevirtual 113	org/pentaho/di/www/WebResult:getXML	()Ljava/lang/String;
/*      */     //   220: invokevirtual 43	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   223: pop
/*      */     //   224: aload 9
/*      */     //   226: invokevirtual 51	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   229: astore 12
/*      */     //   231: aload_0
/*      */     //   232: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   235: invokeinterface 77 1 0
/*      */     //   240: ifeq +29 -> 269
/*      */     //   243: aload_0
/*      */     //   244: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   247: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   250: ldc 114
/*      */     //   252: iconst_1
/*      */     //   253: anewarray 46	java/lang/String
/*      */     //   256: dup
/*      */     //   257: iconst_0
/*      */     //   258: aload 12
/*      */     //   260: aastore
/*      */     //   261: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   264: invokeinterface 81 2 0
/*      */     //   269: aload 12
/*      */     //   271: astore 13
/*      */     //   273: aload 7
/*      */     //   275: ifnull +8 -> 283
/*      */     //   278: aload 7
/*      */     //   280: invokevirtual 115	java/io/BufferedInputStream:close	()V
/*      */     //   283: aload 6
/*      */     //   285: ifnull +8 -> 293
/*      */     //   288: aload 6
/*      */     //   290: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   293: aload 4
/*      */     //   295: invokevirtual 117	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*      */     //   298: aload_0
/*      */     //   299: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   302: invokeinterface 118 1 0
/*      */     //   307: ifeq +39 -> 346
/*      */     //   310: aload_0
/*      */     //   311: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   314: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   317: ldc 119
/*      */     //   319: iconst_2
/*      */     //   320: anewarray 46	java/lang/String
/*      */     //   323: dup
/*      */     //   324: iconst_0
/*      */     //   325: aload_2
/*      */     //   326: aastore
/*      */     //   327: dup
/*      */     //   328: iconst_1
/*      */     //   329: aload_0
/*      */     //   330: aload_0
/*      */     //   331: getfield 17	org/pentaho/di/cluster/SlaveServer:hostname	Ljava/lang/String;
/*      */     //   334: invokevirtual 56	org/pentaho/di/cluster/SlaveServer:environmentSubstitute	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   337: aastore
/*      */     //   338: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   341: invokeinterface 120 2 0
/*      */     //   346: aload 13
/*      */     //   348: areturn
/*      */     //   349: astore 8
/*      */     //   351: aload_0
/*      */     //   352: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   355: aload_0
/*      */     //   356: invokevirtual 122	org/pentaho/di/cluster/SlaveServer:toString	()Ljava/lang/String;
/*      */     //   359: iconst_2
/*      */     //   360: anewarray 123	java/lang/Object
/*      */     //   363: dup
/*      */     //   364: iconst_0
/*      */     //   365: ldc 124
/*      */     //   367: iconst_1
/*      */     //   368: anewarray 123	java/lang/Object
/*      */     //   371: dup
/*      */     //   372: iconst_0
/*      */     //   373: aload_2
/*      */     //   374: aastore
/*      */     //   375: invokestatic 125	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   378: aastore
/*      */     //   379: dup
/*      */     //   380: iconst_1
/*      */     //   381: aload 8
/*      */     //   383: aastore
/*      */     //   384: invokeinterface 126 3 0
/*      */     //   389: aload 8
/*      */     //   391: athrow
/*      */     //   392: astore 14
/*      */     //   394: aload 7
/*      */     //   396: ifnull +8 -> 404
/*      */     //   399: aload 7
/*      */     //   401: invokevirtual 115	java/io/BufferedInputStream:close	()V
/*      */     //   404: aload 6
/*      */     //   406: ifnull +8 -> 414
/*      */     //   409: aload 6
/*      */     //   411: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   414: aload 4
/*      */     //   416: invokevirtual 117	org/apache/commons/httpclient/methods/PostMethod:releaseConnection	()V
/*      */     //   419: aload_0
/*      */     //   420: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   423: invokeinterface 118 1 0
/*      */     //   428: ifeq +39 -> 467
/*      */     //   431: aload_0
/*      */     //   432: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   435: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   438: ldc 119
/*      */     //   440: iconst_2
/*      */     //   441: anewarray 46	java/lang/String
/*      */     //   444: dup
/*      */     //   445: iconst_0
/*      */     //   446: aload_2
/*      */     //   447: aastore
/*      */     //   448: dup
/*      */     //   449: iconst_1
/*      */     //   450: aload_0
/*      */     //   451: aload_0
/*      */     //   452: getfield 17	org/pentaho/di/cluster/SlaveServer:hostname	Ljava/lang/String;
/*      */     //   455: invokevirtual 56	org/pentaho/di/cluster/SlaveServer:environmentSubstitute	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   458: aastore
/*      */     //   459: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   462: invokeinterface 120 2 0
/*      */     //   467: aload 14
/*      */     //   469: athrow
/*      */     // Line number table:
/*      */     //   Java source line #420	-> byte code offset #0
/*      */     //   Java source line #421	-> byte code offset #7
/*      */     //   Java source line #425	-> byte code offset #15
/*      */     //   Java source line #426	-> byte code offset #23
/*      */     //   Java source line #427	-> byte code offset #29
/*      */     //   Java source line #431	-> byte code offset #35
/*      */     //   Java source line #432	-> byte code offset #38
/*      */     //   Java source line #436	-> byte code offset #41
/*      */     //   Java source line #439	-> byte code offset #50
/*      */     //   Java source line #443	-> byte code offset #91
/*      */     //   Java source line #444	-> byte code offset #98
/*      */     //   Java source line #446	-> byte code offset #112
/*      */     //   Java source line #448	-> byte code offset #121
/*      */     //   Java source line #450	-> byte code offset #145
/*      */     //   Java source line #452	-> byte code offset #152
/*      */     //   Java source line #456	-> byte code offset #172
/*      */     //   Java source line #457	-> byte code offset #194
/*      */     //   Java source line #458	-> byte code offset #207
/*      */     //   Java source line #459	-> byte code offset #213
/*      */     //   Java source line #463	-> byte code offset #224
/*      */     //   Java source line #466	-> byte code offset #231
/*      */     //   Java source line #468	-> byte code offset #269
/*      */     //   Java source line #475	-> byte code offset #273
/*      */     //   Java source line #476	-> byte code offset #278
/*      */     //   Java source line #478	-> byte code offset #283
/*      */     //   Java source line #479	-> byte code offset #288
/*      */     //   Java source line #483	-> byte code offset #293
/*      */     //   Java source line #484	-> byte code offset #298
/*      */     //   Java source line #469	-> byte code offset #349
/*      */     //   Java source line #470	-> byte code offset #351
/*      */     //   Java source line #471	-> byte code offset #389
/*      */     //   Java source line #475	-> byte code offset #392
/*      */     //   Java source line #476	-> byte code offset #399
/*      */     //   Java source line #478	-> byte code offset #404
/*      */     //   Java source line #479	-> byte code offset #409
/*      */     //   Java source line #483	-> byte code offset #414
/*      */     //   Java source line #484	-> byte code offset #419
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	470	0	this	SlaveServer
/*      */     //   0	470	1	xml	String
/*      */     //   0	470	2	service	String
/*      */     //   6	3	3	content	byte[]
/*      */     //   13	402	4	post	PostMethod
/*      */     //   21	21	5	client	HttpClient
/*      */     //   36	374	6	inputStream	java.io.InputStream
/*      */     //   39	361	7	bufferedInputStream	java.io.BufferedInputStream
/*      */     //   48	105	8	result	int
/*      */     //   349	41	8	e	Exception
/*      */     //   119	106	9	bodyBuffer	StringBuffer
/*      */     //   127	9	10	c	int
/*      */     //   150	35	11	bodyTmp	String
/*      */     //   192	9	12	message	String
/*      */     //   229	41	12	body	String
/*      */     //   205	142	13	webResult	WebResult
/*      */     //   392	76	14	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   41	273	349	java/lang/Exception
/*      */     //   41	273	392	finally
/*      */     //   349	394	392	finally
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public String sendExport(String filename, String type, String load)
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: ldc 127
/*      */     //   2: astore 4
/*      */     //   4: aload_2
/*      */     //   5: ifnull +60 -> 65
/*      */     //   8: aload_3
/*      */     //   9: ifnull +56 -> 65
/*      */     //   12: new 58	java/lang/StringBuilder
/*      */     //   15: dup
/*      */     //   16: invokespecial 59	java/lang/StringBuilder:<init>	()V
/*      */     //   19: aload 4
/*      */     //   21: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   24: ldc -128
/*      */     //   26: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   29: aload_2
/*      */     //   30: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   33: ldc -127
/*      */     //   35: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   38: ldc -126
/*      */     //   40: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   43: ldc -125
/*      */     //   45: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   48: aload_3
/*      */     //   49: ldc 93
/*      */     //   51: invokestatic 132	java/net/URLEncoder:encode	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   54: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   57: invokevirtual 62	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   60: dup
/*      */     //   61: astore 4
/*      */     //   63: astore 4
/*      */     //   65: aload_0
/*      */     //   66: aload 4
/*      */     //   68: invokevirtual 76	org/pentaho/di/cluster/SlaveServer:constructUrl	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   71: astore 5
/*      */     //   73: aload_0
/*      */     //   74: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   77: invokeinterface 77 1 0
/*      */     //   82: ifeq +29 -> 111
/*      */     //   85: aload_0
/*      */     //   86: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   89: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   92: ldc 79
/*      */     //   94: iconst_1
/*      */     //   95: anewarray 46	java/lang/String
/*      */     //   98: dup
/*      */     //   99: iconst_0
/*      */     //   100: aload 5
/*      */     //   102: aastore
/*      */     //   103: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   106: invokeinterface 81 2 0
/*      */     //   111: new 133	org/apache/commons/httpclient/methods/PutMethod
/*      */     //   114: dup
/*      */     //   115: aload 5
/*      */     //   117: invokespecial 134	org/apache/commons/httpclient/methods/PutMethod:<init>	(Ljava/lang/String;)V
/*      */     //   120: astore 6
/*      */     //   122: aload_1
/*      */     //   123: invokestatic 135	org/pentaho/di/core/vfs/KettleVFS:getFileObject	(Ljava/lang/String;)Lorg/apache/commons/vfs/FileObject;
/*      */     //   126: astore 7
/*      */     //   128: aload 7
/*      */     //   130: invokestatic 136	org/pentaho/di/core/vfs/KettleVFS:getInputStream	(Lorg/apache/commons/vfs/FileObject;)Ljava/io/InputStream;
/*      */     //   133: astore 8
/*      */     //   135: new 137	org/apache/commons/httpclient/methods/InputStreamRequestEntity
/*      */     //   138: dup
/*      */     //   139: aload 8
/*      */     //   141: invokespecial 138	org/apache/commons/httpclient/methods/InputStreamRequestEntity:<init>	(Ljava/io/InputStream;)V
/*      */     //   144: astore 9
/*      */     //   146: aload 6
/*      */     //   148: aload 9
/*      */     //   150: invokevirtual 139	org/apache/commons/httpclient/methods/PutMethod:setRequestEntity	(Lorg/apache/commons/httpclient/methods/RequestEntity;)V
/*      */     //   153: aload 6
/*      */     //   155: iconst_1
/*      */     //   156: invokevirtual 140	org/apache/commons/httpclient/methods/PutMethod:setDoAuthentication	(Z)V
/*      */     //   159: aload 6
/*      */     //   161: new 88	org/apache/commons/httpclient/Header
/*      */     //   164: dup
/*      */     //   165: ldc 89
/*      */     //   167: ldc -115
/*      */     //   169: invokespecial 91	org/apache/commons/httpclient/Header:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   172: invokevirtual 142	org/apache/commons/httpclient/methods/PutMethod:addRequestHeader	(Lorg/apache/commons/httpclient/Header;)V
/*      */     //   175: invokestatic 96	org/pentaho/di/cluster/SlaveConnectionManager:getInstance	()Lorg/pentaho/di/cluster/SlaveConnectionManager;
/*      */     //   178: invokevirtual 97	org/pentaho/di/cluster/SlaveConnectionManager:createHttpClient	()Lorg/apache/commons/httpclient/HttpClient;
/*      */     //   181: astore 10
/*      */     //   183: aload_0
/*      */     //   184: aload 10
/*      */     //   186: invokevirtual 98	org/pentaho/di/cluster/SlaveServer:addCredentials	(Lorg/apache/commons/httpclient/HttpClient;)V
/*      */     //   189: aload_0
/*      */     //   190: aload 10
/*      */     //   192: invokevirtual 99	org/pentaho/di/cluster/SlaveServer:addProxy	(Lorg/apache/commons/httpclient/HttpClient;)V
/*      */     //   195: aconst_null
/*      */     //   196: astore 11
/*      */     //   198: aconst_null
/*      */     //   199: astore 12
/*      */     //   201: aload 10
/*      */     //   203: aload 6
/*      */     //   205: invokevirtual 100	org/apache/commons/httpclient/HttpClient:executeMethod	(Lorg/apache/commons/httpclient/HttpMethod;)I
/*      */     //   208: istore 13
/*      */     //   210: aload_0
/*      */     //   211: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   214: invokeinterface 77 1 0
/*      */     //   219: ifeq +32 -> 251
/*      */     //   222: aload_0
/*      */     //   223: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   226: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   229: ldc 101
/*      */     //   231: iconst_1
/*      */     //   232: anewarray 46	java/lang/String
/*      */     //   235: dup
/*      */     //   236: iconst_0
/*      */     //   237: iload 13
/*      */     //   239: invokestatic 102	java/lang/Integer:toString	(I)Ljava/lang/String;
/*      */     //   242: aastore
/*      */     //   243: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   246: invokeinterface 81 2 0
/*      */     //   251: aload 6
/*      */     //   253: invokevirtual 143	org/apache/commons/httpclient/methods/PutMethod:getResponseBodyAsStream	()Ljava/io/InputStream;
/*      */     //   256: astore 11
/*      */     //   258: new 104	java/io/BufferedInputStream
/*      */     //   261: dup
/*      */     //   262: aload 11
/*      */     //   264: sipush 1000
/*      */     //   267: invokespecial 105	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;I)V
/*      */     //   270: astore 12
/*      */     //   272: new 40	java/lang/StringBuffer
/*      */     //   275: dup
/*      */     //   276: invokespecial 41	java/lang/StringBuffer:<init>	()V
/*      */     //   279: astore 14
/*      */     //   281: aload 12
/*      */     //   283: invokevirtual 106	java/io/BufferedInputStream:read	()I
/*      */     //   286: dup
/*      */     //   287: istore 15
/*      */     //   289: iconst_m1
/*      */     //   290: if_icmpeq +15 -> 305
/*      */     //   293: aload 14
/*      */     //   295: iload 15
/*      */     //   297: i2c
/*      */     //   298: invokevirtual 107	java/lang/StringBuffer:append	(C)Ljava/lang/StringBuffer;
/*      */     //   301: pop
/*      */     //   302: goto -21 -> 281
/*      */     //   305: aload 14
/*      */     //   307: invokevirtual 51	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   310: astore 16
/*      */     //   312: iload 13
/*      */     //   314: lookupswitch	default:+70->384, 401:+18->332
/*      */     //   332: new 58	java/lang/StringBuilder
/*      */     //   335: dup
/*      */     //   336: invokespecial 59	java/lang/StringBuilder:<init>	()V
/*      */     //   339: ldc 108
/*      */     //   341: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   344: aload 16
/*      */     //   346: invokevirtual 60	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   349: invokevirtual 62	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   352: astore 17
/*      */     //   354: new 109	org/pentaho/di/www/WebResult
/*      */     //   357: dup
/*      */     //   358: ldc 110
/*      */     //   360: aload 17
/*      */     //   362: invokespecial 111	org/pentaho/di/www/WebResult:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   365: astore 18
/*      */     //   367: aload 14
/*      */     //   369: iconst_0
/*      */     //   370: invokevirtual 112	java/lang/StringBuffer:setLength	(I)V
/*      */     //   373: aload 14
/*      */     //   375: aload 18
/*      */     //   377: invokevirtual 113	org/pentaho/di/www/WebResult:getXML	()Ljava/lang/String;
/*      */     //   380: invokevirtual 43	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   383: pop
/*      */     //   384: aload 14
/*      */     //   386: invokevirtual 51	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   389: astore 17
/*      */     //   391: aload_0
/*      */     //   392: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   395: invokeinterface 77 1 0
/*      */     //   400: ifeq +29 -> 429
/*      */     //   403: aload_0
/*      */     //   404: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   407: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   410: ldc 114
/*      */     //   412: iconst_1
/*      */     //   413: anewarray 46	java/lang/String
/*      */     //   416: dup
/*      */     //   417: iconst_0
/*      */     //   418: aload 17
/*      */     //   420: aastore
/*      */     //   421: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   424: invokeinterface 81 2 0
/*      */     //   429: aload 17
/*      */     //   431: astore 18
/*      */     //   433: aload 12
/*      */     //   435: ifnull +8 -> 443
/*      */     //   438: aload 12
/*      */     //   440: invokevirtual 115	java/io/BufferedInputStream:close	()V
/*      */     //   443: aload 11
/*      */     //   445: ifnull +8 -> 453
/*      */     //   448: aload 11
/*      */     //   450: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   453: aload 6
/*      */     //   455: invokevirtual 144	org/apache/commons/httpclient/methods/PutMethod:releaseConnection	()V
/*      */     //   458: aload_0
/*      */     //   459: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   462: invokeinterface 118 1 0
/*      */     //   467: ifeq +40 -> 507
/*      */     //   470: aload_0
/*      */     //   471: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   474: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   477: ldc -111
/*      */     //   479: iconst_2
/*      */     //   480: anewarray 46	java/lang/String
/*      */     //   483: dup
/*      */     //   484: iconst_0
/*      */     //   485: ldc 127
/*      */     //   487: aastore
/*      */     //   488: dup
/*      */     //   489: iconst_1
/*      */     //   490: aload_0
/*      */     //   491: aload_0
/*      */     //   492: getfield 17	org/pentaho/di/cluster/SlaveServer:hostname	Ljava/lang/String;
/*      */     //   495: invokevirtual 56	org/pentaho/di/cluster/SlaveServer:environmentSubstitute	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   498: aastore
/*      */     //   499: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   502: invokeinterface 120 2 0
/*      */     //   507: aload 8
/*      */     //   509: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   512: goto +5 -> 517
/*      */     //   515: astore 19
/*      */     //   517: aload 18
/*      */     //   519: areturn
/*      */     //   520: astore 20
/*      */     //   522: aload 12
/*      */     //   524: ifnull +8 -> 532
/*      */     //   527: aload 12
/*      */     //   529: invokevirtual 115	java/io/BufferedInputStream:close	()V
/*      */     //   532: aload 11
/*      */     //   534: ifnull +8 -> 542
/*      */     //   537: aload 11
/*      */     //   539: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   542: aload 6
/*      */     //   544: invokevirtual 144	org/apache/commons/httpclient/methods/PutMethod:releaseConnection	()V
/*      */     //   547: aload_0
/*      */     //   548: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   551: invokeinterface 118 1 0
/*      */     //   556: ifeq +40 -> 596
/*      */     //   559: aload_0
/*      */     //   560: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   563: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   566: ldc -111
/*      */     //   568: iconst_2
/*      */     //   569: anewarray 46	java/lang/String
/*      */     //   572: dup
/*      */     //   573: iconst_0
/*      */     //   574: ldc 127
/*      */     //   576: aastore
/*      */     //   577: dup
/*      */     //   578: iconst_1
/*      */     //   579: aload_0
/*      */     //   580: aload_0
/*      */     //   581: getfield 17	org/pentaho/di/cluster/SlaveServer:hostname	Ljava/lang/String;
/*      */     //   584: invokevirtual 56	org/pentaho/di/cluster/SlaveServer:environmentSubstitute	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   587: aastore
/*      */     //   588: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   591: invokeinterface 120 2 0
/*      */     //   596: aload 20
/*      */     //   598: athrow
/*      */     //   599: astore 21
/*      */     //   601: aload 8
/*      */     //   603: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   606: goto +5 -> 611
/*      */     //   609: astore 22
/*      */     //   611: aload 21
/*      */     //   613: athrow
/*      */     // Line number table:
/*      */     //   Java source line #498	-> byte code offset #0
/*      */     //   Java source line #499	-> byte code offset #4
/*      */     //   Java source line #500	-> byte code offset #12
/*      */     //   Java source line #503	-> byte code offset #65
/*      */     //   Java source line #504	-> byte code offset #73
/*      */     //   Java source line #506	-> byte code offset #111
/*      */     //   Java source line #510	-> byte code offset #122
/*      */     //   Java source line #511	-> byte code offset #128
/*      */     //   Java source line #513	-> byte code offset #135
/*      */     //   Java source line #515	-> byte code offset #146
/*      */     //   Java source line #516	-> byte code offset #153
/*      */     //   Java source line #517	-> byte code offset #159
/*      */     //   Java source line #521	-> byte code offset #175
/*      */     //   Java source line #522	-> byte code offset #183
/*      */     //   Java source line #523	-> byte code offset #189
/*      */     //   Java source line #527	-> byte code offset #195
/*      */     //   Java source line #528	-> byte code offset #198
/*      */     //   Java source line #532	-> byte code offset #201
/*      */     //   Java source line #535	-> byte code offset #210
/*      */     //   Java source line #538	-> byte code offset #251
/*      */     //   Java source line #539	-> byte code offset #258
/*      */     //   Java source line #541	-> byte code offset #272
/*      */     //   Java source line #543	-> byte code offset #281
/*      */     //   Java source line #544	-> byte code offset #305
/*      */     //   Java source line #546	-> byte code offset #312
/*      */     //   Java source line #550	-> byte code offset #332
/*      */     //   Java source line #551	-> byte code offset #354
/*      */     //   Java source line #552	-> byte code offset #367
/*      */     //   Java source line #553	-> byte code offset #373
/*      */     //   Java source line #557	-> byte code offset #384
/*      */     //   Java source line #561	-> byte code offset #391
/*      */     //   Java source line #563	-> byte code offset #429
/*      */     //   Java source line #567	-> byte code offset #433
/*      */     //   Java source line #568	-> byte code offset #438
/*      */     //   Java source line #570	-> byte code offset #443
/*      */     //   Java source line #571	-> byte code offset #448
/*      */     //   Java source line #575	-> byte code offset #453
/*      */     //   Java source line #576	-> byte code offset #458
/*      */     //   Java source line #580	-> byte code offset #507
/*      */     //   Java source line #583	-> byte code offset #512
/*      */     //   Java source line #581	-> byte code offset #515
/*      */     //   Java source line #583	-> byte code offset #517
/*      */     //   Java source line #567	-> byte code offset #520
/*      */     //   Java source line #568	-> byte code offset #527
/*      */     //   Java source line #570	-> byte code offset #532
/*      */     //   Java source line #571	-> byte code offset #537
/*      */     //   Java source line #575	-> byte code offset #542
/*      */     //   Java source line #576	-> byte code offset #547
/*      */     //   Java source line #579	-> byte code offset #599
/*      */     //   Java source line #580	-> byte code offset #601
/*      */     //   Java source line #583	-> byte code offset #606
/*      */     //   Java source line #581	-> byte code offset #609
/*      */     //   Java source line #583	-> byte code offset #611
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	614	0	this	SlaveServer
/*      */     //   0	614	1	filename	String
/*      */     //   0	614	2	type	String
/*      */     //   0	614	3	load	String
/*      */     //   2	65	4	serviceUrl	String
/*      */     //   71	45	5	urlString	String
/*      */     //   120	423	6	putMethod	org.apache.commons.httpclient.methods.PutMethod
/*      */     //   126	3	7	fileObject	org.apache.commons.vfs.FileObject
/*      */     //   133	469	8	fis	java.io.InputStream
/*      */     //   144	5	9	entity	RequestEntity
/*      */     //   181	21	10	client	HttpClient
/*      */     //   196	342	11	inputStream	java.io.InputStream
/*      */     //   199	329	12	bufferedInputStream	java.io.BufferedInputStream
/*      */     //   208	105	13	result	int
/*      */     //   279	106	14	bodyBuffer	StringBuffer
/*      */     //   287	9	15	c	int
/*      */     //   310	35	16	bodyTmp	String
/*      */     //   352	9	17	message	String
/*      */     //   389	41	17	body	String
/*      */     //   365	153	18	webResult	WebResult
/*      */     //   515	3	19	ignored	java.io.IOException
/*      */     //   520	77	20	localObject1	Object
/*      */     //   599	13	21	localObject2	Object
/*      */     //   609	3	22	ignored	java.io.IOException
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   507	512	515	java/io/IOException
/*      */     //   201	433	520	finally
/*      */     //   520	522	520	finally
/*      */     //   135	507	599	finally
/*      */     //   520	601	599	finally
/*      */     //   601	606	609	java/io/IOException
/*      */   }
/*      */   
/*      */   public void addProxy(HttpClient client)
/*      */   {
/*  589 */     String host = environmentSubstitute(this.hostname);
/*  590 */     String phost = environmentSubstitute(this.proxyHostname);
/*  591 */     String pport = environmentSubstitute(this.proxyPort);
/*  592 */     String nonprox = environmentSubstitute(this.nonProxyHosts);
/*      */     
/*      */ 
/*      */ 
/*  596 */     if ((!Const.isEmpty(phost)) && (!Const.isEmpty(pport)))
/*      */     {
/*      */ 
/*  599 */       if ((!Const.isEmpty(nonprox)) && (!Const.isEmpty(host)) && (host.matches(nonprox)))
/*      */       {
/*  601 */         return;
/*      */       }
/*  603 */       client.getHostConfiguration().setProxy(phost, Integer.parseInt(pport));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void addCredentials(HttpClient client)
/*      */   {
/*  610 */     if (StringUtils.isEmpty(this.webAppName)) {
/*  611 */       client.getState().setCredentials(new AuthScope(environmentSubstitute(this.hostname), Const.toInt(environmentSubstitute(this.port), 80), "Kettle"), new UsernamePasswordCredentials(environmentSubstitute(this.username), Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password))));
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  617 */       Credentials creds = new UsernamePasswordCredentials(environmentSubstitute(this.username), Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password)));
/*  618 */       client.getState().setCredentials(AuthScope.ANY, creds);
/*  619 */       client.getParams().setAuthenticationPreemptive(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMaster()
/*      */   {
/*  628 */     return this.master;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaster(boolean master)
/*      */   {
/*  636 */     this.master = master;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public synchronized String execService(String service)
/*      */     throws Exception
/*      */   {
/*      */     // Byte code:
/*      */     //   0: invokestatic 96	org/pentaho/di/cluster/SlaveConnectionManager:getInstance	()Lorg/pentaho/di/cluster/SlaveConnectionManager;
/*      */     //   3: invokevirtual 97	org/pentaho/di/cluster/SlaveConnectionManager:createHttpClient	()Lorg/apache/commons/httpclient/HttpClient;
/*      */     //   6: astore_2
/*      */     //   7: aload_0
/*      */     //   8: aload_2
/*      */     //   9: invokevirtual 98	org/pentaho/di/cluster/SlaveServer:addCredentials	(Lorg/apache/commons/httpclient/HttpClient;)V
/*      */     //   12: aload_0
/*      */     //   13: aload_2
/*      */     //   14: invokevirtual 99	org/pentaho/di/cluster/SlaveServer:addProxy	(Lorg/apache/commons/httpclient/HttpClient;)V
/*      */     //   17: new 162	org/apache/commons/httpclient/methods/GetMethod
/*      */     //   20: dup
/*      */     //   21: aload_0
/*      */     //   22: aload_1
/*      */     //   23: invokevirtual 76	org/pentaho/di/cluster/SlaveServer:constructUrl	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   26: invokespecial 163	org/apache/commons/httpclient/methods/GetMethod:<init>	(Ljava/lang/String;)V
/*      */     //   29: astore_3
/*      */     //   30: aconst_null
/*      */     //   31: astore 4
/*      */     //   33: aconst_null
/*      */     //   34: astore 5
/*      */     //   36: aload_2
/*      */     //   37: aload_3
/*      */     //   38: invokevirtual 100	org/apache/commons/httpclient/HttpClient:executeMethod	(Lorg/apache/commons/httpclient/HttpMethod;)I
/*      */     //   41: istore 6
/*      */     //   43: aload_0
/*      */     //   44: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   47: invokeinterface 77 1 0
/*      */     //   52: ifeq +32 -> 84
/*      */     //   55: aload_0
/*      */     //   56: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   59: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   62: ldc 101
/*      */     //   64: iconst_1
/*      */     //   65: anewarray 46	java/lang/String
/*      */     //   68: dup
/*      */     //   69: iconst_0
/*      */     //   70: iload 6
/*      */     //   72: invokestatic 102	java/lang/Integer:toString	(I)Ljava/lang/String;
/*      */     //   75: aastore
/*      */     //   76: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   79: invokeinterface 81 2 0
/*      */     //   84: aload_3
/*      */     //   85: invokeinterface 164 1 0
/*      */     //   90: astore 4
/*      */     //   92: new 104	java/io/BufferedInputStream
/*      */     //   95: dup
/*      */     //   96: aload 4
/*      */     //   98: sipush 1000
/*      */     //   101: invokespecial 105	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;I)V
/*      */     //   104: astore 5
/*      */     //   106: new 40	java/lang/StringBuffer
/*      */     //   109: dup
/*      */     //   110: invokespecial 41	java/lang/StringBuffer:<init>	()V
/*      */     //   113: astore 7
/*      */     //   115: aload 5
/*      */     //   117: invokevirtual 106	java/io/BufferedInputStream:read	()I
/*      */     //   120: dup
/*      */     //   121: istore 8
/*      */     //   123: iconst_m1
/*      */     //   124: if_icmpeq +15 -> 139
/*      */     //   127: aload 7
/*      */     //   129: iload 8
/*      */     //   131: i2c
/*      */     //   132: invokevirtual 107	java/lang/StringBuffer:append	(C)Ljava/lang/StringBuffer;
/*      */     //   135: pop
/*      */     //   136: goto -21 -> 115
/*      */     //   139: aload 7
/*      */     //   141: invokevirtual 51	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   144: astore 9
/*      */     //   146: aload_0
/*      */     //   147: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   150: invokeinterface 118 1 0
/*      */     //   155: ifeq +36 -> 191
/*      */     //   158: aload_0
/*      */     //   159: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   162: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   165: ldc -91
/*      */     //   167: iconst_1
/*      */     //   168: anewarray 46	java/lang/String
/*      */     //   171: dup
/*      */     //   172: iconst_0
/*      */     //   173: aload 9
/*      */     //   175: invokevirtual 166	java/lang/String:getBytes	()[B
/*      */     //   178: arraylength
/*      */     //   179: invokestatic 102	java/lang/Integer:toString	(I)Ljava/lang/String;
/*      */     //   182: aastore
/*      */     //   183: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   186: invokeinterface 120 2 0
/*      */     //   191: aload_0
/*      */     //   192: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   195: invokeinterface 77 1 0
/*      */     //   200: ifeq +29 -> 229
/*      */     //   203: aload_0
/*      */     //   204: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   207: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   210: ldc 114
/*      */     //   212: iconst_1
/*      */     //   213: anewarray 46	java/lang/String
/*      */     //   216: dup
/*      */     //   217: iconst_0
/*      */     //   218: aload 9
/*      */     //   220: aastore
/*      */     //   221: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   224: invokeinterface 81 2 0
/*      */     //   229: aload 9
/*      */     //   231: astore 10
/*      */     //   233: aload 5
/*      */     //   235: ifnull +8 -> 243
/*      */     //   238: aload 5
/*      */     //   240: invokevirtual 115	java/io/BufferedInputStream:close	()V
/*      */     //   243: aload 4
/*      */     //   245: ifnull +8 -> 253
/*      */     //   248: aload 4
/*      */     //   250: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   253: aload_3
/*      */     //   254: invokeinterface 167 1 0
/*      */     //   259: aload_0
/*      */     //   260: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   263: invokeinterface 118 1 0
/*      */     //   268: ifeq +35 -> 303
/*      */     //   271: aload_0
/*      */     //   272: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   275: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   278: ldc -88
/*      */     //   280: iconst_2
/*      */     //   281: anewarray 46	java/lang/String
/*      */     //   284: dup
/*      */     //   285: iconst_0
/*      */     //   286: aload_1
/*      */     //   287: aastore
/*      */     //   288: dup
/*      */     //   289: iconst_1
/*      */     //   290: aload_0
/*      */     //   291: getfield 17	org/pentaho/di/cluster/SlaveServer:hostname	Ljava/lang/String;
/*      */     //   294: aastore
/*      */     //   295: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   298: invokeinterface 120 2 0
/*      */     //   303: aload 10
/*      */     //   305: areturn
/*      */     //   306: astore 11
/*      */     //   308: aload 5
/*      */     //   310: ifnull +8 -> 318
/*      */     //   313: aload 5
/*      */     //   315: invokevirtual 115	java/io/BufferedInputStream:close	()V
/*      */     //   318: aload 4
/*      */     //   320: ifnull +8 -> 328
/*      */     //   323: aload 4
/*      */     //   325: invokevirtual 116	java/io/InputStream:close	()V
/*      */     //   328: aload_3
/*      */     //   329: invokeinterface 167 1 0
/*      */     //   334: aload_0
/*      */     //   335: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   338: invokeinterface 118 1 0
/*      */     //   343: ifeq +35 -> 378
/*      */     //   346: aload_0
/*      */     //   347: getfield 10	org/pentaho/di/cluster/SlaveServer:log	Lorg/pentaho/di/core/logging/LogChannelInterface;
/*      */     //   350: getstatic 78	org/pentaho/di/cluster/SlaveServer:PKG	Ljava/lang/Class;
/*      */     //   353: ldc -88
/*      */     //   355: iconst_2
/*      */     //   356: anewarray 46	java/lang/String
/*      */     //   359: dup
/*      */     //   360: iconst_0
/*      */     //   361: aload_1
/*      */     //   362: aastore
/*      */     //   363: dup
/*      */     //   364: iconst_1
/*      */     //   365: aload_0
/*      */     //   366: getfield 17	org/pentaho/di/cluster/SlaveServer:hostname	Ljava/lang/String;
/*      */     //   369: aastore
/*      */     //   370: invokestatic 80	org/pentaho/di/i18n/BaseMessages:getString	(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
/*      */     //   373: invokeinterface 120 2 0
/*      */     //   378: aload 11
/*      */     //   380: athrow
/*      */     // Line number table:
/*      */     //   Java source line #643	-> byte code offset #0
/*      */     //   Java source line #644	-> byte code offset #7
/*      */     //   Java source line #645	-> byte code offset #12
/*      */     //   Java source line #646	-> byte code offset #17
/*      */     //   Java source line #650	-> byte code offset #30
/*      */     //   Java source line #651	-> byte code offset #33
/*      */     //   Java source line #655	-> byte code offset #36
/*      */     //   Java source line #658	-> byte code offset #43
/*      */     //   Java source line #662	-> byte code offset #84
/*      */     //   Java source line #663	-> byte code offset #92
/*      */     //   Java source line #665	-> byte code offset #106
/*      */     //   Java source line #667	-> byte code offset #115
/*      */     //   Java source line #669	-> byte code offset #139
/*      */     //   Java source line #671	-> byte code offset #146
/*      */     //   Java source line #672	-> byte code offset #191
/*      */     //   Java source line #674	-> byte code offset #229
/*      */     //   Java source line #678	-> byte code offset #233
/*      */     //   Java source line #679	-> byte code offset #238
/*      */     //   Java source line #681	-> byte code offset #243
/*      */     //   Java source line #682	-> byte code offset #248
/*      */     //   Java source line #686	-> byte code offset #253
/*      */     //   Java source line #687	-> byte code offset #259
/*      */     //   Java source line #678	-> byte code offset #306
/*      */     //   Java source line #679	-> byte code offset #313
/*      */     //   Java source line #681	-> byte code offset #318
/*      */     //   Java source line #682	-> byte code offset #323
/*      */     //   Java source line #686	-> byte code offset #328
/*      */     //   Java source line #687	-> byte code offset #334
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	381	0	this	SlaveServer
/*      */     //   0	381	1	service	String
/*      */     //   6	31	2	client	HttpClient
/*      */     //   29	300	3	method	org.apache.commons.httpclient.HttpMethod
/*      */     //   31	293	4	inputStream	java.io.InputStream
/*      */     //   34	280	5	bufferedInputStream	java.io.BufferedInputStream
/*      */     //   41	30	6	result	int
/*      */     //   113	27	7	bodyBuffer	StringBuffer
/*      */     //   121	9	8	c	int
/*      */     //   144	86	9	body	String
/*      */     //   231	73	10	str1	String
/*      */     //   306	73	11	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   36	233	306	finally
/*      */     //   306	308	306	finally
/*      */   }
/*      */   
/*      */   public SlaveServerStatus getStatus()
/*      */     throws Exception
/*      */   {
/*  694 */     String xml = execService("/kettle/status/?xml=Y");
/*  695 */     return SlaveServerStatus.fromXML(xml);
/*      */   }
/*      */   
/*      */   public List<SlaveServerDetection> getSlaveServerDetections() throws Exception
/*      */   {
/*  700 */     String xml = execService("/kettle/getSlaves/");
/*  701 */     Document document = XMLHandler.loadXMLString(xml);
/*  702 */     Node detectionsNode = XMLHandler.getSubNode(document, "SlaveServerDetections");
/*  703 */     int nrDetections = XMLHandler.countNodes(detectionsNode, "SlaveServerDetection");
/*      */     
/*  705 */     List<SlaveServerDetection> detections = new ArrayList();
/*  706 */     for (int i = 0; i < nrDetections; i++) {
/*  707 */       Node detectionNode = XMLHandler.getSubNodeByNr(detectionsNode, "SlaveServerDetection", i);
/*  708 */       SlaveServerDetection detection = new SlaveServerDetection(detectionNode);
/*  709 */       detections.add(detection);
/*      */     }
/*  711 */     return detections;
/*      */   }
/*      */   
/*      */   public SlaveServerTransStatus getTransStatus(String transName, String carteObjectId, int startLogLineNr) throws Exception
/*      */   {
/*  716 */     String xml = execService("/kettle/transStatus/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y&from=" + startLogLineNr);
/*  717 */     return SlaveServerTransStatus.fromXML(xml);
/*      */   }
/*      */   
/*      */   public SlaveServerJobStatus getJobStatus(String jobName, String carteObjectId, int startLogLineNr) throws Exception
/*      */   {
/*  722 */     String xml = execService("/kettle/jobStatus/?name=" + URLEncoder.encode(jobName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y&from=" + startLogLineNr);
/*  723 */     return SlaveServerJobStatus.fromXML(xml);
/*      */   }
/*      */   
/*      */   public WebResult stopTransformation(String transName, String carteObjectId) throws Exception
/*      */   {
/*  728 */     String xml = execService("/kettle/stopTrans/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y");
/*  729 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult pauseResumeTransformation(String transName, String carteObjectId) throws Exception
/*      */   {
/*  734 */     String xml = execService("/kettle/pauseTrans/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y");
/*  735 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult removeTransformation(String transName, String carteObjectId) throws Exception
/*      */   {
/*  740 */     String xml = execService("/kettle/removeTrans/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y");
/*  741 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult removeJob(String jobName, String carteObjectId) throws Exception
/*      */   {
/*  746 */     String xml = execService("/kettle/removeJob/?name=" + URLEncoder.encode(jobName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y");
/*  747 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult stopJob(String transName, String carteObjectId) throws Exception
/*      */   {
/*  752 */     String xml = execService("/kettle/stopJob/?name=" + URLEncoder.encode(transName, "UTF-8") + "&xml=Y&id=" + Const.NVL(carteObjectId, ""));
/*  753 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult startTransformation(String transName, String carteObjectId) throws Exception
/*      */   {
/*  758 */     String xml = execService("/kettle/startTrans/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y");
/*  759 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult startJob(String jobName, String carteObjectId) throws Exception
/*      */   {
/*  764 */     String xml = execService("/kettle/startJob/?name=" + URLEncoder.encode(jobName, "UTF-8") + "&xml=Y&id=" + Const.NVL(carteObjectId, ""));
/*  765 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public WebResult cleanupTransformation(String transName, String carteObjectId) throws Exception
/*      */   {
/*  770 */     String xml = execService("/kettle/cleanupTrans/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(carteObjectId, "") + "&xml=Y");
/*  771 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public synchronized WebResult deAllocateServerSockets(String transName, String clusteredRunId) throws Exception
/*      */   {
/*  776 */     String xml = execService("/kettle/cleanupTrans/?name=" + URLEncoder.encode(transName, "UTF-8") + "&id=" + Const.NVL(clusteredRunId, "") + "&xml=Y&sockets=Y");
/*  777 */     return WebResult.fromXMLString(xml);
/*      */   }
/*      */   
/*      */   public static SlaveServer findSlaveServer(List<SlaveServer> slaveServers, String name) {
/*      */     SlaveServer slaveServer;
/*  782 */     for (Iterator i$ = slaveServers.iterator(); i$.hasNext(); 
/*      */         
/*  784 */         return slaveServer)
/*      */     {
/*  782 */       slaveServer = (SlaveServer)i$.next();
/*      */       
/*  784 */       if ((slaveServer.getName() == null) || (!slaveServer.getName().equalsIgnoreCase(name))) {}
/*      */     }
/*  786 */     return null;
/*      */   }
/*      */   
/*      */   public static SlaveServer findSlaveServer(List<SlaveServer> slaveServers, ObjectId id) {
/*      */     SlaveServer slaveServer;
/*  791 */     for (Iterator i$ = slaveServers.iterator(); i$.hasNext(); 
/*      */         
/*  793 */         return slaveServer)
/*      */     {
/*  791 */       slaveServer = (SlaveServer)i$.next();
/*      */       
/*  793 */       if ((slaveServer.getObjectId() == null) || (!slaveServer.getObjectId().equals(id))) {}
/*      */     }
/*  795 */     return null;
/*      */   }
/*      */   
/*      */   public static String[] getSlaveServerNames(List<SlaveServer> slaveServers)
/*      */   {
/*  800 */     String[] names = new String[slaveServers.size()];
/*  801 */     for (int i = 0; i < slaveServers.size(); i++)
/*      */     {
/*  803 */       SlaveServer slaveServer = (SlaveServer)slaveServers.get(i);
/*  804 */       names[i] = slaveServer.getName();
/*      */     }
/*  806 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized int allocateServerSocket(String runId, int portRangeStart, String hostname, String transformationName, String sourceSlaveName, String sourceStepName, String sourceStepCopy, String targetSlaveName, String targetStepName, String targetStepCopy)
/*      */     throws Exception
/*      */   {
/*  814 */     InetAddress inetAddress = InetAddress.getByName(hostname);
/*  815 */     String address = inetAddress.getHostAddress();
/*      */     
/*  817 */     String service = "/kettle/allocateSocket/?";
/*  818 */     service = service + "rangeStart=" + Integer.toString(portRangeStart);
/*  819 */     service = service + "&id=" + URLEncoder.encode(runId, "UTF-8");
/*  820 */     service = service + "&host=" + address;
/*  821 */     service = service + "&trans=" + URLEncoder.encode(transformationName, "UTF-8");
/*  822 */     service = service + "&sourceSlave=" + URLEncoder.encode(sourceSlaveName, "UTF-8");
/*  823 */     service = service + "&sourceStep=" + URLEncoder.encode(sourceStepName, "UTF-8");
/*  824 */     service = service + "&sourceCopy=" + URLEncoder.encode(sourceStepCopy, "UTF-8");
/*  825 */     service = service + "&targetSlave=" + URLEncoder.encode(targetSlaveName, "UTF-8");
/*  826 */     service = service + "&targetStep=" + URLEncoder.encode(targetStepName, "UTF-8");
/*  827 */     service = service + "&targetCopy=" + URLEncoder.encode(targetStepCopy, "UTF-8");
/*  828 */     service = service + "&xml=Y";
/*  829 */     String xml = execService(service);
/*  830 */     Document doc = XMLHandler.loadXMLString(xml);
/*  831 */     String portString = XMLHandler.getTagValue(doc, "port");
/*      */     
/*  833 */     int port = Const.toInt(portString, -1);
/*  834 */     if (port < 0) {
/*  835 */       throw new Exception("Unable to retrieve port from service : " + service + ", received : \n" + xml);
/*      */     }
/*      */     
/*  838 */     return port;
/*      */   }
/*      */   
/*      */   public String getName()
/*      */   {
/*  843 */     return this.name;
/*      */   }
/*      */   
/*      */   public void setName(String name)
/*      */   {
/*  848 */     this.name = name;
/*      */   }
/*      */   
/*      */   public boolean isShared()
/*      */   {
/*  853 */     return this.shared;
/*      */   }
/*      */   
/*      */   public void setShared(boolean shared)
/*      */   {
/*  858 */     this.shared = shared;
/*      */   }
/*      */   
/*      */   public void copyVariablesFrom(VariableSpace space)
/*      */   {
/*  863 */     this.variables.copyVariablesFrom(space);
/*      */   }
/*      */   
/*      */   public String environmentSubstitute(String aString)
/*      */   {
/*  868 */     return this.variables.environmentSubstitute(aString);
/*      */   }
/*      */   
/*      */   public String[] environmentSubstitute(String[] aString)
/*      */   {
/*  873 */     return this.variables.environmentSubstitute(aString);
/*      */   }
/*      */   
/*      */   public VariableSpace getParentVariableSpace()
/*      */   {
/*  878 */     return this.variables.getParentVariableSpace();
/*      */   }
/*      */   
/*      */   public void setParentVariableSpace(VariableSpace parent)
/*      */   {
/*  883 */     this.variables.setParentVariableSpace(parent);
/*      */   }
/*      */   
/*      */   public String getVariable(String variableName, String defaultValue)
/*      */   {
/*  888 */     return this.variables.getVariable(variableName, defaultValue);
/*      */   }
/*      */   
/*      */   public String getVariable(String variableName)
/*      */   {
/*  893 */     return this.variables.getVariable(variableName);
/*      */   }
/*      */   
/*      */   public boolean getBooleanValueOfVariable(String variableName, boolean defaultValue) {
/*  897 */     if (!Const.isEmpty(variableName))
/*      */     {
/*  899 */       String value = environmentSubstitute(variableName);
/*  900 */       if (!Const.isEmpty(value))
/*      */       {
/*  902 */         return ValueMeta.convertStringToBoolean(value).booleanValue();
/*      */       }
/*      */     }
/*  905 */     return defaultValue;
/*      */   }
/*      */   
/*      */   public void initializeVariablesFrom(VariableSpace parent)
/*      */   {
/*  910 */     this.variables.initializeVariablesFrom(parent);
/*      */   }
/*      */   
/*      */   public String[] listVariables()
/*      */   {
/*  915 */     return this.variables.listVariables();
/*      */   }
/*      */   
/*      */   public void setVariable(String variableName, String variableValue)
/*      */   {
/*  920 */     this.variables.setVariable(variableName, variableValue);
/*      */   }
/*      */   
/*      */   public void shareVariablesWith(VariableSpace space)
/*      */   {
/*  925 */     this.variables = space;
/*      */   }
/*      */   
/*      */   public void injectVariables(Map<String, String> prop)
/*      */   {
/*  930 */     this.variables.injectVariables(prop);
/*      */   }
/*      */   
/*      */   public ObjectId getObjectId() {
/*  934 */     return this.id;
/*      */   }
/*      */   
/*      */   public void setObjectId(ObjectId id) {
/*  938 */     this.id = id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public RepositoryDirectoryInterface getRepositoryDirectory()
/*      */   {
/*  945 */     return new RepositoryDirectory();
/*      */   }
/*      */   
/*      */   public void setRepositoryDirectory(RepositoryDirectoryInterface repositoryDirectory) {
/*  949 */     throw new RuntimeException("Setting a directory on a database connection is not supported");
/*      */   }
/*      */   
/*      */   public RepositoryObjectType getRepositoryElementType() {
/*  953 */     return REPOSITORY_ELEMENT_TYPE;
/*      */   }
/*      */   
/*      */   public ObjectRevision getObjectRevision() {
/*  957 */     return this.objectRevision;
/*      */   }
/*      */   
/*      */   public void setObjectRevision(ObjectRevision objectRevision) {
/*  961 */     this.objectRevision = objectRevision;
/*      */   }
/*      */   
/*      */   public String getDescription() {
/*  965 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDescription(String description) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String sniffStep(String transName, String stepName, String copyNr, int lines, String type)
/*      */     throws Exception
/*      */   {
/*  983 */     String xml = execService("/kettle/sniffStep/?trans=" + URLEncoder.encode(transName, "UTF-8") + "&step=" + URLEncoder.encode(stepName, "UTF-8") + "&copynr=" + copyNr + "&type=" + type + "&lines=" + lines + "&xml=Y");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  990 */     return xml;
/*      */   }
/*      */   
/*      */   public long getNextSlaveSequenceValue(String slaveSequenceName, long incrementValue) throws KettleException {
/*      */     try {
/*  995 */       String xml = execService("/kettle/nextSequence/?name=" + URLEncoder.encode(slaveSequenceName, "UTF-8") + "&" + "increment" + "=" + Long.toString(incrementValue));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1000 */       Document doc = XMLHandler.loadXMLString(xml);
/* 1001 */       Node seqNode = XMLHandler.getSubNode(doc, "seq");
/* 1002 */       String nextValueString = XMLHandler.getTagValue(seqNode, "value");
/* 1003 */       String errorString = XMLHandler.getTagValue(seqNode, "error");
/*      */       
/* 1005 */       if (!Const.isEmpty(errorString)) {
/* 1006 */         throw new KettleException(errorString);
/*      */       }
/* 1008 */       if (Const.isEmpty(nextValueString)) {
/* 1009 */         throw new KettleException("No value retrieved from slave sequence '" + slaveSequenceName + "' on slave " + toString());
/*      */       }
/* 1011 */       long nextValue = Const.toLong(nextValueString, Long.MIN_VALUE);
/* 1012 */       if (nextValue == Long.MIN_VALUE) {
/* 1013 */         throw new KettleException("Incorrect value '" + nextValueString + "' retrieved from slave sequence '" + slaveSequenceName + "' on slave " + toString());
/*      */       }
/*      */       
/* 1016 */       return nextValue;
/*      */     } catch (Exception e) {
/* 1018 */       throw new KettleException("There was a problem retrieving a next sequence value from slave sequence '" + slaveSequenceName + "' on slave " + toString(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Date getChangedDate()
/*      */   {
/* 1026 */     return this.changedDate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setChangedDate(Date changedDate)
/*      */   {
/* 1033 */     this.changedDate = changedDate;
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\cluster\SlaveServer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */