/*     */ package org.pentaho.di.core.undo;
/*     */ 
/*     */ import org.pentaho.di.core.NotePadMeta;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.gui.Point;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobHopMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryCopy;
/*     */ import org.pentaho.di.trans.TransHopMeta;
/*     */ import org.pentaho.di.trans.step.StepMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransAction
/*     */ {
/*  54 */   private static Class<?> PKG = TransAction.class;
/*     */   
/*     */   public static final int TYPE_ACTION_NONE = 0;
/*     */   
/*     */   public static final int TYPE_ACTION_CHANGE_STEP = 1;
/*     */   
/*     */   public static final int TYPE_ACTION_CHANGE_CONNECTION = 2;
/*     */   
/*     */   public static final int TYPE_ACTION_CHANGE_HOP = 3;
/*     */   
/*     */   public static final int TYPE_ACTION_CHANGE_NOTE = 4;
/*     */   
/*     */   public static final int TYPE_ACTION_NEW_STEP = 5;
/*     */   
/*     */   public static final int TYPE_ACTION_NEW_CONNECTION = 6;
/*     */   
/*     */   public static final int TYPE_ACTION_NEW_HOP = 7;
/*     */   public static final int TYPE_ACTION_NEW_NOTE = 8;
/*     */   public static final int TYPE_ACTION_DELETE_STEP = 9;
/*     */   public static final int TYPE_ACTION_DELETE_CONNECTION = 10;
/*     */   public static final int TYPE_ACTION_DELETE_HOP = 11;
/*     */   public static final int TYPE_ACTION_DELETE_NOTE = 12;
/*     */   public static final int TYPE_ACTION_POSITION_STEP = 13;
/*     */   public static final int TYPE_ACTION_POSITION_NOTE = 14;
/*     */   public static final int TYPE_ACTION_CHANGE_JOB_ENTRY = 15;
/*     */   public static final int TYPE_ACTION_CHANGE_JOB_HOP = 16;
/*     */   public static final int TYPE_ACTION_NEW_JOB_ENTRY = 17;
/*     */   public static final int TYPE_ACTION_NEW_JOB_HOP = 18;
/*     */   public static final int TYPE_ACTION_DELETE_JOB_ENTRY = 19;
/*     */   public static final int TYPE_ACTION_DELETE_JOB_HOP = 20;
/*     */   public static final int TYPE_ACTION_POSITION_JOB_ENTRY = 21;
/*     */   public static final int TYPE_ACTION_CHANGE_TABLEITEM = 22;
/*     */   public static final int TYPE_ACTION_NEW_TABLEITEM = 23;
/*     */   public static final int TYPE_ACTION_DELETE_TABLEITEM = 24;
/*     */   public static final int TYPE_ACTION_POSITION_TABLEITEM = 25;
/*     */   public static final int TYPE_ACTION_CHANGE_TABLE = 26;
/*     */   public static final int TYPE_ACTION_CHANGE_RELATIONSHIP = 27;
/*     */   public static final int TYPE_ACTION_NEW_TABLE = 28;
/*     */   public static final int TYPE_ACTION_NEW_RELATIONSHIP = 29;
/*     */   public static final int TYPE_ACTION_DELETE_TABLE = 30;
/*     */   public static final int TYPE_ACTION_DELETE_RELATIONSHIP = 31;
/*     */   public static final int TYPE_ACTION_POSITION_TABLE = 32;
/*     */   public static final int TYPE_ACTION_NEW_SLAVE = 33;
/*     */   public static final int TYPE_ACTION_CHANGE_SLAVE = 34;
/*     */   public static final int TYPE_ACTION_DELETE_SLAVE = 35;
/*     */   public static final int TYPE_ACTION_NEW_CLUSTER = 36;
/*     */   public static final int TYPE_ACTION_CHANGE_CLUSTER = 37;
/*     */   public static final int TYPE_ACTION_DELETE_CLUSTER = 38;
/*     */   public static final int TYPE_ACTION_NEW_PARTITION = 39;
/*     */   public static final int TYPE_ACTION_CHANGE_PARTITION = 40;
/*     */   public static final int TYPE_ACTION_DELETE_PARTITION = 41;
/* 105 */   public static final String[] desc_action = { "", BaseMessages.getString(PKG, "TransAction.label.ChangeStep", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeConnection", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeHop", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeNote", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewStep", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewConnection", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewHop", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewNote", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteStep", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteConnection", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteHop", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteNote", new String[0]), BaseMessages.getString(PKG, "TransAction.label.PositionStep", new String[0]), BaseMessages.getString(PKG, "TransAction.label.PositionNote", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeJobEntry", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeJobHop", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewJobEntry", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewJobHop", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteJobEntry", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteJobHop", new String[0]), BaseMessages.getString(PKG, "TransAction.label.PositionJobEntry", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeTableRow", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewTableRow", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteTableRow", new String[0]), BaseMessages.getString(PKG, "TransAction.label.PositionTableRow", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeTable", new String[0]), BaseMessages.getString(PKG, "TransAction.label.ChangeRelationship", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewTable", new String[0]), BaseMessages.getString(PKG, "TransAction.label.NewRelationship", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteTable", new String[0]), BaseMessages.getString(PKG, "TransAction.label.DeleteRelationship", new String[0]), BaseMessages.getString(PKG, "TransAction.label.PositionTable", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */   private int type;
/*     */   
/*     */ 
/*     */ 
/*     */   private Object[] previous;
/*     */   
/*     */ 
/*     */ 
/*     */   private Point[] previous_location;
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] previous_index;
/*     */   
/*     */ 
/*     */   private Object[] current;
/*     */   
/*     */ 
/*     */   private Point[] current_location;
/*     */   
/*     */ 
/*     */   private int[] current_index;
/*     */   
/*     */ 
/*     */   private boolean nextAlso;
/*     */   
/*     */ 
/*     */ 
/*     */   public TransAction()
/*     */   {
/* 139 */     this.type = 0;
/*     */   }
/*     */   
/*     */   public void setDelete(Object[] prev, int[] idx)
/*     */   {
/* 144 */     this.current = prev;
/* 145 */     this.current_index = idx;
/*     */     
/* 147 */     if ((prev[0] instanceof StepMeta)) this.type = 9;
/* 148 */     if ((prev[0] instanceof DatabaseMeta)) this.type = 10;
/* 149 */     if ((prev[0] instanceof TransHopMeta)) this.type = 11;
/* 150 */     if ((prev[0] instanceof NotePadMeta)) this.type = 12;
/* 151 */     if ((prev[0] instanceof JobEntryCopy)) this.type = 19;
/* 152 */     if ((prev[0] instanceof JobHopMeta)) this.type = 20;
/* 153 */     if ((prev[0] instanceof String[])) this.type = 24;
/*     */   }
/*     */   
/*     */   public void setChanged(Object[] prev, Object[] curr, int[] idx)
/*     */   {
/* 158 */     this.previous = prev;
/* 159 */     this.current = curr;
/* 160 */     this.current_index = idx;
/* 161 */     this.previous_index = idx;
/*     */     
/* 163 */     if ((prev[0] instanceof StepMeta)) this.type = 1;
/* 164 */     if ((prev[0] instanceof DatabaseMeta)) this.type = 2;
/* 165 */     if ((prev[0] instanceof TransHopMeta)) this.type = 3;
/* 166 */     if ((prev[0] instanceof NotePadMeta)) this.type = 4;
/* 167 */     if ((prev[0] instanceof JobEntryCopy)) this.type = 15;
/* 168 */     if ((prev[0] instanceof JobHopMeta)) this.type = 16;
/* 169 */     if ((prev[0] instanceof String[])) this.type = 22;
/*     */   }
/*     */   
/*     */   public void setNew(Object[] prev, int[] position)
/*     */   {
/* 174 */     if (prev.length == 0) { return;
/*     */     }
/* 176 */     this.current = prev;
/* 177 */     this.current_index = position;
/* 178 */     this.previous = null;
/*     */     
/* 180 */     if ((prev[0] instanceof StepMeta)) this.type = 5;
/* 181 */     if ((prev[0] instanceof DatabaseMeta)) this.type = 6;
/* 182 */     if ((prev[0] instanceof TransHopMeta)) this.type = 7;
/* 183 */     if ((prev[0] instanceof NotePadMeta)) this.type = 8;
/* 184 */     if ((prev[0] instanceof JobEntryCopy)) this.type = 17;
/* 185 */     if ((prev[0] instanceof JobHopMeta)) this.type = 18;
/* 186 */     if ((prev[0] instanceof String[])) this.type = 23;
/*     */   }
/*     */   
/*     */   public void setPosition(Object[] obj, int[] idx, Point[] prev, Point[] curr)
/*     */   {
/* 191 */     if (prev.length != curr.length) { return;
/*     */     }
/* 193 */     this.previous_location = new Point[prev.length];
/* 194 */     this.current_location = new Point[curr.length];
/* 195 */     this.current = obj;
/* 196 */     this.current_index = idx;
/*     */     
/* 198 */     for (int i = 0; i < prev.length; i++)
/*     */     {
/* 200 */       this.previous_location[i] = new Point(prev[i].x, prev[i].y);
/* 201 */       this.current_location[i] = new Point(curr[i].x, curr[i].y);
/*     */     }
/*     */     
/* 204 */     Object fobj = obj[0];
/* 205 */     if ((fobj instanceof StepMeta)) this.type = 13;
/* 206 */     if ((fobj instanceof NotePadMeta)) this.type = 14;
/* 207 */     if ((fobj instanceof JobEntryCopy)) this.type = 21;
/*     */   }
/*     */   
/*     */   public void setItemMove(int[] prev, int[] curr)
/*     */   {
/* 212 */     this.previous_location = null;
/* 213 */     this.current_location = null;
/* 214 */     this.current = null;
/* 215 */     this.current_index = curr;
/* 216 */     this.previous = null;
/* 217 */     this.previous_index = prev;
/*     */     
/* 219 */     this.type = 25;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getType()
/*     */   {
/* 226 */     return this.type;
/*     */   }
/*     */   
/*     */   public Object[] getPrevious()
/*     */   {
/* 231 */     return this.previous;
/*     */   }
/*     */   
/*     */   public Object[] getCurrent()
/*     */   {
/* 236 */     return this.current;
/*     */   }
/*     */   
/*     */   public Point[] getPreviousLocation()
/*     */   {
/* 241 */     return this.previous_location;
/*     */   }
/*     */   
/*     */   public Point[] getCurrentLocation()
/*     */   {
/* 246 */     return this.current_location;
/*     */   }
/*     */   
/*     */   public int[] getPreviousIndex()
/*     */   {
/* 251 */     return this.previous_index;
/*     */   }
/*     */   
/*     */   public int[] getCurrentIndex()
/*     */   {
/* 256 */     return this.current_index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNextAlso(boolean nextAlso)
/*     */   {
/* 265 */     this.nextAlso = nextAlso;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getNextAlso()
/*     */   {
/* 274 */     return this.nextAlso;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 279 */     String retval = "";
/* 280 */     if ((this.type < 0) || (this.type >= desc_action.length)) { return TransAction.class.getName();
/*     */     }
/* 282 */     retval = desc_action[this.type];
/*     */     
/* 284 */     if ((this.current != null) && (this.current.length > 1)) { retval = retval + " (x" + this.current.length + ")";
/*     */     }
/* 286 */     return retval;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\undo\TransAction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */