/*     */ package org.pentaho.di.job.entries.msaccessbulkload;
/*     */ 
/*     */ import com.healthmarketscience.jackcess.Database;
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryMSAccessBulkLoad
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  71 */   private static Class<?> PKG = JobEntryMSAccessBulkLoad.class;
/*     */   
/*     */   private boolean add_result_filenames;
/*     */   
/*     */   private boolean include_subfolders;
/*     */   
/*     */   private boolean is_args_from_previous;
/*     */   public String[] source_filefolder;
/*     */   public String[] source_wildcard;
/*     */   public String[] delimiter;
/*     */   public String[] target_Db;
/*     */   public String[] target_table;
/*     */   private String limit;
/*     */   private String success_condition;
/*  85 */   public String SUCCESS_IF_AT_LEAST = "success_when_at_least";
/*  86 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/*  87 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*     */   
/*  89 */   private int NrErrors = 0;
/*  90 */   private int NrSuccess = 0;
/*  91 */   private int NrFilesToProcess = 0;
/*  92 */   private boolean continueProcessing = true;
/*  93 */   int limitFiles = 0;
/*     */   
/*     */   public JobEntryMSAccessBulkLoad(String n)
/*     */   {
/*  97 */     super(n, "");
/*  98 */     this.limit = "10";
/*  99 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/* 100 */     this.add_result_filenames = false;
/* 101 */     this.include_subfolders = false;
/* 102 */     this.source_filefolder = null;
/* 103 */     this.source_wildcard = null;
/* 104 */     this.delimiter = null;
/* 105 */     this.target_Db = null;
/* 106 */     this.target_table = null;
/*     */     
/* 108 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryMSAccessBulkLoad()
/*     */   {
/* 113 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 118 */     JobEntryMSAccessBulkLoad je = (JobEntryMSAccessBulkLoad)super.clone();
/* 119 */     return je;
/*     */   }
/*     */   
/*     */   public void setAddResultFilenames(boolean addtoresultfilenames) {
/* 123 */     this.add_result_filenames = addtoresultfilenames;
/*     */   }
/*     */   
/*     */   public boolean isAddResultFilename() {
/* 127 */     return this.add_result_filenames;
/*     */   }
/*     */   
/*     */   public void setIncludeSubFoders(boolean includeSubfolders) {
/* 131 */     this.include_subfolders = includeSubfolders;
/*     */   }
/*     */   
/*     */   public boolean isIncludeSubFoders() {
/* 135 */     return this.include_subfolders;
/*     */   }
/*     */   
/*     */   public void setArgsFromPrevious(boolean isargsfromprevious) {
/* 139 */     this.is_args_from_previous = isargsfromprevious;
/*     */   }
/*     */   
/*     */   public boolean isArgsFromPrevious() {
/* 143 */     return this.is_args_from_previous;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getXML()
/*     */   {
/* 149 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 151 */     retval.append(super.getXML());
/* 152 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.include_subfolders));
/* 153 */     retval.append("      ").append(XMLHandler.addTagValue("is_args_from_previous", this.is_args_from_previous));
/*     */     
/* 155 */     retval.append("      ").append(XMLHandler.addTagValue("add_result_filenames", this.add_result_filenames));
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("limit", this.limit));
/* 157 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*     */     
/* 159 */     retval.append("      <fields>").append(Const.CR);
/* 160 */     if (this.source_filefolder != null)
/*     */     {
/* 162 */       for (int i = 0; i < this.source_filefolder.length; i++)
/*     */       {
/* 164 */         retval.append("        <field>").append(Const.CR);
/* 165 */         retval.append("          ").append(XMLHandler.addTagValue("source_filefolder", this.source_filefolder[i]));
/* 166 */         retval.append("          ").append(XMLHandler.addTagValue("source_wildcard", this.source_wildcard[i]));
/* 167 */         retval.append("          ").append(XMLHandler.addTagValue("delimiter", this.delimiter[i]));
/* 168 */         retval.append("          ").append(XMLHandler.addTagValue("target_db", this.target_Db[i]));
/* 169 */         retval.append("          ").append(XMLHandler.addTagValue("target_table", this.target_table[i]));
/* 170 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 173 */     retval.append("      </fields>").append(Const.CR);
/* 174 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 181 */       super.loadXML(entrynode, databases, slaveServers);
/* 182 */       this.include_subfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/* 183 */       this.add_result_filenames = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_result_filenames"));
/* 184 */       this.is_args_from_previous = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "is_args_from_previous"));
/*     */       
/* 186 */       this.limit = XMLHandler.getTagValue(entrynode, "limit");
/* 187 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/* 188 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 191 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 192 */       this.source_filefolder = new String[nrFields];
/* 193 */       this.delimiter = new String[nrFields];
/* 194 */       this.source_wildcard = new String[nrFields];
/* 195 */       this.target_Db = new String[nrFields];
/* 196 */       this.target_table = new String[nrFields];
/*     */       
/*     */ 
/* 199 */       for (int i = 0; i < nrFields; i++)
/*     */       {
/* 201 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 203 */         this.source_filefolder[i] = XMLHandler.getTagValue(fnode, "source_filefolder");
/* 204 */         this.source_wildcard[i] = XMLHandler.getTagValue(fnode, "source_wildcard");
/* 205 */         this.delimiter[i] = XMLHandler.getTagValue(fnode, "delimiter");
/* 206 */         this.target_Db[i] = XMLHandler.getTagValue(fnode, "target_db");
/* 207 */         this.target_table[i] = XMLHandler.getTagValue(fnode, "target_table");
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 212 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Meta.UnableLoadXML", new String[] { xe.getMessage() }), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 220 */       this.include_subfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/* 221 */       this.add_result_filenames = rep.getJobEntryAttributeBoolean(id_jobentry, "add_result_filenames");
/* 222 */       this.is_args_from_previous = rep.getJobEntryAttributeBoolean(id_jobentry, "is_args_from_previous");
/*     */       
/* 224 */       this.limit = rep.getJobEntryAttributeString(id_jobentry, "limit");
/* 225 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/*     */       
/*     */ 
/* 228 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "source_filefolder");
/* 229 */       this.source_filefolder = new String[argnr];
/* 230 */       this.source_wildcard = new String[argnr];
/* 231 */       this.delimiter = new String[argnr];
/* 232 */       this.target_Db = new String[argnr];
/* 233 */       this.target_table = new String[argnr];
/*     */       
/*     */ 
/* 236 */       for (int a = 0; a < argnr; a++)
/*     */       {
/* 238 */         this.source_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_filefolder");
/* 239 */         this.source_wildcard[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_wildcard");
/* 240 */         this.delimiter[a] = rep.getJobEntryAttributeString(id_jobentry, a, "delimiter");
/* 241 */         this.target_Db[a] = rep.getJobEntryAttributeString(id_jobentry, a, "target_db");
/* 242 */         this.target_table[a] = rep.getJobEntryAttributeString(id_jobentry, a, "target_table");
/*     */       }
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 247 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Meta.UnableLoadRep", new String[] { "" + id_jobentry, dbe.getMessage() }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   private void displayResults() {
/* 252 */     if (this.log.isDetailed()) {
/* 253 */       logDetailed("=======================================");
/* 254 */       logDetailed(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.Info.FilesToLoad", new String[] { "" + this.NrFilesToProcess }));
/* 255 */       logDetailed(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.Info.FilesLoaded", new String[] { "" + this.NrSuccess }));
/* 256 */       logDetailed(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.Info.NrErrors", new String[] { "" + this.NrErrors }));
/* 257 */       logDetailed("=======================================");
/*     */     }
/*     */   }
/*     */   
/*     */   public void setLimit(String limit) {
/* 262 */     this.limit = limit;
/*     */   }
/*     */   
/*     */   public String getLimit() {
/* 266 */     return this.limit;
/*     */   }
/*     */   
/*     */   public void setSuccessCondition(String success_condition) {
/* 270 */     this.success_condition = success_condition;
/*     */   }
/*     */   
/*     */   public String getSuccessCondition() {
/* 274 */     return this.success_condition;
/*     */   }
/*     */   
/*     */   private void addFileToResultFilenames(String fileaddentry, Result result, Job parentJob) {
/*     */     try {
/* 279 */       ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(fileaddentry, this), parentJob.getJobname(), toString());
/* 280 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */       
/* 282 */       if (this.log.isDebug()) {
/* 283 */         logDebug(" ------ ");
/* 284 */         logDebug(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.FileAddedToResultFilesName", new String[] { fileaddentry }));
/*     */       }
/*     */     } catch (Exception e) {
/* 287 */       this.log.logError(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Error.AddingToFilenameResult", new String[0]), new Object[] { fileaddentry + "" + e.getMessage() });
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try {
/* 294 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.include_subfolders);
/* 295 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_result_filenames", this.add_result_filenames);
/* 296 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "is_args_from_previous", this.is_args_from_previous);
/*     */       
/* 298 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "limit", this.limit);
/* 299 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*     */       
/* 301 */       if (this.source_filefolder != null)
/*     */       {
/* 303 */         for (int i = 0; i < this.source_filefolder.length; i++)
/*     */         {
/* 305 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_filefolder", this.source_filefolder[i]);
/* 306 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_wildcard", this.source_wildcard[i]);
/* 307 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "delimiter", this.delimiter[i]);
/* 308 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "target_Db", this.target_Db[i]);
/* 309 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "target_table", this.target_table[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 315 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Meta.UnableSave", new String[] { "" + id_job, dbe.getMessage() }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*     */   {
/* 326 */     Pattern pattern = null;
/* 327 */     boolean getIt = true;
/*     */     
/* 329 */     if (!Const.isEmpty(wildcard)) {
/* 330 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 332 */       if (pattern != null) {
/* 333 */         Matcher matcher = pattern.matcher(selectedfile);
/* 334 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/* 337 */     return getIt;
/*     */   }
/*     */   
/*     */   private boolean processOneRow(String sourceFileFolder, String SourceWildcard, String Delimiter, String targetDb, String targetTable, Job parentJob, Result result)
/*     */   {
/* 342 */     boolean retval = false;
/*     */     try {
/* 344 */       File sourcefilefolder = new File(sourceFileFolder);
/* 345 */       if (!sourcefilefolder.exists())
/*     */       {
/* 347 */         logError(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Error.CanNotFindFile", new String[] { sourceFileFolder }));
/* 348 */         return retval;
/*     */       }
/* 350 */       if (sourcefilefolder.isFile())
/*     */       {
/*     */ 
/* 353 */         retval = importFile(sourceFileFolder, Delimiter, targetDb, targetTable, result, parentJob);
/* 354 */       } else if (sourcefilefolder.isDirectory())
/*     */       {
/*     */ 
/* 357 */         File[] listFiles = sourcefilefolder.listFiles();
/* 358 */         int nrFiles = listFiles.length;
/* 359 */         if (nrFiles > 0)
/*     */         {
/*     */ 
/* 362 */           for (int i = 0; (i < nrFiles) && (!parentJob.isStopped()) && (this.continueProcessing); i++)
/*     */           {
/* 364 */             File child = listFiles[i];
/* 365 */             String childFullName = child.getAbsolutePath();
/* 366 */             if (child.isFile())
/*     */             {
/* 368 */               if (Const.isEmpty(SourceWildcard)) {
/* 369 */                 retval = importFile(childFullName, Delimiter, targetDb, targetTable, result, parentJob);
/*     */               }
/* 371 */               else if (GetFileWildcard(childFullName, SourceWildcard)) {
/* 372 */                 retval = importFile(childFullName, Delimiter, targetDb, targetTable, result, parentJob);
/*     */               }
/*     */               
/*     */ 
/*     */             }
/* 377 */             else if (this.include_subfolders) {
/* 378 */               processOneRow(childFullName, SourceWildcard, Delimiter, targetDb, targetTable, parentJob, result);
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */         else {
/* 385 */           logBasic(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.FolderEmpty", new String[] { sourceFileFolder }));
/*     */         }
/*     */       }
/*     */       else {
/* 389 */         logError(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.UnknowType", new String[] { sourceFileFolder }));
/*     */       }
/* 391 */     } catch (Exception e) { logError(e.getMessage());
/* 392 */       incrErrors();
/*     */     }
/* 394 */     return retval;
/*     */   }
/*     */   
/*     */   private boolean importFile(String sourceFilename, String delimiter, String targetFilename, String tablename, Result result, Job parentJob)
/*     */   {
/* 399 */     boolean retval = false;
/*     */     
/*     */     try
/*     */     {
/* 403 */       incrFilesToProcess();
/*     */       
/* 405 */       File sourceDataFile = new File(sourceFilename);
/* 406 */       File targetDbFile = new File(targetFilename);
/*     */       
/*     */ 
/* 409 */       if (!targetDbFile.exists())
/*     */       {
/* 411 */         Database.create(targetDbFile);
/* 412 */         logBasic(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.DbCreated", new String[] { targetFilename }));
/*     */       }
/*     */       else
/*     */       {
/* 416 */         Database db = Database.open(targetDbFile);
/* 417 */         logBasic(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.DbOpened", new String[] { targetFilename }));
/*     */         
/* 419 */         if (db.getTable(tablename) != null)
/*     */         {
/* 421 */           logBasic(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.TableExists", new String[] { tablename }));
/*     */         }
/*     */         
/*     */ 
/* 425 */         if (db != null) db.close();
/* 426 */         logBasic(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.DbCosed", new String[] { targetFilename }));
/*     */       }
/*     */       
/* 429 */       Database.open(targetDbFile).importFile(tablename, sourceDataFile, delimiter);
/*     */       
/* 431 */       logBasic(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.FileImported", new String[] { sourceFilename, tablename, targetFilename }));
/*     */       
/*     */ 
/* 434 */       if (this.add_result_filenames) {
/* 435 */         addFileToResultFilenames(sourceFilename, result, parentJob);
/*     */       }
/*     */       
/* 438 */       retval = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 442 */       logError(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Error.LoadingDataToFile", new String[] { sourceFilename, targetFilename, e.getMessage() }));
/*     */     }
/*     */     
/*     */ 
/* 446 */     if (retval) {
/* 447 */       incrSuccess();
/*     */     } else
/* 449 */       incrErrors();
/* 450 */     return retval;
/*     */   }
/*     */   
/*     */   private void incrErrors() {
/* 454 */     this.NrErrors += 1;
/* 455 */     if (checkIfSuccessConditionBroken())
/*     */     {
/*     */ 
/* 458 */       this.continueProcessing = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkIfSuccessConditionBroken() {
/* 463 */     boolean retval = false;
/* 464 */     if (((this.NrErrors > 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/*     */ 
/* 467 */       retval = true;
/*     */     }
/* 469 */     return retval;
/*     */   }
/*     */   
/*     */   private void incrSuccess() {
/* 473 */     this.NrSuccess += 1;
/*     */   }
/*     */   
/*     */   private void incrFilesToProcess() {
/* 477 */     this.NrFilesToProcess += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 483 */     Result result = previousResult;
/*     */     
/* 485 */     List<RowMetaAndData> rows = result.getRows();
/* 486 */     RowMetaAndData resultRow = null;
/* 487 */     result.setResult(false);
/*     */     
/* 489 */     this.NrErrors = 0;
/* 490 */     this.NrSuccess = 0;
/* 491 */     this.NrFilesToProcess = 0;
/* 492 */     this.continueProcessing = true;
/* 493 */     this.limitFiles = Const.toInt(environmentSubstitute(getLimit()), 10);
/*     */     
/*     */ 
/*     */ 
/* 497 */     String[] vsourceFilefolder = this.source_filefolder;
/* 498 */     String[] vsourceWildcard = this.source_wildcard;
/* 499 */     String[] vsourceDelimiter = this.delimiter;
/* 500 */     String[] targetDb = this.target_Db;
/* 501 */     String[] targetTable = this.target_table;
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 507 */       if ((this.is_args_from_previous) && 
/* 508 */         (this.log.isDetailed())) {
/* 509 */         logDetailed(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.Log.ArgFromPrevious.Found", new String[] { (rows != null ? rows.size() : 0) + "" }));
/*     */       }
/* 511 */       if ((this.is_args_from_previous) && (rows != null)) {
/* 512 */         for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()) && (this.continueProcessing); iteration++) {
/* 513 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*     */           
/*     */ 
/* 516 */           String vSourceFileFolder_previous = resultRow.getString(0, null);
/* 517 */           String vSourceWildcard_previous = resultRow.getString(1, null);
/* 518 */           String vDelimiter_previous = resultRow.getString(2, null);
/* 519 */           String vTargetDb_previous = resultRow.getString(3, null);
/* 520 */           String vTargetTable_previous = resultRow.getString(4, null);
/*     */           
/* 522 */           processOneRow(vSourceFileFolder_previous, vSourceWildcard_previous, vDelimiter_previous, vTargetDb_previous, vTargetTable_previous, this.parentJob, result);
/*     */ 
/*     */         }
/*     */         
/*     */       }
/* 527 */       else if ((vsourceFilefolder != null) && (targetDb != null) && (targetTable != null))
/*     */       {
/* 529 */         for (int i = 0; (i < vsourceFilefolder.length) && (!this.parentJob.isStopped()) && (this.continueProcessing); i++)
/*     */         {
/*     */ 
/* 532 */           String realSourceFileFolder = environmentSubstitute(vsourceFilefolder[i]);
/* 533 */           String realSourceWildcard = environmentSubstitute(vsourceWildcard[i]);
/* 534 */           String realSourceDelimiter = environmentSubstitute(vsourceDelimiter[i]);
/* 535 */           String realTargetDb = environmentSubstitute(targetDb[i]);
/* 536 */           String realTargetTable = environmentSubstitute(targetTable[i]);
/*     */           
/* 538 */           processOneRow(realSourceFileFolder, realSourceWildcard, realSourceDelimiter, realTargetDb, realTargetTable, this.parentJob, result);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 544 */       incrErrors();
/* 545 */       logError(BaseMessages.getString(PKG, "JobEntryMSAccessBulkLoad.UnexpectedError", new String[] { e.getMessage() }));
/*     */     }
/*     */     
/*     */ 
/* 549 */     result.setNrErrors(this.NrErrors);
/* 550 */     result.setNrLinesInput(this.NrFilesToProcess);
/* 551 */     result.setNrLinesWritten(this.NrSuccess);
/* 552 */     if (getSuccessStatus()) { result.setResult(true);
/*     */     }
/* 554 */     displayResults();
/* 555 */     return result;
/*     */   }
/*     */   
/*     */   private boolean getSuccessStatus() {
/* 559 */     boolean retval = false;
/*     */     
/* 561 */     if (((this.NrErrors == 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrSuccess >= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_AT_LEAST))) || ((this.NrErrors <= this.limitFiles) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/*     */ 
/* 564 */       retval = true;
/*     */     }
/*     */     
/* 567 */     return retval;
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 571 */     return true;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 576 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */     
/* 578 */     if (!res)
/*     */     {
/* 580 */       return;
/*     */     }
/*     */     
/* 583 */     ValidatorContext ctx = new ValidatorContext();
/* 584 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 585 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*     */     
/* 587 */     for (int i = 0; i < this.source_filefolder.length; i++)
/*     */     {
/* 589 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\msaccessbulkload\JobEntryMSAccessBulkLoad.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */