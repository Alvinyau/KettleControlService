/*     */ package org.pentaho.di.core.plugins;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.core.annotations.PartitionerPlugin;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannel;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.trans.Partitioner;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PluginMainClassType(Partitioner.class)
/*     */ @PluginAnnotationType(PartitionerPlugin.class)
/*     */ public class PartitionerPluginType
/*     */   extends BasePluginType
/*     */   implements PluginTypeInterface
/*     */ {
/*     */   private static PartitionerPluginType pluginType;
/*     */   
/*     */   private PartitionerPluginType()
/*     */   {
/*  54 */     super(PartitionerPlugin.class, "PARTITIONER", "Partitioner");
/*  55 */     populateFolders("steps");
/*     */   }
/*     */   
/*     */   public static PartitionerPluginType getInstance() {
/*  59 */     if (pluginType == null) {
/*  60 */       pluginType = new PartitionerPluginType();
/*     */     }
/*  62 */     return pluginType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerNatives()
/*     */     throws KettlePluginException
/*     */   {
/*  71 */     String kettlePartitionerXmlFile = "kettle-partition-plugins.xml";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  76 */       InputStream inputStream = getClass().getResourceAsStream(kettlePartitionerXmlFile);
/*  77 */       if (inputStream == null) {
/*  78 */         inputStream = getClass().getResourceAsStream("/" + kettlePartitionerXmlFile);
/*     */       }
/*  80 */       if (inputStream == null) {
/*  81 */         throw new KettlePluginException("Unable to find native partition plugins definition file: kettle-partition-plugins.xml");
/*     */       }
/*  83 */       Document document = XMLHandler.loadXMLFile(inputStream, null, true, false);
/*     */       
/*     */ 
/*     */ 
/*  87 */       Node stepsNode = XMLHandler.getSubNode(document, "plugins");
/*  88 */       List<Node> stepNodes = XMLHandler.getNodes(stepsNode, "plugin-partitioner");
/*  89 */       for (Node stepNode : stepNodes) {
/*  90 */         registerPluginFromXmlResource(stepNode, null, getClass(), true, null);
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException e) {
/*  94 */       throw new KettlePluginException("Unable to read the kettle steps XML config file: " + kettlePartitionerXmlFile, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void registerAnnotations()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */   protected void registerXmlPlugins()
/*     */     throws KettlePluginException
/*     */   {
/* 106 */     for (PluginFolderInterface folder : this.pluginFolders)
/*     */     {
/* 108 */       if (folder.isPluginXmlFolder()) {
/* 109 */         List<FileObject> pluginXmlFiles = findPluginXmlFiles(folder.getFolder());
/* 110 */         for (FileObject file : pluginXmlFiles) {
/*     */           try
/*     */           {
/* 113 */             Document document = XMLHandler.loadXMLFile(file);
/* 114 */             Node pluginNode = XMLHandler.getSubNode(document, "partitioner-plugin");
/* 115 */             if (pluginNode != null) {
/* 116 */               registerPluginFromXmlResource(pluginNode, KettleVFS.getFilename(file.getParent()), getClass(), false, file.getParent().getURL());
/*     */             }
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 121 */             this.log.logError("Error found while reading partitioning plugin.xml file: " + file.getName().toString(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected String extractCategory(Annotation annotation)
/*     */   {
/* 131 */     return "";
/*     */   }
/*     */   
/*     */   protected String extractDesc(Annotation annotation)
/*     */   {
/* 136 */     return ((PartitionerPlugin)annotation).description();
/*     */   }
/*     */   
/*     */   protected String extractID(Annotation annotation)
/*     */   {
/* 141 */     return ((PartitionerPlugin)annotation).id();
/*     */   }
/*     */   
/*     */   protected String extractName(Annotation annotation)
/*     */   {
/* 146 */     return ((PartitionerPlugin)annotation).name();
/*     */   }
/*     */   
/*     */   protected String extractImageFile(Annotation annotation)
/*     */   {
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*     */   {
/* 156 */     return false;
/*     */   }
/*     */   
/*     */   protected String extractI18nPackageName(Annotation annotation)
/*     */   {
/* 161 */     return ((PartitionerPlugin)annotation).i18nPackageName();
/*     */   }
/*     */   
/*     */   protected void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation) {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\PartitionerPluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */