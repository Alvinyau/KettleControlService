/*    */ package org.pentaho.di.cluster;
/*    */ 
/*    */ import org.apache.commons.httpclient.HttpClient;
/*    */ import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
/*    */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SlaveConnectionManager
/*    */ {
/*    */   private static SlaveConnectionManager slaveConnectionManager;
/*    */   private MultiThreadedHttpConnectionManager manager;
/*    */   
/*    */   private SlaveConnectionManager()
/*    */   {
/* 42 */     this.manager = new MultiThreadedHttpConnectionManager();
/* 43 */     this.manager.getParams().setDefaultMaxConnectionsPerHost(100);
/* 44 */     this.manager.getParams().setMaxTotalConnections(200);
/*    */   }
/*    */   
/*    */   public static SlaveConnectionManager getInstance() {
/* 48 */     if (slaveConnectionManager == null) {
/* 49 */       slaveConnectionManager = new SlaveConnectionManager();
/*    */     }
/* 51 */     return slaveConnectionManager;
/*    */   }
/*    */   
/*    */   public HttpClient createHttpClient() {
/* 55 */     return new HttpClient(this.manager);
/*    */   }
/*    */   
/*    */   public void shutdown() {
/* 59 */     this.manager.shutdown();
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\cluster\SlaveConnectionManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */