/*     */ package org.pentaho.di.job.entries.ftpput;
/*     */ 
/*     */ import com.enterprisedt.net.ftp.FTPClient;
/*     */ import com.enterprisedt.net.ftp.FTPControlSocket;
/*     */ import com.enterprisedt.net.ftp.FTPException;
/*     */ import com.enterprisedt.net.ftp.FTPFile;
/*     */ import com.enterprisedt.net.ftp.FTPReply;
/*     */ import com.enterprisedt.net.ftp.FileNotFoundStrings;
/*     */ import java.io.IOException;
/*     */ import java.text.ParseException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDIFTPClient
/*     */   extends FTPClient
/*     */ {
/*  63 */   private boolean mdtmSupported = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private boolean sizeSupported = true;
/*     */   
/*  70 */   private static Class<?> PKG = PDIFTPClient.class;
/*     */   
/*     */   private LogChannelInterface log;
/*     */   
/*     */   public PDIFTPClient(LogChannelInterface log)
/*     */   {
/*  76 */     this.log = log;
/*  77 */     log.logBasic(BaseMessages.getString(PKG, "PDIFTPClient.DEBUG.Using.Overridden.FTPClient", new String[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean exists(String remoteFile)
/*     */     throws IOException, FTPException
/*     */   {
/*  85 */     checkConnection(true);
/*     */     
/*     */ 
/*  88 */     if (this.sizeSupported) {
/*  89 */       this.lastReply = this.control.sendCommand("SIZE " + remoteFile);
/*  90 */       char ch = this.lastReply.getReplyCode().charAt(0);
/*  91 */       if (ch == '2')
/*  92 */         return true;
/*  93 */       if ((ch == '5') && (this.fileNotFoundStrings.matches(this.lastReply.getReplyText()))) {
/*  94 */         return false;
/*     */       }
/*  96 */       this.sizeSupported = false;
/*  97 */       this.log.logDebug("SIZE not supported - trying MDTM");
/*     */     }
/*     */     
/*     */ 
/* 101 */     if (this.mdtmSupported) {
/* 102 */       this.lastReply = this.control.sendCommand("MDTM " + remoteFile);
/* 103 */       char ch = this.lastReply.getReplyCode().charAt(0);
/* 104 */       if (ch == '2')
/* 105 */         return true;
/* 106 */       if ((ch == '5') && (this.fileNotFoundStrings.matches(this.lastReply.getReplyText()))) {
/* 107 */         return false;
/*     */       }
/* 109 */       this.mdtmSupported = false;
/* 110 */       this.log.logDebug("MDTM not supported - trying LIST");
/*     */     }
/*     */     try
/*     */     {
/* 114 */       FTPFile[] files = dirDetails(null);
/* 115 */       for (int i = 0; i < files.length; i++) {
/* 116 */         if (files[i].getName().equals(remoteFile)) {
/* 117 */           return files[i].isFile();
/*     */         }
/*     */       }
/* 120 */       return false;
/*     */     } catch (ParseException ex) {
/* 122 */       this.log.logBasic(ex.getMessage()); }
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\ftpput\PDIFTPClient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */