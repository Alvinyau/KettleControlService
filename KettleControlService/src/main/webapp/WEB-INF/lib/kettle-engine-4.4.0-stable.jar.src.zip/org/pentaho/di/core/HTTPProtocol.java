/*     */ package org.pentaho.di.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.MalformedURLException;
/*     */ import org.apache.commons.httpclient.Credentials;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.HttpState;
/*     */ import org.apache.commons.httpclient.UsernamePasswordCredentials;
/*     */ import org.apache.commons.httpclient.auth.AuthScope;
/*     */ import org.apache.commons.httpclient.auth.AuthenticationException;
/*     */ import org.apache.commons.httpclient.methods.GetMethod;
/*     */ import org.apache.commons.httpclient.params.HttpClientParams;
/*     */ import org.pentaho.di.cluster.SlaveConnectionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTTPProtocol
/*     */ {
/*  52 */   private static final String[] requestHeaders = { "accept", "accept-charset", "cache-control", "content-type" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getRequestHeaders()
/*     */   {
/*  59 */     return requestHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(String urlAsString, String username, String password)
/*     */     throws MalformedURLException, IOException, AuthenticationException
/*     */   {
/*  82 */     HttpClient httpClient = SlaveConnectionManager.getInstance().createHttpClient();
/*  83 */     GetMethod getMethod = new GetMethod(urlAsString);
/*  84 */     httpClient.getParams().setAuthenticationPreemptive(true);
/*  85 */     Credentials defaultcreds = new UsernamePasswordCredentials(username, password);
/*  86 */     httpClient.getState().setCredentials(AuthScope.ANY, defaultcreds);
/*  87 */     int statusCode = httpClient.executeMethod(getMethod);
/*  88 */     StringBuffer bodyBuffer = new StringBuffer();
/*     */     
/*  90 */     if (statusCode != -1) {
/*  91 */       if (statusCode != 401)
/*     */       {
/*     */ 
/*  94 */         InputStreamReader inputStreamReader = new InputStreamReader(getMethod.getResponseBodyAsStream());
/*     */         
/*     */         int c;
/*  97 */         while ((c = inputStreamReader.read()) != -1) {
/*  98 */           bodyBuffer.append((char)c);
/*     */         }
/* 100 */         inputStreamReader.close();
/*     */       }
/*     */       else
/*     */       {
/* 104 */         throw new AuthenticationException();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 109 */     return bodyBuffer.toString();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\HTTPProtocol.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */