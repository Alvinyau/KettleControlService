/*    */ package org.pentaho.di.core.util;
/*    */ 
/*    */ import org.pentaho.di.trans.Trans;
/*    */ import org.pentaho.di.trans.TransMeta;
/*    */ import org.pentaho.di.trans.step.BaseStep;
/*    */ import org.pentaho.di.trans.step.StepDataInterface;
/*    */ import org.pentaho.di.trans.step.StepMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStep
/*    */   extends BaseStep
/*    */ {
/*    */   public static final String UNEXPECTED_ERROR = "Unexpected error";
/*    */   public static final long DEFAULT_ERROR_CODE = 1L;
/*    */   
/*    */   public AbstractStep(StepMeta stepMeta, StepDataInterface stepDataInterface, int copyNr, TransMeta transMeta, Trans trans)
/*    */   {
/* 60 */     super(stepMeta, stepDataInterface, copyNr, transMeta, trans);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void logUnexpectedError(Throwable exception)
/*    */   {
/* 70 */     logError("Unexpected error", exception);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setDefaultError()
/*    */   {
/* 77 */     setErrors(1L);
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\util\AbstractStep.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */