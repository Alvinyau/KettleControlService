/*      */ package org.pentaho.di.job.entries.copyfiles;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.apache.commons.vfs.FileName;
/*      */ import org.apache.commons.vfs.FileObject;
/*      */ import org.apache.commons.vfs.FileSelectInfo;
/*      */ import org.apache.commons.vfs.FileSelector;
/*      */ import org.apache.commons.vfs.FileSystemException;
/*      */ import org.apache.commons.vfs.FileType;
/*      */ import org.pentaho.di.cluster.SlaveServer;
/*      */ import org.pentaho.di.core.CheckResultInterface;
/*      */ import org.pentaho.di.core.Const;
/*      */ import org.pentaho.di.core.Result;
/*      */ import org.pentaho.di.core.ResultFile;
/*      */ import org.pentaho.di.core.RowMetaAndData;
/*      */ import org.pentaho.di.core.database.DatabaseMeta;
/*      */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*      */ import org.pentaho.di.core.exception.KettleException;
/*      */ import org.pentaho.di.core.exception.KettleXMLException;
/*      */ import org.pentaho.di.core.vfs.KettleVFS;
/*      */ import org.pentaho.di.core.xml.XMLHandler;
/*      */ import org.pentaho.di.i18n.BaseMessages;
/*      */ import org.pentaho.di.job.Job;
/*      */ import org.pentaho.di.job.JobMeta;
/*      */ import org.pentaho.di.job.entry.JobEntryBase;
/*      */ import org.pentaho.di.job.entry.JobEntryInterface;
/*      */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*      */ import org.pentaho.di.job.entry.validator.AndValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*      */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*      */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*      */ import org.pentaho.di.repository.ObjectId;
/*      */ import org.pentaho.di.repository.Repository;
/*      */ import org.w3c.dom.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobEntryCopyFiles
/*      */   extends JobEntryBase
/*      */   implements Cloneable, JobEntryInterface
/*      */ {
/*   74 */   private static Class<?> PKG = JobEntryCopyFiles.class;
/*      */   
/*      */   public boolean copy_empty_folders;
/*      */   public boolean arg_from_previous;
/*      */   public boolean overwrite_files;
/*      */   public boolean include_subfolders;
/*      */   public boolean add_result_filesname;
/*      */   public boolean remove_source_files;
/*      */   public boolean destination_is_a_file;
/*      */   public boolean create_destination_folder;
/*      */   public String[] source_filefolder;
/*      */   public String[] destination_filefolder;
/*      */   public String[] wildcard;
/*   87 */   HashSet<String> list_files_remove = new HashSet();
/*   88 */   HashSet<String> list_add_result = new HashSet();
/*   89 */   int NbrFail = 0;
/*      */   
/*      */   public JobEntryCopyFiles(String n)
/*      */   {
/*   93 */     super(n, "");
/*   94 */     this.copy_empty_folders = true;
/*   95 */     this.arg_from_previous = false;
/*   96 */     this.source_filefolder = null;
/*   97 */     this.remove_source_files = false;
/*   98 */     this.destination_filefolder = null;
/*   99 */     this.wildcard = null;
/*  100 */     this.overwrite_files = false;
/*  101 */     this.include_subfolders = false;
/*  102 */     this.add_result_filesname = false;
/*  103 */     this.destination_is_a_file = false;
/*  104 */     this.create_destination_folder = false;
/*  105 */     setID(-1L);
/*      */   }
/*      */   
/*      */   public JobEntryCopyFiles()
/*      */   {
/*  110 */     this("");
/*      */   }
/*      */   
/*      */   public Object clone()
/*      */   {
/*  115 */     JobEntryCopyFiles je = (JobEntryCopyFiles)super.clone();
/*  116 */     return je;
/*      */   }
/*      */   
/*      */   public String getXML()
/*      */   {
/*  121 */     StringBuffer retval = new StringBuffer(300);
/*      */     
/*  123 */     retval.append(super.getXML());
/*  124 */     retval.append("      ").append(XMLHandler.addTagValue("copy_empty_folders", this.copy_empty_folders));
/*  125 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.arg_from_previous));
/*  126 */     retval.append("      ").append(XMLHandler.addTagValue("overwrite_files", this.overwrite_files));
/*  127 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.include_subfolders));
/*  128 */     retval.append("      ").append(XMLHandler.addTagValue("remove_source_files", this.remove_source_files));
/*  129 */     retval.append("      ").append(XMLHandler.addTagValue("add_result_filesname", this.add_result_filesname));
/*  130 */     retval.append("      ").append(XMLHandler.addTagValue("destination_is_a_file", this.destination_is_a_file));
/*  131 */     retval.append("      ").append(XMLHandler.addTagValue("create_destination_folder", this.create_destination_folder));
/*      */     
/*  133 */     retval.append("      <fields>").append(Const.CR);
/*  134 */     if (this.source_filefolder != null)
/*      */     {
/*  136 */       for (int i = 0; i < this.source_filefolder.length; i++)
/*      */       {
/*  138 */         retval.append("        <field>").append(Const.CR);
/*  139 */         retval.append("          ").append(XMLHandler.addTagValue("source_filefolder", this.source_filefolder[i]));
/*  140 */         retval.append("          ").append(XMLHandler.addTagValue("destination_filefolder", this.destination_filefolder[i]));
/*  141 */         retval.append("          ").append(XMLHandler.addTagValue("wildcard", this.wildcard[i]));
/*  142 */         retval.append("        </field>").append(Const.CR);
/*      */       }
/*      */     }
/*  145 */     retval.append("      </fields>").append(Const.CR);
/*      */     
/*  147 */     return retval.toString();
/*      */   }
/*      */   
/*      */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*      */     throws KettleXMLException
/*      */   {
/*      */     try
/*      */     {
/*  155 */       super.loadXML(entrynode, databases, slaveServers);
/*  156 */       this.copy_empty_folders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "copy_empty_folders"));
/*  157 */       this.arg_from_previous = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/*  158 */       this.overwrite_files = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "overwrite_files"));
/*  159 */       this.include_subfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/*  160 */       this.remove_source_files = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "remove_source_files"));
/*  161 */       this.add_result_filesname = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_result_filesname"));
/*  162 */       this.destination_is_a_file = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "destination_is_a_file"));
/*  163 */       this.create_destination_folder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "create_destination_folder"));
/*      */       
/*  165 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*      */       
/*      */ 
/*  168 */       int nrFields = XMLHandler.countNodes(fields, "field");
/*  169 */       this.source_filefolder = new String[nrFields];
/*  170 */       this.destination_filefolder = new String[nrFields];
/*  171 */       this.wildcard = new String[nrFields];
/*      */       
/*      */ 
/*  174 */       for (int i = 0; i < nrFields; i++)
/*      */       {
/*  176 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*      */         
/*  178 */         this.source_filefolder[i] = XMLHandler.getTagValue(fnode, "source_filefolder");
/*  179 */         this.destination_filefolder[i] = XMLHandler.getTagValue(fnode, "destination_filefolder");
/*  180 */         this.wildcard[i] = XMLHandler.getTagValue(fnode, "wildcard");
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     catch (KettleXMLException xe)
/*      */     {
/*  187 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobCopyFiles.Error.Exception.UnableLoadXML", new String[0]), xe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  195 */       this.copy_empty_folders = rep.getJobEntryAttributeBoolean(id_jobentry, "copy_empty_folders");
/*  196 */       this.arg_from_previous = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/*  197 */       this.overwrite_files = rep.getJobEntryAttributeBoolean(id_jobentry, "overwrite_files");
/*  198 */       this.include_subfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*  199 */       this.remove_source_files = rep.getJobEntryAttributeBoolean(id_jobentry, "remove_source_files");
/*      */       
/*  201 */       this.add_result_filesname = rep.getJobEntryAttributeBoolean(id_jobentry, "add_result_filesname");
/*  202 */       this.destination_is_a_file = rep.getJobEntryAttributeBoolean(id_jobentry, "destination_is_a_file");
/*  203 */       this.create_destination_folder = rep.getJobEntryAttributeBoolean(id_jobentry, "create_destination_folder");
/*      */       
/*      */ 
/*  206 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "source_filefolder");
/*  207 */       this.source_filefolder = new String[argnr];
/*  208 */       this.destination_filefolder = new String[argnr];
/*  209 */       this.wildcard = new String[argnr];
/*      */       
/*      */ 
/*  212 */       for (int a = 0; a < argnr; a++)
/*      */       {
/*  214 */         this.source_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_filefolder");
/*  215 */         this.destination_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "destination_filefolder");
/*  216 */         this.wildcard[a] = rep.getJobEntryAttributeString(id_jobentry, a, "wildcard");
/*      */       }
/*      */       
/*      */     }
/*      */     catch (KettleException dbe)
/*      */     {
/*  222 */       throw new KettleException(BaseMessages.getString(PKG, "JobCopyFiles.Error.Exception.UnableLoadRep", new String[0]) + id_jobentry, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*      */   {
/*      */     try
/*      */     {
/*  230 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "copy_empty_folders", this.copy_empty_folders);
/*  231 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.arg_from_previous);
/*  232 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "overwrite_files", this.overwrite_files);
/*  233 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.include_subfolders);
/*  234 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "remove_source_files", this.remove_source_files);
/*  235 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_result_filesname", this.add_result_filesname);
/*  236 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "destination_is_a_file", this.destination_is_a_file);
/*  237 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "create_destination_folder", this.create_destination_folder);
/*      */       
/*      */ 
/*  240 */       if (this.source_filefolder != null)
/*      */       {
/*  242 */         for (int i = 0; i < this.source_filefolder.length; i++)
/*      */         {
/*  244 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_filefolder", this.source_filefolder[i]);
/*  245 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "destination_filefolder", this.destination_filefolder[i]);
/*  246 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "wildcard", this.wildcard[i]);
/*      */         }
/*      */         
/*      */       }
/*      */     }
/*      */     catch (KettleDatabaseException dbe)
/*      */     {
/*  253 */       throw new KettleException(BaseMessages.getString(PKG, "JobCopyFiles.Error.Exception.UnableSaveRep", new String[0]) + id_job, dbe);
/*      */     }
/*      */   }
/*      */   
/*      */   public Result execute(Result previousResult, int nr) throws KettleException
/*      */   {
/*  259 */     Result result = previousResult;
/*      */     
/*  261 */     List<RowMetaAndData> rows = result.getRows();
/*  262 */     RowMetaAndData resultRow = null;
/*      */     
/*  264 */     int NbrFail = 0;
/*      */     
/*  266 */     NbrFail = 0;
/*      */     
/*  268 */     if (isBasic()) { logBasic(BaseMessages.getString(PKG, "JobCopyFiles.Log.Starting", new String[0]));
/*      */     }
/*      */     try
/*      */     {
/*  272 */       String[] vsourcefilefolder = this.source_filefolder;
/*  273 */       String[] vdestinationfilefolder = this.destination_filefolder;
/*  274 */       String[] vwildcard = this.wildcard;
/*      */       
/*  276 */       result.setResult(false);
/*  277 */       result.setNrErrors(1L);
/*      */       
/*  279 */       if (this.arg_from_previous)
/*      */       {
/*  281 */         if (isDetailed()) {
/*  282 */           logDetailed(BaseMessages.getString(PKG, "JobCopyFiles.Log.ArgFromPrevious.Found", new String[] { (rows != null ? rows.size() : 0) + "" }));
/*      */         }
/*      */       }
/*  285 */       if ((this.arg_from_previous) && (rows != null))
/*      */       {
/*  287 */         for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++)
/*      */         {
/*  289 */           resultRow = (RowMetaAndData)rows.get(iteration);
/*      */           
/*      */ 
/*  292 */           String vsourcefilefolder_previous = resultRow.getString(0, null);
/*  293 */           String vdestinationfilefolder_previous = resultRow.getString(1, null);
/*  294 */           String vwildcard_previous = resultRow.getString(2, null);
/*      */           
/*  296 */           if ((!Const.isEmpty(vsourcefilefolder_previous)) && (!Const.isEmpty(vdestinationfilefolder_previous)))
/*      */           {
/*  298 */             if (isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobCopyFiles.Log.ProcessingRow", new String[] { vsourcefilefolder_previous, vdestinationfilefolder_previous, vwildcard_previous }));
/*      */             }
/*  300 */             if (!ProcessFileFolder(vsourcefilefolder_previous, vdestinationfilefolder_previous, vwildcard_previous, this.parentJob, result))
/*      */             {
/*      */ 
/*  303 */               NbrFail++;
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*  308 */           else if (isDetailed()) {
/*  309 */             logDetailed(BaseMessages.getString(PKG, "JobCopyFiles.Log.IgnoringRow", new String[] { vsourcefilefolder[iteration], vdestinationfilefolder[iteration], vwildcard[iteration] }));
/*      */           }
/*      */           
/*      */         }
/*  313 */       } else if ((vsourcefilefolder != null) && (vdestinationfilefolder != null))
/*      */       {
/*  315 */         for (int i = 0; (i < vsourcefilefolder.length) && (!this.parentJob.isStopped()); i++)
/*      */         {
/*  317 */           if ((!Const.isEmpty(vsourcefilefolder[i])) && (!Const.isEmpty(vdestinationfilefolder[i])))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  322 */             if (isBasic()) { logBasic(BaseMessages.getString(PKG, "JobCopyFiles.Log.ProcessingRow", new String[] { vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i] }));
/*      */             }
/*  324 */             if (!ProcessFileFolder(vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i], this.parentJob, result))
/*      */             {
/*      */ 
/*  327 */               NbrFail++;
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*  332 */           else if (isDetailed()) {
/*  333 */             logDetailed(BaseMessages.getString(PKG, "JobCopyFiles.Log.IgnoringRow", new String[] { vsourcefilefolder[i], vdestinationfilefolder[i], vwildcard[i] }));
/*      */           }
/*      */         }
/*      */       }
/*      */     } finally {
/*  338 */       this.list_add_result = null;
/*  339 */       this.list_files_remove = null;
/*      */     }
/*      */     
/*      */ 
/*  343 */     if (NbrFail == 0)
/*      */     {
/*  345 */       result.setResult(true);
/*  346 */       result.setNrErrors(0L);
/*      */     }
/*      */     else {
/*  349 */       result.setNrErrors(NbrFail);
/*      */     }
/*      */     
/*      */ 
/*  353 */     return result;
/*      */   }
/*      */   
/*      */   private boolean ProcessFileFolder(String sourcefilefoldername, String destinationfilefoldername, String wildcard, Job parentJob, Result result)
/*      */   {
/*  358 */     boolean entrystatus = false;
/*  359 */     FileObject sourcefilefolder = null;
/*  360 */     FileObject destinationfilefolder = null;
/*      */     
/*      */ 
/*      */ 
/*  364 */     this.list_files_remove.clear();
/*  365 */     this.list_add_result.clear();
/*      */     
/*      */ 
/*      */ 
/*  369 */     String realSourceFilefoldername = environmentSubstitute(sourcefilefoldername);
/*  370 */     String realDestinationFilefoldername = environmentSubstitute(destinationfilefoldername);
/*  371 */     String realWildcard = environmentSubstitute(wildcard);
/*      */     
/*      */     try
/*      */     {
/*  375 */       sourcefilefolder = KettleVFS.getFileObject(realSourceFilefoldername, this);
/*  376 */       destinationfilefolder = KettleVFS.getFileObject(realDestinationFilefoldername, this);
/*      */       
/*  378 */       if (sourcefilefolder.exists())
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  384 */         if (CreateDestinationFolder(destinationfilefolder)) {
/*      */           String destinationFilefoldername;
/*      */           int trimPathLength;
/*      */           Iterator<String> iter;
/*  388 */           if ((sourcefilefolder.getType().equals(FileType.FOLDER)) && (this.destination_is_a_file))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  393 */             logError(BaseMessages.getString(PKG, "JobCopyFiles.Log.CanNotCopyFolderToFile", new String[] { realSourceFilefoldername, realDestinationFilefoldername }));
/*      */             
/*  395 */             this.NbrFail += 1;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  401 */             if ((destinationfilefolder.getType().equals(FileType.FOLDER)) && (sourcefilefolder.getType().equals(FileType.FILE)))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*  406 */               destinationfilefolder.copyFrom(sourcefilefolder.getParent(), new TextOneFileSelector(sourcefilefolder.getParent().toString(), sourcefilefolder.getName().getBaseName(), destinationfilefolder.toString()));
/*  407 */               if (isDetailed()) {
/*  408 */                 logDetailed(BaseMessages.getString(PKG, "JobCopyFiles.Log.FileCopied", new String[] { sourcefilefolder.getName().toString(), destinationfilefolder.getName().toString() }));
/*      */               }
/*      */             }
/*  411 */             else if ((sourcefilefolder.getType().equals(FileType.FILE)) && (this.destination_is_a_file))
/*      */             {
/*      */ 
/*      */ 
/*  415 */               destinationfilefolder.copyFrom(sourcefilefolder, new TextOneToOneFileSelector(destinationfilefolder));
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  420 */               if (isDetailed())
/*      */               {
/*  422 */                 logDetailed("  ");
/*  423 */                 logDetailed(BaseMessages.getString(PKG, "JobCopyFiles.Log.FetchFolder", new String[] { sourcefilefolder.toString() }));
/*      */               }
/*      */               
/*      */ 
/*  427 */               TextFileSelector textFileSelector = new TextFileSelector(sourcefilefolder, destinationfilefolder, realWildcard, parentJob);
/*      */               try {
/*  429 */                 destinationfilefolder.copyFrom(sourcefilefolder, textFileSelector);
/*      */               } finally {
/*  431 */                 textFileSelector.shutdown();
/*      */               } }
/*      */             String sourceFilefoldername;
/*      */             int trimPathLength;
/*      */             Iterator<String> iter;
/*  436 */             if ((this.remove_source_files) && (!this.list_files_remove.isEmpty()))
/*      */             {
/*  438 */               sourceFilefoldername = sourcefilefolder.toString();
/*  439 */               trimPathLength = sourceFilefoldername.length() + 1;
/*      */               
/*      */ 
/*  442 */               for (iter = this.list_files_remove.iterator(); (iter.hasNext()) && (!parentJob.isStopped());)
/*      */               {
/*  444 */                 String fileremoventry = (String)iter.next();
/*  445 */                 FileObject removeFile = null;
/*      */                 
/*  447 */                 if ((fileremoventry.startsWith(sourceFilefoldername)) && 
/*  448 */                   (trimPathLength < fileremoventry.length())) {
/*  449 */                   removeFile = sourcefilefolder.getChild(fileremoventry.substring(trimPathLength));
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*  454 */                 if (removeFile == null) {
/*  455 */                   removeFile = KettleVFS.getFileObject(fileremoventry, this);
/*      */                 }
/*      */                 
/*      */ 
/*  459 */                 if (removeFile.getType() == FileType.FILE)
/*      */                 {
/*  461 */                   boolean deletefile = removeFile.delete();
/*  462 */                   logBasic(" ------ ");
/*  463 */                   if (!deletefile)
/*      */                   {
/*  465 */                     logError("      " + BaseMessages.getString(PKG, "JobCopyFiles.Error.Exception.CanRemoveFileFolder", new String[] { fileremoventry }));
/*      */ 
/*      */ 
/*      */                   }
/*  469 */                   else if (isDetailed()) {
/*  470 */                     logDetailed("      " + BaseMessages.getString(PKG, "JobCopyFiles.Log.FileFolderRemoved", new String[] { fileremoventry }));
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*  478 */             if ((this.add_result_filesname) && (!this.list_add_result.isEmpty()))
/*      */             {
/*  480 */               destinationFilefoldername = destinationfilefolder.toString();
/*  481 */               trimPathLength = destinationFilefoldername.length() + 1;
/*      */               
/*      */ 
/*  484 */               for (iter = this.list_add_result.iterator(); iter.hasNext();)
/*      */               {
/*  486 */                 String fileaddentry = (String)iter.next();
/*  487 */                 FileObject addFile = null;
/*      */                 
/*      */ 
/*  490 */                 if ((fileaddentry.startsWith(destinationFilefoldername)) && 
/*  491 */                   (trimPathLength < fileaddentry.length())) {
/*  492 */                   addFile = destinationfilefolder.getChild(fileaddentry.substring(trimPathLength));
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*  497 */                 if (addFile == null) {
/*  498 */                   addFile = KettleVFS.getFileObject(fileaddentry, this);
/*      */                 }
/*      */                 
/*      */ 
/*  502 */                 if (addFile.getType() == FileType.FILE)
/*      */                 {
/*  504 */                   ResultFile resultFile = new ResultFile(0, addFile, parentJob.getJobname(), toString());
/*  505 */                   result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*  506 */                   if (isDetailed())
/*      */                   {
/*  508 */                     logDetailed(" ------ ");
/*  509 */                     logDetailed("      " + BaseMessages.getString(PKG, "JobCopyFiles.Log.FileAddedToResultFilesName", new String[] { fileaddentry }));
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  515 */           entrystatus = true;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  520 */           logError(BaseMessages.getString(PKG, "JobCopyFiles.Error.DestinationFolderNotFound", new String[] { realDestinationFilefoldername }));
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/*  525 */         logError(BaseMessages.getString(PKG, "JobCopyFiles.Error.SourceFileNotExists", new String[] { realSourceFilefoldername }));
/*      */       }
/*      */     }
/*      */     catch (FileSystemException fse)
/*      */     {
/*  530 */       logError(BaseMessages.getString(PKG, "JobCopyFiles.Error.Exception.CopyProcessFileSystemException", new String[] { fse.getMessage() }));
/*  531 */       Throwable throwable = fse.getCause();
/*  532 */       while (throwable != null) {
/*  533 */         logError(BaseMessages.getString(PKG, "JobCopyFiles.Log.CausedBy", new String[] { throwable.getMessage() }));
/*  534 */         throwable = throwable.getCause();
/*      */       }
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  539 */       logError(BaseMessages.getString(PKG, "JobCopyFiles.Error.Exception.CopyProcess", new String[] { realSourceFilefoldername, realDestinationFilefoldername, e.getMessage() }), e);
/*      */     }
/*      */     finally
/*      */     {
/*  543 */       if (sourcefilefolder != null)
/*      */       {
/*      */         try
/*      */         {
/*  547 */           sourcefilefolder.close();
/*  548 */           sourcefilefolder = null;
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*  552 */       if (destinationfilefolder != null)
/*      */       {
/*      */         try
/*      */         {
/*  556 */           destinationfilefolder.close();
/*  557 */           destinationfilefolder = null;
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*      */     
/*  563 */     return entrystatus;
/*      */   }
/*      */   
/*      */   private class TextOneToOneFileSelector
/*      */     implements FileSelector
/*      */   {
/*  569 */     FileObject destfile = null;
/*      */     
/*      */ 
/*      */     public TextOneToOneFileSelector(FileObject destinationfile)
/*      */     {
/*  574 */       if (destinationfile != null)
/*      */       {
/*  576 */         this.destfile = destinationfile;
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean includeFile(FileSelectInfo info)
/*      */     {
/*  582 */       boolean resultat = false;
/*  583 */       String fil_name = null;
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  589 */         if (this.destfile.exists())
/*      */         {
/*  591 */           if (JobEntryCopyFiles.this.isDetailed()) {
/*  592 */             JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExists", new String[] { this.destfile.toString() }));
/*      */           }
/*  594 */           if (JobEntryCopyFiles.this.overwrite_files)
/*      */           {
/*  596 */             if (JobEntryCopyFiles.this.isDetailed()) {
/*  597 */               JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileOverwrite", new String[] { this.destfile.toString() }));
/*      */             }
/*  599 */             resultat = true;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  604 */           if (JobEntryCopyFiles.this.isDetailed()) {
/*  605 */             JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileCopied", new String[] { info.getFile().toString(), this.destfile.toString() }));
/*      */           }
/*      */           
/*  608 */           resultat = true;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  613 */         if ((resultat) && (JobEntryCopyFiles.this.remove_source_files))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  618 */           JobEntryCopyFiles.this.list_files_remove.add(info.getFile().toString());
/*      */         }
/*      */         
/*  621 */         if ((resultat) && (JobEntryCopyFiles.this.add_result_filesname))
/*      */         {
/*      */ 
/*  624 */           JobEntryCopyFiles.this.list_add_result.add(this.destfile.toString());
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */ 
/*  632 */         JobEntryCopyFiles.this.logError(BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Error.Exception.CopyProcess", new String[] { info.getFile().toString(), fil_name, e.getMessage() }));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  638 */       return resultat;
/*      */     }
/*      */     
/*      */     public boolean traverseDescendents(FileSelectInfo info)
/*      */     {
/*  643 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean CreateDestinationFolder(FileObject filefolder)
/*      */   {
/*  652 */     FileObject folder = null;
/*      */     try
/*      */     {
/*  655 */       if (this.destination_is_a_file) {
/*  656 */         folder = filefolder.getParent();
/*      */       } else
/*  658 */         folder = filefolder;
/*      */       boolean bool;
/*  660 */       if (!folder.exists())
/*      */       {
/*  662 */         if (this.create_destination_folder)
/*      */         {
/*  664 */           if (isDetailed()) logDetailed("Folder  " + folder.getName() + " does not exist !");
/*  665 */           folder.createFolder();
/*  666 */           if (isDetailed()) logDetailed("Folder parent was created.");
/*      */         }
/*      */         else {
/*  669 */           logError("Folder  " + folder.getName() + " does not exist !");
/*  670 */           return false;
/*      */         }
/*      */       }
/*  673 */       return true;
/*      */     }
/*      */     catch (Exception e) {
/*  676 */       logError("Couldn't created parent folder " + folder.getName(), e);
/*      */     }
/*      */     finally {
/*  679 */       if (folder != null) {
/*      */         try
/*      */         {
/*  682 */           folder.close();
/*  683 */           folder = null;
/*      */         }
/*      */         catch (Exception ex) {}
/*      */       }
/*      */     }
/*  688 */     return false;
/*      */   }
/*      */   
/*      */   private class TextFileSelector implements FileSelector
/*      */   {
/*  693 */     String file_wildcard = null; String source_folder = null; String destination_folder = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  699 */     FileObject destinationFolderObject = null;
/*      */     
/*      */     Job parentjob;
/*      */     
/*      */     Pattern pattern;
/*      */     
/*      */     private int traverseCount;
/*      */     
/*      */     private boolean GetFileWildcard(String selectedfile)
/*      */     {
/*  709 */       boolean getIt = true;
/*      */       
/*  711 */       if (this.pattern != null)
/*      */       {
/*  713 */         Matcher matcher = this.pattern.matcher(selectedfile);
/*  714 */         getIt = matcher.matches();
/*      */       }
/*  716 */       return getIt;
/*      */     }
/*      */     
/*      */ 
/*      */     public TextFileSelector(FileObject sourcefolderin, FileObject destinationfolderin, String filewildcard, Job parentJob)
/*      */     {
/*  722 */       if (sourcefolderin != null)
/*      */       {
/*  724 */         this.source_folder = sourcefolderin.toString();
/*      */       }
/*  726 */       if (destinationfolderin != null)
/*      */       {
/*  728 */         this.destinationFolderObject = destinationfolderin;
/*  729 */         this.destination_folder = this.destinationFolderObject.toString();
/*      */       }
/*  731 */       if (!Const.isEmpty(filewildcard))
/*      */       {
/*  733 */         this.file_wildcard = filewildcard;
/*  734 */         this.pattern = Pattern.compile(this.file_wildcard);
/*      */       }
/*  736 */       this.parentjob = parentJob;
/*      */     }
/*      */     
/*      */     public boolean includeFile(FileSelectInfo info)
/*      */     {
/*  741 */       boolean returncode = false;
/*  742 */       FileObject file_name = null;
/*  743 */       String addFileNameString = null;
/*      */       
/*      */       try
/*      */       {
/*  747 */         if ((!info.getFile().toString().equals(this.source_folder)) && (!this.parentjob.isStopped()))
/*      */         {
/*      */ 
/*      */ 
/*  751 */           String short_filename = info.getFile().getName().getBaseName();
/*      */           
/*  753 */           if (this.destinationFolderObject == null)
/*      */           {
/*  755 */             this.destinationFolderObject = KettleVFS.getFileObject(this.destination_folder, JobEntryCopyFiles.this);
/*      */           }
/*      */           
/*  758 */           file_name = this.destinationFolderObject.getChild(short_filename);
/*      */           
/*      */ 
/*  761 */           if (!info.getFile().getParent().equals(info.getBaseFolder()))
/*      */           {
/*      */ 
/*      */ 
/*  765 */             if (JobEntryCopyFiles.this.include_subfolders)
/*      */             {
/*      */ 
/*  768 */               if (info.getFile().getType() == FileType.FOLDER)
/*      */               {
/*  770 */                 if ((JobEntryCopyFiles.this.include_subfolders) && (JobEntryCopyFiles.this.copy_empty_folders) && (Const.isEmpty(this.file_wildcard)))
/*      */                 {
/*  772 */                   if ((file_name == null) || (!file_name.exists()))
/*      */                   {
/*  774 */                     if (JobEntryCopyFiles.this.isDetailed())
/*      */                     {
/*  776 */                       JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  777 */                       JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FolderCopied", new String[] { info.getFile().toString(), file_name != null ? file_name.toString() : "" }));
/*      */                     }
/*  779 */                     returncode = true;
/*      */                   }
/*      */                   else
/*      */                   {
/*  783 */                     if (JobEntryCopyFiles.this.isDetailed())
/*      */                     {
/*  785 */                       JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  786 */                       JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FolderExists", new String[] { file_name.toString() }));
/*      */                     }
/*  788 */                     if (JobEntryCopyFiles.this.overwrite_files)
/*      */                     {
/*  790 */                       if (JobEntryCopyFiles.this.isDetailed())
/*  791 */                         JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FolderOverwrite", new String[] { info.getFile().toString(), file_name.toString() }));
/*  792 */                       returncode = true;
/*      */                     }
/*      */                     
/*      */                   }
/*      */                   
/*      */                 }
/*      */                 
/*      */               }
/*  800 */               else if (GetFileWildcard(short_filename))
/*      */               {
/*      */ 
/*  803 */                 if ((file_name == null) || (!file_name.exists()))
/*      */                 {
/*  805 */                   if (JobEntryCopyFiles.this.isDetailed())
/*      */                   {
/*  807 */                     JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  808 */                     JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileCopied", new String[] { info.getFile().toString(), file_name != null ? file_name.toString() : "" }));
/*      */                   }
/*  810 */                   returncode = true;
/*      */                 }
/*      */                 else
/*      */                 {
/*  814 */                   if (JobEntryCopyFiles.this.isDetailed())
/*      */                   {
/*  816 */                     JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  817 */                     JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExists", new String[] { file_name.toString() }));
/*      */                   }
/*  819 */                   if (JobEntryCopyFiles.this.overwrite_files)
/*      */                   {
/*  821 */                     if (JobEntryCopyFiles.this.isDetailed()) {
/*  822 */                       JobEntryCopyFiles.this.logDetailed("       " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExists", new String[] { info.getFile().toString(), file_name.toString() }));
/*      */                     }
/*  824 */                     returncode = true;
/*      */                   }
/*      */                   
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*  835 */           else if (info.getFile().getType() == FileType.FOLDER)
/*      */           {
/*  837 */             if ((JobEntryCopyFiles.this.include_subfolders) && (JobEntryCopyFiles.this.copy_empty_folders) && (Const.isEmpty(this.file_wildcard)))
/*      */             {
/*  839 */               if ((file_name == null) || (!file_name.exists()))
/*      */               {
/*  841 */                 if (JobEntryCopyFiles.this.isDetailed())
/*      */                 {
/*  843 */                   JobEntryCopyFiles.this.logDetailed("", new Object[] { " ------ " });
/*  844 */                   JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FolderCopied", new String[] { info.getFile().toString(), file_name != null ? file_name.toString() : "" }));
/*      */                 }
/*      */                 
/*  847 */                 returncode = true;
/*      */               }
/*      */               else
/*      */               {
/*  851 */                 if (JobEntryCopyFiles.this.isDetailed())
/*      */                 {
/*  853 */                   JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  854 */                   JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FolderExists", new String[] { file_name.toString() }));
/*      */                 }
/*  856 */                 if (JobEntryCopyFiles.this.overwrite_files)
/*      */                 {
/*  858 */                   if (JobEntryCopyFiles.this.isDetailed()) {
/*  859 */                     JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FolderOverwrite", new String[] { info.getFile().toString(), file_name.toString() }));
/*      */                   }
/*      */                   
/*  862 */                   returncode = true;
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  873 */             file_name = KettleVFS.getFileObject(this.destination_folder + Const.FILE_SEPARATOR + short_filename);
/*      */             
/*  875 */             if (GetFileWildcard(short_filename))
/*      */             {
/*  877 */               if ((file_name == null) || (!file_name.exists()))
/*      */               {
/*  879 */                 if (JobEntryCopyFiles.this.isDetailed())
/*      */                 {
/*  881 */                   JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  882 */                   JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileCopied", new String[] { info.getFile().toString(), file_name != null ? file_name.toString() : "" }));
/*      */                 }
/*  884 */                 returncode = true;
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/*  889 */                 if (JobEntryCopyFiles.this.isDetailed())
/*      */                 {
/*  891 */                   JobEntryCopyFiles.this.logDetailed(" ------ ");
/*  892 */                   JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExists", new String[] { file_name.toString() }));
/*      */                 }
/*      */                 
/*  895 */                 if (JobEntryCopyFiles.this.overwrite_files)
/*      */                 {
/*  897 */                   if (JobEntryCopyFiles.this.isDetailed()) {
/*  898 */                     JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExistsInfos", new String[0]), new Object[] { BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExists", new String[] { info.getFile().toString(), file_name.toString() }) });
/*      */                   }
/*  900 */                   returncode = true;
/*      */ 
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */ 
/*  918 */         JobEntryCopyFiles.this.logError(BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Error.Exception.CopyProcess", new String[] { info.getFile().toString(), file_name.toString(), e.getMessage() }));
/*      */         
/*      */ 
/*  921 */         returncode = false;
/*      */       }
/*      */       finally
/*      */       {
/*  925 */         if (file_name != null)
/*      */         {
/*      */           try
/*      */           {
/*  929 */             if ((returncode) && (JobEntryCopyFiles.this.add_result_filesname)) {
/*  930 */               addFileNameString = file_name.toString();
/*      */             }
/*  932 */             file_name.close();
/*  933 */             file_name = null;
/*      */           }
/*      */           catch (IOException ex) {}
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  941 */       if ((returncode) && (JobEntryCopyFiles.this.remove_source_files))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  946 */         JobEntryCopyFiles.this.list_files_remove.add(info.getFile().toString());
/*      */       }
/*      */       
/*  949 */       if ((returncode) && (JobEntryCopyFiles.this.add_result_filesname))
/*      */       {
/*      */ 
/*  952 */         JobEntryCopyFiles.this.list_add_result.add(addFileNameString);
/*      */       }
/*      */       
/*      */ 
/*  956 */       return returncode;
/*      */     }
/*      */     
/*      */     public boolean traverseDescendents(FileSelectInfo info)
/*      */     {
/*  961 */       return (this.traverseCount++ == 0) || (JobEntryCopyFiles.this.include_subfolders);
/*      */     }
/*      */     
/*      */     public void shutdown() {
/*  965 */       if (this.destinationFolderObject != null)
/*      */       {
/*      */         try
/*      */         {
/*  969 */           this.destinationFolderObject.close();
/*      */         }
/*      */         catch (IOException ex) {}
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class TextOneFileSelector implements FileSelector {
/*      */     private int traverseCount;
/*  978 */     String destfolder = null; String foldername = null; String filename = null;
/*      */     
/*      */ 
/*      */     public TextOneFileSelector(String sourcefolderin, String sourcefilenamein, String destfolderin)
/*      */     {
/*  983 */       if (!Const.isEmpty(sourcefilenamein))
/*      */       {
/*  985 */         this.filename = sourcefilenamein;
/*      */       }
/*      */       
/*  988 */       if (!Const.isEmpty(sourcefolderin))
/*      */       {
/*  990 */         this.foldername = sourcefolderin;
/*      */       }
/*  992 */       if (!Const.isEmpty(destfolderin))
/*      */       {
/*  994 */         this.destfolder = destfolderin;
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean includeFile(FileSelectInfo info)
/*      */     {
/* 1000 */       boolean resultat = false;
/* 1001 */       String fil_name = null;
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 1006 */         if (info.getFile().getType() == FileType.FILE)
/*      */         {
/* 1008 */           if ((info.getFile().getName().getBaseName().equals(this.filename)) && (info.getFile().getParent().toString().equals(this.foldername)))
/*      */           {
/*      */ 
/* 1011 */             fil_name = this.destfolder + Const.FILE_SEPARATOR + this.filename;
/*      */             
/* 1013 */             if (KettleVFS.getFileObject(fil_name, JobEntryCopyFiles.this).exists())
/*      */             {
/* 1015 */               if (JobEntryCopyFiles.this.isDetailed()) {
/* 1016 */                 JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileExists", new String[] { fil_name }));
/*      */               }
/* 1018 */               if (JobEntryCopyFiles.this.overwrite_files)
/*      */               {
/* 1020 */                 if (JobEntryCopyFiles.this.isDetailed()) {
/* 1021 */                   JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileOverwrite", new String[] { info.getFile().toString(), fil_name }));
/*      */                 }
/* 1023 */                 resultat = true;
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/* 1030 */               if (JobEntryCopyFiles.this.isDetailed()) { JobEntryCopyFiles.this.logDetailed("      " + BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Log.FileCopied", new String[] { info.getFile().toString(), fil_name }));
/*      */               }
/*      */               
/* 1033 */               resultat = true;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 1038 */           if ((resultat) && (JobEntryCopyFiles.this.remove_source_files))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1043 */             JobEntryCopyFiles.this.list_files_remove.add(info.getFile().toString());
/*      */           }
/*      */           
/* 1046 */           if ((resultat) && (JobEntryCopyFiles.this.add_result_filesname))
/*      */           {
/*      */ 
/* 1049 */             JobEntryCopyFiles.this.list_add_result.add(KettleVFS.getFileObject(fil_name, JobEntryCopyFiles.this).toString());
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1057 */         JobEntryCopyFiles.this.logError(BaseMessages.getString(JobEntryCopyFiles.PKG, "JobCopyFiles.Error.Exception.CopyProcess", new String[] { info.getFile().toString(), fil_name, e.getMessage() }));
/*      */         
/*      */ 
/*      */ 
/* 1061 */         resultat = false;
/*      */       }
/*      */       
/*      */ 
/* 1065 */       return resultat;
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean traverseDescendents(FileSelectInfo info)
/*      */     {
/* 1071 */       return (this.traverseCount++ == 0) || (JobEntryCopyFiles.this.include_subfolders);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setCopyEmptyFolders(boolean copy_empty_foldersin)
/*      */   {
/* 1077 */     this.copy_empty_folders = copy_empty_foldersin;
/*      */   }
/*      */   
/*      */   public void setoverwrite_files(boolean overwrite_filesin)
/*      */   {
/* 1082 */     this.overwrite_files = overwrite_filesin;
/*      */   }
/*      */   
/*      */   public void setIncludeSubfolders(boolean include_subfoldersin)
/*      */   {
/* 1087 */     this.include_subfolders = include_subfoldersin;
/*      */   }
/*      */   
/*      */   public void setAddresultfilesname(boolean add_result_filesnamein)
/*      */   {
/* 1092 */     this.add_result_filesname = add_result_filesnamein;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setArgFromPrevious(boolean argfrompreviousin)
/*      */   {
/* 1098 */     this.arg_from_previous = argfrompreviousin;
/*      */   }
/*      */   
/*      */   public void setRemoveSourceFiles(boolean remove_source_filesin)
/*      */   {
/* 1103 */     this.remove_source_files = remove_source_filesin;
/*      */   }
/*      */   
/*      */   public void setDestinationIsAFile(boolean destination_is_a_file)
/*      */   {
/* 1108 */     this.destination_is_a_file = destination_is_a_file;
/*      */   }
/*      */   
/*      */   public void setCreateDestinationFolder(boolean create_destination_folder)
/*      */   {
/* 1113 */     this.create_destination_folder = create_destination_folder;
/*      */   }
/*      */   
/*      */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*      */   {
/* 1118 */     boolean res = JobEntryValidatorUtils.andValidator().validate(this, "arguments", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*      */     
/* 1120 */     if (!res)
/*      */     {
/* 1122 */       return;
/*      */     }
/*      */     
/* 1125 */     ValidatorContext ctx = new ValidatorContext();
/* 1126 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 1127 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/*      */     
/* 1129 */     for (int i = 0; i < this.source_filefolder.length; i++)
/*      */     {
/* 1131 */       JobEntryValidatorUtils.andValidator().validate(this, "arguments[" + i + "]", remarks, ctx);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean evaluates() {
/* 1136 */     return true;
/*      */   }
/*      */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\copyfiles\JobEntryCopyFiles.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */