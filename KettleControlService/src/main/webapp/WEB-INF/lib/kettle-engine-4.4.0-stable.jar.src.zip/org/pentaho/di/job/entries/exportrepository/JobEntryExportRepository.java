/*     */ package org.pentaho.di.job.entries.exportrepository;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.encryption.Encr;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.plugins.PluginRegistry;
/*     */ import org.pentaho.di.core.plugins.RepositoryPluginType;
/*     */ import org.pentaho.di.core.util.StringUtil;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entries.sftp.JobEntrySFTP;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.IRepositoryExporter;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.RepositoriesMeta;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.repository.RepositoryDirectory;
/*     */ import org.pentaho.di.repository.RepositoryDirectoryInterface;
/*     */ import org.pentaho.di.repository.RepositoryExporter;
/*     */ import org.pentaho.di.repository.RepositoryMeta;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryExportRepository
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  84 */   private static Class<?> PKG = JobEntryExportRepository.class;
/*     */   
/*     */   private String repositoryname;
/*     */   
/*     */   private String username;
/*     */   private String password;
/*     */   private String targetfilename;
/*     */   private String iffileexists;
/*     */   private String export_type;
/*     */   private String directoryPath;
/*  94 */   public String If_FileExists_Skip = "if_file_exists_skip";
/*  95 */   public String If_FileExists_Fail = "if_file_exists_fail";
/*  96 */   public String If_FileExists_Overwrite = "if_file_exists_overwrite";
/*  97 */   public String If_FileExists_Uniquename = "if_file_exists_uniquename";
/*     */   
/*  99 */   public String Export_All = "export_all";
/* 100 */   public String Export_Jobs = "export_jobs";
/* 101 */   public String Export_Trans = "export_trans";
/* 102 */   public String Export_By_Folder = "export_by_folder";
/* 103 */   public String Export_One_Folder = "export_one_folder";
/*     */   
/*     */   private boolean add_date;
/*     */   
/*     */   private boolean add_time;
/*     */   private boolean SpecifyFormat;
/*     */   private String date_time_format;
/*     */   private boolean createfolder;
/*     */   private boolean newfolder;
/*     */   private boolean add_result_filesname;
/*     */   private String nr_errors_less_than;
/*     */   private String success_condition;
/* 115 */   public String SUCCESS_IF_ERRORS_LESS = "success_if_errors_less";
/* 116 */   public String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*     */   
/*     */ 
/* 119 */   FileObject file = null;
/* 120 */   RepositoriesMeta repsinfo = null;
/* 121 */   Repository repository = null;
/* 122 */   RepositoryMeta repositoryMeta = null;
/*     */   
/*     */ 
/* 125 */   int NrErrors = 0;
/* 126 */   boolean successConditionBroken = false;
/* 127 */   int limitErr = 0;
/*     */   
/*     */   public JobEntryExportRepository(String n)
/*     */   {
/* 131 */     super(n, "");
/* 132 */     this.repositoryname = null;
/* 133 */     this.targetfilename = null;
/* 134 */     this.username = null;
/* 135 */     this.iffileexists = this.If_FileExists_Skip;
/* 136 */     this.export_type = this.Export_All;
/* 137 */     this.add_date = false;
/* 138 */     this.add_time = false;
/* 139 */     this.SpecifyFormat = false;
/* 140 */     this.date_time_format = null;
/* 141 */     this.createfolder = false;
/* 142 */     this.newfolder = false;
/* 143 */     this.add_result_filesname = false;
/* 144 */     this.nr_errors_less_than = "10";
/* 145 */     this.success_condition = this.SUCCESS_IF_NO_ERRORS;
/* 146 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryExportRepository()
/*     */   {
/* 151 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 156 */     JobEntryExportRepository je = (JobEntryExportRepository)super.clone();
/* 157 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 162 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/* 164 */     retval.append(super.getXML());
/* 165 */     retval.append("      ").append(XMLHandler.addTagValue("repositoryname", this.repositoryname));
/* 166 */     retval.append("      ").append(XMLHandler.addTagValue("username", this.username));
/* 167 */     retval.append("      ").append(XMLHandler.addTagValue("password", Encr.encryptPasswordIfNotUsingVariables(getPassword())));
/* 168 */     retval.append("      ").append(XMLHandler.addTagValue("targetfilename", this.targetfilename));
/* 169 */     retval.append("      ").append(XMLHandler.addTagValue("iffileexists", this.iffileexists));
/* 170 */     retval.append("      ").append(XMLHandler.addTagValue("export_type", this.export_type));
/* 171 */     retval.append("      ").append(XMLHandler.addTagValue("directoryPath", this.directoryPath));
/* 172 */     retval.append("      ").append(XMLHandler.addTagValue("add_date", this.add_date));
/* 173 */     retval.append("      ").append(XMLHandler.addTagValue("add_time", this.add_time));
/* 174 */     retval.append("      ").append(XMLHandler.addTagValue("SpecifyFormat", this.SpecifyFormat));
/* 175 */     retval.append("      ").append(XMLHandler.addTagValue("date_time_format", this.date_time_format));
/* 176 */     retval.append("      ").append(XMLHandler.addTagValue("createfolder", this.createfolder));
/* 177 */     retval.append("      ").append(XMLHandler.addTagValue("newfolder", this.newfolder));
/* 178 */     retval.append("      ").append(XMLHandler.addTagValue("add_result_filesname", this.add_result_filesname));
/* 179 */     retval.append("      ").append(XMLHandler.addTagValue("nr_errors_less_than", this.nr_errors_less_than));
/* 180 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/*     */     
/* 182 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 190 */       super.loadXML(entrynode, databases, slaveServers);
/* 191 */       this.repositoryname = XMLHandler.getTagValue(entrynode, "repositoryname");
/* 192 */       this.username = XMLHandler.getTagValue(entrynode, "username");
/* 193 */       this.password = Encr.decryptPasswordOptionallyEncrypted(XMLHandler.getTagValue(entrynode, "password"));
/* 194 */       this.targetfilename = XMLHandler.getTagValue(entrynode, "targetfilename");
/* 195 */       this.iffileexists = XMLHandler.getTagValue(entrynode, "iffileexists");
/* 196 */       this.export_type = XMLHandler.getTagValue(entrynode, "export_type");
/* 197 */       this.directoryPath = XMLHandler.getTagValue(entrynode, "directoryPath");
/* 198 */       this.add_date = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_date"));
/* 199 */       this.add_time = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_time"));
/* 200 */       this.SpecifyFormat = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "SpecifyFormat"));
/* 201 */       this.date_time_format = XMLHandler.getTagValue(entrynode, "date_time_format");
/* 202 */       this.createfolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "createfolder"));
/* 203 */       this.newfolder = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "newfolder"));
/* 204 */       this.add_result_filesname = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "add_result_filesname"));
/* 205 */       this.nr_errors_less_than = XMLHandler.getTagValue(entrynode, "nr_errors_less_than");
/* 206 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/*     */ 
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 211 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobExportRepository.Meta.UnableLoadXML", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 219 */       this.repositoryname = rep.getJobEntryAttributeString(id_jobentry, "repositoryname");
/* 220 */       this.username = rep.getJobEntryAttributeString(id_jobentry, "username");
/* 221 */       this.password = Encr.decryptPasswordOptionallyEncrypted(rep.getJobEntryAttributeString(id_jobentry, "password"));
/* 222 */       this.targetfilename = rep.getJobEntryAttributeString(id_jobentry, "targetfilename");
/* 223 */       this.iffileexists = rep.getJobEntryAttributeString(id_jobentry, "iffileexists");
/* 224 */       this.export_type = rep.getJobEntryAttributeString(id_jobentry, "export_type");
/* 225 */       this.directoryPath = rep.getJobEntryAttributeString(id_jobentry, "directoryPath");
/* 226 */       this.add_date = rep.getJobEntryAttributeBoolean(id_jobentry, "add_date");
/* 227 */       this.add_time = rep.getJobEntryAttributeBoolean(id_jobentry, "add_time");
/* 228 */       this.SpecifyFormat = rep.getJobEntryAttributeBoolean(id_jobentry, "SpecifyFormat");
/* 229 */       this.date_time_format = rep.getJobEntryAttributeString(id_jobentry, "date_time_format");
/* 230 */       this.createfolder = rep.getJobEntryAttributeBoolean(id_jobentry, "createfolder");
/* 231 */       this.newfolder = rep.getJobEntryAttributeBoolean(id_jobentry, "newfolder");
/* 232 */       this.add_result_filesname = rep.getJobEntryAttributeBoolean(id_jobentry, "add_result_filesname");
/* 233 */       this.nr_errors_less_than = rep.getJobEntryAttributeString(id_jobentry, "nr_errors_less_than");
/*     */       
/* 235 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/*     */ 
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 240 */       throw new KettleException(BaseMessages.getString(PKG, "JobExportRepository.Meta.UnableLoadRep", new String[] { "" + id_jobentry }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 248 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "repositoryname", this.repositoryname);
/* 249 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "username", this.username);
/* 250 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "password", Encr.encryptPasswordIfNotUsingVariables(this.password));
/* 251 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "targetfilename", this.targetfilename);
/* 252 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "iffileexists", this.iffileexists);
/* 253 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "export_type", this.export_type);
/* 254 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "directoryPath", this.directoryPath);
/* 255 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_date", this.add_date);
/* 256 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_time", this.add_time);
/* 257 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "SpecifyFormat", this.SpecifyFormat);
/* 258 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "date_time_format", this.date_time_format);
/* 259 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "createfolder", this.createfolder);
/* 260 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "newfolder", this.newfolder);
/* 261 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "add_result_filesname", this.add_result_filesname);
/* 262 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_errors_less_than", this.nr_errors_less_than);
/* 263 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 267 */       throw new KettleException(BaseMessages.getString(PKG, "JobExportRepository.Meta.UnableSaveRep", new String[] { "" + id_job }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setSuccessCondition(String success_condition) {
/* 272 */     this.success_condition = success_condition;
/*     */   }
/*     */   
/*     */   public String getSuccessCondition() {
/* 276 */     return this.success_condition;
/*     */   }
/*     */   
/*     */   public void setRepositoryname(String repositoryname) {
/* 280 */     this.repositoryname = repositoryname;
/*     */   }
/*     */   
/*     */   public String getRepositoryname()
/*     */   {
/* 285 */     return this.repositoryname;
/*     */   }
/*     */   
/*     */   public void setUsername(String username)
/*     */   {
/* 290 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 294 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setExportType(String export_type)
/*     */   {
/* 299 */     this.export_type = export_type;
/*     */   }
/*     */   
/*     */   public String getExportType() {
/* 303 */     return this.export_type;
/*     */   }
/*     */   
/*     */   public void setIfFileExists(String iffileexists)
/*     */   {
/* 308 */     this.iffileexists = iffileexists;
/*     */   }
/*     */   
/*     */   public String getIfFileExists() {
/* 312 */     return this.iffileexists;
/*     */   }
/*     */   
/*     */   public void setTargetfilename(String targetfilename)
/*     */   {
/* 317 */     this.targetfilename = targetfilename;
/*     */   }
/*     */   
/*     */   public String getTargetfilename()
/*     */   {
/* 322 */     return this.targetfilename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 330 */     return this.password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 338 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getDirectory()
/*     */   {
/* 343 */     return this.directoryPath;
/*     */   }
/*     */   
/*     */   public String getDateTimeFormat() {
/* 347 */     return this.date_time_format;
/*     */   }
/*     */   
/*     */   public void setDateTimeFormat(String date_time_format) {
/* 351 */     this.date_time_format = date_time_format;
/*     */   }
/*     */   
/*     */   public boolean isSpecifyFormat()
/*     */   {
/* 356 */     return this.SpecifyFormat;
/*     */   }
/*     */   
/*     */   public void setSpecifyFormat(boolean SpecifyFormat) {
/* 360 */     this.SpecifyFormat = SpecifyFormat;
/*     */   }
/*     */   
/*     */   public void setAddTime(boolean addtime) {
/* 364 */     this.add_time = addtime;
/*     */   }
/*     */   
/*     */   public boolean isAddTime()
/*     */   {
/* 369 */     return this.add_time;
/*     */   }
/*     */   
/*     */   public boolean isCreateFolder()
/*     */   {
/* 374 */     return this.createfolder;
/*     */   }
/*     */   
/*     */   public void setCreateFolder(boolean createfolder) {
/* 378 */     this.createfolder = createfolder;
/*     */   }
/*     */   
/*     */   public void setNewFolder(boolean newfolder) {
/* 382 */     this.newfolder = newfolder;
/*     */   }
/*     */   
/*     */   public boolean isNewFolder() {
/* 386 */     return this.newfolder;
/*     */   }
/*     */   
/*     */   public void setDirectory(String directoryPath) {
/* 390 */     this.directoryPath = directoryPath;
/*     */   }
/*     */   
/*     */   public void setAddDate(boolean adddate) {
/* 394 */     this.add_date = adddate;
/*     */   }
/*     */   
/*     */   public boolean isAddDate()
/*     */   {
/* 399 */     return this.add_date;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAddresultfilesname(boolean add_result_filesnamein)
/*     */   {
/* 405 */     this.add_result_filesname = add_result_filesnamein;
/*     */   }
/*     */   
/*     */   public boolean isAddresultfilesname()
/*     */   {
/* 410 */     return this.add_result_filesname;
/*     */   }
/*     */   
/*     */   public void setNrLimit(String nr_errors_less_than)
/*     */   {
/* 415 */     this.nr_errors_less_than = nr_errors_less_than;
/*     */   }
/*     */   
/*     */   public String getNrLimit()
/*     */   {
/* 420 */     return this.nr_errors_less_than;
/*     */   }
/*     */   
/*     */   public String buildFilename(String filename)
/*     */   {
/* 425 */     String retval = "";
/* 426 */     if (Const.isEmpty(filename)) { return null;
/*     */     }
/* 428 */     int lenstring = filename.length();
/* 429 */     int lastindexOfDot = filename.lastIndexOf('.');
/* 430 */     if (lastindexOfDot == -1) { lastindexOfDot = lenstring;
/*     */     }
/* 432 */     retval = filename.substring(0, lastindexOfDot);
/*     */     
/* 434 */     SimpleDateFormat daf = new SimpleDateFormat();
/* 435 */     Date now = new Date();
/*     */     
/* 437 */     if ((isSpecifyFormat()) && (!Const.isEmpty(getDateTimeFormat())))
/*     */     {
/* 439 */       daf.applyPattern(getDateTimeFormat());
/* 440 */       String dt = daf.format(now);
/* 441 */       retval = retval + dt;
/*     */     }
/*     */     else {
/* 444 */       if (isAddDate())
/*     */       {
/* 446 */         daf.applyPattern("yyyyMMdd");
/* 447 */         String d = daf.format(now);
/* 448 */         retval = retval + "_" + d;
/*     */       }
/* 450 */       if (isAddTime())
/*     */       {
/* 452 */         daf.applyPattern("HHmmssSSS");
/* 453 */         String t = daf.format(now);
/* 454 */         retval = retval + "_" + t;
/*     */       }
/*     */     }
/* 457 */     retval = retval + filename.substring(lastindexOfDot, lenstring);
/* 458 */     return retval;
/*     */   }
/*     */   
/*     */   public String buildUniqueFilename(String filename) {
/* 462 */     String retval = "";
/* 463 */     if (Const.isEmpty(filename)) { return null;
/*     */     }
/* 465 */     int lenstring = filename.length();
/* 466 */     int lastindexOfDot = filename.lastIndexOf('.');
/* 467 */     if (lastindexOfDot == -1) lastindexOfDot = lenstring;
/* 468 */     retval = filename.substring(0, lastindexOfDot);
/* 469 */     retval = retval + StringUtil.getFormattedDateTimeNow();
/* 470 */     retval = retval + filename.substring(lastindexOfDot, lenstring);
/*     */     
/* 472 */     return retval;
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 477 */     Result result = previousResult;
/* 478 */     result.setNrErrors(1L);
/* 479 */     result.setResult(false);
/*     */     
/* 481 */     String realrepName = environmentSubstitute(this.repositoryname);
/* 482 */     String realusername = environmentSubstitute(this.username);
/* 483 */     String realpassword = Encr.decryptPasswordOptionallyEncrypted(environmentSubstitute(this.password));
/* 484 */     String realfoldername = environmentSubstitute(this.directoryPath);
/*     */     
/* 486 */     String realoutfilename = environmentSubstitute(this.targetfilename);
/* 487 */     if ((this.export_type.equals(this.Export_All)) || (this.export_type.equals(this.Export_Jobs)) || (this.export_type.equals(this.Export_Trans)) || (this.export_type.equals(this.Export_One_Folder)))
/*     */     {
/* 489 */       realoutfilename = buildFilename(realoutfilename);
/*     */     }
/* 491 */     this.NrErrors = 0;
/* 492 */     this.successConditionBroken = false;
/* 493 */     this.limitErr = Const.toInt(environmentSubstitute(getNrLimit()), 10);
/*     */     
/*     */     try
/*     */     {
/* 497 */       this.file = KettleVFS.getFileObject(realoutfilename, this);
/* 498 */       Object parentFolder; if (this.file.exists())
/*     */       {
/* 500 */         if ((this.export_type.equals(this.Export_All)) || (this.export_type.equals(this.Export_Jobs)) || (this.export_type.equals(this.Export_Trans)) || (this.export_type.equals(this.Export_One_Folder)))
/*     */         {
/*     */           Result localResult1;
/* 503 */           if (this.iffileexists.equals(this.If_FileExists_Fail))
/*     */           {
/* 505 */             logError(BaseMessages.getString(PKG, "JobExportRepository.Log.Failing", new String[] { realoutfilename }));
/* 506 */             return result; }
/* 507 */           if (this.iffileexists.equals(this.If_FileExists_Skip))
/*     */           {
/* 509 */             if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.Exit", new String[] { realoutfilename }));
/* 510 */             result.setResult(true);
/* 511 */             result.setNrErrors(0L);
/* 512 */             return result; }
/* 513 */           if (this.iffileexists.equals(this.If_FileExists_Uniquename))
/*     */           {
/* 515 */             parentFolder = KettleVFS.getFilename(this.file.getParent());
/* 516 */             String shortFilename = this.file.getName().getBaseName();
/* 517 */             shortFilename = buildUniqueFilename(shortFilename);
/* 518 */             this.file = KettleVFS.getFileObject((String)parentFolder + Const.FILE_SEPARATOR + shortFilename, this);
/* 519 */             if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.NewFilename", new String[] { this.file.toString() }));
/*     */           }
/* 521 */         } else if (this.export_type.equals(this.Export_By_Folder))
/*     */         {
/* 523 */           if (this.file.getType() != FileType.FOLDER)
/*     */           {
/* 525 */             logError(BaseMessages.getString(PKG, "JobExportRepository.Log.NotFolder", new String[] { "" + this.file.getName() }));
/* 526 */             return result;
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 531 */       else if (this.export_type.equals(this.Export_By_Folder))
/*     */       {
/*     */ 
/* 534 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.FolderNotExists", new String[] { "" + this.file.getName() }));
/* 535 */         if (!this.createfolder)
/*     */         {
/* 537 */           return result;
/*     */         }
/* 539 */         this.file.createFolder();
/* 540 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.FolderCreated", new String[] { this.file.toString() }));
/* 541 */       } else if ((this.export_type.equals(this.Export_All)) || (this.export_type.equals(this.Export_Jobs)) || (this.export_type.equals(this.Export_Trans)) || (this.export_type.equals(this.Export_One_Folder)))
/*     */       {
/*     */ 
/*     */ 
/* 545 */         if (!this.file.getParent().exists())
/*     */         {
/* 547 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.FolderNotExists", new String[] { "" + this.file.getParent().toString() }));
/* 548 */           if (this.createfolder)
/*     */           {
/* 550 */             this.file.getParent().createFolder();
/* 551 */             if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.FolderCreated", new String[] { this.file.getParent().toString() }));
/*     */           }
/*     */           else {
/* 554 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 560 */       realoutfilename = KettleVFS.getFilename(this.file);
/*     */       
/*     */ 
/* 563 */       connectRep(this.log, realrepName, realusername, realpassword);
/*     */       
/* 565 */       IRepositoryExporter exporter = this.repository.getExporter();
/*     */       
/* 567 */       if (this.export_type.equals(this.Export_All))
/*     */       {
/* 569 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.StartingExportAllRep", new String[] { realoutfilename }));
/* 570 */         exporter.exportAllObjects(null, realoutfilename, null, "all");
/* 571 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.EndExportAllRep", new String[] { realoutfilename }));
/*     */         }
/* 573 */         if (this.add_result_filesname) addFileToResultFilenames(realoutfilename, this.log, result, this.parentJob);
/*     */       }
/* 575 */       else if (this.export_type.equals(this.Export_Jobs))
/*     */       {
/* 577 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.StartingExportJobsRep", new String[] { realoutfilename }));
/* 578 */         exporter.exportAllObjects(null, realoutfilename, null, "jobs");
/* 579 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.EndExportJobsRep", new String[] { realoutfilename }));
/*     */         }
/* 581 */         if (this.add_result_filesname) addFileToResultFilenames(realoutfilename, this.log, result, this.parentJob);
/*     */       }
/* 583 */       else if (this.export_type.equals(this.Export_Trans))
/*     */       {
/* 585 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.StartingExportTransRep", new String[] { realoutfilename }));
/* 586 */         exporter.exportAllObjects(null, realoutfilename, null, "trans");
/* 587 */         if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.EndExportTransRep", new String[] { realoutfilename }));
/*     */         }
/* 589 */         if (this.add_result_filesname) addFileToResultFilenames(realoutfilename, this.log, result, this.parentJob);
/*     */       }
/* 591 */       else if (this.export_type.equals(this.Export_One_Folder))
/*     */       {
/* 593 */         RepositoryDirectoryInterface directory = new RepositoryDirectory();
/* 594 */         directory = this.repository.findDirectory(realfoldername);
/* 595 */         if (directory != null)
/*     */         {
/* 597 */           if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.ExpAllFolderRep", new String[] { this.directoryPath, realoutfilename }));
/* 598 */           exporter.exportAllObjects(null, realoutfilename, directory, "all");
/* 599 */           if (this.log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.EndExpAllFolderRep", new String[] { this.directoryPath, realoutfilename }));
/*     */           }
/* 601 */           if (this.add_result_filesname) addFileToResultFilenames(realoutfilename, this.log, result, this.parentJob);
/*     */         }
/*     */         else {
/* 604 */           logError(BaseMessages.getString(PKG, "JobExportRepository.Error.CanNotFindFolderInRep", new String[] { realfoldername, realrepName }));
/* 605 */           return result;
/*     */         }
/*     */       }
/* 608 */       else if (this.export_type.equals(this.Export_By_Folder))
/*     */       {
/*     */ 
/*     */ 
/* 612 */         RepositoryDirectoryInterface directory = new RepositoryDirectory();
/* 613 */         directory = this.repository.loadRepositoryDirectoryTree().findRoot();
/*     */         
/* 615 */         ObjectId[] dirids = directory.getDirectoryIDs();
/* 616 */         if (this.log.isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.TotalFolders", new String[] { "" + dirids.length }));
/* 617 */         for (int d = 0; (d < dirids.length) && (!this.parentJob.isStopped()); d++)
/*     */         {
/*     */ 
/* 620 */           if (this.successConditionBroken)
/*     */           {
/* 622 */             logError(BaseMessages.getString(PKG, "JobExportRepository.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/* 623 */             throw new Exception(BaseMessages.getString(PKG, "JobExportRepository.Error.SuccessConditionbroken", new String[] { "" + this.NrErrors }));
/*     */           }
/*     */           
/* 626 */           RepositoryDirectoryInterface repdir = directory.findDirectory(dirids[d]);
/* 627 */           if (!processOneFolder(this.parentJob, result, this.log, repdir, realoutfilename, d, dirids.length))
/*     */           {
/*     */ 
/* 630 */             updateErrors();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 637 */       updateErrors();
/* 638 */       logError(BaseMessages.getString(PKG, "JobExportRepository.UnExpectedError", new String[] { e.toString() }));
/* 639 */       logError("Stack trace: " + Const.CR + Const.getStackTracker(e));
/*     */     }
/*     */     finally {
/* 642 */       if (this.repository != null)
/*     */       {
/* 644 */         this.repository.disconnect();
/* 645 */         this.repository = null;
/*     */       }
/* 647 */       if (this.repositoryMeta != null) this.repositoryMeta = null;
/* 648 */       if (this.repsinfo != null)
/*     */       {
/* 650 */         this.repsinfo.clear();
/* 651 */         this.repsinfo = null;
/*     */       }
/* 653 */       if (this.file != null) {
/* 654 */         try { this.file.close();
/* 655 */           this.file = null;
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/* 660 */     result.setNrErrors(this.NrErrors);
/* 661 */     if (getSuccessStatus()) { result.setResult(true);
/*     */     }
/* 663 */     return result;
/*     */   }
/*     */   
/*     */   private boolean getSuccessStatus() {
/* 667 */     boolean retval = false;
/*     */     
/* 669 */     if (((this.NrErrors == 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors <= this.limitErr) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/* 671 */       retval = true;
/*     */     }
/*     */     
/* 674 */     return retval;
/*     */   }
/*     */   
/*     */   private void updateErrors() {
/* 678 */     this.NrErrors += 1;
/* 679 */     if (checkIfSuccessConditionBroken())
/*     */     {
/*     */ 
/* 682 */       this.successConditionBroken = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean processOneFolder(Job parentJob, Result result, LogChannelInterface log, RepositoryDirectoryInterface repdir, String realoutfilename, int folderno, int totalfolders)
/*     */   {
/* 688 */     boolean retval = false;
/*     */     try {
/* 690 */       if (!repdir.isRoot())
/*     */       {
/* 692 */         if (repdir.toString().lastIndexOf("/") == 0)
/*     */         {
/* 694 */           String filename = repdir.toString().replace("/", "");
/* 695 */           String foldername = realoutfilename;
/* 696 */           if (this.newfolder)
/*     */           {
/* 698 */             foldername = realoutfilename + Const.FILE_SEPARATOR + filename;
/* 699 */             this.file = KettleVFS.getFileObject(foldername, this);
/* 700 */             if (!this.file.exists())
/*     */             {
/* 702 */               this.file.createFolder();
/*     */             }
/*     */           }
/*     */           
/* 706 */           filename = foldername + Const.FILE_SEPARATOR + buildFilename(filename) + ".xml";
/* 707 */           this.file = KettleVFS.getFileObject(filename, this);
/*     */           
/* 709 */           if (this.file.exists())
/*     */           {
/* 711 */             if (this.iffileexists.equals(this.If_FileExists_Skip))
/*     */             {
/* 713 */               return true; }
/* 714 */             if (this.iffileexists.equals(this.If_FileExists_Uniquename)) {
/* 715 */               filename = realoutfilename + Const.FILE_SEPARATOR + buildUniqueFilename(filename) + ".xml";
/* 716 */             } else if (this.iffileexists.equals(this.If_FileExists_Fail))
/*     */             {
/* 718 */               return false;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 723 */           if (log.isDetailed())
/*     */           {
/* 725 */             logDetailed("---");
/* 726 */             logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.FolderProcessing", new String[] { "" + folderno, "" + totalfolders }));
/* 727 */             logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.OutFilename", new String[] { repdir.toString(), filename }));
/*     */           }
/*     */           
/* 730 */           new RepositoryExporter(this.repository).exportAllObjects(null, filename, repdir, "all");
/* 731 */           if (log.isDetailed()) { logDetailed(BaseMessages.getString(PKG, "JobExportRepository.Log.OutFilenameEnd", new String[] { repdir.toString(), filename }));
/*     */           }
/* 733 */           if (this.add_result_filesname) { addFileToResultFilenames(filename, log, result, parentJob);
/*     */           }
/*     */         }
/*     */       }
/* 737 */       retval = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 741 */       updateErrors();
/* 742 */       logError(BaseMessages.getString(PKG, "JobExportRepository.ErrorExportingFolder", new String[] { repdir.toString(), e.toString() }));
/*     */     }
/* 744 */     return retval;
/*     */   }
/*     */   
/*     */   private boolean checkIfSuccessConditionBroken() {
/* 748 */     boolean retval = false;
/* 749 */     if (((this.NrErrors > 0) && (getSuccessCondition().equals(this.SUCCESS_IF_NO_ERRORS))) || ((this.NrErrors >= this.limitErr) && (getSuccessCondition().equals(this.SUCCESS_IF_ERRORS_LESS))))
/*     */     {
/*     */ 
/* 752 */       retval = true;
/*     */     }
/* 754 */     return retval;
/*     */   }
/*     */   
/*     */   private void connectRep(LogChannelInterface log, String realrepName, String realusername, String realpassword) throws Exception {
/* 758 */     this.repsinfo = new RepositoriesMeta();
/*     */     try {
/* 760 */       this.repsinfo.readData();
/*     */     } catch (Exception e) {
/* 762 */       logError(BaseMessages.getString(PKG, "JobExportRepository.Error.NoRep", new String[0]));
/* 763 */       throw new Exception(BaseMessages.getString(PKG, "JobExportRepository.Error.NoRep", new String[0]));
/*     */     }
/* 765 */     this.repositoryMeta = this.repsinfo.findRepository(realrepName);
/* 766 */     if (this.repositoryMeta == null)
/*     */     {
/* 768 */       logError(BaseMessages.getString(PKG, "JobExportRepository.Error.NoRepSystem", new String[0]));
/* 769 */       throw new Exception(BaseMessages.getString(PKG, "JobExportRepository.Error.NoRepSystem", new String[0]));
/*     */     }
/*     */     
/* 772 */     this.repository = ((Repository)PluginRegistry.getInstance().loadClass(RepositoryPluginType.class, this.repositoryMeta, Repository.class));
/* 773 */     this.repository.init(this.repositoryMeta);
/*     */     try
/*     */     {
/* 776 */       this.repository.connect(realusername, realpassword);
/*     */     } catch (Exception e) {
/* 778 */       logError(BaseMessages.getString(PKG, "JobExportRepository.Error.CanNotConnectRep", new String[0]));
/* 779 */       throw new Exception(BaseMessages.getString(PKG, "JobExportRepository.Error.CanNotConnectRep", new String[0]), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addFileToResultFilenames(String fileaddentry, LogChannelInterface log, Result result, Job parentJob)
/*     */   {
/*     */     try {
/* 786 */       ResultFile resultFile = new ResultFile(0, KettleVFS.getFileObject(fileaddentry, this), parentJob.getJobname(), toString());
/* 787 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/* 788 */       if (log.isDebug()) logDebug(BaseMessages.getString(PKG, "JobExportRepository.Log.FileAddedToResultFilesName", new String[] { fileaddentry }));
/*     */     }
/*     */     catch (Exception e) {
/* 791 */       log.logError(BaseMessages.getString(PKG, "JobExportRepository.Error.AddingToFilenameResult", new String[0]), new Object[] { fileaddentry + "" + e.getMessage() });
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 796 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 802 */     JobEntryValidatorUtils.andValidator().validate(this, "repositoryname", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/*     */     
/* 804 */     ValidatorContext ctx = new ValidatorContext();
/* 805 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 806 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 807 */     JobEntryValidatorUtils.andValidator().validate(this, "targetfilename", remarks, ctx);
/*     */     
/* 809 */     JobEntryValidatorUtils.andValidator().validate(this, "username", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notBlankValidator() }));
/* 810 */     JobEntryValidatorUtils.andValidator().validate(this, "password", remarks, AndValidator.putValidators(new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator() }));
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 814 */     List<CheckResultInterface> remarks = new ArrayList();
/* 815 */     new JobEntrySFTP().check(remarks, null);
/* 816 */     System.out.printf("Remarks: %s\n", new Object[] { remarks });
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\exportrepository\JobEntryExportRepository.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */