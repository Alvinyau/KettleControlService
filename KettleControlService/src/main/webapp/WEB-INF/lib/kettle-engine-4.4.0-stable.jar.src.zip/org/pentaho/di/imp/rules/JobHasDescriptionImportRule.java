/*     */ package org.pentaho.di.imp.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.pentaho.di.imp.rule.ImportValidationFeedback;
/*     */ import org.pentaho.di.imp.rule.ImportValidationResultType;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobHasDescriptionImportRule
/*     */   extends BaseImportRule
/*     */   implements ImportRuleInterface
/*     */ {
/*     */   private int minLength;
/*     */   
/*     */   public JobHasDescriptionImportRule()
/*     */   {
/*  44 */     this.minLength = 20;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  49 */     if (this.minLength > 0) {
/*  50 */       return super.toString() + " The minimum length is " + this.minLength;
/*     */     }
/*  52 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<ImportValidationFeedback> verifyRule(Object subject)
/*     */   {
/*  59 */     List<ImportValidationFeedback> feedback = new ArrayList();
/*     */     
/*  61 */     if (!isEnabled()) return feedback;
/*  62 */     if (!(subject instanceof JobMeta)) { return feedback;
/*     */     }
/*  64 */     JobMeta transMeta = (JobMeta)subject;
/*  65 */     String description = transMeta.getDescription();
/*     */     
/*  67 */     if ((description != null) && (description.length() > this.minLength)) {
/*  68 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.APPROVAL, "A description is present"));
/*     */     } else {
/*  70 */       feedback.add(new ImportValidationFeedback(this, ImportValidationResultType.ERROR, "A description is not present or too short"));
/*     */     }
/*     */     
/*  73 */     return feedback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMinLength()
/*     */   {
/*  80 */     return this.minLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMinLength(int minLength)
/*     */   {
/*  87 */     this.minLength = minLength;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getXML()
/*     */   {
/*  93 */     StringBuilder xml = new StringBuilder();
/*  94 */     xml.append(XMLHandler.openTag(XML_TAG));
/*     */     
/*  96 */     xml.append(super.getXML());
/*     */     
/*  98 */     xml.append(XMLHandler.addTagValue("min_length", this.minLength));
/*     */     
/* 100 */     xml.append(XMLHandler.closeTag(XML_TAG));
/* 101 */     return xml.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node ruleNode) throws KettleException
/*     */   {
/* 106 */     super.loadXML(ruleNode);
/*     */     
/* 108 */     this.minLength = Const.toInt(XMLHandler.getTagValue(ruleNode, "min_length"), 0);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\imp\rules\JobHasDescriptionImportRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */