/*     */ package org.pentaho.di.job.entries.dostounix;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.vfs.AllFileSelector;
/*     */ import org.apache.commons.vfs.FileName;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.apache.commons.vfs.FileSelectInfo;
/*     */ import org.apache.commons.vfs.FileType;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.ResultFile;
/*     */ import org.pentaho.di.core.RowMetaAndData;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.Job;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDosToUnix
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*     */   private static final int LF = 10;
/*     */   private static final int CR = 13;
/*  70 */   private static Class<?> PKG = JobEntryDosToUnix.class;
/*     */   
/*  72 */   public static final String[] ConversionTypeDesc = { BaseMessages.getString(PKG, "JobEntryDosToUnix.ConversionType.Guess.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryDosToUnix.ConversionType.DosToUnix.Label", new String[0]), BaseMessages.getString(PKG, "JobEntryDosToUnix.ConversionType.UnixToDos.Label", new String[0]) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   public static final String[] ConversionTypeCode = { "guess", "dostounix", "unixtodos" };
/*     */   
/*     */   public static final int CONVERTION_TYPE_GUESS = 0;
/*     */   
/*     */   public static final int CONVERTION_TYPE_DOS_TO_UNIX = 1;
/*     */   
/*     */   public static final int CONVERTION_TYPE_UNIX_TO_DOS = 2;
/*     */   
/*     */   private static final int TYPE_DOS_FILE = 0;
/*     */   
/*     */   private static final int TYPE_UNIX_FILE = 1;
/*     */   
/*     */   private static final int TYPE_BINAY_FILE = 2;
/*     */   
/*     */   public static final String ADD_NOTHING = "nothing";
/*     */   
/*     */   public static final String SUCCESS_IF_AT_LEAST_X_FILES_PROCESSED = "success_when_at_least";
/*     */   
/*     */   public static final String SUCCESS_IF_ERROR_FILES_LESS = "success_if_error_files_less";
/*     */   
/*     */   public static final String SUCCESS_IF_NO_ERRORS = "success_if_no_errors";
/*     */   
/*     */   public static final String ADD_ALL_FILENAMES = "all_filenames";
/*     */   
/*     */   public static final String ADD_PROCESSED_FILES_ONLY = "only_processed_filenames";
/*     */   
/*     */   public static final String ADD_ERROR_FILES_ONLY = "only_error_filenames";
/*     */   
/*     */   public boolean arg_from_previous;
/*     */   public boolean include_subfolders;
/*     */   public String[] source_filefolder;
/*     */   public String[] wildcard;
/*     */   public int[] ConversionTypes;
/*     */   private String nr_errors_less_than;
/*     */   private String success_condition;
/*     */   private String resultfilenames;
/* 113 */   int NrAllErrors = 0;
/* 114 */   int NrErrorFiles = 0;
/* 115 */   int NrProcessedFiles = 0;
/* 116 */   int limitFiles = 0;
/* 117 */   int NrErrors = 0;
/*     */   
/* 119 */   boolean successConditionBroken = false;
/* 120 */   boolean successConditionBrokenExit = false;
/*     */   
/*     */   private static String tempFolder;
/*     */   
/*     */   public JobEntryDosToUnix(String n)
/*     */   {
/* 126 */     super(n, "");
/* 127 */     this.resultfilenames = "all_filenames";
/* 128 */     this.arg_from_previous = false;
/* 129 */     this.source_filefolder = null;
/* 130 */     this.ConversionTypes = null;
/* 131 */     this.wildcard = null;
/* 132 */     this.include_subfolders = false;
/* 133 */     this.nr_errors_less_than = "10";
/* 134 */     this.success_condition = "success_if_no_errors";
/*     */     
/* 136 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryDosToUnix()
/*     */   {
/* 141 */     this("");
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 147 */     JobEntryDosToUnix je = (JobEntryDosToUnix)super.clone();
/* 148 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/* 153 */     StringBuffer retval = new StringBuffer(300);
/*     */     
/* 155 */     retval.append(super.getXML());
/* 156 */     retval.append("      ").append(XMLHandler.addTagValue("arg_from_previous", this.arg_from_previous));
/* 157 */     retval.append("      ").append(XMLHandler.addTagValue("include_subfolders", this.include_subfolders));
/* 158 */     retval.append("      ").append(XMLHandler.addTagValue("nr_errors_less_than", this.nr_errors_less_than));
/* 159 */     retval.append("      ").append(XMLHandler.addTagValue("success_condition", this.success_condition));
/* 160 */     retval.append("      ").append(XMLHandler.addTagValue("resultfilenames", this.resultfilenames));
/* 161 */     retval.append("      <fields>").append(Const.CR);
/* 162 */     if (this.source_filefolder != null)
/*     */     {
/* 164 */       for (int i = 0; i < this.source_filefolder.length; i++)
/*     */       {
/* 166 */         retval.append("        <field>").append(Const.CR);
/* 167 */         retval.append("          ").append(XMLHandler.addTagValue("source_filefolder", this.source_filefolder[i]));
/* 168 */         retval.append("          ").append(XMLHandler.addTagValue("wildcard", this.wildcard[i]));
/* 169 */         retval.append("          ").append(XMLHandler.addTagValue("ConversionType", getConversionTypeCode(this.ConversionTypes[i])));
/* 170 */         retval.append("        </field>").append(Const.CR);
/*     */       }
/*     */     }
/* 173 */     retval.append("      </fields>").append(Const.CR);
/*     */     
/* 175 */     return retval.toString();
/*     */   }
/*     */   
/* 178 */   private static String getConversionTypeCode(int i) { if ((i < 0) || (i >= ConversionTypeCode.length))
/* 179 */       return ConversionTypeCode[0];
/* 180 */     return ConversionTypeCode[i];
/*     */   }
/*     */   
/* 183 */   public static String getConversionTypeDesc(int i) { if ((i < 0) || (i >= ConversionTypeDesc.length))
/* 184 */       return ConversionTypeDesc[0];
/* 185 */     return ConversionTypeDesc[i];
/*     */   }
/*     */   
/* 188 */   public static int getConversionTypeByDesc(String tt) { if (tt == null) {
/* 189 */       return 0;
/*     */     }
/* 191 */     for (int i = 0; i < ConversionTypeDesc.length; i++) {
/* 192 */       if (ConversionTypeDesc[i].equalsIgnoreCase(tt)) {
/* 193 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 197 */     return getConversionTypeByCode(tt);
/*     */   }
/*     */   
/* 200 */   private static int getConversionTypeByCode(String tt) { if (tt == null) {
/* 201 */       return 0;
/*     */     }
/* 203 */     for (int i = 0; i < ConversionTypeCode.length; i++) {
/* 204 */       if (ConversionTypeCode[i].equalsIgnoreCase(tt))
/* 205 */         return i;
/*     */     }
/* 207 */     return 0;
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 214 */       super.loadXML(entrynode, databases, slaveServers);
/*     */       
/* 216 */       this.arg_from_previous = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "arg_from_previous"));
/* 217 */       this.include_subfolders = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "include_subfolders"));
/*     */       
/* 219 */       this.nr_errors_less_than = XMLHandler.getTagValue(entrynode, "nr_errors_less_than");
/* 220 */       this.success_condition = XMLHandler.getTagValue(entrynode, "success_condition");
/* 221 */       this.resultfilenames = XMLHandler.getTagValue(entrynode, "resultfilenames");
/*     */       
/*     */ 
/* 224 */       Node fields = XMLHandler.getSubNode(entrynode, "fields");
/*     */       
/*     */ 
/* 227 */       int nrFields = XMLHandler.countNodes(fields, "field");
/* 228 */       this.source_filefolder = new String[nrFields];
/* 229 */       this.wildcard = new String[nrFields];
/* 230 */       this.ConversionTypes = new int[nrFields];
/*     */       
/*     */ 
/* 233 */       for (int i = 0; i < nrFields; i++)
/*     */       {
/* 235 */         Node fnode = XMLHandler.getSubNodeByNr(fields, "field", i);
/*     */         
/* 237 */         this.source_filefolder[i] = XMLHandler.getTagValue(fnode, "source_filefolder");
/* 238 */         this.wildcard[i] = XMLHandler.getTagValue(fnode, "wildcard");
/* 239 */         this.ConversionTypes[i] = getConversionTypeByCode(Const.NVL(XMLHandler.getTagValue(fnode, "ConversionType"), ""));
/*     */       }
/*     */       
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 245 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobDosToUnix.Error.Exception.UnableLoadXML", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 253 */       this.arg_from_previous = rep.getJobEntryAttributeBoolean(id_jobentry, "arg_from_previous");
/* 254 */       this.include_subfolders = rep.getJobEntryAttributeBoolean(id_jobentry, "include_subfolders");
/*     */       
/* 256 */       this.nr_errors_less_than = rep.getJobEntryAttributeString(id_jobentry, "nr_errors_less_than");
/* 257 */       this.success_condition = rep.getJobEntryAttributeString(id_jobentry, "success_condition");
/* 258 */       this.resultfilenames = rep.getJobEntryAttributeString(id_jobentry, "resultfilenames");
/*     */       
/*     */ 
/* 261 */       int argnr = rep.countNrJobEntryAttributes(id_jobentry, "source_filefolder");
/* 262 */       this.source_filefolder = new String[argnr];
/* 263 */       this.wildcard = new String[argnr];
/* 264 */       this.ConversionTypes = new int[argnr];
/*     */       
/* 266 */       for (int a = 0; a < argnr; a++)
/*     */       {
/* 268 */         this.source_filefolder[a] = rep.getJobEntryAttributeString(id_jobentry, a, "source_filefolder");
/* 269 */         this.wildcard[a] = rep.getJobEntryAttributeString(id_jobentry, a, "wildcard");
/* 270 */         this.ConversionTypes[a] = getConversionTypeByCode(Const.NVL(rep.getJobEntryAttributeString(id_jobentry, "ConversionType"), ""));
/*     */       }
/*     */       
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 276 */       throw new KettleException(BaseMessages.getString(PKG, "JobDosToUnix.Error.Exception.UnableLoadRep", new String[0]) + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 284 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "arg_from_previous", this.arg_from_previous);
/* 285 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "include_subfolders", this.include_subfolders);
/* 286 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "nr_errors_less_than", this.nr_errors_less_than);
/* 287 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "success_condition", this.success_condition);
/* 288 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "resultfilenames", this.resultfilenames);
/*     */       
/*     */ 
/* 291 */       if (this.source_filefolder != null)
/*     */       {
/* 293 */         for (int i = 0; i < this.source_filefolder.length; i++)
/*     */         {
/* 295 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "source_filefolder", this.source_filefolder[i]);
/* 296 */           rep.saveJobEntryAttribute(id_job, getObjectId(), i, "wildcard", this.wildcard[i]);
/* 297 */           rep.saveJobEntryAttribute(id_job, getObjectId(), "ConversionType", getConversionTypeCode(this.ConversionTypes[i]));
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 304 */       throw new KettleException(BaseMessages.getString(PKG, "JobDosToUnix.Error.Exception.UnableSaveRep", new String[0]) + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr) throws KettleException
/*     */   {
/* 310 */     Result result = previousResult;
/* 311 */     result.setNrErrors(1L);
/* 312 */     result.setResult(false);
/*     */     
/* 314 */     List<RowMetaAndData> rows = previousResult.getRows();
/* 315 */     RowMetaAndData resultRow = null;
/*     */     
/* 317 */     this.NrErrors = 0;
/* 318 */     this.NrProcessedFiles = 0;
/* 319 */     this.NrErrorFiles = 0;
/* 320 */     this.limitFiles = Const.toInt(environmentSubstitute(getNrErrorsLessThan()), 10);
/* 321 */     this.successConditionBroken = false;
/* 322 */     this.successConditionBrokenExit = false;
/* 323 */     tempFolder = environmentSubstitute("%%java.io.tmpdir%%");
/*     */     
/*     */ 
/* 326 */     String[] vsourcefilefolder = this.source_filefolder;
/* 327 */     String[] vwildcard = this.wildcard;
/*     */     
/* 329 */     if (this.arg_from_previous)
/*     */     {
/* 331 */       if (isDetailed()) {
/* 332 */         logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.ArgFromPrevious.Found", new String[] { (rows != null ? rows.size() : 0) + "" }));
/*     */       }
/*     */     }
/* 335 */     if ((this.arg_from_previous) && (rows != null))
/*     */     {
/* 337 */       for (int iteration = 0; (iteration < rows.size()) && (!this.parentJob.isStopped()); iteration++)
/*     */       {
/* 339 */         if (this.successConditionBroken)
/*     */         {
/* 341 */           if (!this.successConditionBrokenExit)
/*     */           {
/* 343 */             logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.SuccessConditionbroken", new String[] { "" + this.NrAllErrors }));
/* 344 */             this.successConditionBrokenExit = true;
/*     */           }
/* 346 */           result.setEntryNr(this.NrAllErrors);
/* 347 */           result.setNrLinesRejected(this.NrErrorFiles);
/* 348 */           result.setNrLinesWritten(this.NrProcessedFiles);
/* 349 */           return result;
/*     */         }
/*     */         
/* 352 */         resultRow = (RowMetaAndData)rows.get(iteration);
/*     */         
/*     */ 
/* 355 */         String vsourcefilefolder_previous = resultRow.getString(0, null);
/* 356 */         String vwildcard_previous = resultRow.getString(1, null);
/* 357 */         int convertion_type = getConversionTypeByCode(resultRow.getString(2, null));
/*     */         
/* 359 */         if (isDetailed()) {
/* 360 */           logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.ProcessingRow", new String[] { vsourcefilefolder_previous, vwildcard_previous }));
/*     */         }
/* 362 */         ProcessFileFolder(vsourcefilefolder_previous, vwildcard_previous, convertion_type, this.parentJob, result);
/*     */       }
/*     */       
/* 365 */     } else if (vsourcefilefolder != null)
/*     */     {
/* 367 */       for (int i = 0; (i < vsourcefilefolder.length) && (!this.parentJob.isStopped()); i++)
/*     */       {
/* 369 */         if (this.successConditionBroken)
/*     */         {
/* 371 */           if (!this.successConditionBrokenExit)
/*     */           {
/* 373 */             logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.SuccessConditionbroken", new String[] { "" + this.NrAllErrors }));
/* 374 */             this.successConditionBrokenExit = true;
/*     */           }
/* 376 */           result.setEntryNr(this.NrAllErrors);
/* 377 */           result.setNrLinesRejected(this.NrErrorFiles);
/* 378 */           result.setNrLinesWritten(this.NrProcessedFiles);
/* 379 */           return result;
/*     */         }
/*     */         
/* 382 */         if (isDetailed()) {
/* 383 */           logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.ProcessingRow", new String[] { vsourcefilefolder[i], vwildcard[i] }));
/*     */         }
/* 385 */         ProcessFileFolder(vsourcefilefolder[i], vwildcard[i], this.ConversionTypes[i], this.parentJob, result);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 391 */     result.setNrErrors(this.NrAllErrors);
/* 392 */     result.setNrLinesRejected(this.NrErrorFiles);
/* 393 */     result.setNrLinesWritten(this.NrProcessedFiles);
/* 394 */     if (getSuccessStatus())
/*     */     {
/* 396 */       result.setNrErrors(0L);
/* 397 */       result.setResult(true);
/*     */     }
/*     */     
/* 400 */     displayResults();
/*     */     
/* 402 */     return result;
/*     */   }
/*     */   
/*     */   private void displayResults() {
/* 406 */     if (isDetailed())
/*     */     {
/* 408 */       logDetailed("=======================================");
/* 409 */       logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.Info.Errors", new Object[] { Integer.valueOf(this.NrErrors) }));
/* 410 */       logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.Info.ErrorFiles", new Object[] { Integer.valueOf(this.NrErrorFiles) }));
/* 411 */       logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.Info.FilesProcessed", new Object[] { Integer.valueOf(this.NrProcessedFiles) }));
/* 412 */       logDetailed("=======================================");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkIfSuccessConditionBroken()
/*     */   {
/* 418 */     boolean retval = false;
/* 419 */     if (((this.NrAllErrors > 0) && (getSuccessCondition().equals("success_if_no_errors"))) || ((this.NrErrorFiles >= this.limitFiles) && (getSuccessCondition().equals("success_if_error_files_less"))))
/*     */     {
/*     */ 
/* 422 */       retval = true;
/*     */     }
/* 424 */     return retval;
/*     */   }
/*     */   
/*     */   private boolean getSuccessStatus() {
/* 428 */     boolean retval = false;
/*     */     
/* 430 */     if (((this.NrAllErrors == 0) && (getSuccessCondition().equals("success_if_no_errors"))) || ((this.NrProcessedFiles >= this.limitFiles) && (getSuccessCondition().equals("success_when_at_least"))) || ((this.NrErrorFiles < this.limitFiles) && (getSuccessCondition().equals("success_if_error_files_less"))))
/*     */     {
/*     */ 
/*     */ 
/* 434 */       retval = true;
/*     */     }
/*     */     
/* 437 */     return retval;
/*     */   }
/*     */   
/*     */   private void updateErrors() {
/* 441 */     this.NrErrors += 1;
/* 442 */     updateAllErrors();
/* 443 */     if (checkIfSuccessConditionBroken())
/*     */     {
/*     */ 
/* 446 */       this.successConditionBroken = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 451 */   private void updateAllErrors() { this.NrAllErrors = (this.NrErrors + this.NrErrorFiles); }
/*     */   
/*     */   private static int getFileType(FileObject file) throws Exception {
/* 454 */     int aCount = 0;
/* 455 */     int dCount = 0;
/* 456 */     FileInputStream in = new FileInputStream(file.getName().getPathDecoded());
/* 457 */     while (in.available() > 0) {
/* 458 */       int b = in.read();
/* 459 */       if (b == 13) {
/* 460 */         dCount++;
/* 461 */         if (in.available() > 0) {
/* 462 */           b = in.read();
/* 463 */           if (b == 10) {
/* 464 */             aCount++;
/*     */           } else {
/* 466 */             return 2;
/*     */           }
/*     */         }
/*     */       }
/* 470 */       else if (b == 10) {
/* 471 */         aCount++;
/*     */       }
/*     */     }
/* 474 */     in.close();
/* 475 */     if (aCount == dCount) {
/* 476 */       return 0;
/*     */     }
/* 478 */     return 1;
/*     */   }
/*     */   
/*     */   private boolean convert(FileObject file, boolean toUnix)
/*     */   {
/* 483 */     boolean retval = false;
/*     */     
/*     */     try
/*     */     {
/* 487 */       String localfilename = KettleVFS.getFilename(file);
/* 488 */       File source = new File(localfilename);
/* 489 */       if (isDetailed()) {
/* 490 */         if (toUnix) {
/* 491 */           logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.ConvertingFileToUnix", new String[] { source.getAbsolutePath() }));
/*     */         } else {
/* 493 */           logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.ConvertingFileToDos", new String[] { source.getAbsolutePath() }));
/*     */         }
/*     */       }
/* 496 */       File tempFile = new File(tempFolder, source.getName() + ".tmp");
/*     */       
/* 498 */       if (isDebug()) {
/* 499 */         logDebug(BaseMessages.getString(PKG, "JobDosToUnix.Log.CreatingTempFile", new String[] { tempFile.getAbsolutePath() }));
/*     */       }
/* 501 */       FileOutputStream out = new FileOutputStream(tempFile);
/* 502 */       FileInputStream in = new FileInputStream(localfilename);
/*     */       
/* 504 */       if (toUnix)
/*     */       {
/* 506 */         while (in.available() > 0) {
/* 507 */           int b1 = in.read();
/* 508 */           if (b1 == 13) {
/* 509 */             int b2 = in.read();
/* 510 */             if (b2 == 10) {
/* 511 */               out.write(10);
/*     */             } else {
/* 513 */               out.write(b1);
/* 514 */               out.write(b2);
/*     */             }
/*     */           } else {
/* 517 */             out.write(b1);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 522 */       while (in.available() > 0) {
/* 523 */         int b1 = in.read();
/* 524 */         if (b1 == 13) {
/* 525 */           boolean b = true;
/* 526 */           while (b) {
/* 527 */             if (in.available() > 0) {
/* 528 */               int b2 = in.read();
/* 529 */               if (b2 != 13) {
/* 530 */                 b = false;
/*     */               }
/*     */             } else {
/* 533 */               b = false;
/*     */             }
/*     */           }
/* 536 */           out.write(13);
/* 537 */           out.write(10);
/*     */         } else {
/* 539 */           out.write(b1);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 544 */       in.close();
/* 545 */       out.close();
/*     */       
/*     */ 
/* 548 */       if (isDebug()) {
/* 549 */         logDebug(BaseMessages.getString(PKG, "JobDosToUnix.Log.DeletingSourceFile", new String[] { localfilename }));
/*     */       }
/* 551 */       file.delete();
/* 552 */       if (isDebug()) {
/* 553 */         logDebug(BaseMessages.getString(PKG, "JobDosToUnix.Log.RenamingTempFile", new String[] { tempFile.getAbsolutePath(), source.getAbsolutePath() }));
/*     */       }
/* 555 */       tempFile.renameTo(source);
/*     */       
/* 557 */       retval = true;
/*     */     }
/*     */     catch (Exception e) {
/* 560 */       logError(BaseMessages.getString(PKG, "JobDosToUnix.Log.ErrorConvertingFile", new String[] { file.toString(), e.getMessage() }));
/*     */     }
/*     */     
/* 563 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean ProcessFileFolder(String sourcefilefoldername, String wildcard, int convertion, Job parentJob, Result result)
/*     */   {
/* 569 */     boolean entrystatus = false;
/* 570 */     FileObject sourcefilefolder = null;
/* 571 */     FileObject CurrentFile = null;
/*     */     
/*     */ 
/* 574 */     String realSourceFilefoldername = environmentSubstitute(sourcefilefoldername);
/* 575 */     if (Const.isEmpty(realSourceFilefoldername)) {
/* 576 */       logError(BaseMessages.getString(PKG, "JobDosToUnix.log.FileFolderEmpty", new String[] { sourcefilefoldername }));
/*     */       
/* 578 */       updateErrors();
/*     */       
/* 580 */       return entrystatus;
/*     */     }
/* 582 */     String realWildcard = environmentSubstitute(wildcard);
/*     */     try
/*     */     {
/* 585 */       sourcefilefolder = KettleVFS.getFileObject(realSourceFilefoldername);
/*     */       
/* 587 */       if (sourcefilefolder.exists()) {
/* 588 */         if (isDetailed()) logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.FileExists", new String[] { sourcefilefolder.toString() }));
/* 589 */         if (sourcefilefolder.getType() == FileType.FILE) {
/* 590 */           entrystatus = convertOneFile(sourcefilefolder, convertion, result, parentJob);
/*     */         }
/* 592 */         else if (sourcefilefolder.getType() == FileType.FOLDER) {
/* 593 */           FileObject[] fileObjects = sourcefilefolder.findFiles(new AllFileSelector()
/*     */           {
/*     */ 
/*     */             public boolean traverseDescendents(FileSelectInfo info)
/*     */             {
/* 598 */               return (info.getDepth() == 0) || (JobEntryDosToUnix.this.include_subfolders);
/*     */             }
/*     */             
/*     */ 
/*     */             public boolean includeFile(FileSelectInfo info)
/*     */             {
/* 604 */               FileObject fileObject = info.getFile();
/*     */               try { boolean bool1;
/* 606 */                 if (fileObject == null) return false;
/* 607 */                 if (fileObject.getType() != FileType.FILE) { return false;
/*     */                 }
/*     */               }
/*     */               catch (Exception ex)
/*     */               {
/* 612 */                 return false;
/*     */ 
/*     */               }
/*     */               finally
/*     */               {
/* 617 */                 if (fileObject != null) {
/*     */                   try {
/* 619 */                     fileObject.close();
/*     */                   } catch (IOException ex) {}
/*     */                 }
/*     */               }
/* 623 */               return true;
/*     */             }
/*     */           });
/*     */           
/*     */ 
/* 628 */           if (fileObjects != null)
/*     */           {
/* 630 */             for (int j = 0; (j < fileObjects.length) && (!parentJob.isStopped()); j++)
/*     */             {
/* 632 */               if (this.successConditionBroken)
/*     */               {
/* 634 */                 if (!this.successConditionBrokenExit)
/*     */                 {
/* 636 */                   logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.SuccessConditionbroken", new String[] { "" + this.NrAllErrors }));
/* 637 */                   this.successConditionBrokenExit = true;
/*     */                 }
/* 639 */                 return false;
/*     */               }
/*     */               
/* 642 */               CurrentFile = fileObjects[j];
/*     */               
/* 644 */               if (!CurrentFile.getParent().toString().equals(sourcefilefolder.toString()))
/*     */               {
/*     */ 
/* 647 */                 if (this.include_subfolders)
/*     */                 {
/* 649 */                   if (GetFileWildcard(CurrentFile.toString(), realWildcard))
/*     */                   {
/* 651 */                     convertOneFile(CurrentFile, convertion, result, parentJob);
/*     */                   }
/*     */                   
/*     */                 }
/*     */                 
/*     */ 
/*     */               }
/* 658 */               else if (GetFileWildcard(CurrentFile.toString(), realWildcard))
/*     */               {
/* 660 */                 convertOneFile(CurrentFile, convertion, result, parentJob);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 667 */           logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.UnknowFileFormat", new String[] { sourcefilefolder.toString() }));
/*     */           
/* 669 */           updateErrors();
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 674 */         logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.SourceFileNotExists", new String[] { realSourceFilefoldername }));
/*     */         
/* 676 */         updateErrors();
/*     */       }
/*     */       
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 682 */       logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.Exception.Processing", new String[] { realSourceFilefoldername.toString(), e.getMessage() }));
/*     */       
/* 684 */       updateErrors();
/*     */     }
/*     */     finally
/*     */     {
/* 688 */       if (sourcefilefolder != null) {
/*     */         try
/*     */         {
/* 691 */           sourcefilefolder.close();
/*     */         }
/*     */         catch (IOException ex) {}
/*     */       }
/* 695 */       if (CurrentFile != null) {
/*     */         try
/*     */         {
/* 698 */           CurrentFile.close();
/*     */         } catch (IOException ex) {}
/*     */       }
/*     */     }
/* 702 */     return entrystatus;
/*     */   }
/*     */   
/*     */   private boolean convertOneFile(FileObject file, int convertion, Result result, Job parentJob)
/*     */   {
/* 707 */     boolean retval = false;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 712 */       boolean convertToUnix = true;
/*     */       
/* 714 */       if (convertion == 0)
/*     */       {
/* 716 */         int fileType = getFileType(file);
/* 717 */         if (fileType == 0)
/*     */         {
/*     */ 
/* 720 */           convertToUnix = true;
/*     */         }
/*     */         else
/*     */         {
/* 724 */           convertToUnix = false;
/*     */         }
/* 726 */       } else if (convertion == 1) {
/* 727 */         convertToUnix = true;
/*     */       } else {
/* 729 */         convertToUnix = false;
/*     */       }
/*     */       
/* 732 */       retval = convert(file, convertToUnix);
/*     */       
/* 734 */       if (!retval) {
/* 735 */         logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.FileNotConverted", new String[] { file.toString() }));
/*     */         
/* 737 */         updateBadFormed();
/* 738 */         if ((this.resultfilenames.equals("all_filenames")) || (this.resultfilenames.equals("only_error_filenames")))
/* 739 */           addFileToResultFilenames(file, result, parentJob);
/*     */       } else {
/* 741 */         if (isDetailed()) {
/* 742 */           logDetailed("---------------------------");
/* 743 */           logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Error.FileConverted", new Object[] { file, convertToUnix ? "UNIX" : "DOS" }));
/*     */         }
/*     */         
/*     */ 
/* 747 */         updateProcessedFormed();
/* 748 */         if ((this.resultfilenames.equals("all_filenames")) || (this.resultfilenames.equals("only_processed_filenames"))) {
/* 749 */           addFileToResultFilenames(file, result, parentJob);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {}
/* 753 */     return retval;
/*     */   }
/*     */   
/*     */   private void updateProcessedFormed()
/*     */   {
/* 758 */     this.NrProcessedFiles += 1;
/*     */   }
/*     */   
/*     */   private void updateBadFormed() {
/* 762 */     this.NrErrorFiles += 1;
/* 763 */     updateAllErrors();
/*     */   }
/*     */   
/*     */   private void addFileToResultFilenames(FileObject fileaddentry, Result result, Job parentJob) {
/* 767 */     try { ResultFile resultFile = new ResultFile(0, fileaddentry, parentJob.getName(), toString());
/* 768 */       result.getResultFiles().put(resultFile.getFile().toString(), resultFile);
/*     */       
/* 770 */       if (isDetailed())
/*     */       {
/* 772 */         logDetailed(BaseMessages.getString(PKG, "JobDosToUnix.Log.FileAddedToResultFilesName", new Object[] { fileaddentry }));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 776 */       logError(BaseMessages.getString(PKG, "JobDosToUnix.Error.AddingToFilenameResult", new String[] { fileaddentry.toString(), e.getMessage() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean GetFileWildcard(String selectedfile, String wildcard)
/*     */   {
/* 789 */     Pattern pattern = null;
/* 790 */     boolean getIt = true;
/*     */     
/* 792 */     if (!Const.isEmpty(wildcard))
/*     */     {
/* 794 */       pattern = Pattern.compile(wildcard);
/*     */       
/* 796 */       if (pattern != null)
/*     */       {
/* 798 */         Matcher matcher = pattern.matcher(selectedfile);
/* 799 */         getIt = matcher.matches();
/*     */       }
/*     */     }
/*     */     
/* 803 */     return getIt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIncludeSubfolders(boolean include_subfoldersin)
/*     */   {
/* 809 */     this.include_subfolders = include_subfoldersin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setArgFromPrevious(boolean argfrompreviousin)
/*     */   {
/* 816 */     this.arg_from_previous = argfrompreviousin;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setNrErrorsLessThan(String nr_errors_less_than)
/*     */   {
/* 822 */     this.nr_errors_less_than = nr_errors_less_than;
/*     */   }
/*     */   
/*     */   public String getNrErrorsLessThan()
/*     */   {
/* 827 */     return this.nr_errors_less_than;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSuccessCondition(String success_condition)
/*     */   {
/* 833 */     this.success_condition = success_condition;
/*     */   }
/*     */   
/*     */   public String getSuccessCondition() {
/* 837 */     return this.success_condition;
/*     */   }
/*     */   
/*     */   public void setResultFilenames(String resultfilenames)
/*     */   {
/* 842 */     this.resultfilenames = resultfilenames;
/*     */   }
/*     */   
/*     */   public String getResultFilenames() {
/* 846 */     return this.resultfilenames;
/*     */   }
/*     */   
/*     */   public boolean evaluates() {
/* 850 */     return true;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\dostounix\JobEntryDosToUnix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */