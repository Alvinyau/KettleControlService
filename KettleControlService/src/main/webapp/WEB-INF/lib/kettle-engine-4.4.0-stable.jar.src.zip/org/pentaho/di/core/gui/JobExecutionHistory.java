/*    */ package org.pentaho.di.core.gui;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobExecutionHistory
/*    */ {
/*    */   private Map<String, JobEntryExecutionResult> executionMap;
/*    */   
/*    */   public JobExecutionHistory()
/*    */   {
/* 43 */     this.executionMap = new HashMap();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Map<String, JobEntryExecutionResult> getExecutionMap()
/*    */   {
/* 50 */     return this.executionMap;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setExecutionMap(Map<String, JobEntryExecutionResult> executionMap)
/*    */   {
/* 57 */     this.executionMap = executionMap;
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\JobExecutionHistory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */