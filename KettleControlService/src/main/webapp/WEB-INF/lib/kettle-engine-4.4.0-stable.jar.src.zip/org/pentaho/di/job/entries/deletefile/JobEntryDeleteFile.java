/*     */ package org.pentaho.di.job.entries.deletefile;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.vfs.FileObject;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.logging.LogChannelInterface;
/*     */ import org.pentaho.di.core.vfs.KettleVFS;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.i18n.BaseMessages;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.AbstractFileValidator;
/*     */ import org.pentaho.di.job.entry.validator.AndValidator;
/*     */ import org.pentaho.di.job.entry.validator.FileExistsValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidator;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.job.entry.validator.ValidatorContext;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.pentaho.di.resource.ResourceEntry;
/*     */ import org.pentaho.di.resource.ResourceEntry.ResourceType;
/*     */ import org.pentaho.di.resource.ResourceReference;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryDeleteFile
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*  70 */   private static Class<?> PKG = JobEntryDeleteFile.class;
/*     */   
/*     */   private String filename;
/*     */   private boolean failIfFileNotExists;
/*     */   
/*     */   public JobEntryDeleteFile(String n)
/*     */   {
/*  77 */     super(n, "");
/*  78 */     this.filename = null;
/*  79 */     this.failIfFileNotExists = false;
/*  80 */     setID(-1L);
/*     */   }
/*     */   
/*     */   public JobEntryDeleteFile()
/*     */   {
/*  85 */     this("");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  90 */     JobEntryDeleteFile je = (JobEntryDeleteFile)super.clone();
/*  91 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  96 */     StringBuffer retval = new StringBuffer(50);
/*     */     
/*  98 */     retval.append(super.getXML());
/*  99 */     retval.append("      ").append(XMLHandler.addTagValue("filename", this.filename));
/* 100 */     retval.append("      ").append(XMLHandler.addTagValue("fail_if_file_not_exists", this.failIfFileNotExists));
/*     */     
/* 102 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep) throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/* 109 */       super.loadXML(entrynode, databases, slaveServers);
/* 110 */       this.filename = XMLHandler.getTagValue(entrynode, "filename");
/* 111 */       this.failIfFileNotExists = "Y".equalsIgnoreCase(XMLHandler.getTagValue(entrynode, "fail_if_file_not_exists"));
/*     */     }
/*     */     catch (KettleXMLException xe)
/*     */     {
/* 115 */       throw new KettleXMLException(BaseMessages.getString(PKG, "JobEntryDeleteFile.Error_0001_Unable_To_Load_Job_From_Xml_Node", new String[0]), xe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 123 */       this.filename = rep.getJobEntryAttributeString(id_jobentry, "filename");
/* 124 */       this.failIfFileNotExists = rep.getJobEntryAttributeBoolean(id_jobentry, "fail_if_file_not_exists");
/*     */     }
/*     */     catch (KettleException dbe)
/*     */     {
/* 128 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDeleteFile.ERROR_0002_Unable_To_Load_From_Repository", new Object[] { id_jobentry }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveRep(Repository rep, ObjectId id_job) throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 136 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "filename", this.filename);
/* 137 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "fail_if_file_not_exists", this.failIfFileNotExists);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 141 */       throw new KettleException(BaseMessages.getString(PKG, "JobEntryDeleteFile.ERROR_0003_Unable_To_Save_Job_To_Repository", new Object[] { id_job }), dbe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFilename(String filename)
/*     */   {
/* 147 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 152 */     return this.filename;
/*     */   }
/*     */   
/*     */   public String getRealFilename()
/*     */   {
/* 157 */     return environmentSubstitute(getFilename());
/*     */   }
/*     */   
/*     */   public Result execute(Result previousResult, int nr)
/*     */   {
/* 162 */     Result result = previousResult;
/* 163 */     result.setResult(false);
/*     */     
/* 165 */     if (this.filename != null)
/*     */     {
/* 167 */       String realFilename = getRealFilename();
/*     */       
/* 169 */       FileObject fileObject = null;
/*     */       try {
/* 171 */         fileObject = KettleVFS.getFileObject(realFilename, this);
/*     */         
/* 173 */         if (!fileObject.exists())
/*     */         {
/* 175 */           if (isFailIfFileNotExists())
/*     */           {
/*     */ 
/* 178 */             result.setResult(false);
/* 179 */             logError(BaseMessages.getString(PKG, "JobEntryDeleteFile.ERROR_0004_File_Does_Not_Exist", new String[] { realFilename }));
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 184 */             result.setResult(true);
/* 185 */             if (this.log.isBasic()) logBasic(BaseMessages.getString(PKG, "JobEntryDeleteFile.File_Already_Deleted", new String[] { realFilename }));
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 190 */           boolean deleted = fileObject.delete();
/* 191 */           if (!deleted)
/*     */           {
/* 193 */             logError(BaseMessages.getString(PKG, "JobEntryDeleteFile.ERROR_0005_Could_Not_Delete_File", new String[] { realFilename }));
/* 194 */             result.setResult(false);
/* 195 */             result.setNrErrors(1L);
/*     */           }
/* 197 */           if (this.log.isBasic()) logBasic(BaseMessages.getString(PKG, "JobEntryDeleteFile.File_Deleted", new String[] { realFilename }));
/* 198 */           result.setResult(true);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 202 */         logError(BaseMessages.getString(PKG, "JobEntryDeleteFile.ERROR_0006_Exception_Deleting_File", new String[] { realFilename, e.getMessage() }), e);
/* 203 */         result.setResult(false);
/* 204 */         result.setNrErrors(1L);
/*     */       }
/*     */       finally {
/* 207 */         if (fileObject != null) {
/*     */           try
/*     */           {
/* 210 */             fileObject.close();
/* 211 */             fileObject = null;
/*     */           }
/*     */           catch (IOException ex) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 219 */       logError(BaseMessages.getString(PKG, "JobEntryDeleteFile.ERROR_0007_No_Filename_Is_Defined", new String[0]));
/*     */     }
/*     */     
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isFailIfFileNotExists() {
/* 226 */     return this.failIfFileNotExists;
/*     */   }
/*     */   
/*     */   public void setFailIfFileNotExists(boolean failIfFileExists) {
/* 230 */     this.failIfFileNotExists = failIfFileExists;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 235 */     return true;
/*     */   }
/*     */   
/*     */   public List<ResourceReference> getResourceDependencies(JobMeta jobMeta) {
/* 239 */     List<ResourceReference> references = super.getResourceDependencies(jobMeta);
/* 240 */     if (!Const.isEmpty(this.filename)) {
/* 241 */       String realFileName = jobMeta.environmentSubstitute(this.filename);
/* 242 */       ResourceReference reference = new ResourceReference(this);
/* 243 */       reference.getEntries().add(new ResourceEntry(realFileName, ResourceEntry.ResourceType.FILE));
/* 244 */       references.add(reference);
/*     */     }
/* 246 */     return references;
/*     */   }
/*     */   
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta) {
/* 250 */     ValidatorContext ctx = new ValidatorContext();
/* 251 */     AbstractFileValidator.putVariableSpace(ctx, getVariables());
/* 252 */     AndValidator.putValidators(ctx, new JobEntryValidator[] { JobEntryValidatorUtils.notNullValidator(), JobEntryValidatorUtils.fileExistsValidator() });
/* 253 */     if (isFailIfFileNotExists()) {
/* 254 */       FileExistsValidator.putFailIfDoesNotExist(ctx, true);
/*     */     }
/* 256 */     JobEntryValidatorUtils.andValidator().validate(this, "filename", remarks, ctx);
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 261 */     List<CheckResultInterface> remarks = new ArrayList();
/* 262 */     new JobEntryDeleteFile().check(remarks, null);
/* 263 */     System.out.printf("Remarks: %s\n", new Object[] { remarks });
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\deletefile\JobEntryDeleteFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */