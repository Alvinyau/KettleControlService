/*    */ package org.pentaho.di.core.lifecycle;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.pentaho.di.core.Const;
/*    */ import org.pentaho.di.core.exception.KettleException;
/*    */ import org.pentaho.di.core.logging.LogChannel;
/*    */ import org.pentaho.di.core.logging.LogChannelInterface;
/*    */ import org.pentaho.di.core.plugins.KettleLifecyclePluginType;
/*    */ import org.pentaho.di.i18n.BaseMessages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KettleLifecycleSupport
/*    */ {
/* 38 */   private static Class<?> PKG = Const.class;
/*    */   private Set<KettleLifecycleListener> kettleLifecycleListeners;
/*    */   
/*    */   public KettleLifecycleSupport()
/*    */   {
/* 43 */     this.kettleLifecycleListeners = LifecycleSupport.loadPlugins(KettleLifecyclePluginType.class, KettleLifecycleListener.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void onEnvironmentInit()
/*    */     throws KettleException
/*    */   {
/* 55 */     for (KettleLifecycleListener listener : this.kettleLifecycleListeners) {
/*    */       try {
/* 57 */         listener.onEnvironmentInit();
/*    */       } catch (LifecycleException ex) {
/* 59 */         String message = BaseMessages.getString(PKG, "LifecycleSupport.ErrorInvokingKettleLifecycleListener", new Object[] { listener });
/* 60 */         if (ex.isSevere()) {
/* 61 */           throw new KettleException(message, ex);
/*    */         }
/*    */         
/* 64 */         LogChannel.GENERAL.logError(message, ex);
/*    */       } catch (Throwable t) {
/* 66 */         throw new KettleException(BaseMessages.getString(PKG, "LifecycleSupport.ErrorInvokingKettleLifecycleListener", new Object[] { listener }), t);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void onEnvironmentShutdown()
/*    */   {
/* 73 */     for (KettleLifecycleListener listener : this.kettleLifecycleListeners) {
/*    */       try {
/* 75 */         listener.onEnvironmentShutdown();
/*    */       }
/*    */       catch (Throwable t) {
/* 78 */         LogChannel.GENERAL.logError(BaseMessages.getString(PKG, "LifecycleSupport.ErrorInvokingKettleLifecycleListener", new Object[] { listener }), t);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\lifecycle\KettleLifecycleSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */