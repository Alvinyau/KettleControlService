package org.pentaho.di.core.changed;

public abstract interface ChangedFlagInterface
{
  public abstract boolean hasChanged();
  
  public abstract void setChanged(boolean paramBoolean);
  
  public abstract void setChanged();
  
  public abstract void clearChanged();
}


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\changed\ChangedFlagInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */