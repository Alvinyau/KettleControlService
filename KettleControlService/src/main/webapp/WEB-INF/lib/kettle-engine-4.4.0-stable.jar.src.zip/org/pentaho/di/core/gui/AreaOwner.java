/*     */ package org.pentaho.di.core.gui;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AreaOwner
/*     */ {
/*     */   private Rectangle area;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object parent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object owner;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AreaType areaType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum AreaType
/*     */   {
/*  38 */     NOTE,  REMOTE_INPUT_STEP,  REMOTE_OUTPUT_STEP,  STEP_PARTITIONING, 
/*  39 */     STEP_ICON,  STEP_ERROR_ICON,  STEP_INPUT_HOP_ICON,  STEP_OUTPUT_HOP_ICON,  STEP_INFO_HOP_ICON,  STEP_ERROR_HOP_ICON,  STEP_TARGET_HOP_ICON, 
/*  40 */     HOP_COPY_ICON,  HOP_ERROR_ICON,  HOP_INFO_ICON,  HOP_INFO_STEP_COPIES_ERROR, 
/*     */     
/*  42 */     MINI_ICONS_BALLOON, 
/*     */     
/*  44 */     STEP_TARGET_HOP_ICON_OPTION, 
/*  45 */     STEP_EDIT_ICON,  STEP_MENU_ICON, 
/*     */     
/*     */ 
/*  48 */     JOB_ENTRY_ICON,  JOB_HOP_ICON,  JOB_HOP_PARALLEL_ICON, 
/*  49 */     JOB_ENTRY_MINI_ICON_INPUT,  JOB_ENTRY_MINI_ICON_OUTPUT,  JOB_ENTRY_MINI_ICON_CONTEXT,  JOB_ENTRY_MINI_ICON_EDIT, 
/*     */     
/*  51 */     JOB_ENTRY_BUSY,  JOB_ENTRY_RESULT_SUCCESS,  JOB_ENTRY_RESULT_FAILURE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private AreaType() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AreaOwner(AreaType areaType, int x, int y, int width, int heigth, Point offset, Object parent, Object owner)
/*     */   {
/*  69 */     this.areaType = areaType;
/*  70 */     this.area = new Rectangle(x - offset.x, y - offset.y, width, heigth);
/*  71 */     this.parent = parent;
/*  72 */     this.owner = owner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(int x, int y)
/*     */   {
/*  82 */     return this.area.contains(x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Rectangle getArea()
/*     */   {
/*  89 */     return this.area;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setArea(Rectangle area)
/*     */   {
/*  96 */     this.area = area;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getOwner()
/*     */   {
/* 103 */     return this.owner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOwner(Object owner)
/*     */   {
/* 110 */     this.owner = owner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getParent()
/*     */   {
/* 117 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setParent(Object parent)
/*     */   {
/* 124 */     this.parent = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AreaType getAreaType()
/*     */   {
/* 131 */     return this.areaType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAreaType(AreaType areaType)
/*     */   {
/* 138 */     this.areaType = areaType;
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\AreaOwner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */