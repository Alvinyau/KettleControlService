/*     */ package org.pentaho.di.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.regex.Pattern;
/*     */ import org.pentaho.di.core.exception.KettleValueException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.row.RowMetaInterface;
/*     */ import org.pentaho.di.core.row.ValueMetaAndData;
/*     */ import org.pentaho.di.core.row.ValueMetaInterface;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.core.xml.XMLInterface;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Condition
/*     */   implements Cloneable, XMLInterface
/*     */ {
/*     */   public static final String XML_TAG = "condition";
/*  63 */   public static final String[] operators = { "-", "OR", "AND", "NOT", "OR NOT", "AND NOT", "XOR" };
/*     */   
/*     */   public static final int OPERATOR_NONE = 0;
/*     */   public static final int OPERATOR_OR = 1;
/*     */   public static final int OPERATOR_AND = 2;
/*     */   public static final int OPERATOR_NOT = 3;
/*     */   public static final int OPERATOR_OR_NOT = 4;
/*     */   public static final int OPERATOR_AND_NOT = 5;
/*     */   public static final int OPERATOR_XOR = 6;
/*  72 */   public static final String[] functions = { "=", "<>", "<", "<=", ">", ">=", "REGEXP", "IS NULL", "IS NOT NULL", "IN LIST", "CONTAINS", "STARTS WITH", "ENDS WITH" };
/*     */   
/*     */   public static final int FUNC_EQUAL = 0;
/*     */   
/*     */   public static final int FUNC_NOT_EQUAL = 1;
/*     */   
/*     */   public static final int FUNC_SMALLER = 2;
/*     */   
/*     */   public static final int FUNC_SMALLER_EQUAL = 3;
/*     */   
/*     */   public static final int FUNC_LARGER = 4;
/*     */   
/*     */   public static final int FUNC_LARGER_EQUAL = 5;
/*     */   
/*     */   public static final int FUNC_REGEXP = 6;
/*     */   
/*     */   public static final int FUNC_NULL = 7;
/*     */   
/*     */   public static final int FUNC_NOT_NULL = 8;
/*     */   
/*     */   public static final int FUNC_IN_LIST = 9;
/*     */   
/*     */   public static final int FUNC_CONTAINS = 10;
/*     */   
/*     */   public static final int FUNC_STARTS_WITH = 11;
/*     */   
/*     */   public static final int FUNC_ENDS_WITH = 12;
/*     */   
/*     */   private ObjectId id;
/*     */   
/*     */   private boolean negate;
/*     */   
/*     */   private int operator;
/*     */   
/*     */   private String left_valuename;
/*     */   
/*     */   private int function;
/*     */   private String right_valuename;
/*     */   private ValueMetaAndData right_exact;
/*     */   private ObjectId id_right_exact;
/*     */   private int left_fieldnr;
/*     */   private int right_fieldnr;
/*     */   private ArrayList<Condition> list;
/*     */   private String right_string;
/*     */   private String[] inList;
/*     */   
/*     */   public Condition()
/*     */   {
/* 120 */     this.list = new ArrayList();
/* 121 */     this.operator = 0;
/* 122 */     this.negate = false;
/*     */     
/* 124 */     this.left_fieldnr = -2;
/* 125 */     this.right_fieldnr = -2;
/*     */     
/* 127 */     this.id = null;
/*     */   }
/*     */   
/*     */   public Condition(String valuename, int function, String valuename2, ValueMetaAndData exact)
/*     */   {
/* 132 */     this();
/* 133 */     this.left_valuename = valuename;
/* 134 */     this.function = function;
/* 135 */     this.right_valuename = valuename2;
/* 136 */     this.right_exact = exact;
/*     */     
/* 138 */     clearFieldPositions();
/*     */   }
/*     */   
/*     */   public Condition(int operator, String valuename, int function, String valuename2, ValueMetaAndData exact)
/*     */   {
/* 143 */     this();
/* 144 */     this.operator = operator;
/* 145 */     this.left_valuename = valuename;
/* 146 */     this.function = function;
/* 147 */     this.right_valuename = valuename2;
/* 148 */     this.right_exact = exact;
/*     */     
/* 150 */     clearFieldPositions();
/*     */   }
/*     */   
/*     */   public Condition(boolean negate, String valuename, int function, String valuename2, ValueMetaAndData exact)
/*     */   {
/* 155 */     this(valuename, function, valuename2, exact);
/* 156 */     this.negate = negate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectId getObjectId()
/*     */   {
/* 166 */     return this.id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setObjectId(ObjectId id)
/*     */   {
/* 176 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 182 */     Condition retval = null;
/*     */     
/* 184 */     retval = new Condition();
/* 185 */     retval.negate = this.negate;
/* 186 */     retval.operator = this.operator;
/*     */     
/* 188 */     if (isComposite())
/*     */     {
/* 190 */       for (int i = 0; i < nrConditions(); i++)
/*     */       {
/* 192 */         Condition c = getCondition(i);
/* 193 */         Condition cCopy = (Condition)c.clone();
/* 194 */         retval.addCondition(cCopy);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 199 */       retval.negate = this.negate;
/* 200 */       retval.left_valuename = this.left_valuename;
/* 201 */       retval.operator = this.operator;
/* 202 */       retval.right_valuename = this.right_valuename;
/* 203 */       retval.function = this.function;
/* 204 */       if (this.right_exact != null)
/*     */       {
/* 206 */         retval.right_exact = ((ValueMetaAndData)this.right_exact.clone());
/*     */       }
/*     */       else
/*     */       {
/* 210 */         retval.right_exact = null;
/*     */       }
/*     */     }
/*     */     
/* 214 */     return retval;
/*     */   }
/*     */   
/*     */   public void setOperator(int operator)
/*     */   {
/* 219 */     this.operator = operator;
/*     */   }
/*     */   
/*     */   public int getOperator()
/*     */   {
/* 224 */     return this.operator;
/*     */   }
/*     */   
/*     */   public String getOperatorDesc()
/*     */   {
/* 229 */     return Const.rightPad(operators[this.operator], 7);
/*     */   }
/*     */   
/*     */   public static final int getOperator(String description)
/*     */   {
/* 234 */     if (description == null) { return 0;
/*     */     }
/* 236 */     for (int i = 1; i < operators.length; i++)
/*     */     {
/* 238 */       if (operators[i].equalsIgnoreCase(Const.trim(description))) return i;
/*     */     }
/* 240 */     return 0;
/*     */   }
/*     */   
/*     */   public static final String[] getOperators()
/*     */   {
/* 245 */     String[] retval = new String[operators.length - 1];
/* 246 */     for (int i = 1; i < operators.length; i++)
/*     */     {
/* 248 */       retval[(i - 1)] = operators[i];
/*     */     }
/* 250 */     return retval;
/*     */   }
/*     */   
/*     */   public static final String[] getRealOperators()
/*     */   {
/* 255 */     return new String[] { "OR", "AND", "OR NOT", "AND NOT", "XOR" };
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLeftValuename(String left_valuename)
/*     */   {
/* 261 */     this.left_valuename = left_valuename;
/*     */   }
/*     */   
/*     */   public String getLeftValuename()
/*     */   {
/* 266 */     return this.left_valuename;
/*     */   }
/*     */   
/*     */   public int getFunction()
/*     */   {
/* 271 */     return this.function;
/*     */   }
/*     */   
/*     */   public void setFunction(int function)
/*     */   {
/* 276 */     this.function = function;
/*     */   }
/*     */   
/*     */   public String getFunctionDesc()
/*     */   {
/* 281 */     return functions[this.function];
/*     */   }
/*     */   
/*     */   public static final int getFunction(String description)
/*     */   {
/* 286 */     for (int i = 1; i < functions.length; i++)
/*     */     {
/* 288 */       if (functions[i].equalsIgnoreCase(Const.trim(description))) return i;
/*     */     }
/* 290 */     return 0;
/*     */   }
/*     */   
/*     */   public void setRightValuename(String right_valuename)
/*     */   {
/* 295 */     this.right_valuename = right_valuename;
/*     */   }
/*     */   
/*     */   public String getRightValuename()
/*     */   {
/* 300 */     return this.right_valuename;
/*     */   }
/*     */   
/*     */   public void setRightExact(ValueMetaAndData right_exact)
/*     */   {
/* 305 */     this.right_exact = right_exact;
/*     */   }
/*     */   
/*     */   public ValueMetaAndData getRightExact()
/*     */   {
/* 310 */     return this.right_exact;
/*     */   }
/*     */   
/*     */   public String getRightExactString()
/*     */   {
/* 315 */     if (this.right_exact == null) return null;
/* 316 */     return this.right_exact.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectId getRightExactID()
/*     */   {
/* 325 */     return this.id_right_exact;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRightExactID(ObjectId id_right_exact)
/*     */   {
/* 335 */     this.id_right_exact = id_right_exact;
/*     */   }
/*     */   
/*     */   public boolean isAtomic()
/*     */   {
/* 340 */     return this.list.size() == 0;
/*     */   }
/*     */   
/*     */   public boolean isComposite()
/*     */   {
/* 345 */     return this.list.size() != 0;
/*     */   }
/*     */   
/*     */   public boolean isNegated()
/*     */   {
/* 350 */     return this.negate;
/*     */   }
/*     */   
/*     */   public void setNegated(boolean negate)
/*     */   {
/* 355 */     this.negate = negate;
/*     */   }
/*     */   
/*     */   public void negate()
/*     */   {
/* 360 */     setNegated(!isNegated());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 368 */     return (isAtomic()) && (this.left_valuename == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearFieldPositions()
/*     */   {
/* 378 */     this.left_fieldnr = -2;
/* 379 */     this.right_fieldnr = -2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate(RowMetaInterface rowMeta, Object[] r)
/*     */   {
/* 388 */     boolean retval = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 395 */       if (isAtomic())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 400 */         if ((this.left_valuename != null) && (this.left_valuename.length() > 0) && (this.left_fieldnr < -1)) { this.left_fieldnr = rowMeta.indexOfValue(this.left_valuename);
/*     */         }
/*     */         
/*     */ 
/* 404 */         if ((this.right_valuename != null) && (this.right_valuename.length() > 0) && (this.right_fieldnr < -1)) { this.right_fieldnr = rowMeta.indexOfValue(this.right_valuename);
/*     */         }
/*     */         
/* 407 */         ValueMetaInterface fieldMeta = null;
/* 408 */         Object field = null;
/* 409 */         if (this.left_fieldnr >= 0)
/*     */         {
/* 411 */           fieldMeta = rowMeta.getValueMeta(this.left_fieldnr);
/* 412 */           field = r[this.left_fieldnr];
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 420 */           return false;
/*     */         }
/*     */         
/* 423 */         ValueMetaInterface fieldMeta2 = this.right_exact != null ? this.right_exact.getValueMeta() : null;
/* 424 */         Object field2 = this.right_exact != null ? this.right_exact.getValueData() : null;
/* 425 */         if ((field2 == null) && (this.right_fieldnr >= 0))
/*     */         {
/* 427 */           fieldMeta2 = rowMeta.getValueMeta(this.right_fieldnr);
/* 428 */           field2 = r[this.right_fieldnr];
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 448 */         switch (this.function) {
/*     */         case 0: 
/* 450 */           retval = fieldMeta.compare(field, fieldMeta2, field2) == 0; break;
/* 451 */         case 1:  retval = fieldMeta.compare(field, fieldMeta2, field2) != 0; break;
/* 452 */         case 2:  retval = fieldMeta.compare(field, fieldMeta2, field2) < 0; break;
/* 453 */         case 3:  retval = fieldMeta.compare(field, fieldMeta2, field2) <= 0; break;
/* 454 */         case 4:  retval = fieldMeta.compare(field, fieldMeta2, field2) > 0; break;
/* 455 */         case 5:  retval = fieldMeta.compare(field, fieldMeta2, field2) >= 0; break;
/*     */         case 6: 
/* 457 */           if ((fieldMeta.isNull(field)) || (field2 == null))
/*     */           {
/* 459 */             retval = false;
/*     */           }
/*     */           else
/*     */           {
/* 463 */             retval = Pattern.matches(fieldMeta2.getCompatibleString(field2), fieldMeta.getCompatibleString(field));
/*     */           }
/* 465 */           break;
/* 466 */         case 7:  retval = fieldMeta.isNull(field); break;
/* 467 */         case 8:  retval = !fieldMeta.isNull(field); break;
/*     */         case 9: 
/* 469 */           if ((this.inList == null) || (this.right_fieldnr >= 0)) {
/* 470 */             this.inList = Const.splitString(fieldMeta2.getString(field2), ';');
/* 471 */             Arrays.sort(this.inList);
/*     */           }
/* 473 */           String searchString = fieldMeta.getCompatibleString(field);
/* 474 */           int inIndex = -1;
/* 475 */           if (searchString != null) {
/* 476 */             inIndex = Arrays.binarySearch(this.inList, searchString);
/*     */           }
/* 478 */           retval = Boolean.valueOf(inIndex >= 0).booleanValue();
/* 479 */           break;
/*     */         case 10: 
/* 481 */           retval = fieldMeta.getCompatibleString(field).indexOf(fieldMeta2.getCompatibleString(field2)) >= 0;
/* 482 */           break;
/*     */         case 11: 
/* 484 */           retval = fieldMeta.getCompatibleString(field) != null ? fieldMeta.getCompatibleString(field).startsWith(fieldMeta2.getCompatibleString(field2)) : false;
/* 485 */           break;
/*     */         case 12: 
/* 487 */           String string = fieldMeta.getCompatibleString(field);
/* 488 */           if (!Const.isEmpty(string))
/*     */           {
/* 490 */             if ((this.right_string == null) && (field2 != null)) this.right_string = fieldMeta2.getCompatibleString(field2);
/* 491 */             if (this.right_string != null)
/*     */             {
/* 493 */               retval = string.endsWith(fieldMeta2.getCompatibleString(field2));
/*     */             }
/*     */             else
/*     */             {
/* 497 */               retval = false;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 502 */             retval = false;
/*     */           }
/* 504 */           break;
/*     */         }
/*     */         
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 511 */         if (isNegated()) { retval = !retval;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 516 */         Condition cb0 = (Condition)this.list.get(0);
/* 517 */         retval = cb0.evaluate(rowMeta, r);
/*     */         
/*     */ 
/*     */ 
/* 521 */         for (int i = 1; i < this.list.size(); i++)
/*     */         {
/*     */ 
/*     */ 
/* 525 */           Condition cb = (Condition)this.list.get(i);
/*     */           
/*     */ 
/*     */ 
/* 529 */           switch (cb.getOperator()) {
/*     */           case 1: 
/* 531 */             retval = (retval) || (cb.evaluate(rowMeta, r)); break;
/* 532 */           case 2:  retval = (retval) && (cb.evaluate(rowMeta, r)); break;
/* 533 */           case 4:  retval = (retval) || (!cb.evaluate(rowMeta, r)); break;
/* 534 */           case 5:  retval = (retval) && (!cb.evaluate(rowMeta, r)); break;
/* 535 */           case 6:  retval ^= cb.evaluate(rowMeta, r);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/* 541 */         if (isNegated()) retval = !retval;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 546 */       throw new RuntimeException("Unexpected error evaluation condition [" + toString() + "]", e);
/*     */     }
/*     */     
/* 549 */     return retval;
/*     */   }
/*     */   
/*     */   public void addCondition(Condition cb)
/*     */   {
/* 554 */     if ((isAtomic()) && (getLeftValuename() != null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 559 */       Condition current = new Condition(getLeftValuename(), getFunction(), getRightValuename(), getRightExact());
/*     */       
/*     */ 
/*     */ 
/* 563 */       current.setNegated(isNegated());
/* 564 */       setNegated(false);
/* 565 */       this.list.add(current);
/*     */ 
/*     */ 
/*     */     }
/* 569 */     else if ((isComposite()) && (this.list.size() > 0) && (cb.getOperator() == 0))
/*     */     {
/* 571 */       cb.setOperator(2);
/*     */     }
/* 573 */     this.list.add(cb);
/*     */   }
/*     */   
/*     */   public void addCondition(int idx, Condition cb)
/*     */   {
/* 578 */     if ((isAtomic()) && (getLeftValuename() != null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 583 */       Condition current = new Condition(getLeftValuename(), getFunction(), getRightValuename(), getRightExact());
/*     */       
/*     */ 
/*     */ 
/* 587 */       current.setNegated(isNegated());
/* 588 */       setNegated(false);
/* 589 */       this.list.add(current);
/*     */ 
/*     */ 
/*     */     }
/* 593 */     else if ((isComposite()) && (idx > 0) && (cb.getOperator() == 0))
/*     */     {
/* 595 */       cb.setOperator(2);
/*     */     }
/* 597 */     this.list.add(idx, cb);
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeCondition(int nr)
/*     */   {
/* 603 */     if (isComposite())
/*     */     {
/* 605 */       Condition c = (Condition)this.list.get(nr);
/* 606 */       this.list.remove(nr);
/*     */       
/*     */ 
/*     */ 
/* 610 */       boolean moveUp = (isAtomic()) || (nrConditions() == 1);
/* 611 */       if (nrConditions() == 1) { c = getCondition(0);
/*     */       }
/* 613 */       if (moveUp)
/*     */       {
/* 615 */         setLeftValuename(c.getLeftValuename());
/* 616 */         setFunction(c.getFunction());
/* 617 */         setRightValuename(c.getRightValuename());
/* 618 */         setRightExact(c.getRightExact());
/* 619 */         setNegated(c.isNegated());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int nrConditions()
/*     */   {
/* 626 */     return this.list.size();
/*     */   }
/*     */   
/*     */   public Condition getCondition(int i)
/*     */   {
/* 631 */     return (Condition)this.list.get(i);
/*     */   }
/*     */   
/*     */   public void setCondition(int i, Condition subCondition)
/*     */   {
/* 636 */     this.list.set(i, subCondition);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 641 */     return toString(0, true, true);
/*     */   }
/*     */   
/*     */   public String toString(int level, boolean show_negate, boolean show_operator)
/*     */   {
/* 646 */     String retval = "";
/*     */     
/* 648 */     if (isAtomic())
/*     */     {
/*     */ 
/*     */ 
/* 652 */       for (int i = 0; i < level; i++) { retval = retval + "  ";
/*     */       }
/* 654 */       if ((show_operator) && (getOperator() != 0))
/*     */       {
/* 656 */         retval = retval + getOperatorDesc() + " ";
/*     */       }
/*     */       else
/*     */       {
/* 660 */         retval = retval + "        ";
/*     */       }
/*     */       
/*     */ 
/* 664 */       if ((isNegated()) && ((show_negate) || (level > 0)))
/*     */       {
/* 666 */         retval = retval + "NOT ( ";
/*     */       }
/*     */       else
/*     */       {
/* 670 */         retval = retval + "      ";
/*     */       }
/* 672 */       retval = retval + this.left_valuename + " " + getFunctionDesc();
/* 673 */       if ((this.function != 7) && (this.function != 8))
/*     */       {
/* 675 */         if (this.right_valuename != null)
/*     */         {
/* 677 */           retval = retval + " " + this.right_valuename;
/*     */         }
/*     */         else
/*     */         {
/* 681 */           retval = retval + " [" + (getRightExactString() == null ? "" : getRightExactString()) + "]";
/*     */         }
/*     */       }
/*     */       
/* 685 */       if ((isNegated()) && ((show_negate) || (level > 0))) { retval = retval + " )";
/*     */       }
/* 687 */       retval = retval + Const.CR;
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 694 */       if ((isNegated()) && ((show_negate) || (level > 0)))
/*     */       {
/* 696 */         for (int i = 0; i < level; i++) retval = retval + "  ";
/* 697 */         retval = retval + "NOT" + Const.CR;
/*     */       }
/*     */       
/* 700 */       if ((getOperator() != 0) && ((show_operator) || (level > 0)))
/*     */       {
/* 702 */         for (int i = 0; i < level; i++) retval = retval + "  ";
/* 703 */         retval = retval + getOperatorDesc() + Const.CR;
/*     */       }
/* 705 */       for (int i = 0; i < level; i++) retval = retval + "  "; retval = retval + "(" + Const.CR;
/* 706 */       for (int i = 0; i < this.list.size(); i++)
/*     */       {
/* 708 */         Condition cb = (Condition)this.list.get(i);
/* 709 */         retval = retval + cb.toString(level + 1, true, i > 0);
/*     */       }
/* 711 */       for (int i = 0; i < level; i++) retval = retval + "  "; retval = retval + ")" + Const.CR;
/*     */     }
/*     */     
/* 714 */     return retval;
/*     */   }
/*     */   
/*     */   public String getXML() throws KettleValueException
/*     */   {
/* 719 */     return getXML(0);
/*     */   }
/*     */   
/*     */   public String getXML(int level) throws KettleValueException
/*     */   {
/* 724 */     String retval = "";
/* 725 */     String indent1 = Const.rightPad(" ", level);
/* 726 */     String indent2 = Const.rightPad(" ", level + 1);
/* 727 */     String indent3 = Const.rightPad(" ", level + 2);
/*     */     
/* 729 */     retval = retval + indent1 + XMLHandler.openTag("condition") + Const.CR;
/*     */     
/* 731 */     retval = retval + indent2 + XMLHandler.addTagValue("negated", isNegated());
/*     */     
/* 733 */     if (getOperator() != 0)
/*     */     {
/* 735 */       retval = retval + indent2 + XMLHandler.addTagValue("operator", Const.rtrim(getOperatorDesc()));
/*     */     }
/*     */     
/* 738 */     if (isAtomic())
/*     */     {
/* 740 */       retval = retval + indent2 + XMLHandler.addTagValue("leftvalue", getLeftValuename());
/* 741 */       retval = retval + indent2 + XMLHandler.addTagValue("function", getFunctionDesc());
/* 742 */       retval = retval + indent2 + XMLHandler.addTagValue("rightvalue", getRightValuename());
/* 743 */       if (getRightExact() != null)
/*     */       {
/* 745 */         retval = retval + indent2 + getRightExact().getXML();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 750 */       retval = retval + indent2 + "<conditions>" + Const.CR;
/* 751 */       for (int i = 0; i < nrConditions(); i++)
/*     */       {
/* 753 */         Condition c = getCondition(i);
/* 754 */         retval = retval + c.getXML(level + 2);
/*     */       }
/* 756 */       retval = retval + indent3 + "</conditions>" + Const.CR;
/*     */     }
/*     */     
/* 759 */     retval = retval + indent2 + XMLHandler.closeTag("condition") + Const.CR;
/*     */     
/* 761 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Condition(Node condnode)
/*     */     throws KettleXMLException
/*     */   {
/* 771 */     this();
/*     */     
/* 773 */     this.list = new ArrayList();
/*     */     try
/*     */     {
/* 776 */       String str_negated = XMLHandler.getTagValue(condnode, "negated");
/* 777 */       setNegated("Y".equalsIgnoreCase(str_negated));
/*     */       
/* 779 */       String str_operator = XMLHandler.getTagValue(condnode, "operator");
/* 780 */       setOperator(getOperator(str_operator));
/*     */       
/* 782 */       Node conditions = XMLHandler.getSubNode(condnode, "conditions");
/* 783 */       int nrconditions = XMLHandler.countNodes(conditions, "condition");
/* 784 */       if (nrconditions == 0)
/*     */       {
/* 786 */         setLeftValuename(XMLHandler.getTagValue(condnode, "leftvalue"));
/* 787 */         setFunction(getFunction(XMLHandler.getTagValue(condnode, "function")));
/* 788 */         setRightValuename(XMLHandler.getTagValue(condnode, "rightvalue"));
/* 789 */         Node exactnode = XMLHandler.getSubNode(condnode, "value");
/* 790 */         if (exactnode != null)
/*     */         {
/* 792 */           ValueMetaAndData exact = new ValueMetaAndData(exactnode);
/* 793 */           setRightExact(exact);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 798 */         for (int i = 0; i < nrconditions; i++)
/*     */         {
/* 800 */           Node subcondnode = XMLHandler.getSubNodeByNr(conditions, "condition", i);
/* 801 */           Condition c = new Condition(subcondnode);
/* 802 */           addCondition(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 808 */       throw new KettleXMLException("Unable to create condition using xml: " + Const.CR + condnode, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] getUsedFields()
/*     */   {
/* 814 */     Hashtable<String, String> fields = new Hashtable();
/* 815 */     getUsedFields(fields);
/*     */     
/* 817 */     String[] retval = new String[fields.size()];
/* 818 */     Enumeration<String> keys = fields.keys();
/* 819 */     int i = 0;
/* 820 */     while (keys.hasMoreElements())
/*     */     {
/* 822 */       retval[i] = ((String)keys.nextElement());
/* 823 */       i++;
/*     */     }
/*     */     
/* 826 */     return retval;
/*     */   }
/*     */   
/*     */   public void getUsedFields(Hashtable<String, String> fields)
/*     */   {
/* 831 */     if (isAtomic())
/*     */     {
/* 833 */       if (getLeftValuename() != null) fields.put(getLeftValuename(), "-");
/* 834 */       if (getRightValuename() != null) fields.put(getRightValuename(), "-");
/*     */     }
/*     */     else
/*     */     {
/* 838 */       for (int i = 0; i < nrConditions(); i++)
/*     */       {
/* 840 */         Condition subc = getCondition(i);
/* 841 */         subc.getUsedFields(fields);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\Condition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */