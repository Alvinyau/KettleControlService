/*     */ package org.pentaho.di.core.gui;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.core.AddUndoPositionInterface;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SnapAllignDistribute
/*     */ {
/*     */   private List<? extends GUIPositionInterface> elements;
/*     */   private AddUndoPositionInterface addUndoPositionInterface;
/*     */   private int[] indices;
/*     */   private Redrawable redrawable;
/*     */   private UndoInterface undoInterface;
/*     */   
/*     */   public SnapAllignDistribute(UndoInterface undoInterface, List<? extends GUIPositionInterface> elements, int[] indices, AddUndoPositionInterface addUndoPositionInterface, Redrawable redrawable)
/*     */   {
/*  39 */     this.undoInterface = undoInterface;
/*  40 */     this.elements = elements;
/*  41 */     this.indices = indices;
/*  42 */     this.addUndoPositionInterface = addUndoPositionInterface;
/*  43 */     this.redrawable = redrawable;
/*     */   }
/*     */   
/*     */   public void snaptogrid(int size)
/*     */   {
/*  48 */     if (this.elements.isEmpty()) { return;
/*     */     }
/*     */     
/*     */ 
/*  52 */     GUIPositionInterface[] elemArray = new GUIPositionInterface[this.elements.size()];
/*     */     
/*  54 */     Point[] before = new Point[this.elements.size()];
/*  55 */     Point[] after = new Point[this.elements.size()];
/*     */     
/*  57 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/*  59 */       GUIPositionInterface positionInterface = (GUIPositionInterface)this.elements.get(i);
/*     */       
/*  61 */       elemArray[i] = positionInterface;
/*  62 */       Point p = positionInterface.getLocation();
/*  63 */       before[i] = new Point(p.x, p.y);
/*     */       
/*     */ 
/*  66 */       int dx = p.x % size;
/*  67 */       int dy = p.y % size;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */       if (dx > size / 2) {
/*  76 */         p.x += size - dx;
/*     */       } else
/*  78 */         p.x -= dx;
/*  79 */       if (dy > size / 2) {
/*  80 */         p.y += size - dy;
/*     */       } else
/*  82 */         p.y -= dy;
/*  83 */       after[i] = new Point(p.x, p.y);
/*     */     }
/*     */     
/*  86 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/*  87 */     this.redrawable.redraw();
/*     */   }
/*     */   
/*     */   public void allignleft()
/*     */   {
/*  92 */     if (this.elements.isEmpty()) { return;
/*     */     }
/*  94 */     GUIPositionInterface[] elemArray = (GUIPositionInterface[])this.elements.toArray(new GUIPositionInterface[this.elements.size()]);
/*     */     
/*  96 */     Point[] before = new Point[this.elements.size()];
/*  97 */     Point[] after = new Point[this.elements.size()];
/*     */     
/*  99 */     int min = 99999;
/*     */     
/*     */ 
/* 102 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 104 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/* 105 */       Point p = element.getLocation();
/* 106 */       if (p.x < min) { min = p.x;
/*     */       }
/*     */     }
/*     */     
/* 110 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 112 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 114 */       Point p = element.getLocation();
/* 115 */       before[i] = new Point(p.x, p.y);
/* 116 */       element.setLocation(min, p.y);
/* 117 */       after[i] = new Point(min, p.y);
/*     */     }
/*     */     
/* 120 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/* 121 */     this.redrawable.redraw();
/*     */   }
/*     */   
/*     */   public void allignright()
/*     */   {
/* 126 */     if (this.elements.isEmpty()) { return;
/*     */     }
/* 128 */     GUIPositionInterface[] elemArray = (GUIPositionInterface[])this.elements.toArray(new GUIPositionInterface[this.elements.size()]);
/*     */     
/* 130 */     Point[] before = new Point[this.elements.size()];
/* 131 */     Point[] after = new Point[this.elements.size()];
/*     */     
/* 133 */     int max = -99999;
/*     */     
/*     */ 
/* 136 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 138 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 140 */       Point p = element.getLocation();
/* 141 */       if (p.x > max) { max = p.x;
/*     */       }
/*     */     }
/* 144 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 146 */       GUIPositionInterface stepMeta = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 148 */       Point p = stepMeta.getLocation();
/* 149 */       before[i] = new Point(p.x, p.y);
/* 150 */       stepMeta.setLocation(max, p.y);
/* 151 */       after[i] = new Point(max, p.y);
/*     */     }
/*     */     
/* 154 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/* 155 */     this.redrawable.redraw();
/*     */   }
/*     */   
/*     */   public void alligntop()
/*     */   {
/* 160 */     if (this.elements.isEmpty()) { return;
/*     */     }
/* 162 */     GUIPositionInterface[] elemArray = (GUIPositionInterface[])this.elements.toArray(new GUIPositionInterface[this.elements.size()]);
/*     */     
/* 164 */     Point[] before = new Point[this.elements.size()];
/* 165 */     Point[] after = new Point[this.elements.size()];
/*     */     
/* 167 */     int min = 99999;
/*     */     
/*     */ 
/* 170 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 172 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/* 173 */       Point p = element.getLocation();
/* 174 */       if (p.y < min) { min = p.y;
/*     */       }
/*     */     }
/* 177 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 179 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 181 */       Point p = element.getLocation();
/* 182 */       before[i] = new Point(p.x, p.y);
/* 183 */       element.setLocation(p.x, min);
/* 184 */       after[i] = new Point(p.x, min);
/*     */     }
/*     */     
/* 187 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/* 188 */     this.redrawable.redraw();
/*     */   }
/*     */   
/*     */   public void allignbottom()
/*     */   {
/* 193 */     if (this.elements.isEmpty()) { return;
/*     */     }
/* 195 */     GUIPositionInterface[] elemArray = (GUIPositionInterface[])this.elements.toArray(new GUIPositionInterface[this.elements.size()]);
/*     */     
/* 197 */     Point[] before = new Point[this.elements.size()];
/* 198 */     Point[] after = new Point[this.elements.size()];
/*     */     
/* 200 */     int max = -99999;
/*     */     
/*     */ 
/* 203 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 205 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 207 */       Point p = element.getLocation();
/* 208 */       if (p.y > max) { max = p.y;
/*     */       }
/*     */     }
/*     */     
/* 212 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 214 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 216 */       Point p = element.getLocation();
/* 217 */       before[i] = new Point(p.x, p.y);
/* 218 */       element.setLocation(p.x, max);
/* 219 */       after[i] = new Point(p.x, max);
/*     */     }
/*     */     
/* 222 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/* 223 */     this.redrawable.redraw();
/*     */   }
/*     */   
/*     */   public void distributehorizontal()
/*     */   {
/* 228 */     if (this.elements.size() <= 1) { return;
/*     */     }
/* 230 */     GUIPositionInterface[] elemArray = (GUIPositionInterface[])this.elements.toArray(new GUIPositionInterface[this.elements.size()]);
/*     */     
/* 232 */     Point[] before = new Point[this.elements.size()];
/* 233 */     Point[] after = new Point[this.elements.size()];
/*     */     
/* 235 */     int min = 99999;
/* 236 */     int max = -99999;
/*     */     
/* 238 */     int[] order = new int[this.elements.size()];
/*     */     
/*     */ 
/* 241 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 243 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 245 */       Point p = element.getLocation();
/* 246 */       if (p.x < min) min = p.x;
/* 247 */       if (p.x > max) max = p.x;
/* 248 */       order[i] = i;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 256 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 258 */       for (int j = 0; j < this.elements.size() - 1; j++)
/*     */       {
/* 260 */         Point p1 = ((GUIPositionInterface)this.elements.get(order[j])).getLocation();
/* 261 */         Point p2 = ((GUIPositionInterface)this.elements.get(order[(j + 1)])).getLocation();
/* 262 */         if (p1.x > p2.x)
/*     */         {
/* 264 */           int dummy = order[j];
/* 265 */           order[j] = order[(j + 1)];
/* 266 */           order[(j + 1)] = dummy;
/*     */           
/* 268 */           dummy = this.indices[j];
/* 269 */           this.indices[j] = this.indices[(j + 1)];
/* 270 */           this.indices[(j + 1)] = dummy;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 276 */     int distance = (max - min) / (this.elements.size() - 1);
/*     */     
/* 278 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 280 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(order[i]);
/*     */       
/* 282 */       Point p = element.getLocation();
/* 283 */       before[i] = new Point(p.x, p.y);
/* 284 */       p.x = (min + i * distance);
/* 285 */       after[i] = new Point(p.x, p.y);
/* 286 */       elemArray[i] = element;
/*     */     }
/*     */     
/*     */ 
/* 290 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/* 291 */     this.redrawable.redraw();
/*     */   }
/*     */   
/*     */   public void distributevertical()
/*     */   {
/* 296 */     if (this.elements.size() <= 1) { return;
/*     */     }
/* 298 */     GUIPositionInterface[] elemArray = (GUIPositionInterface[])this.elements.toArray(new GUIPositionInterface[this.elements.size()]);
/*     */     
/* 300 */     Point[] before = new Point[this.elements.size()];
/* 301 */     Point[] after = new Point[this.elements.size()];
/*     */     
/* 303 */     int min = 99999;
/* 304 */     int max = -99999;
/*     */     
/* 306 */     int[] order = new int[this.elements.size()];
/*     */     
/*     */ 
/* 309 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 311 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(i);
/*     */       
/* 313 */       Point p = element.getLocation();
/* 314 */       if (p.y < min) min = p.y;
/* 315 */       if (p.y > max) max = p.y;
/* 316 */       order[i] = i;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 324 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 326 */       for (int j = 0; j < this.elements.size() - 1; j++)
/*     */       {
/* 328 */         Point p1 = ((GUIPositionInterface)this.elements.get(order[j])).getLocation();
/* 329 */         Point p2 = ((GUIPositionInterface)this.elements.get(order[(j + 1)])).getLocation();
/* 330 */         if (p1.y > p2.y)
/*     */         {
/* 332 */           int dummy = order[j];
/* 333 */           order[j] = order[(j + 1)];
/* 334 */           order[(j + 1)] = dummy;
/*     */           
/* 336 */           dummy = this.indices[j];
/* 337 */           this.indices[j] = this.indices[(j + 1)];
/* 338 */           this.indices[(j + 1)] = dummy;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 344 */     int distance = (max - min) / (this.elements.size() - 1);
/*     */     
/* 346 */     for (int i = 0; i < this.elements.size(); i++)
/*     */     {
/* 348 */       GUIPositionInterface element = (GUIPositionInterface)this.elements.get(order[i]);
/*     */       
/* 350 */       Point p = element.getLocation();
/* 351 */       before[i] = new Point(p.x, p.y);
/* 352 */       p.y = (min + i * distance);
/* 353 */       after[i] = new Point(p.x, p.y);
/* 354 */       elemArray[i] = element;
/*     */     }
/*     */     
/*     */ 
/* 358 */     if (this.addUndoPositionInterface != null) this.addUndoPositionInterface.addUndoPosition(this.undoInterface, elemArray, this.indices, before, after);
/* 359 */     this.redrawable.redraw();
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\SnapAllignDistribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */