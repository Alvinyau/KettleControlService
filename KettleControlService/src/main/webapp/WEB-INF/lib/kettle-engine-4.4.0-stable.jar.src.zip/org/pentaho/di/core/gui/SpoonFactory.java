/*    */ package org.pentaho.di.core.gui;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpoonFactory
/*    */ {
/*    */   private static SpoonInterface spoonInstance;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static SpoonInterface getInstance()
/*    */   {
/* 30 */     return spoonInstance;
/*    */   }
/*    */   
/*    */   public static void setSpoonInstance(SpoonInterface anInstance) {
/* 34 */     spoonInstance = anInstance;
/*    */   }
/*    */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\gui\SpoonFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */