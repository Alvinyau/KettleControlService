/*     */ package org.pentaho.di.core.plugins;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.pentaho.di.core.annotations.ImportRulePlugin;
/*     */ import org.pentaho.di.core.exception.KettlePluginException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.imp.rule.ImportRuleInterface;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @PluginMainClassType(ImportRuleInterface.class)
/*     */ @PluginAnnotationType(ImportRulePlugin.class)
/*     */ public class ImportRulePluginType
/*     */   extends BasePluginType
/*     */   implements PluginTypeInterface
/*     */ {
/*     */   private static ImportRulePluginType pluginType;
/*     */   
/*     */   private ImportRulePluginType()
/*     */   {
/*  52 */     super(ImportRulePlugin.class, "IMPORT_RULE", "Import rule");
/*  53 */     populateFolders("rules");
/*     */   }
/*     */   
/*     */   public static ImportRulePluginType getInstance() {
/*  57 */     if (pluginType == null) {
/*  58 */       pluginType = new ImportRulePluginType();
/*     */     }
/*  60 */     return pluginType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerNatives()
/*     */     throws KettlePluginException
/*     */   {
/*  69 */     String kettleImportRulesXmlFile = "kettle-import-rules.xml";
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  74 */       InputStream inputStream = getClass().getResourceAsStream(kettleImportRulesXmlFile);
/*  75 */       if (inputStream == null) {
/*  76 */         inputStream = getClass().getResourceAsStream("/" + kettleImportRulesXmlFile);
/*     */       }
/*  78 */       if (inputStream == null) {
/*  79 */         throw new KettlePluginException("Unable to find native import rules definition file: kettle-import-rules.xml");
/*     */       }
/*  81 */       Document document = XMLHandler.loadXMLFile(inputStream, null, true, false);
/*     */       
/*     */ 
/*     */ 
/*  85 */       Node stepsNode = XMLHandler.getSubNode(document, "rules");
/*  86 */       List<Node> stepNodes = XMLHandler.getNodes(stepsNode, "rule");
/*  87 */       for (Node stepNode : stepNodes) {
/*  88 */         registerPluginFromXmlResource(stepNode, null, getClass(), true, null);
/*     */       }
/*     */     }
/*     */     catch (KettleXMLException e) {
/*  92 */       throw new KettlePluginException("Unable to read the kettle steps XML config file: " + kettleImportRulesXmlFile, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void registerAnnotations()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */ 
/*     */   protected void registerXmlPlugins()
/*     */     throws KettlePluginException
/*     */   {}
/*     */   
/*     */ 
/*     */   protected String extractCategory(Annotation annotation)
/*     */   {
/* 110 */     return "";
/*     */   }
/*     */   
/*     */   protected String extractDesc(Annotation annotation)
/*     */   {
/* 115 */     return ((ImportRulePlugin)annotation).description();
/*     */   }
/*     */   
/*     */   protected String extractID(Annotation annotation)
/*     */   {
/* 120 */     return ((ImportRulePlugin)annotation).id();
/*     */   }
/*     */   
/*     */   protected String extractName(Annotation annotation)
/*     */   {
/* 125 */     return ((ImportRulePlugin)annotation).name();
/*     */   }
/*     */   
/*     */   protected String extractImageFile(Annotation annotation)
/*     */   {
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   protected boolean extractSeparateClassLoader(Annotation annotation)
/*     */   {
/* 135 */     return false;
/*     */   }
/*     */   
/*     */   protected String extractI18nPackageName(Annotation annotation)
/*     */   {
/* 140 */     return ((ImportRulePlugin)annotation).i18nPackageName();
/*     */   }
/*     */   
/*     */   protected void addExtraClasses(Map<Class<?>, String> classMap, Class<?> clazz, Annotation annotation) {}
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\core\plugins\ImportRulePluginType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */