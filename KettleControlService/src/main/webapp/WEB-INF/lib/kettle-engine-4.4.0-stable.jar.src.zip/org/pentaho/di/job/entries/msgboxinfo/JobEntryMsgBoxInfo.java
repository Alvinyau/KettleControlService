/*     */ package org.pentaho.di.job.entries.msgboxinfo;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.pentaho.di.cluster.SlaveServer;
/*     */ import org.pentaho.di.core.CheckResultInterface;
/*     */ import org.pentaho.di.core.Const;
/*     */ import org.pentaho.di.core.Result;
/*     */ import org.pentaho.di.core.database.DatabaseMeta;
/*     */ import org.pentaho.di.core.exception.KettleDatabaseException;
/*     */ import org.pentaho.di.core.exception.KettleException;
/*     */ import org.pentaho.di.core.exception.KettleXMLException;
/*     */ import org.pentaho.di.core.gui.GUIFactory;
/*     */ import org.pentaho.di.core.gui.ThreadDialogs;
/*     */ import org.pentaho.di.core.xml.XMLHandler;
/*     */ import org.pentaho.di.job.JobMeta;
/*     */ import org.pentaho.di.job.entry.JobEntryBase;
/*     */ import org.pentaho.di.job.entry.JobEntryInterface;
/*     */ import org.pentaho.di.job.entry.validator.JobEntryValidatorUtils;
/*     */ import org.pentaho.di.repository.ObjectId;
/*     */ import org.pentaho.di.repository.Repository;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobEntryMsgBoxInfo
/*     */   extends JobEntryBase
/*     */   implements Cloneable, JobEntryInterface
/*     */ {
/*     */   private String bodymessage;
/*     */   private String titremessage;
/*     */   
/*     */   public JobEntryMsgBoxInfo(String n, String scr)
/*     */   {
/*  61 */     super(n, "");
/*  62 */     this.bodymessage = null;
/*  63 */     this.titremessage = null;
/*     */   }
/*     */   
/*     */   public JobEntryMsgBoxInfo()
/*     */   {
/*  68 */     this("", "");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*  73 */     JobEntryMsgBoxInfo je = (JobEntryMsgBoxInfo)super.clone();
/*  74 */     return je;
/*     */   }
/*     */   
/*     */   public String getXML()
/*     */   {
/*  79 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  81 */     retval.append(super.getXML());
/*  82 */     retval.append("      ").append(XMLHandler.addTagValue("bodymessage", this.bodymessage));
/*  83 */     retval.append("      ").append(XMLHandler.addTagValue("titremessage", this.titremessage));
/*     */     
/*     */ 
/*  86 */     return retval.toString();
/*     */   }
/*     */   
/*     */   public void loadXML(Node entrynode, List<DatabaseMeta> databases, List<SlaveServer> slaveServers, Repository rep)
/*     */     throws KettleXMLException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       super.loadXML(entrynode, databases, slaveServers);
/*  95 */       this.bodymessage = XMLHandler.getTagValue(entrynode, "bodymessage");
/*  96 */       this.titremessage = XMLHandler.getTagValue(entrynode, "titremessage");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 100 */       throw new KettleXMLException("Unable to load job entry of type 'Msgbox Info' from XML node", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadRep(Repository rep, ObjectId id_jobentry, List<DatabaseMeta> databases, List<SlaveServer> slaveServers)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 109 */       this.bodymessage = rep.getJobEntryAttributeString(id_jobentry, "bodymessage");
/* 110 */       this.titremessage = rep.getJobEntryAttributeString(id_jobentry, "titremessage");
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 114 */       throw new KettleException("Unable to load job entry of type 'Msgbox Info' from the repository with id_jobentry=" + id_jobentry, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void saveRep(Repository rep, ObjectId id_job)
/*     */     throws KettleException
/*     */   {
/*     */     try
/*     */     {
/* 124 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "bodymessage", this.bodymessage);
/* 125 */       rep.saveJobEntryAttribute(id_job, getObjectId(), "titremessage", this.titremessage);
/*     */     }
/*     */     catch (KettleDatabaseException dbe)
/*     */     {
/* 129 */       throw new KettleException("Unable to save job entry of type 'Msgbox Info' to the repository for id_job=" + id_job, dbe);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean evaluate(Result result)
/*     */   {
/*     */     try
/*     */     {
/* 144 */       boolean response = true;
/*     */       
/* 146 */       ThreadDialogs dialogs = GUIFactory.getThreadDialogs();
/* 147 */       if (dialogs != null) {}
/* 148 */       return dialogs.threadMessageBox(getRealBodyMessage() + Const.CR, getRealTitleMessage(), true, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 158 */       result.setNrErrors(1L);
/* 159 */       logError("Couldn't display message box: " + e.toString()); }
/* 160 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result execute(Result prev_result, int nr)
/*     */   {
/* 174 */     prev_result.setResult(evaluate(prev_result));
/* 175 */     return prev_result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean resetErrorsBeforeExecution()
/*     */   {
/* 182 */     return false;
/*     */   }
/*     */   
/*     */   public boolean evaluates()
/*     */   {
/* 187 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnconditional()
/*     */   {
/* 192 */     return false;
/*     */   }
/*     */   
/*     */   public String getRealTitleMessage()
/*     */   {
/* 197 */     return environmentSubstitute(getTitleMessage());
/*     */   }
/*     */   
/*     */   public String getRealBodyMessage()
/*     */   {
/* 202 */     return environmentSubstitute(getBodyMessage());
/*     */   }
/*     */   
/*     */   public String getTitleMessage()
/*     */   {
/* 207 */     if (this.titremessage == null)
/*     */     {
/* 209 */       this.titremessage = "";
/*     */     }
/* 211 */     return this.titremessage;
/*     */   }
/*     */   
/*     */   public String getBodyMessage() {
/* 215 */     if (this.bodymessage == null)
/*     */     {
/* 217 */       this.bodymessage = "";
/*     */     }
/* 219 */     return this.bodymessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBodyMessage(String s)
/*     */   {
/* 227 */     this.bodymessage = s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTitleMessage(String s)
/*     */   {
/* 234 */     this.titremessage = s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void check(List<CheckResultInterface> remarks, JobMeta jobMeta)
/*     */   {
/* 241 */     JobEntryValidatorUtils.addOkRemark(this, "bodyMessage", remarks);
/* 242 */     JobEntryValidatorUtils.addOkRemark(this, "titleMessage", remarks);
/*     */   }
/*     */ }


/* Location:              G:\kettle-engine-4.4.0-stable.jar!\org\pentaho\di\job\entries\msgboxinfo\JobEntryMsgBoxInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */